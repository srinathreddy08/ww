export interface IParticipant {
    Configuration: any;
}