export interface IJavascriptRuleModel {
  definition: string,
  attributes: Object,
}
