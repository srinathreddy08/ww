export interface IEmployeePlanModel {
  AssociationCostType: string;
  CarrierID: string;
  ContentAlias: string;
  DisplayOrder: number;
  ElectedOption: EmployeePlanOptionModel;
  EligibleOptions: EmployeePlanOptionModel[];
  IsNoCovPlan: boolean;
  NetworkID: string;
  PlanCompareContentAlias: string;
  PlanID: string;
  PlanYearDefBeneRequirement: string;
  PlanYearDefDesc1: string;
  PlanYearDefPCPRequirement: string;
  PlanYearDefPcpType: string;
  Type: number;
  IsElected?: boolean;
  GroupID?: string;
  MemberID?: string;
  IncrementAmount?: number;
}

export interface EmployeePlanOptionModel {
  AdministrativeCostAnnual: number;
  AdministrativeCostMonthly: number;
  Amount5: number;
  AmountElected: number;
  AmountInforce: number;
  AmountPended: number;
  AutoElections: unknown[];
  BenefitEffectiveDate: Date;
  ContentAlias: string;
  DependentAssociations: IDependentAssociationData[];
  DisplayOrder: number;
  EEPayPeriodCostInforce: number;
  EOIPendingStatus: string;
  EmployeeAnnualCost: number;
  EmployeePayPeriodCost: number;
  EmployerAnnualCost: number;
  EmployerPayPeriodCost: number;
  IsCoreBenefit: boolean;
  IsElected: boolean;
  IsPreTax: boolean;
  MaximumElectAmount: number;
  MinimumElectAmount: number;
  OptionID: string;
  OptionYearDefDescr1: string;
  PendedEmployeeAnnualCost: number;
  PendedEmployeePayPeriodCost: number;
  PremiumAnnual: number;
  PremiumMonthly: number;
  PrimaryCarePhysicians: {};
  Status: string;
  VerifiedAnnualCost: number;
  VerifiedOptionID: string;
  VerifiedPPCost: number;
  YearToDateContributions: string;
  YearToDateReconciledContributions: string;
}

export interface IDependentAssociationData {
  AmountElected: number;
  BenefitEffectiveDate: string;
  ChangeIndicator: string;
  CoverageEffectiveDate: string;
  DateElected: string;
  DateTerminated: Date | string | null;
  DependentElectedIndicator: string | null;
  DependentSsn: string;
  EffectiveEndDate: null | string;
  ElectionEffectiveDate: string;
  PercentElected: null | string;
}
