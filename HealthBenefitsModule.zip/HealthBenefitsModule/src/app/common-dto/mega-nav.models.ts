import { ContentRaw } from './content-wrapper';

export interface IMegaNavData {
  Navigation: {
    Footer: IMegaNavNavigationItem;
    MegaNav: IMegaNavNavigationItem;
  };
  AccountNavigation?: IMegaNavUiNavigationItem[];
  VbNavigation?: IMegaNavUiNavigationItem[];
  DocuploadNavigation?: IMegaNavUiNavigationItem[];
}

export interface IMegaNavUiNavigationItem {
  Key: string;
  IsEnabled: boolean;
  Name: string;
  Url: string;
  DisplayOrder: number;
  SubNav?: IMegaNavUiNavigationItem[];
}

export interface IMegaNavNavigationItem {
  Id: string;
  MenuType: string;
  ContentAlias: string;
  RowOrder?: number;
  ColumnOrder?: number;
  DisplayOrder: number;
  NavLevel: number;
  DisplayInProxyMode: number;
  Items?: IMegaNavNavigationItem[];
  SourceFromDomain: boolean;
  ExpandItems: boolean;
  Ignore: boolean;
  IgnoreChildren: boolean;
}

export enum DisplayInProxyMode {
  NoProxyAccess = 0,
  ReadOnlyProxyAccess = 1,
  ReadWriteProxyAccess = 2
}

export interface IMegaNav extends ContentRaw<IMegaNavData, Record<string, any>> {
}
