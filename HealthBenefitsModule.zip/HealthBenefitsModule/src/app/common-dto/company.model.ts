export interface ICompanyModel {
  BenefitsUsingTobaccoCost: number;
  BrokerageID: number;
  BrokerageType: string;
  CallCenterFlag: number;
  CompanyID: string;
  CompanyName: string;
  CompanyOneCode: string;
  CompanyPlanYearQuestions: ICompanyPlanYearQuestions[];
  CompanyType: string;
  ContribType: string;
  CurrentYearBeginDayOfMonth: number;
  CurrentYearBeginMonth: number;
  CurrentYearEndDayOfMonth: number;
  CurrentYearEndMonth: number;
  DPFlag: number;
  EGroupID: string;
  EligFactor4: string;
  EligFactor5: string;
  EnrollmentMode: string;
  Environment: string;
  GlogFlag: number;
  HSALimit1: number;
  HSALimit2: number;
  HSALimit3: number;
  HSALimit4: number;
  HealthAdvocateFlag: number;
  HealthAdvocateOption: string;
  HsaEmployerContribStrategy: string;
  IsAssociation: boolean;
  IsSmallMarketClient: boolean;
  NextPlanYear: string;
  NextYearBeginDate: Date;
  NextYearBeginDayOfMonth: number;
  NextYearBeginMonth: number;
  NextYearEndDate: Date;
  NextYearEndDayOfMonth: number;
  NextYearEndMonth: number;
  OngoingStartDate: Date;
  PerkspotFlag: number;
  PlanYear: number;
  RuleForEmpInitiatedEvents: string;
  LifeEventRules: Record<number, Record<string, string>>;
  PlanYears: IPlanYearData[];
  SitusState: string;
  Tier: number;
  UserRole: string;
  YearBeginDate: Date;
  YearEndDate: Date;
  DepEligVerificationType: string;
  LifeEventVerificationType: string;
  BenefitsWithVerificationEnabled: string;
  LifeEventsWithVerificationEnabled: string;
}

export interface ICompanyPlanYearQuestions {
  Answer: 'Yes' | 'No';
  BenefitId: string;
  Seq: number;
}

export interface IPlanYearData {
  PlanYear: number;
  StartDate: Date;
  EndDate: Date;
}
