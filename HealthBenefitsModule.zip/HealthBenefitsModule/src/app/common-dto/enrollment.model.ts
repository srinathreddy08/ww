import { ContentRaw, ContentWrapper } from './content-wrapper';
import { EmployeeModel } from './employee.model';
import { IPlansCompareModel } from './plan-compare.model';

export interface IEnrollmentData {
  PendingEmployee: EmployeeModel;
  PendingLEVEmployee: EmployeeModel;
  CurrentCoveragesEmployee: EmployeeModel;
  FutureCoverages: EmployeeModel[];
  PlanCompares: IPlansCompareModel[];
}

export enum LifeEventPathMode {
  expertGuidance = '0',
  chooseYourOwn = '1',
  userChoice = '2'
}

export enum LifeEventUIMode {
  linear = 'L',
  jumpAround = 'J'
}

export interface IEnrollment extends ContentRaw<IEnrollmentData, Record<string, any>> {
}

export type EnrollmentContent = ContentWrapper<IEnrollmentData, Record<string, any>>;
