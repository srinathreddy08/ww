export enum LifeEventCategory {
    OPEN_ENROLLMENT = 'OE'
}