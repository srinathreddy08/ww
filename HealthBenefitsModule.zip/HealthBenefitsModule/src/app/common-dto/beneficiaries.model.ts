import { IEnrollment, IEnrollmentData } from "src/app/common-dto/enrollment.model";
import { KeyValuePair } from "src/app/common-dto/key-value-pair";
import { EmployeeAddress } from "src/app/common-dto/employee.model";
import { IBeneficiaryData } from "./shopping-cart.model";

export interface IBeneficiariesSection {
  Title: string;
  SectionOrderId: number;
  NodeName: string;
  LobName: string;
  Data: { employeeData: IEnrollment; };
  ContentData: IBeneficiariesContentData;
  Plans: IBeneficiariesPlan[];
}

export interface IBeneficiariesContentData {
  BeneficiaryContent: {
    data: IEnrollmentData;
    contentSource: IEnrollment;
  };
  RelationshipsHash: Record<string, string>;
  Relationships: KeyValuePair<string, string>[];
  NoBeneficiaryOnFile: string;
  AcceptanceText: string;
  SignatureTitle: string;
  BeneAllocationValidation: string;
}

export interface IBeneficiariesPlan {
  PlanName: string;
  Id: string;
  BenefitID: string;
  Beneficiaries: Record<string, IBeneficiary>;
  Designations: {
    Primary: IBeneficiaryDesignation[];
    Secondary: IBeneficiaryDesignation[];
  };
  HasDesignations: boolean;
  EmployeeAddress: EmployeeAddress;
  PersonalInfoViewLocation: string;
  OnlineSignatureViewLocation: string;
  ShouldDisableBeneficiaryFields: boolean;
  IsSecondaryAvailable: boolean;
  ViewOnly: boolean;
  CheckDuplicateForExistingBeneficiary: boolean;
}

export class IBeneficiary {
  Id: string;
  Name: string;
  Relationship: string;
  ControlId?: string;
  DateChanged?: string;
  BeneficiarySsn: string;
  BirthDate: string;
  Sex: string;
  Address1: string;
  Address2: string;
  City: string;
  State: string;
  Zip: string;
  Country: string;
  County: string;
  IsDependent: boolean;
  IsEmployee: boolean;
  Status?: string;
  Phone?: string;
  Email?: string;
}

export interface IBeneficiaryDesignation {
  Id: string;
  Name: string;
  Relationship: string;
  SequenceNumber: number;
  ControlId: string;
  EffectiveDate: string;
  BenefitId: string;
  PlanId: string;
  IsSecondary: boolean;
  Percentage: number;
  AbsoluteAssigned: boolean;
  DisplayOrder: number;
}

export interface IBeneficiariesPlanModel {
  planName: string;
  benefitId: string;
  beneficiaries: Array<IBeneficiary>;
  designations: {
    primary: IBeneficiaryDesignation[];
    secondary: IBeneficiaryDesignation[];
  };
  hasDesignations: boolean;
}

export interface ISaveBeneficiariesOutsideLeRequestObject {
  Beneficiaries: Record<string, IBeneficiary>;
  Designations: Record<string, IBeneficiaryDesignation[]>;
  LifeEventDate: string;
}
