export enum OeStates {
    /**
     * 1: Hasn't done anything yet this oe event
     * - leStatusDate < oeStartDate && cart == null
     * - fallback to pending employee > elected option > elected plan
     */
    HASN_T_DONE_ANYTHING_YET_THIS_OE_EVENT = '1',
    /**
     * 2: Has an active session
     * - cart != null
     */
    HAS_AN_ACTIVE_SESSION = '2', //(ENROLL NOW)
    /**
     * 3: Has saved at least once, but does not have an active session
     * - leStatusDate >= oeStartDate && cart == null
     * - fallback to pending employee > elected option > elected plan
     */
    SAVED_AT_LEAST_ONCE_BUT_DOESN_T_HAVE_AN_ACTIVE_SESSION = '3',
    /**
     * 4: Not in oe event
     * - days left == 0
     * - go future coverages
     */
    NOT_IN_OE_EVENT = '4' //(EDIT ELECTIONS)
}