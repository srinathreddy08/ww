export interface NavigationStatusItem {
  IsAvailable: boolean;
  IsEnabled: boolean;
  VisitID: string;
  IsShoppingCartLoaded: boolean;
  SubNav: Record<string, NavigationStatusItem>;
}

export interface NavigationLifeEventResponse {
  LifeEventId: string;
  LifeEventDate: string;
  NavigationStatus: {
    "get-started": NavigationStatusItem,
    "choose-benefits": NavigationStatusItem,
    "supplemental-benefits": NavigationStatusItem,
    "voluntary-benefits": NavigationStatusItem,
    "cart": NavigationStatusItem
  };
  CategoryOrder: {
    SPENDING: number;
    PROTECTION: number;
    DISABILITY: number;
    MEDICAL: number;
    ACCRUAL: number;
    LIFEINSURANCE: number;
    VISION: number;
    O65MED: number;
    SUPPLEMENTAL: number;
    DENTAL: number;
    ADDITIONAL: number;
    U65MED: number;
  };
  NavKeysToCategories: {
    "medical": "MEDICAL",
    "medical-under65": "U65MED",
    "medical-over65": "O65MED",
    "dental": "DENTAL",
    "vision": "VISION",
    "accounts": "SPENDING",
    "life-insurance": "LIFE INSURANCE",
    "additional-benefits": "ADDITIONAL",
    "disability-insurance": "DISABILITY",
    "protection": "PROTECTION"
  };
}
