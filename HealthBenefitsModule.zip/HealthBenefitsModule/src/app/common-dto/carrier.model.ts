import { YNBool } from './general.types';

export interface CarrierModel {
  BankingNo: string;
  CarrierActiveInd: YNBool;
  CarrierAlias: string;
  CarrierId: string;
  CarrierLongDesc: string;
  CarrierShortDesc: string;
  ClaimsAddress: string;
  ClaimsCity: string;
  ClaimsState: string;
  ClaimsZip: string;
  ControlId: string;
  ContentAlias: string;
  EffDate: Date;
  FaxNo: string;
  FtpSite: string;
  GrpNumber: string;
  InternetAdress: string;
  NpiNo: string;
  ProvDesc: string;
  TaxId: string;
  Telephone: string;
  TermDate: string;
  TransferMethod: string;
  TransmitTel: string;
  WireAddress: string;
}
