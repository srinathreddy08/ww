import { YNBool, BinBool } from './general.types';
import { ContentRaw, ContentWrapper } from './content-wrapper';

interface ParticipantContentData {
    DBParticipantEligibilityStatus: YNBool;
    DCParticipantEligibilityStatus: YNBool;
    HasCompletedWelcomeProfile: boolean;
    HasAcceptedTermsAndConditions: boolean;
    HBParticipantEligibilityStatus: YNBool;
    ParticipantLanguagePreference: 'en' | string;
    DBLegacyParticipantEligibilityStatus: YNBool;
    ContinueOnDomainOutage: boolean;
    ProxyAccess: {
        DBProxyAccess: any
    }
}

interface ParticipantContentConfiguration {
    'Portal.Participant.ClientHasOutsideBalances': BinBool;
    'Portal.HB.IsDomainInOutage': BinBool;
    'Portal.HB.IsDomainInOutageForClient': BinBool;
    'Portal.Participant.AvailableLanguageList': string;
    'Portal.Participant.ChatIconPlacement': string;
    'Portal.SuppressEditLinks': string;
    'Portal.DC.IsDomainInOutage': BinBool;
    'Portal.Participant.IsChatAvailable':BinBool;
    'Portal.Participant.BYPShowCommPrefs':BinBool;
    'Portal.Participant.BYPShowPersonalization': BinBool;
    'Portal.Participant.IsCognosReportsAccessAllowed': BinBool;
    'Portal.Participant.ChatSpecialRouting': string;
    'Portal.DB.IsDomainInOutage': BinBool;
    'Portal.DC.IsDomainInOutageForClient': BinBool;
    'Portal.Participant.ProactiveChat': {
        PROACTIVE_IND: BinBool
    };
    'Portal.Participant.HighContrastDefaultBehavior': BinBool;
    'Portal.Participant.ShowHighContrastButton': BinBool;
    'Portal.Participant.SuppressContactUs':BinBool;
    'Portal.Participant.ChatProviderParameters': {
        CLIENT_ID: string;
        APP_ID: string;
        PROVIDER: string;
    };
    'Portal.Participant.ProxyAccessLevel': BinBool;
    'Portal.Participant.EnableTermsConditions':BinBool;
    'Portal.DB.IsDomainInOutageForClient': BinBool;
    'Portal.Participant.ShowWelcomeFlow':BinBool
}

export type ParticipantContentRaw = ContentRaw<ParticipantContentData, ParticipantContentConfiguration>;
export type ParticipantContent = ContentWrapper<ParticipantContentData, ParticipantContentConfiguration>;
