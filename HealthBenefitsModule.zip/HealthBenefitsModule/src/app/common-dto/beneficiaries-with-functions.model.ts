import { IBeneficiariesPlan, IBeneficiaryDesignation } from "src/app/common-dto/beneficiaries.model";


export interface IBeneficiariesPlanWithFunctions extends IBeneficiariesPlan {
  //---------------------------------------------------------------------------------//
  //--- functions added by .factory('getBeneficiariesSectionsFromPendingEmployee' ---//
  //---------------------------------------------------------------------------------//

  // hbBeneficiaryPlansService - addNewDesignation(beneficiary, isSecondary)
  AddNewDesignation(beneficiary, isSecondary): IBeneficiaryDesignationWithFunctions;

  // beneficiaryService - asyncValidateSsnDuplication(beneficiarySsn, originalBeneficiarySsn, isTrust)
  AsyncSsnValidation(beneficiarySsn, originalBeneficiarySsn, isTrust): any;

  // beneficiaryService - asyncValidateSsnDuplication(beneficiarySsn, originalBeneficiarySsn, isTrust)
  AsyncSsnValidationForLe(beneficiarySsn, originalBeneficiarySsn, isTrust): any;

  // hbBeneficiaryPlansService - checkDisableToggle(disableToggle)
  CheckDisableToggle(disableToggle): any;

  // hbBeneficiaryPlansService - clone()
  Clone(): any;

  // hbBeneficiaryPlansService - getBeneficiaryValidationErrors()
  GetBeneficiaryValidationErrors(): any;

  // hbBeneficiaryPlansService - getDefaultBeneficiariesTypes()
  GetDefaultBeneficiariesTypes(): any;

  // hbBeneficiaryPlansService - getDefaultBeneficiary(beneficiaryFormType)
  GetDefaultBeneficiary(beneficiaryFormType): any;

  // hbBeneficiaryPlansService - getDuplicateFields(beneficiary)
  GetDuplicateFields(beneficiary): any;

  // hbBeneficiaryPlansService - getDuplicateValidationResult(beneficiary, originalBeneficiary)
  GetDuplicateValidationResult(beneficiary, originalBeneficiary): any;

  // hbBeneficiaryPlansService - getEmptyDesignation(beneficiary, isSecondary)
  GetEmptyDesignation(beneficiary, isSecondary): any;

  // hbBeneficiaryPlansService - saveChanges()
  Save(): Promise<any>;

  // hbBeneficiaryPlansService - getDesignatedBeneficiary(beneficiary, designations)
  getDesignatedBeneficiary(beneficiary, designations): any;


  //------------------------------------------------------------//
  //--- functions added by .factory('loadBeneficiariesModel' ---//
  //------------------------------------------------------------//

  apply(): any;

  beginAddMode(): void;

  endAddMode(): void;

  createDesignation: {
    // createIndividualDesignation()
    individual(): IBeneficiaryDesignationWithFunctions;

    // createTrustDesignation()
    trust(): IBeneficiaryDesignationWithFunctions;

    // createDesignationFromBeneficiary(beneficiary)
    fromBeneficiary(beneficiary): IBeneficiaryDesignationWithFunctions;
  };

  getDesignatedBeneficiary(beneficiary, designations): any;

  getFlatDesignations(): any;

  getModel(): any;

  getPlanErrors(): any;

  // isPlanAddMode()
  isAddMode(): boolean;

  // isPlanChanged()
  isChanged(): boolean;

  isDisabled(): boolean;

  // isPlanEditMode()
  isEditMode(): boolean;

  // isPlanValid()
  isValid(): boolean;

  showAddOverlay(callback): void;
}

export interface IBeneficiaryDesignationWithFunctions extends IBeneficiaryDesignation {
  //------------------------------------------------------------//
  //--- functions added by .factory('loadBeneficiariesModel' ---//
  //------------------------------------------------------------//

  actions: {
    edit: {
      // doEdit()
      do(): void;

      // isEditDisabled()
      isDisabled(): boolean;

      // isEditVisible()
      isVisible(): boolean;
    };
    save: {
      // doSave()
      do(): void;

      // isSaveDisabled()
      isDisabled(): boolean;

      // isSaveVisible()
      isVisible(): boolean;
    };
    remove: {
      // doRemove()
      do(): void;

      // isRemoveDisabled()
      isDisabled(): boolean;

      // isRemoveVisible()
      isVisible(): boolean;
    };
  };

  asyncSsnValidation(): any;

  getAvatarLetters(): string;

  getBeneficiary(): any;

  getExistingSsns(): string;

  // getModelFromDesignation()
  getModel(): any;

  getPlan(): any;

  getPriorityOptions(): any;

  // isDesignationEditMode()
  isEditMode(): boolean;

  // isDesignationValid()
  isValid(): boolean;

  isViewMode(): boolean;

  relationshipChanged(val): void;

  setValidFromForm(isValidFromForm): void;

  toggleSameAddress(): void;
}
