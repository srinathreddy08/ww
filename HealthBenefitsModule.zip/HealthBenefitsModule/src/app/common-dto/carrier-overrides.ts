import { Image } from './image';

export interface CarrierNameOverride {
  [carrierId: string]: {
    BenefitCategories: string[];
    CarrierLogo: Image;
    LongName: string;
    ShortName: string;
  }
}

export interface CarrierLinkOverride {
  planYear: number;
  carrierID: string;
  link: string;
}
