import { IBenefitModel } from './benefit.model';
import { CarrierModel } from './carrier.model';
import { YNBool } from './general.types';

export interface IEmployeeLifeEventModel {
  BestMatch: string;
  Carriers: Record<string, CarrierModel>;
  ControlID: string;
  DateEntered: string; // in US date format mm/dd/yyyy
  DaysLeftToEnroll: number;
  EffectiveDate: string; // in US date format mm/dd/yyyy
  ElectionPath: string;
  EligibleBenefits: IBenefitModel[];
  GuidedShoppingEnabled: YNBool;
  IsModel: YNBool;
  IsOpenEnrollment: boolean;
  IsRecalcNeeded: boolean;
  LifeEventCategory: string;
  LifeEventDate: string; // in US date format mm/dd/yyyy
  LifeEventID: string;
  LifeEventSequenceNumber: number;
  LifeEventStatus: string;
  LifeEventStatusDate: string; // in US date format mm/dd/yyyy
  PlanYear: number;
  LifeEventVerificationStatus: string;
  LifeEventVerificationStatusDate: string;
}
