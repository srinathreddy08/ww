interface IConfigurator {
    [key: string]: string
}

interface RowContent {
    Body: string;
    Icon: string;
}

interface Rows {
    Rows: RowContent[];
    Title: string;
    Body?: string;
    IconType?: string;
    Link?: any
}

interface ContentData {
    Rows?: Rows,
    Title: string
}

export interface TilesLifeEventDto {
    Configuration: IConfigurator;
    Content: Map<string, string | ContentData>;
    ContentAliases: Map<string, string>;
    JavascriptRules: {}
}

export interface getTilesLifeEventData {
    ContentAliases: Map<string, string> | null;
    Content: Map<string, string | ContentData> | null;
}
