import { IEnrollment } from './enrollment.model';
import { Static } from './static';
import { ParticipantContentRaw } from './participant.content';
import { LifeEventAction } from '@my-account/life-event-page/dto/lifeEventAction.model';
import { Client } from './client';
import { GetProfileContentRaw } from './profile/get-profile.content';
import { ILanguagePreference } from './language.model';
import { IMegaNav } from './mega-nav.models';

export class FirstTimeConfigDto {
  Static: Static;
  Enrollment: IEnrollment;
  Participant: ParticipantContentRaw;
  IsImpersonation: boolean;
  IsProxySimulation: boolean;
  EmployeeLifeEventActions: LifeEventAction[];
  Client: Client;
  Profile: GetProfileContentRaw;
  LanguagePreference: ILanguagePreference;
  DisplayCosts: boolean;
  MegaNav: IMegaNav;
}
