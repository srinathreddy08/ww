interface IContentAliasesData {
    [key: string]: string;
}

interface BenefitsLinkContent {
    Text: string;
    LinkType: string;
    Url: string;
    Title: string;
    Target: string;
    Class: string;
    id: number | null | string;
    IconType: string | null;
}

interface BenefitsLink {
    Link: BenefitsLinkContent
}

interface OpenEnrollmentHealthEnrollmentStatusMessage {
    Title: string;
    Body: string;
    ButtonText: string;
}

interface OpenEnrollmentHealthSummaryOverviewPageTitle {
    Title: string;
    PageTitle: string
}

interface OpenEnrollmentHealthSummaryOverviewWhatToDoHere {
    Copy: string;
    Link1: string;
    Link2: string;
}

interface ContentData {
    [key: string]:
    OpenEnrollmentHealthEnrollmentStatusMessage
    | BenefitsLink
    | OpenEnrollmentHealthSummaryOverviewPageTitle
    | OpenEnrollmentHealthSummaryOverviewWhatToDoHere
}

export class TilesOeDto {
    Configurator: {} | null;
    Content: ContentData | null;
    ContentAliases: IContentAliasesData | null;
    JavascriptRules: {} | null;
}
