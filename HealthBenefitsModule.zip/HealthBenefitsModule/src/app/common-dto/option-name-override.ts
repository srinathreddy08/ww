export interface OptionNameOverride {
  [benefitId: string]: {
    [optionId: string]: string
  }
}
