export interface ILifeEventRequestData {
  LifeEventDate: string;
  LifeEventId: string;
  LifeEventSeqNo: number;
}
