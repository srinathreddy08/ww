export interface IPlansComparePlanYearCategoryItem {
  Name: string;
  Header: string;
  Combined: string;
  InNetwork: string;
  OutNetwork: string;
}

export interface IPlansComparePlanYearCategory {
  Header: string;
  DisplayOrder: number;
  Items: IPlansComparePlanYearCategoryItem[];
}

export interface IPlansComparePlanYear {
  Year: number;
  Categories: IPlansComparePlanYearCategory[];
}

export interface IPlansComparePlan {
  PlanId: string;
  Years: IPlansComparePlanYear[];
}

export interface IPlansCompareModel {
  BenefitId: string;
  Plans: IPlansComparePlan[];
}
