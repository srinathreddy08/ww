import { Image } from './image';

export interface BenefitNameOverrideEp {
  [key: string]: {
    CONTENT_ALIAS: string;
    'HB.LIFEEVENT.BENEFITNAMEOVERRIDE': string;
  }
}

export interface BenefitNameOverride {
  BenefitLogo: Image;
  LongName: string;
  ShortName: string;
}
