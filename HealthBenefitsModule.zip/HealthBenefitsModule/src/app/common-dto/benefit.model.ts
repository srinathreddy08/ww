import { IEmployeePlanModel } from './employee-plan.model';

export interface IBenefitModel {
  BeneFlexYearBenefitTypeInd: string;
  BeneFlexYearDescr: string;
  BenefitCategory: string;
  BenefitGroupingID: string;
  BenefitID: string;
  BenefitType: string;
  Content: IContent;
  ContentAlias: string;
  DisplayOrder: number;
  ElectedPlan: IEmployeePlanModel;
  EligiblePlans: IEmployeePlanModel[];
  IsAmountType: boolean;
  IsChangeable: boolean;
  IsCoreBenefit: boolean;
  IsElected: boolean;
  IsInterested: boolean;
  IsNZ: boolean;
  VoluntaryBenefitType: string;
  YearToDateContributions: string;
  YearToDateReconciledContributions: string;
}
export interface IContent {
  Alias: string;
  ShortName: string;
}
export interface ICoverageAsEmployee {
  BenefitId: string;
  PlanId: string;
  OptionId: string;
}
