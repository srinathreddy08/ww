export interface IQuestionnaire {
  [key: string]: {
    Answers: Record<string, IQuestionnaireAnswer>
    Type: string;
  }
}

export interface IQuestionnaireAnswer {
  IsReadOnly: boolean;
  Value: string;
  SubValue: string;
}
