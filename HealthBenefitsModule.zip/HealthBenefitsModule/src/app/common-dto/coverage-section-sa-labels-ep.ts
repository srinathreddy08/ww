export interface CoverageSectionSaLabelsEp {
  [key: string]: {
    CONTENT_ALIAS: string;
    CARD: string;
  }
}

export interface CoverageSectionSaLabels {
  Title1: string;
  Title2: string;
  Title3: string;
}
