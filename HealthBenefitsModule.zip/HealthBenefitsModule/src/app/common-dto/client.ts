import { ContentRaw } from './content-wrapper';

export interface Client extends ContentRaw<Record<string, any>, Record<string, any>> {
}
