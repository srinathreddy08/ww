import { formatDate } from '@angular/common';
import { isPlainObject } from 'lodash';

import {
  GetProfileContentRaw,
  ProfileAddressRaw,
  ProfileConfigItemRaw,
  ProfileContentConfiguration,
  ProfileContentData,
} from './get-profile.content';
import { ProfileFieldlengthsModel } from './profile-fieldlengths.model';
import { YNBool } from '../general.types';
import { IStaticContent } from '../static';
import { endsWith } from '../../utils/string.utils';

interface ProfileParserConfigItem {
  configurationKey?: string;
  maxLength?: number;
}

const profileParserConfig: Record<keyof ProfileContentData, ProfileParserConfigItem> = {
  FirstName: { configurationKey: 'PARTFIRSTNAME', maxLength: 30 },
  LastName: { configurationKey: 'PARTLASTNAME', maxLength: 30 },
  MiddleName: { configurationKey: 'PARTMIDDLEINITIAL', maxLength: 1 },
  DOB: { configurationKey: 'DOB' },
  DateOfDeath: { configurationKey: 'DEATHDATE' },
  Ssn: { configurationKey: 'PARTSSN', maxLength: 11 },
  RealSsn: { configurationKey: 'PARTSSN' },
  Gender: { configurationKey: 'GENDER' },
  MaritalStatus: { configurationKey: 'MARITALSTATUS' },
  HICN: { configurationKey: 'HICN' },
  PartProvidedEmail: { configurationKey: 'PARTEMAIL', maxLength: 100 },
  ERProvidedEmail1: { configurationKey: 'EREMAIL1', maxLength: 100 },
  ERProvidedEmail2: { configurationKey: 'EREMAIL2', maxLength: 100 },
  HomePhone: { configurationKey: 'HOMEPHONE', maxLength: 20 },
  MobilePhone: { configurationKey: 'MOBILEPHONE', maxLength: 20 },
  WorkPhone: { configurationKey: 'WORKPHONE', maxLength: 20 },
  EmployeeID: { configurationKey: 'EMPLOYEEID' },
  DBParticipantEligibilityStatus: {},
  DBLegacyParticipantEligibilityStatus: {},
  DCParticipantEligibilityStatus: {},
  HBParticipantEligibilityStatus: {},
  Address_1: { configurationKey: 'ADDR1', maxLength: 70 },
  Address_2: { configurationKey: 'ADDR2', maxLength: 70 },
  Address_3: { configurationKey: 'ADDR3', maxLength: 70 },
  City: { configurationKey: 'CITY' },
  Zip: { configurationKey: 'POSTALCODE' },
  State: { configurationKey: 'STATE' },
  Country: { configurationKey: 'COUNTRYCODE' },
  MailingAddress: {},
};

export interface ProfileFormData extends Partial<Omit<ProfileContentData, keyof ProfileAddressRaw>> {
  ParticipantAddress: ProfileAddressRaw;
}

export interface ProfileValueItem<V> {
  value: V;
  isVisible: boolean;
  isEditable: boolean;
  isRequired: boolean;
  maxLength?: number;
  sourceOrder?: string[];
}

export interface ProfileAddressValueItem extends ProfileValueItem<ProfileAddress> {
  fullAddress: string;
}

export interface ProfileAddress {
  Address_1: ProfileValueItem<string>;
  Address_2: ProfileValueItem<string>;
  Address_3: ProfileValueItem<string>;
  City: ProfileValueItem<string>;
  Zip: ProfileValueItem<string>;
  State: ProfileValueItem<string>;
  Country: ProfileValueItem<string>;
}

export class ProfileModel {
  private static readonly addressKeys = [
    'Address_1',
    'Address_2',
    'Address_3',
    'City',
    'Zip',
    'State',
    'Country',
    'MailingAddress',
  ];
  private static readonly optionalFields = [
    'MiddleName',
    'EmployeeID',
    'MaritalStatus',
    'Address_2',
    'ERProvidedEmail1',
    'ERProvidedEmail2',
    'PartProvidedEmail',
    'HomePhone',
    'MobilePhone',
    'WorkPhone',
    'DateOfDeath',
  ];

  private _data: ProfileContentData;
  private _countries: IStaticContent['Countries'];

  Ssn: string;
  DBParticipantEligibilityStatus: YNBool;
  DBLegacyParticipantEligibilityStatus: YNBool;
  DCParticipantEligibilityStatus: YNBool;
  HBParticipantEligibilityStatus: YNBool;

  FirstName: ProfileValueItem<string>;
  LastName: ProfileValueItem<string>;
  MiddleName: ProfileValueItem<string>;
  DOB: ProfileValueItem<Date>;
  RealSsn: ProfileValueItem<string>;
  Gender: ProfileValueItem<'MALE' | 'FEMALE'>;
  MaritalStatus: ProfileValueItem<string>;
  HICN: ProfileValueItem<string>;
  ERProvidedEmail1: ProfileValueItem<string>;
  ERProvidedEmail2: ProfileValueItem<string>;
  WorkPhone: ProfileValueItem<string>;
  MobilePhone: ProfileValueItem<string>;
  HomePhone: ProfileValueItem<string>;
  PartProvidedEmail: ProfileValueItem<string>;
  DateOfDeath: ProfileValueItem<Date>;
  EmployeeID: ProfileValueItem<string>;
  ParticipantAddress: ProfileAddressValueItem;
  MailingAddress?: ProfileAddressValueItem;

  get originalData(): ProfileContentData {
    return this._data;
  }

  get fullName(): string {
    return [
      ProfileModel.separatedField(this.FirstName, ''),
      ProfileModel.separatedField(this.MiddleName, endsWith(this.MiddleName.value, '.') ? '' : '.'),
      ProfileModel.separatedField(this.LastName, ''),
    ].join(' ');
  }

  static fromRaw(
    rawData: GetProfileContentRaw,
    fieldLengths: ProfileFieldlengthsModel,
    countries: IStaticContent['Countries'],
  ): ProfileModel {
    const res = new ProfileModel();
    const { addressKeys } = ProfileModel;

    res._data = Object.freeze(rawData.Data);
    res._countries = countries;

    Object.assign(res, ProfileModel.createValueItems(res.originalData, rawData.Configuration, fieldLengths, addressKeys));

    const participantAddress = {
      Address_1: res.originalData.Address_1,
      Address_2: res.originalData.Address_2,
      Address_3: res.originalData.Address_3,
      City: res.originalData.City,
      Zip: res.originalData.Zip,
      State: res.originalData.State,
      Country: res.originalData.Country,
    };

    res.ParticipantAddress = ProfileModel.createAddressValueItem(
      ProfileModel.createValueItems(participantAddress, rawData.Configuration, fieldLengths, null, 'PART'),
      countries,
    );

    if (res.originalData.MailingAddress) {
      res.MailingAddress = ProfileModel.createAddressValueItem(
        ProfileModel.createValueItems(res.originalData.MailingAddress, rawData.Configuration, fieldLengths, null, 'MAIL'),
        countries,
      );
    }

    return res;
  }

  static toRaw(formDate: ProfileFormData, data: ProfileModel): ProfileContentData {
    const { createRawAddress } = ProfileModel;
    const { originalData } = data;
    const { ParticipantAddress, ...restData } = formDate;
    const mailingAddress = Object.assign(createRawAddress(), originalData.MailingAddress, formDate.MailingAddress);
    const rawData = Object.assign({}, originalData, restData, ParticipantAddress, { MailingAddress: mailingAddress });
    const formatDateToUS = (date: Date) => formatDate(date, 'MM/dd/yyyy', 'en-US');

    this.nullifyEmptyFields(mailingAddress);
    this.nullifyEmptyFields(rawData);

    if (rawData.DOB) rawData.DOB = formatDateToUS(new Date(rawData.DOB));
    if (rawData.DateOfDeath) rawData.DateOfDeath = formatDateToUS(new Date(rawData.DateOfDeath));
    if (!rawData.RealSsn) rawData.RealSsn = '';

    return rawData as ProfileContentData;
  }

  private static nullifyEmptyFields(obj: object): void {
    Object.keys(obj)
      .forEach(key => {
        if (isPlainObject(obj[key])) {
          this.nullifyEmptyFields(obj[key]);
        } else if (typeof obj[key] === 'string' && !obj[key]) {
          obj[key] = null;
        }
      });
  }

  private static createRawAddress(): ProfileAddressRaw {
    return {
      Address_1: null,
      Address_2: null,
      Address_3: null,
      City: null,
      Zip: null,
      State: null,
      Country: null,
    };
  }

  private static separatedField(field: ProfileValueItem<string>, sep: string) {
    return field.value && field.isVisible ? field.value + sep : '';
  }

  private static createAddressValueItem(
    value: Record<keyof ProfileContentData, ProfileValueItem<any>>,
    countries: IStaticContent['Countries'],
  ): ProfileAddressValueItem {
    const br = '<br/>';
    const { Address_1, Address_2, City, State, Zip, Country } = value;
    const isVisible = Address_1.isVisible || Address_2.isVisible || City.isVisible ||
      State.isVisible || Zip.isVisible || Country.isVisible;
    return {
      value,
      isVisible,
      isRequired: true,
      isEditable: isVisible,
      get fullAddress() {
        return [
          ProfileModel.separatedField(this.value.Address_1, br),
          ProfileModel.separatedField(this.value.Address_2, br),
          ProfileModel.separatedField(this.value.City, ', '),
          ProfileModel.separatedField(this.value.State, ' '),
          ProfileModel.separatedField(this.value.Zip, br),
          this.value.Country.value && this.value.Country.isVisible ? countries[this.value.Country.value].CountryName + ' ' : '',
        ].join('');
      },
    };
  }

  private static createValueItems(
    obj: Partial<ProfileContentData>,
    configuration: ProfileContentConfiguration,
    fieldLengths: ProfileFieldlengthsModel,
    excludeKeys?: string[],
    prefix?: string,
  ): Record<keyof typeof obj, ProfileValueItem<any> | any> {
    const ignoreMaxLengthsFields = ['DOB', 'DateOfDeath'];

    return Object.keys(obj)
      .filter((key: keyof typeof obj) => {
        return profileParserConfig[key].configurationKey && excludeKeys ? !excludeKeys.includes(key) : true;
      })
      .reduce((res, key: keyof typeof obj) => {
        const config = profileParserConfig[key];
        const value = obj[key];
        const configKey = prefix ? `${prefix}${config.configurationKey}` : config.configurationKey;
        const itemConfig = configuration[configKey];
        const maxLength = ignoreMaxLengthsFields.includes(key) ? null : config.maxLength || fieldLengths[configKey];
        res[key] = itemConfig ? ProfileModel.createValueItem(key, value, itemConfig, maxLength) : value;
        return res;
      }, {} as Record<keyof typeof obj, ProfileValueItem<any> | any>);
  }

  private static createValueItem<V>(name: string, value: V, itemConfig: ProfileConfigItemRaw, maxLength?: number): ProfileValueItem<V> {
    return {
      value,
      isRequired: !ProfileModel.optionalFields.includes(name),
      isVisible: itemConfig.DISPLAY_ENABLED === 'True',
      isEditable: itemConfig.ISEDITABLE === 'True',
      maxLength,
    };
  }
}
