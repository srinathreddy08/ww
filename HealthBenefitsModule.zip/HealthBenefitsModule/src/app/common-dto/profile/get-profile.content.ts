import { ContentRaw, ContentWrapper } from '../content-wrapper';
import { YNBool } from '../general.types';

export interface ProfileConfigItemRaw {
    DISPLAY_ENABLED: 'True' | 'False';
    ISEDITABLE: 'True' | 'False';
    SOURCE_ORDER?: string;
}

export interface ProfileAddressRaw {
    Address_1: string;
    Address_2: string;
    Address_3: string;
    City: string;
    Zip: string;
    State: string;
    Country: string;
}

export interface ProfileContentData {
    FirstName: string;
    LastName: string;
    MiddleName: string;
    DOB: string;
    Ssn: string;
    RealSsn: string;
    Gender: 'MALE' | 'FEMALE';
    MaritalStatus: string;
    HICN: string;
    ERProvidedEmail1: string;
    ERProvidedEmail2: string;
    HomePhone: string;
    MobilePhone: string;
    PartProvidedEmail: string;
    WorkPhone: string;
    DateOfDeath: Date;
    EmployeeID: string;
    DBParticipantEligibilityStatus: YNBool;
    DBLegacyParticipantEligibilityStatus: YNBool;
    DCParticipantEligibilityStatus: YNBool;
    HBParticipantEligibilityStatus: YNBool;
    Address_1: string;
    Address_2: string;
    Address_3: string;
    City: string;
    Zip: string;
    State: string;
    Country: string;
    MailingAddress?: ProfileAddressRaw;
}

export interface ProfileContentConfiguration {
    PARTFIRSTNAME: ProfileConfigItemRaw;
    PARTMIDDLEINITIAL: ProfileConfigItemRaw;
    PARTLASTNAME: ProfileConfigItemRaw;
    PARTSSN: ProfileConfigItemRaw;
    DOB: ProfileConfigItemRaw;
    GENDER: ProfileConfigItemRaw;
    MARITALSTATUS: ProfileConfigItemRaw;
    PARTADDR1: ProfileConfigItemRaw;
    PARTADDR2: ProfileConfigItemRaw;
    PARTADDR3: ProfileConfigItemRaw;
    PARTCITY: ProfileConfigItemRaw;
    PARTSTATE: ProfileConfigItemRaw;
    PARTPOSTALCODE: ProfileConfigItemRaw;
    PARTCOUNTRYCODE: ProfileConfigItemRaw;
    EREMAIL1: ProfileConfigItemRaw;
    EREMAIL2: ProfileConfigItemRaw;
    PARTEMAIL: ProfileConfigItemRaw;
    HOMEPHONE: ProfileConfigItemRaw;
    WORKPHONE: ProfileConfigItemRaw;
    MOBILEPHONE: ProfileConfigItemRaw;
    DEATHDATE: ProfileConfigItemRaw;
    EMPLOYEEID: ProfileConfigItemRaw;
    MAILADDR1: ProfileConfigItemRaw;
    MAILADDR2: ProfileConfigItemRaw;
    MAILADDR3: ProfileConfigItemRaw;
    MAILCITY: ProfileConfigItemRaw;
    MAILSTATE: ProfileConfigItemRaw;
    MAILPOSTALCODE: ProfileConfigItemRaw;
    MAILCOUNTRYCODE: ProfileConfigItemRaw;
    HICN: ProfileConfigItemRaw;
}

export type GetProfileContentRaw = ContentRaw<ProfileContentData, ProfileContentConfiguration>;
export type GetProfileContent = ContentWrapper<ProfileContentData, ProfileContentConfiguration>;
