export interface ProfileAlertMessage {
    displayOrder: number;
    message: { Body: string };
}

export interface ProfileAlertMessageRaw {
    DISPLAY_ORDER: number;
    CONTENT_ALIAS: string;
}
