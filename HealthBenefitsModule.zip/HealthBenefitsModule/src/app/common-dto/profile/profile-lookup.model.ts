export interface ProfileLookupItem {
    Code: string;
    Description: string;
    ID: string;
}

export interface ProfileLookupModel {
    Gender: ProfileLookupItem[];
    MaritalStatus: ProfileLookupItem[];
}
