export class DashboardModel {
  Configuration: any;
  Content: any;
  ContentAliases: any;
}
