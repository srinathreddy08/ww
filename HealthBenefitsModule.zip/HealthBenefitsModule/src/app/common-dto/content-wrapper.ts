import * as _ from 'lodash';

import { convertArrayStringToArray } from '../utils/string.utils';

export interface ContentRaw<D, C> {
  Data: D;
  Configuration: C;
  JavascriptRules: any;
  ContentAliases: Record<string, any>;
  Content: Record<string, any>;
}

export class ContentWrapper<D, C> {
  data: D;
  contentSource: ContentRaw<D, C>;

  static fromRaw<D, C>(contentRaw: ContentRaw<D, C>) {
    return new ContentWrapper(contentRaw);
  }

  private static logError(msg: string): void {
    console.log(msg);
  }

  constructor(data: ContentRaw<D, C>) {
    let hasError = false;
    if (!data) {
      ContentWrapper.logError('forData, data missing');
      hasError = true;
    }
    if (data) {
      const missingKey = ['Content', 'ContentAliases', 'Configuration'].find(k => !data[k]);
      if (missingKey) {
        ContentWrapper.logError(`forData, data.${missingKey} missing`);
        hasError = true;
      }
    }

    if (hasError) throw new Error('Error during creation of ContentWrapper');

    this.data = data.Data;
    this.contentSource = data;
  }

  getObjectOrDefault(evaluationPoint) {
    return this.getObjectValue(evaluationPoint) || {};
  }

  getStringOrDefault(evaluationPoint) {
    return this.getStringValue(evaluationPoint) || '';
  }

  getAliasObjectOrDefault(evaluationPoint) {
    return this.getAliasObject(evaluationPoint) || {};
  }

  getContentObjectOrDefault(aliasPath) {
    return this.getContentObject(aliasPath) || {};
  }

  getContentValue(aliasPath) {
    if (!aliasPath) ContentWrapper.logError('getContentValue(aliasPath), aliasPath is missing');

    if (this.contentSource.Content[aliasPath] === undefined) {
      ContentWrapper.logError('getContentValue(aliasPath), data.Content[aliasPath] === undefined, aliasPath=' + aliasPath);
    }

    return this.contentSource.Content[aliasPath];
  }

  getAliasValue(evaluationPoint) {
    if (this.contentSource.ContentAliases[evaluationPoint] === undefined) {
      ContentWrapper.logError(
        'getAliasValue(evaluationPoint), ' +
        'data.ContentAliases[evaluationPoint] === undefined, evaluationPoint=' + evaluationPoint,
      );
    }

    return this.contentSource.ContentAliases[evaluationPoint];
  }

  logError(errorMessage) {
    console.error(`contentAliasService: ${errorMessage}`);
  }

  checkValue(value: any, expectedType: string, valueName: string): any {
    if (value !== undefined && value !== null) {
      const valueType = typeof value;
      if (valueType !== expectedType) {
        ContentWrapper.logError(
          `Value of ${valueName} is expected ` +
          `to be of '${expectedType}' type, but received a value of '${valueType}' type`,
        );
      }
    }

    return value;
  }

  evaluationPointName(evaluationPoint) {
    return `evaluation point '${evaluationPoint}'`;
  }

  aliasPathName(aliasPath) {
    return `SiteCore alias path '${aliasPath}'`;
  }

  getAliasPath(evaluationPoint) {
    const result = this.getAliasValue(evaluationPoint);
    const pointName = this.evaluationPointName(evaluationPoint);
    return this.checkValue(result, 'string', `SiteCore alias path for ${pointName}`);
  }

  getAliasObject(evaluationPoint) {
    const result = this.getAliasValue(evaluationPoint);
    const pointName = this.evaluationPointName(evaluationPoint);
    return this.checkValue(result, 'object', `alias object for ${pointName}`);
  }

  getContentObject(aliasPath) {
    return this.checkValue(this.getContentValue(aliasPath), 'object', this.aliasPathName(aliasPath));
  }

  getContentString(aliasPath) {
    return this.checkValue(this.getContentValue(aliasPath), 'string', this.aliasPathName(aliasPath));
  }

  getEvaluationPointValue(evaluationPoint) {
    return this.getContentValue(this.getAliasPath(evaluationPoint));
  }

  getEvaluationPoint(evaluationPoint) {
    return this.valueWrapper(this.getEvaluationPointValue(evaluationPoint));
  }

  getEvaluationPointTypedValue(evaluationPoint, expectedType) {
    return this.checkValue(this.getEvaluationPointValue(evaluationPoint), expectedType, this.evaluationPointName(evaluationPoint));
  }

  getStringValue(evaluationPoint) {
    return this.getEvaluationPointTypedValue(evaluationPoint, 'string');
  }

  getObjectValue(evaluationPoint) {
    return this.getEvaluationPointTypedValue(evaluationPoint, 'object');
  }

  getConfiguration(configurationPoint) {
    const config = this.contentSource.Configuration[configurationPoint];
    if (config === undefined) {
      ContentWrapper.logError('getConfiguration(configurationPoint), data.Configuration[configurationPoint] === undefined, configurationPoint=' + configurationPoint);
    }
    return this.valueWrapper(config);
  }

  getAlias(evaluationPoint) {
    return this.valueWrapper(this.getAliasValue(evaluationPoint));
  }

  getConfigurationValue(configurationPoint) {
    return this.getConfiguration(configurationPoint).value;
  }

  evaluationPointExists(evaluationPoint) {
    return !!(this.contentSource.ContentAliases[evaluationPoint]);
  }

  valueWrapper(value) {
    const asStringArray = () => {
      if (typeof value !== 'string') throw Error('value should be string');
      return convertArrayStringToArray(value);
    };
    const getLinkedContent = () => {
      const aliasPath = value.CONTENT_ALIAS;
      if (aliasPath === undefined) {
        ContentWrapper.logError('valueWrapper.getLinkedContent, aliasPath === undefined, value=' + value);
        return;
      }
      return this.valueWrapper(this.getContentValue(aliasPath));
    };

    return {
      value,
      asNumber: () => Number(value),
      asDate: () => new Date(value),
      asStringArray,
      asFirstChildStringArray: () => convertArrayStringToArray(value[0]),
      asLodashObject: () => _(value).mapValues(this.valueWrapper.bind(this)),
      asSwitch: (namedValues) => _(namedValues).mapValues(fv => fv === value).value(),
      getField: (key: string) => this.valueWrapper(value[key]),
      getContent: () => this.valueWrapper(this.getContentValue(value)),
      getLinkedContent,
    };
  }
}
