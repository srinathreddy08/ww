export type YNBool = 'Y' | 'N';
export type BinBool = '1' | '0';
