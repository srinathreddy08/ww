export interface IAvailableLanguage {
  LanguageCode: string;
  LanguageDescription: string;
}

export interface ILanguagePreference {
  Language: string;
  SelectedLanguage?: any;
  AreSeveralLanguagesAvailable: boolean;
  LanguagesForSelection?: any
}
