import { IBeneficiary, IBeneficiaryDesignation } from "src/app/common-dto/beneficiaries.model";

export interface IShoppingCart {
  BeneficiaryData: IBeneficiaryData;
  ShoppingCart: IBenefitsShoppingCartModel[];
}

export interface IBeneficiaryData {
  Beneficiaries: Record<string, IBeneficiary>;
  Designations: Record<string, IBeneficiaryDesignation[]>;
}

export interface IBenefitsShoppingCartModel {
  BenefitID: string;
  PlanID: string;
  OptionID: string;
  BenefitCategory: string;
  IsNoCov: boolean;
  Amount: number;
  DependentAssociationList: string[];
  IsChanged: boolean;
  IsLostEligibility: boolean;
  IsVisited: boolean;
  IsInterested: boolean;
  ControlID: string;
  LifeEventDate: string;
  LifeEventID: string;
  Ssn: string;
  UpdateDate?: string;
  DisplayOrder: number;
  EOIPendingStatus: string;
  AmountInforce: number;
  AmountPended: number;
  AdministrativeCostAnnual: number;
  AdministrativeCostMonthly: number;
  EmployeeAnnualCost: number;
  EmployeePayPeriodCost: number;
  EmployerAnnualCost: number;
  EmployerPayPeriodCost: number;
  PendedEmployeeAnnualCost: number;
  PendedEmployeePayPeriodCost: number;
  PremiumAnnual: number;
  PremiumMonthly: number;
  IsRepriced: boolean;
}

export interface ISaveShoppingCardAndDesignationsRequestObject {
  Data: IBeneficiaryData;
  IsExpertGuidance: boolean;
  LifeEventDate: string;
}

export interface ssnValidationRequestObject {
  Ssn: string;
  OriginalSsn: string;
  IsLifeEvent: boolean;
  IsTrust: boolean;
}
