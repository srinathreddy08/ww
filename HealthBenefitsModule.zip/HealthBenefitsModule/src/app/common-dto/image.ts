
export class Image {
    MediaId: string;
    Alt: any;
}
