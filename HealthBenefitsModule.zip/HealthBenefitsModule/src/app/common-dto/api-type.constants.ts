export enum ApiTypesConstants {
  get = 'get',
  load = 'load'
};
