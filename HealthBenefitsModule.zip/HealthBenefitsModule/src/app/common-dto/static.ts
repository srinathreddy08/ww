export class Static {
  Terms: {
    ReadMore?: string;
    LearnMore?: string;
    WatchVideo?: string;
    Articles?: string;
    Next?: string;
    Previous?: string;
    PayPeriod?: string;
    AddToCart?: string;
    NoCoverage?: string;
    CurrentlySelected?: string;
    ChooseBenefitsRemoveToWaive?: string;
    WebsiteLabel?: string;
    WhatToDoHere?: string;
    Resume?: string;
    Close?: string;
    SelectALifeEvent?: string;
    Select?: string;
    Category?: string;
    LifeEvent?: string;
    Description?: string;
    Link?: string;
    Edit?: string;
    ContactHR?: string;
    GetStarted?: string;
    Model?: string;
    HelpCenter?: string;
    GettingPrepared?: string;
    Continue?: string;
    Province?: string;
    State?: string;
    ZipCode?: string;
    Search?: string;
    Logout?: string;
    Attention?: string;
    EndImpersonation?: string;
    YouAreImpersonating?: string;
    Cancel?: string;
    Home?: string;
    PrimaryBeneficiaryRequired?: string;
    Save?: string;
    UpdateSaved?: string;
    NoBeneficiaryOnFile?: string;
    IDoNotAgree?: string;
    IAgree?: string;
  };
  Images?: any;
  Countries?: Record<string, ICountry>;
  CountriesArray?: Array<ICountry>;
}

export interface ICountry {
  CountryCode: string;
  CountryName: string;
  IsDomestic: boolean;
  States: { StateProvinceCode: string; StateProvinceName: string }[];
}

export interface IStaticContent {
  Terms: Record<string, string>;
  AuthTerms: Record<string, string>;
  Gender: Record<string, string>;
  MaritalStatus: Record<string, string>;
  MessageCenterCategories: Record<string, string>;
  MessageCenterContactUs: Record<string, string>;
  Proxy: Record<string, string>;
  SortBy: Record<string, string>;
  Countries: Record<string, ICountry>;
  CountriesArray?: Array<ICountry>;
  Images: Record<string, { MediaId: string; Alt: string }>;
  DcPlanTypes: Record<string, string>;
  MonthsNames: Record<string, string>;
}
