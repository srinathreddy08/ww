export enum LifeEventIdentifier {
    NEW_HIRE = '1',
    OPEN_ENROLMENT = '55',
    ANNUAL_ENROLLMENT_CORRECTION = '114'
}