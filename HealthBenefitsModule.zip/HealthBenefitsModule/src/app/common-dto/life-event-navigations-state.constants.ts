export class LifeEventNavigationsState {
  public static CartReview = 'life-event.review';
  public static GetStarted = 'life-event.get-started';
  public static ChooseBenefitsSummary = 'life-event.choose-benefits';
  public static ExpertGuidancePackageReview = 'expert-guidance.package-review';
  public static ExpertGuidanceGetStarted = 'expert-guidance.get-started';
  public static SupplementalBenefits = 'life-event.supplemental-benefits';
  public static WhosCovered = 'life-event.whos-covered';
  public static ReInitiate = 'life-event.reinitiate';
  public static MyInformation = 'life-event.my-information';
};