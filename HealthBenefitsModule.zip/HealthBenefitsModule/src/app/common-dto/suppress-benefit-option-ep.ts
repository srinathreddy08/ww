export interface ISuppressBPOfromUI {
    [key: string]: {
        BENEFITID?: string;
        PLANID?: string;
        OPTIONID?: string;
    };
  }
  