import { IEmployeeLifeEventModel } from "./employee-life-event.model";

export interface ILifeEventDateOffsetEvaluationModel {
  LEDateOffsetData: {
    LifeEventDate: Date,
    LifeEventCategory: string,
    EmpCgData_Usercode_1: string,
    EmpCgData_Usercode_2: string,
    FirstDateOfCurrentPlanYear: Date,
    FirstDateOfNextPlanYear: Date,
    LastDateOfCurrentPlanYear: Date,
    LastDateOfNextPlanYear: Date,
    LifeEventID: string,
    DaysToInit: number,
    DaysToComplete: number,
    DaysAfterInit: number,
    RuleForEmpInitiatedEvents: string,
    CompanyOneCode: string,
    CurrentCoverageExists: IEmployeeLifeEventModel,
    FutureCoverageExists: IEmployeeLifeEventModel,
    FutureCoverageLifeEventID: string,
    FutureCoverageLifeEventCategory: string,
    FutureCoverageLifeEventDate: Date | string,
    DateOfFirstCoverage: Date,
    DateOfRetireeCoverage: Date,
    CurrentControlledGroupStatus: string,
    GlogFlag: number,
    OngoingStartDate: Date,
    MonthsLEDateIsFarFromCurrentPLanYearBeginDate: number | null,
  }
}
