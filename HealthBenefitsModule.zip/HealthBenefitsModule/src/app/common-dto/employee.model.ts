import { YNBool } from './general.types';
import { IQuestionnaire } from './questionnaire.model';
import { ICompanyModel } from './company.model';
import { IEmployeeLifeEventModel } from './employee-life-event.model';
import { AddDependentsResponseModel } from '@my-account/whos-covered/dto/new-dependent.model';

export interface EmployeeModel {
  Addresses: EmployeeAddress[];
  Beneficiaries: unknown[];
  BeneficiaryDesignations: unknown[];
  BenefitsCoveredBySpouse: null | string | boolean;
  BirthDate: string;
  CompanyAddress: string;
  CompanyEmpSecondaryStatusCode: YNBool;
  CompanyID: string;
  CompanyName: string;
  ContributionTypes: string[];
  ControlledGroupStatus: string;
  CurrentControlledGroupStatus: string;
  DateOfFirstCoverage: Date;
  DateOfRetireeCoverage: Date;
  DepVerificationStatus: string;
  DependentCoverageAsEmployee: unknown[];
  Dependents: AddDependentsResponseModel[];
  DocUploadDate: Date;
  EmailAddress: string;
  EmpCgData_Date_11: string;
  EmpCgData_Date_12: string;
  EmpCgData_Date_5: string;
  EmpCgData_Status_3: string;
  EmpCgData_Status_6: string;
  EmpCgData_Usercode_1: string;
  EmpCgData_Usercode_20: string;
  EmpCgData_Usercode_21: string;
  EmpCgData_Usercode_22: string;
  EmpCgData_Usercode_2: string;
  EmpCgData_Usercode_3: string;
  EmpCgData_Usercode_4: string;
  EmployeeData_Date_4: string;
  EmployeeData_Date_5: string;
  EmployeeData_Dollar_4: string;
  EmployeeData_Dollar_5: string;
  FirstName: string;
  FrozenPlanYearData: unknown[];
  FutureDatedNH: string;
  FutureDatedOE: string;
  HICN: string;
  HasCoverageAsEmployee: boolean;
  HasFutureDatedNH: string;
  HasFutureDatedOE: string;
  IsMedicareEligibleByAge: boolean;
  IsMedicareEligibleByAgeAsOfDateEntered: boolean;
  Last4SsnDigits: string;
  LastName: string;
  LifeEvents: IEmployeeLifeEventModel[];
  Location: string;
  MaritalStatus: string;
  MedicareEligibilityStatus: string | null | undefined;
  MedicareEligibilityStatusDate: string | null | undefined;
  MiddleInitial: string;
  MiddleName: string;
  ParentSsn: string | undefined;
  PayGroupFrequency: number;
  PayStatusCode: string;
  PlanYearInfo: IPlanYearInfo;
  ReinitLifeEvent: ReinitLifeEvent;
  Questionnaires: IQuestionnaire;
  Rate1: number;
  Rate2: number;
  RealSsn: string;
  ReferenceNumber: string;
  RelationType: string;
  RelationshipCode: string;
  RemainingPayPeriods: number;
  RetireeModelingData: string;
  Salary1: number;
  Salary2: number;
  SalaryHourlyCode: string;
  Sex: string;
  SmallMarketData: ICompanyModel;
  Ssn: string;
  TotalPayPeriods: number;
  UnionCode: string;
  UserCode1: string | null | undefined;
  WorkCode: string;
}

export interface IPlanYearInfo {
  CurrentPlanYear: number;
  CurrentPlanYearBeginDate: Date;
  CurrentPlanYearEndDate: Date;
  NextPlanYear: number;
  NextPlanYearBeginDate: Date;
  NextPlanYearEndDate: Date;
}

export class EmployeeAddress {
  Address_1?: string;
  Address_2?: string;
  Address_3?: string;
  Address1?: string;
  Address2?: string;
  Address3?: string;
  City: string;
  Country: string;
  County: string;
  Ssn: string;
  State: string;
  Telephone: string;
  Zip: string;
}

export class ReinitLifeEvent {
  DateEntered: Date;
  LifeEventEndDate: Date;
  LifeEventID: string;
}
