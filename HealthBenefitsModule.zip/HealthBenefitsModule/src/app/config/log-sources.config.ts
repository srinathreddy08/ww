export const LOG_SOURCES = {
  MBCDevTools: true,
  CartValidationService: false,
  ChatService: false,
  CheckCartConsistency: false,
  DomDataLifeCycle: false,
  Routing: false,
  SpinnerService: false,
  WhosCoveredCoverageState: false,
  WhosCoveredDeferred: false,
  DependentUserCoverage: false,
  NavigationService: false,
  TransformOpenEnrollment: true,
  PCE: true,
  AutocompleteService: false,
  MissingShoppingCartFunctionInExpertGuidanceFlow: false
};
