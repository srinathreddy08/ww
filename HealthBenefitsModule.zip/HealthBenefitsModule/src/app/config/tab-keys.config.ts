export const TAB_KEYS = {
  getStarted: 'get-started',
  healthBenefits: 'choose-benefits',
  supplementalBenefits: 'supplemental-benefits'
};
