import { Component, OnInit } from '@angular/core';
import { ExpertGuidanceState } from '../../services/expert-guidance-state.service';

@Component({
  selector: 'app-common-coverage-grid',
  templateUrl: './common-coverage-grid.component.html',
  styleUrls: ['./common-coverage-grid.component.css']
})
export class CommonCoverageGridComponent implements OnInit {
  isExpertGuidanceFlow: boolean = false;

  constructor(private expertGuidanceState: ExpertGuidanceState) {}

  ngOnInit(): void {
    this.isExpertGuidanceFlow = !this.expertGuidanceState.isDoItYourselfFlow();
  }
}
