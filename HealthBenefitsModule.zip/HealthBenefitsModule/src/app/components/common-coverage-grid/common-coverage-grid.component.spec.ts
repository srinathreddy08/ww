import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonCoverageGridComponent } from './common-coverage-grid.component';

describe('CommonCoverageGridComponent', () => {
  let component: CommonCoverageGridComponent;
  let fixture: ComponentFixture<CommonCoverageGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommonCoverageGridComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonCoverageGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Add more tests to cover the component logic
});
