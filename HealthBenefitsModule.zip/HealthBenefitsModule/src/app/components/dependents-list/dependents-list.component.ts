import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dependents-list',
  templateUrl: './dependents-list.component.html',
  styleUrls: ['./dependents-list.component.css']
})
export class DependentsListComponent implements OnInit {
  @Input() dependents: any[] = [];
  @Input() enrollmentContent: any;

  dependentCoveredTitle: string = '';

  constructor() {}

  ngOnInit(): void {
    this.dependentCoveredTitle = this.enrollmentContent.getStringOrDefault('HB.LifeEvent.ExpertGuidance.DependentsCoveredLabel') || 'Dependents Covered:';
  }
}
