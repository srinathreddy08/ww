import { Component, Input, OnInit } from '@angular/core';
import { StaticContentService } from '../../services/static-content.service';

@Component({
  selector: 'app-beneficiaries-info',
  templateUrl: './beneficiaries-info.component.html',
  styleUrls: ['./beneficiaries-info.component.css']
})
export class BeneficiariesInfoComponent implements OnInit {
  @Input() enrollmentContent: any;
  @Input() item: any;
  @Input() bene: any;
  @Input() election: any;

  static: any;
  beneficiariesDesignations: any;
  beneficiaries: any;

  constructor(private staticContent: StaticContentService) {}

  ngOnInit(): void {
    this.static = this.staticContent;
    this.beneficiariesDesignations = this.item ? this.item.employee.BeneficiaryDesignations[this.item.ElectedBenefit.BenefitID] : this.bene.designations[this.election.ElectedBenefit.BenefitID];
    this.beneficiaries = this.item ? this.item.employee.Beneficiaries : this.bene.beneficiaries;
  }

  getDesignationBirthDate(id: string): string {
    return this.beneficiaries[id].BirthDate;
  }
}
