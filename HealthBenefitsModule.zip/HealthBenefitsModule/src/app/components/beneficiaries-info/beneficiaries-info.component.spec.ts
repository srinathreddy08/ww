import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BeneficiariesInfoComponent } from './beneficiaries-info.component';

describe('BeneficiariesInfoComponent', () => {
  let component: BeneficiariesInfoComponent;
  let fixture: ComponentFixture<BeneficiariesInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BeneficiariesInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BeneficiariesInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
