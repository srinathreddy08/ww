import { Component, Input, OnInit } from '@angular/core';
import { NavigationService } from '../../services/navigation.service';
import { ProfileDataService } from '../../services/profile-data.service';
import { CartReloadService } from '../../services/cart-reload.service';
import { ContentAliasService } from '../../services/content-alias.service';
import { CoverageStateService } from '../../services/coverage-state.service';
import { AllowEditService } from '../../services/allow-edit.service';
import { ParticipantDataService } from '../../services/participant-data.service';
import { DeferredCoverageService } from '../../services/deferred-coverage.service';
import { PageLoadHelperService } from '../../services/page-load-helper.service';
import { LifeEventVerificationService } from '../../services/life-event-verification.service';

@Component({
  selector: 'app-whos-covered',
  templateUrl: './whos-covered.component.html',
  styleUrls: ['./whos-covered.component.css']
})
export class WhosCoveredComponent implements OnInit {
  @Input() data: any;
  @Input() lifeEventNavigationDataUpdated: Promise<void>;

  editAllowed: boolean = false;
  isAddDependentEnabledByEp: boolean = false;
  employeeType: string = '';
  wtdhAlias: string = 'HB.LifeEvent.GetStarted.WhosCoveredHelp';
  profileData: any;
  dependentRestrictions: any;
  config = { numFormsOpen: 0 };
  upcomingCoverageTabLabel: string = '';
  currentCoverageTabLabel: string = '';
  showCoverageForPendingEmployee: boolean = false;

  constructor(
    private navigationService: NavigationService,
    private profileDataService: ProfileDataService,
    private cartReloadService: CartReloadService,
    private contentAliasService: ContentAliasService,
    private coverageStateService: CoverageStateService,
    private allowEditService: AllowEditService,
    private participantDataService: ParticipantDataService,
    private deferredCoverageService: DeferredCoverageService,
    private pageLoadHelperService: PageLoadHelperService,
    private lifeEventVerificationService: LifeEventVerificationService
  ) {}

  ngOnInit(): void {
    this.pageLoadHelperService.loadPageWithSpinner(window.location.pathname);
    this.navigationService.setCurrentTabByKeys('get-started', 'whos-covered');
    const contentService = this.contentAliasService.forData(this.data.employeeData);
    this.editAllowed = this.allowEditService.dependentsEditAllowed(this.participantDataService);
    this.isAddDependentEnabledByEp = this.getIsAddDependentEnabledByEp();
    this.employeeType = this.lifeEventVerificationService.isLePendingDueToLev(this.data.employeeData) ? 'PendingLEVEmployee' : 'CurrentCoveragesEmployee';

    if (this.lifeEventNavigationDataUpdated) {
      this.lifeEventNavigationDataUpdated.then(() => {
        this.navigationService.activateSubtab('whos-covered');
      });
    }

    this.profileData = this.profileDataService.getProfileData();

    if (this.cartReloadService) {
      this.data.cartData = this.cartReloadService.getCartData();
    }

    this.dependentRestrictions = this.data.restrictionsData;

    this.upcomingCoverageTabLabel = contentService.getEvaluationPointValue('HB.LifeEvent.GetStarted.WhosCovered.UpcomingCoverage');
    this.currentCoverageTabLabel = contentService.getEvaluationPointValue('HB.LifeEvent.GetStarted.WhosCovered.CurrentCoverage');
    this.showCoverageForPendingEmployee = this.showCoverageForPendingEmployeeFn();
  }

  next(): void {
    // Let children know the next button was clicked
    // Implement event broadcasting logic if needed
  }

  formsOpen(open: boolean): void {
    open ? this.config.numFormsOpen++ : this.config.numFormsOpen--;
  }

  showCoverageForPendingEmployeeFn(): boolean {
    const pendingEmployeeCoverageData = this.coverageStateService.getCoverageState(this.data.employeeData.Data.PendingEmployee, this.data, true);
    return pendingEmployeeCoverageData.showCoverage;
  }

  dependentCoverageGridSettings(): any {
    const isHavedeferredCoverage = this.deferredCoverageService.doesParticipantHaveSavedDeferredCoverage();
    const dependentCoverageGridEp = isHavedeferredCoverage ? 'HB.LifeEvent.ChooseBenefits.NOCOVDependentCoverageGrid' : 'HB.Common.CommonTerms.DependentCoverageGrid';
    return this.contentAliasService.forData(this.data.employeeData).getEvaluationPointValue(dependentCoverageGridEp);
  }

  getIsAddDependentEnabledByEp(): boolean {
    const currentLifeEventId = this.data.employeeData.Employee.PendingEmployee.LifeEvents[0].LifeEventID;
    const rawEpValue = this.contentAliasService.forData(this.data.employeeData).getConfiguration('HB.LifeEvent.SuppressAddDependent');

    if (!rawEpValue) {
      return true;
    }

    const suppressForLeIds = rawEpValue.value && rawEpValue.asFirstChildStringArray();

    if (!suppressForLeIds) {
      return true;
    }

    return suppressForLeIds.indexOf(currentLifeEventId) === -1;
  }
}
