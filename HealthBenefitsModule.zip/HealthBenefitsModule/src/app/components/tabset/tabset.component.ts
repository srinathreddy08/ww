import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-tabset',
  templateUrl: './tabset.component.html',
  styleUrls: ['./tabset.component.css']
})
export class TabsetComponent {
  @Input() type: string = 'tabs';
  @Input() vertical: boolean = false;
  @Input() justified: boolean = false;
  @Input() tabs: any[] = [];
}
