import { Component, Input, ElementRef, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { StaticContentService } from '../services/static-content.service';
 
@Component({
  selector: 'app-inc-eoi',
  templateUrl: './inc-eoi.component.html',
  styleUrls: ['./inc-eoi.component.css']
})
export class IncEoiComponent implements AfterViewInit {
  @Input() electedOption: any;
  @Input() data: any;
  @Input() alignBottom: boolean = false;
  @Input() electedBenefit: any;
  @Input() externalEoi: boolean = false;
  @Input() eoiPendingStatus: any;
  @Input() selectedOption: any;
 
  staticContent: any;
 
  constructor(
    private staticContentService: StaticContentService,
    private elementRef: ElementRef,
    private cdr: ChangeDetectorRef
  ) {
    this.staticContent = this.staticContentService.getContent();
  }
 
  ngAfterViewInit(): void {
    if (this.alignBottom) {
      setTimeout(() => {
        const element = this.elementRef.nativeElement as HTMLElement;
        const alignBottomElement = element.querySelector('.align-bottom') as HTMLElement;
        if (alignBottomElement) {
          element.style.height = `${alignBottomElement.clientHeight}px`;
          this.cdr.detectChanges();
        }
      }, 0);
    }
  }
}
