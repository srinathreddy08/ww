import { ComponentFixture, TestBed } from '@angular/core/testing';
import { IncEoiComponent } from './inc-eoi.component';

describe('IncEoiComponent', () => {
  let component: IncEoiComponent;
  let fixture: ComponentFixture<IncEoiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncEoiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IncEoiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Add more tests to cover the component logic
});
