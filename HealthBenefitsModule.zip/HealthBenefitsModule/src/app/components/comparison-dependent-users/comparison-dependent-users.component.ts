import { Component, Input, OnInit } from '@angular/core';
import { CoverageStateFactoryService } from '../../services/coverage-state-factory.service';
import { CoverageSourcesService } from '../../services/coverage-sources.service';
import { DisplayedComparisonCategories } from '../../models/displayed-comparison-categories.model';

@Component({
  selector: 'app-comparison-dependent-users',
  templateUrl: './comparison-dependent-users.component.html',
  styleUrls: ['./comparison-dependent-users.component.css']
})
export class ComparisonDependentUsersComponent implements OnInit {
  @Input() showPrimaryCareProviders: boolean = false;
  @Input() widgetTitle: string = '';
  @Input() hideTitle: boolean = false;
  @Input() data: any;
  @Input() detailsLink: string = '';
  @Input() employee: any;

  displayedComparisonCategories: DisplayedComparisonCategories;
  coverage: any;

  constructor(
    private coverageStateFactoryService: CoverageStateFactoryService,
    private coverageSourcesService: CoverageSourcesService
  ) {}

  ngOnInit(): void {
    this.displayedComparisonCategories = this.getDisplayedComparisonCategories();
    this.coverage = this.calculateCoverage();
  }

  private calculateCoverage(): any {
    const coverageSource = this.getCoverageSource();
    return this.coverageStateFactoryService.getCoverageByCategories(coverageSource);
  }

  private getCoverageSource(): any {
    return this.coverageSourcesService.fromDomElections(this.data.employeeData, this.employee);
  }

  private getDisplayedComparisonCategories(): DisplayedComparisonCategories {
    // Implement logic to retrieve displayed comparison categories
    return {} as DisplayedComparisonCategories;
  }
}
