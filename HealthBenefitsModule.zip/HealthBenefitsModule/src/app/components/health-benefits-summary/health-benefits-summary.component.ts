import { Component, OnInit } from '@angular/core';
import { NavigationService } from '../services/navigation.service';
import { EmployeeDataService } from '../services/employee-data.service';
import { ContentAliasService } from '../services/content-alias.service';
import { LifeEventsService } from '../services/life-events.service';
import { CoverageStateFactoryService } from '../services/coverage-state-factory.service';
import { CoverageSourcesService } from '../services/coverage-sources.service';
import { ShoppingCartService } from '../services/shopping-cart.service';
import { LeBenefitsService } from '../services/le-benefits.service';
import { CoverageEffectiveDateService } from '../services/coverage-effective-date.service';
import { PageLoadHelperService } from '../services/page-load-helper.service';
import { LifeEventVerificationService } from '../services/life-event-verification.service';
import { FeatureTogglesService } from '../services/feature-toggles.service';
import { ActivatedRoute } from '@angular/router';
import { BenefitCategoryMapService } from '../services/benefit-category-map.service';
import { QuestionnairePrintFormService } from '../services/questionnaire-print-form.service';
 
@Component({
  selector: 'app-health-benefits-summary',
  templateUrl: './healthBenefitsSummaryController.component.html',
  styleUrls: ['./healthBenefitsSummaryController.component.css']
})
export class HealthBenefitsSummaryControllerComponent implements OnInit {
  comparisonBenefitCategories: any;
  displayedComparisonCategories: any;
  enrollmentContent: any;
  employeeData: any;
  tabStructure: any[] = [];
  selectedSummary: any;
  tabs: any[] = [];
  openPrintScreenModal = false;
  tabHasChanged = false;
  isPDFConfirmationStatementToggleOn: boolean = false;
 
  constructor(
    private navigationService: NavigationService,
    private employeeDataService: EmployeeDataService,
    private contentAliasService: ContentAliasService,
    private lifeEventsService: LifeEventsService,
    private coverageStateFactoryService: CoverageStateFactoryService,
    private coverageSourcesService: CoverageSourcesService,
    private shoppingCartService: ShoppingCartService,
    private leBenefitsService: LeBenefitsService,
    private coverageEffectiveDateService: CoverageEffectiveDateService,
    private pageLoadHelperService: PageLoadHelperService,
    private lifeEventVerificationService: LifeEventVerificationService,
    private featureTogglesService: FeatureTogglesService,
    private route: ActivatedRoute,
    private benefitCategoryMapService: BenefitCategoryMapService,
    private questionnairePrintFormService: QuestionnairePrintFormService
  ) {}
 
  async ngOnInit() {
    this.pageLoadHelperService.loadPageWithSpinner(this.route.snapshot.url.join('/'));
    await this.lifeEventsService.initLifeEvents();
 
    this.employeeData = this.employeeDataService.getEmployeeData();
    this.enrollmentContent = this.contentAliasService.forData(this.employeeData);
    this.comparisonBenefitCategories = this.contentAliasService.getComparisonBenefitCategories();
    this.displayedComparisonCategories = this.contentAliasService.getDisplayedComparisonCategories();
 
    this.isPDFConfirmationStatementToggleOn = this.getPDFConfirmationStatementToggle();
    this.navigationService.setCurrentTabByKeys('healthsummary');
    this.tabStructure = this.getDisplayedTabs();
    this.selectedSummary = this.tabStructure[0]?.key;
    this.tabs = this.tabStructure.map(value => ({
      active: this.route.snapshot.queryParams['tab'] === 'current-coverage-tab' ? value.key === 'tab2' : value.key === this.selectedSummary,
      employee: value.employee,
      employeeType: value.employeeType,
      questionsInfo: Object.values(value.questions.questions)
    }));
  }
 
  private getDisplayedTabs() {
    let tab2EmpData;
    let tab2EmpType;
    const isVerificationDocumentsToggle = this.enrollmentContent.getConfigurationValue('HB.VerificationDocuments.Toggle') === 'Yes';
    const coverageType = this.lifeEventVerificationService.setCoverageTypeWithLEV(this.employeeData.Employee, isVerificationDocumentsToggle);
    tab2EmpData = coverageType.coverage;
    tab2EmpType = coverageType.type;
 
    return [
      {
        key: 'tab1',
        employee: this.employeeData.Employee.FutureCoverages?.[0],
        label: this.enrollmentContent.getEvaluationPointValue('HB.LifeEvent.Summary.FutureCoverageTabLabel'),
        employeeType: 'FutureCoverages[0]',
        subTitle: this.enrollmentContent.getEvaluationPointValue('HB.LifeEvent.Summary.FutureCoverageHeader'),
        questions: this.questionnairePrintFormService.getQuestions(this.employeeData, 'FutureCoverages[0]')
      },
      {
        key: 'tab2',
        employee: tab2EmpData,
        label: this.enrollmentContent.getEvaluationPointValue('HB.LifeEvent.ChooseBenefits.Summary.CurrentCovTab'),
        employeeType: tab2EmpType,
        subTitle: this.enrollmentContent.getEvaluationPointValue('HB.LifeEvent.Summary.CurrentCoverageHeader'),
        questions: this.questionnairePrintFormService.getQuestions(this.employeeData, tab2EmpType)
      },
      {
        key: 'tab3',
        employee: this.employeeData.Employee.HistoricalCoverages?.[0],
        label: this.enrollmentContent.getEvaluationPointValue('HB.LifeEvent.ChooseBenefits.Summary.PriorCovTab'),
        employeeType: 'HistoricalCoverages[0]',
        subTitle: this.enrollmentContent.getEvaluationPointValue('HB.LifeEvent.Summary.PriorCoverageHeader'),
        questions: this.questionnairePrintFormService.getQuestions(this.employeeData, 'HistoricalCoverages[0]')
      }
    ].filter(tab => !!tab.employee);
  }
 
  private getPDFConfirmationStatementToggle(): boolean {
    return this.enrollmentContent.getConfigurationValue('HB.PDFConfirmationStatement.Toggle') === 'Yes';
  }
 
  printPage() {
    if (this.isPDFConfirmationStatementToggleOn && !this.openPrintScreenModal) {
      this.openPrintScreenModal = true;
      setTimeout(() => window.print(), 0);
    }
  }
}