import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-mbc-what-to-do-here-core',
  templateUrl: './mbc-what-to-do-here-core.component.html',
  styleUrls: ['./mbc-what-to-do-here-core.component.css']
})
export class MbcWhatToDoHereCoreComponent implements OnInit {
  @Input() dataSource: any;
  @Input() static: any;
  @Input() notExpandable: boolean | null = null;

  expandable: boolean = true;
  expanded: boolean = true;
  contentLoaded: boolean = true;

  ngOnInit(): void {
    this.expandable = this.notExpandable === null;
    if (!this.expandable) {
      this.toggle = () => {};
    }
  }

  toggle(): void {
    this.expanded = !this.expanded;
  }

  onContentKeyChange(newVal: any, oldVal: any): void {
    if (this.expanded && newVal !== oldVal) {
      this.contentLoaded = false;
      setTimeout(() => {
        this.contentLoaded = true;
      });
    }
  }
}
