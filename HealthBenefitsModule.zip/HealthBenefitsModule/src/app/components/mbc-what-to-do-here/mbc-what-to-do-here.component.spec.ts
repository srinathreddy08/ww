import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MbcWhatToDoHereComponent } from './mbc-what-to-do-here.component';

describe('MbcWhatToDoHereComponent', () => {
  let component: MbcWhatToDoHereComponent;
  let fixture: ComponentFixture<MbcWhatToDoHereComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MbcWhatToDoHereComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MbcWhatToDoHereComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Add more tests to cover the component logic
});
