import { Component, Input, OnInit } from '@angular/core';
import { DcService } from '../../services/dc.service';
import { OverrideCostDisplayService } from '../../services/override-cost-display.service';
import { StaticContentService } from '../../services/static-content.service';
import { ContentAliasService } from '../../services/content-alias.service';
import { FlagsService } from '../../services/flags.service';

@Component({
  selector: 'app-le-benefit-cost',
  templateUrl: './le-benefit-cost.component.html',
  styleUrls: ['./le-benefit-cost.component.css']
})
export class LeBenefitCostComponent implements OnInit {
  @Input() data: any;
  @Input() employee: any;
  @Input() election: any;
  @Input() companyCont: boolean = false;
  @Input() periodName: string = '';

  enrollmentContent: any;
  static: any;
  displayCosts: boolean;
  showEmployeeContributionLabel: boolean;

  constructor(
    private dcService: DcService,
    private overrideCostDisplayService: OverrideCostDisplayService,
    private staticContentService: StaticContentService,
    private contentAliasService: ContentAliasService,
    private flagsService: FlagsService
  ) {}

  ngOnInit(): void {
    this.enrollmentContent = this.contentAliasService.forData(this.data.employeeData);
    this.static = this.staticContentService.getStaticContent();
    this.displayCosts = this.employee.SmallMarketData.DisplayCosts;
    this.showEmployeeContributionLabel = this.isEmployeeContributionLabelEnabled() && !this.showDcInformation() && this.companyCont && !this.election.ElectedPlan.IsNoCovPlan;
  }

  getTaxLabel(): string {
    const staticTerms = this.static.Terms;
    const electedOption = this.election.ElectedOption;

    if (electedOption.IsPreTax === true) {
      return this.showDcInformation() ? staticTerms.YourBeforeTaxCost : staticTerms.BeforeTax;
    } else if (electedOption.IsPreTax === false) {
      return staticTerms.AfterTax;
    }

    return '';
  }

  getOverridenZeroCostLabel(): string {
    return this.overrideCostDisplayService.forData(this.data.employeeData).getOverridenZeroCostLabel(this.election.ElectedBenefit.BenefitID);
  }

  isOverridenWithZeroCostLabel(cost: number): boolean {
    return cost === 0 && this.getOverridenZeroCostLabel();
  }

  showDcInformation(): boolean {
    const electedPlan = this.election.ElectedPlan;
    const isBenefitDc = this.dcService.isBenefitDc(this.election.ElectedBenefit, this.employee);
    const isCovPlan = !electedPlan.IsNoCovPlan;
    return isCovPlan && isBenefitDc;
  }

  getPlanCost(): number {
    return this.dcService.getPlanCost(this.election.ElectedOption, this.periodName);
  }

  getEmployerCost(): number {
    return this.election.ElectedOption[`Employer${this.periodName}Cost`];
  }

  getEmployeeCost(): number {
    if (this.periodName === 'Annual' && this.election.AccountsData) {
      return this.election.AccountsData.EmployeeAnnualCost || 0;
    }
    return this.election.ElectedOption[`Employee${this.periodName}Cost`] || 0;
  }

  showEmployerCost(): boolean {
    return this.showCompanyContribution() && this.getEmployerCost() && !this.isEmployeeCostOverridenWithZeroCostLabel() && !this.hideIfHsaAndQuarterlyOrSemiAnnual();
  }

  isEmployeeCostOverridenWithZeroCostLabel(): boolean {
    return this.isOverridenWithZeroCostLabel(this.getEmployeeCost());
  }

  showCompanyContribution(): boolean {
    return this.companyCont || this.showDcInformation();
  }

  hideIfHsaAndQuarterlyOrSemiAnnual(): boolean {
    const isHsa = this.election.ElectedBenefit.BenefitID === 'HSA';
    const isPayPeriod = this.periodName === 'PayPeriod';
    return this.flagsService.isQuaterlyOrSemiAnnual(this.employee) && isHsa && isPayPeriod;
  }

  isEmployeeContributionLabelEnabled(): boolean {
    return this.flagsService.isEmployeeContributionLabelEnabled(this.enrollmentContent);
  }

  showConditionalLabels(): boolean {
    const suppressFlag = this.data.employeeData.Configuration['HB.Summary.SuppressOptionInfo'];
    return suppressFlag !== 'Y' || !this.election.ElectedPlan.IsNoCovPlan;
  }
}
