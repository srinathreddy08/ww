import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ByCoverageComponent } from './by-coverage.component';

describe('ByCoverageComponent', () => {
  let component: ByCoverageComponent;
  let fixture: ComponentFixture<ByCoverageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ByCoverageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ByCoverageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Add more tests to cover the component logic
});
