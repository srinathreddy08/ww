import { Component, Input, OnInit } from '@angular/core';
import { SuppressedBenefitsPlansOptionsService } from '../../services/suppressed-benefits-plans-options.service';
import { ContentAliasService } from '../../services/content-alias.service';

@Component({
  selector: 'app-le-benefits-by-coverage',
  templateUrl: './le-benefits-by-coverage.component.html',
  styleUrls: ['./le-benefits-by-coverage.component.css']
})
export class LeBenefitsByCoverageComponent implements OnInit {
  @Input() electionData: any;
  @Input() data: any;

  electionCoverageData: any[] = [];

  constructor(
    private suppressedBenefitsPlansOptionsService: SuppressedBenefitsPlansOptionsService,
    private contentAliasService: ContentAliasService
  ) {}

  ngOnInit(): void {
    this.filterElectionCoverageData();
  }

  filterElectionCoverageData(): void {
    const enrollmentContent = this.contentAliasService.forData(this.data.employeeData);
    this.electionCoverageData = this.electionData.filter((benefitPlanOption: any) =>
      this.suppressedBenefitsPlansOptionsService.filterByBenefits(benefitPlanOption.ElectedBenefit, enrollmentContent)
    );
  }
}
