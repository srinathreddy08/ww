import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-coverage-grid',
  templateUrl: './coverage-grid.component.html',
  styleUrls: ['./coverage-grid.component.css']
})
export class CoverageGridComponent {
  @Input() data: any;
  @Input() desiredCategoriesToShow: any;
  @Input() showByBenefits?: boolean;
  @Input() desiredBenefitsToShow?: any;
  @Input() associationEditable: boolean;
  @Input() showPrimaryCareProviders: boolean;
  @Input() showCategoryNames: boolean;
  @Input() widgetTitle: string;
  @Input() hideTitle: boolean;
  @Input() hideButtons: boolean;
  @Input() initialCollapseOpen: boolean;
  @Input() collapseOnCancelOrApply: boolean;
  @Input() detailsLink: string;
  @Input() coverage: any;
  @Input() useSuppressingIneligibleBenefits: boolean;

  @Output() electionsSaved = new EventEmitter<void>();
  @Output() electionsRejected = new EventEmitter<void>();
  @Output() opened = new EventEmitter<void>();
  @Output() closed = new EventEmitter<void>();

  constructor() {}

  onSave() {
    this.electionsSaved.emit();
  }

  onReject() {
    this.electionsRejected.emit();
  }

  onOpen() {
    this.opened.emit();
  }

  onClose() {
    this.closed.emit();
  }
}
