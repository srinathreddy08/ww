import { Component, Input, OnInit } from '@angular/core';
import { ComparisonBenefitCategories } from '../../models/comparison-benefit-categories.model';
import { BenefitsService } from '../../services/benefits.service';
import { FeatureTogglesService } from '../../services/feature-toggles.service';
import { FlagsService } from '../../services/flags.service';

@Component({
  selector: 'app-benefit',
  templateUrl: './benefit.component.html',
  styleUrls: ['./benefit.component.css']
})
export class LeBenefitComponent implements OnInit {
  @Input() election: any;
  @Input() employee: any;
  @Input() data: any;

  benefitID: string;
  benefitCategory: string;
  benefitGroupingID: string;
  showCoveredDependents: boolean;
  showConditionalLabels: boolean;
  showListOfCoveredDependents: boolean;
  displayCosts: boolean;
  dependents: any[];
  showVoluntaryBenefitPostEnrollmentOutboundLink: boolean = false;
  voluntaryBenefitSignUpAlias: string;

  constructor(
    private benefitsService: BenefitsService,
    private featureToggles: FeatureTogglesService,
    private flags: FlagsService,
    private comparisonBenefitCategories: ComparisonBenefitCategories
  ) {}

  ngOnInit(): void {
    this.benefitID = this.election?.ElectedBenefit?.BenefitID;
    this.benefitCategory = this.election?.ElectedBenefit?.BenefitCategory;
    this.benefitGroupingID = this.election?.ElectedBenefit?.BenefitGroupingID;
    this.showCoveredDependents = this.calculateShowCoveredDependents();
    this.showConditionalLabels = this.calculateShowConditionalLabels();
    this.showListOfCoveredDependents = this.featureToggles.showListOfCoveredDependents;
    this.displayCosts = this.employee.SmallMarketData.DisplayCosts;

    if (this.showListOfCoveredDependents) {
      this.dependents = this.getDependents();
      this.showListOfCoveredDependents = this.showListOfCoveredDependents && this.benefitsService.isOptionDerivedBenefit(this.election.ElectedBenefit) && !this.benefitsService.isBenefitMedicalDentalOrVision(this.election.ElectedBenefit) && this.dependents;
    }

    const isConfirmationPage = this.flags.isConfirmationPage();
    if (isConfirmationPage) {
      const isVoluntaryBenefit = this.benefitGroupingID === 'VOLUNTARY';
      if (isVoluntaryBenefit) {
        this.showVoluntaryBenefitPostEnrollmentOutboundLink = true;
        this.voluntaryBenefitSignUpAlias = 'HB.LifeEvent.VoluntaryBenefits.CheckedOutLink.' + this.benefitID;
      }
    }
  }

  private calculateShowCoveredDependents(): boolean {
    const electedBenefit = this.election.ElectedBenefit;
    const isOptionDerivedBenefit = this.benefitsService.isOptionDerivedBenefit(electedBenefit);
    const isComparisonBenefitCategory = this.comparisonBenefitCategories.includes(electedBenefit.BenefitCategory);
    return isOptionDerivedBenefit && !isComparisonBenefitCategory;
  }

  private calculateShowConditionalLabels(): boolean {
    const suppressFlag = this.data.employeeData.Configuration['HB.Summary.SuppressOptionInfo'];
    return suppressFlag !== 'Y' || !this.election.ElectedPlan.IsNoCovPlan;
  }

  private getDependents(): any[] {
    if (!this.election.CoveredDependents) {
      return null;
    }

    let associatedDependentsSsn = null;

    if (this.election.option?.DependentAssociations?.length) {
      associatedDependentsSsn = this.election.option.DependentAssociations.map(association => association.DependentSsn);
    }

    if (this.election.source?.DependentAssociationList?.length) {
      associatedDependentsSsn = this.election.source.DependentAssociationList;
    }

    if (!associatedDependentsSsn) {
      return null;
    }

    const associatedDependents = this.election.CoveredDependents.filter(dependent => associatedDependentsSsn.includes(dependent.Source.Ssn));

    return associatedDependents.map(dependent => ({
      FirstName: dependent.Source.FirstName,
      LastName: dependent.Source.LastName,
      BirthDate: dependent.Source.BirthDate
    }));
  }
}
