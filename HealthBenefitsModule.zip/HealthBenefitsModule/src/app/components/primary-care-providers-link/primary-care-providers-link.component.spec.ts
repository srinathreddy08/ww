import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PrimaryCareProvidersLinkComponent } from './primary-care-providers-link.component';

describe('PrimaryCareProvidersLinkComponent', () => {
  let component: PrimaryCareProvidersLinkComponent;
  let fixture: ComponentFixture<PrimaryCareProvidersLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrimaryCareProvidersLinkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimaryCareProvidersLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Add more tests to cover the component logic
});
