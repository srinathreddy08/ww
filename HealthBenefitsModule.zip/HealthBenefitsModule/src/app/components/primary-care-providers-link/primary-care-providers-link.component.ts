import { Component, Input, OnInit } from '@angular/core';
import { PrimaryCareProvidersService } from '../../services/primary-care-providers.service';
import { OverlayService } from '../../services/overlay.service';
import { PcpUpdatedEventService } from '../../services/pcp-updated-event.service';
import { PcpDetailsService } from '../../services/pcp-details.service';

@Component({
  selector: 'app-primary-care-providers-link',
  templateUrl: './primary-care-providers-link.component.html',
  styleUrls: ['./primary-care-providers-link.component.css']
})
export class PrimaryCareProvidersLinkComponent implements OnInit {
  @Input() coverage: any;
  @Input() data: any;

  categories = ['MEDICAL', 'DENTAL'];
  currentProviders: any = null;
  pcpDetailsForIndividuals: any = null;

  constructor(
    private primaryCareProvidersService: PrimaryCareProvidersService,
    private overlayService: OverlayService,
    private pcpUpdatedEventService: PcpUpdatedEventService,
    private pcpDetailsService: PcpDetailsService
  ) {}

  ngOnInit(): void {
    this.updateProviders();
    this.pcpUpdatedEventService.subscribe(this.updateProviders.bind(this));
  }

  updateProviders(): void {
    const employeeData = this.coverage.employeeData;
    const employee = this.coverage.employee;
    const shoppingCart = this.data.cartData.ShoppingCart;
    const elections = this.coverage.InitialElections;

    this.primaryCareProvidersService.getProviders(employeeData, employee, elections, this.categories)
      .then(providers => {
        this.currentProviders = providers;
        const filteredCategories = this.categories.filter(category =>
          !Object.values(this.currentProviders[category] || {}).every(provider => provider.EmployeeProviderID === null)
        );

        const newElections = this.getNewElectionsForBenefitCategories(filteredCategories);
        const physiciansByCategory = this.primaryCareProviders2PhysiciansByCategory(this.currentProviders);

        this.pcpDetailsForIndividuals = this.pcpDetailsService.getPcpDetailsForIndividuals(employeeData, newElections, shoppingCart, physiciansByCategory);
      });
  }

  primaryCareProviders2PhysiciansByCategory(providers: any): any {
    return Object.fromEntries(Object.entries(providers).map(([category, providersForCategory]) =>
      [category, { PrimaryCarePhysicians: Object.values(providersForCategory) }]
    ));
  }

  getNewElectionsForBenefitCategories(categories: string[]): any {
    return categories.reduce((resultObject, benefitCategory) => {
      resultObject[benefitCategory] = { benefit: this.findBenefit(benefitCategory) };
      return resultObject;
    }, {});
  }

  findBenefit(benefitCategory: string): any {
    return this.data.cartData.ShoppingCart.find(benefit =>
      benefit.BenefitCategory === benefitCategory && benefit.BenefitID === benefitCategory
    );
  }

  showPrimaryCareProviders(): boolean {
    return this.currentProviders && Object.values(this.currentProviders).some(providersInCategory =>
      Object.values(providersInCategory).some(provider => provider.EmployeeProviderID)
    );
  }

  viewPrimaryCareProviders(): void {
    this.overlayService.open('/life-event/views/pcp/pcp-view-overlay', {
      employeeData: this.coverage.employeeData,
      primaryCareProviders: this.currentProviders,
      employee: this.coverage.employee,
      categories: this.categories.filter(category =>
        !Object.values(this.currentProviders[category] || {}).every(provider => provider.EmployeeProviderID === null)
      ),
      pcpDetails: this.pcpDetailsForIndividuals.pcpDetails.filter(pcp =>
        Object.values(pcp).some(pcpByCategory => pcpByCategory.pcpId)
      )
    });
  }
}
