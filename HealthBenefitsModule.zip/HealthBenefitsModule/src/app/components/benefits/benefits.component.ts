import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { BenefitService } from '../services/benefit.service';
import { ShoppingCartService } from '../services/shopping-cart.service';
import { NavigationService } from '../services/navigation.service';
import { PubSubService } from '../services/pubsub.service';
import { AnnualAmountDisplayService } from '../services/annual-amount-display.service';
import { CoverageEffectiveDateService } from '../services/coverage-effective-date.service';
import { ExecuteAddToCartActionService } from '../services/execute-add-to-cart-action.service';
import { BenefitCategoriesService } from '../services/benefit-categories.service';
import { ContentAliasService } from '../services/content-alias.service';
import { FlagsService } from '../services/flags.service';
 
@Component({
  selector: 'app-benefits',
  templateUrl: './benefits.component.html',
  styleUrls: ['./benefits.component.css']
})
export class BenefitsComponent implements OnInit, OnDestroy {
  @Input() isCart: boolean = false;
  @Input() isLifeEventPage: boolean = false;
  @Input() employeeType: string = '';
  @Input() externalEOI: boolean = false;
  @Input() section: string = '';
  @Input() showCompanyCont: boolean = false;
  public employee: any;
  public electionData: any[] = [];
  public voluntaryBenefits: any[] = [];
  public hasEditableBenefits: boolean = false;
  public hasNonEditableBenefits: boolean = false;
  public benefitsAvailableToUpdate: any[] = [];
  public benefitsNotAvailableToUpdate: any[] = [];
  private subscriptions: Subscription = new Subscription();
 
  constructor(
    private benefitService: BenefitService,
    private shoppingCartService: ShoppingCartService,
    private navigationService: NavigationService,
    private pubsubService: PubSubService,
    private router: Router,
    private annualAmountDisplayService: AnnualAmountDisplayService,
    private coverageEffectiveDateService: CoverageEffectiveDateService,
    private executeAddToCartActionService: ExecuteAddToCartActionService,
    private benefitCategoriesService: BenefitCategoriesService,
    private contentAliasService: ContentAliasService,
    private flagsService: FlagsService
  ) {}
 
  ngOnInit(): void {
    this.initializeComponent();
    this.subscriptions.add(
      this.pubsubService.subscribe('cartUpdated', (cart: any) => {
        this.updateBenefitList(cart.data);
      })
    );
  }
 
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
 
  private initializeComponent(): void {
    this.employee = this.benefitService.getEmployeeData(this.employeeType);
    if (!this.employee) return;
    this.updateBenefitList(this.benefitService.getCartData());
  }
 
  private updateBenefitList(cartData: any): void {
    if (!this.employee) return;
 
    if (this.isCart) {
      this.benefitService.copyOptionCostsFromCart(cartData);
    }
 
    const benefitList = this.benefitService.createBenefitList({
      cart: cartData,
      employee: this.employee,
      isCart: this.isCart,
      isLifeEventPage: this.isLifeEventPage,
      section: this.section
    });
 
    this.benefitsAvailableToUpdate = benefitList.byStatus.benefitsAvailableToUpdate;
    this.benefitsNotAvailableToUpdate = benefitList.byStatus.benefitsNotAvailableToUpdate;
    this.hasEditableBenefits = this.benefitsAvailableToUpdate.length > 0;
    this.hasNonEditableBenefits = this.benefitsNotAvailableToUpdate.length > 0;
  }
 
  public benefitCTA(election: any): void {
    const nav = this.navigationService.getNavMapping(election.ElectedBenefit.BenefitCategory, this.section, election.ElectedBenefit.BenefitType);
    this.router.navigate([nav.tab, nav.subtab], { queryParams: { benefitId: election.ElectedBenefit.BenefitID.toLowerCase() } });
    window.scrollTo(0, 0);
  }
 
  public removeInterest(benefitId: string): void {
    this.executeAddToCartActionService.execute(() => this.removeInterestAsync(benefitId));
  }
 
  private async removeInterestAsync(benefitId: string): Promise<void> {
    const shoppingCartItem = this.benefitService.findShoppingCartItem(benefitId);
    if (!shoppingCartItem) return;
 
    shoppingCartItem.IsInterested = false;
    const options = {
      items: [shoppingCartItem],
      lifeEvent: this.benefitService.getLifeEvent(),
      keepCosts: false,
      visitedBenefitId: null,
      editedBenefitId: shoppingCartItem.BenefitID
    };
 
    const cartData = await this.shoppingCartService.batchAdd(options);
    this.updateBenefitList(cartData);
  }
}