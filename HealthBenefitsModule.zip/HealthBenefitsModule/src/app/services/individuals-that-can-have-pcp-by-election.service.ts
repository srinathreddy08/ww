import { Injectable } from '@angular/core';
import { PcpDomainHelpers } from './pcp-domain-helpers.service';

@Injectable({
  providedIn: 'root'
})
export class IndividualsThatCanHavePcpByElectionService {
  constructor(private pcpDomainHelpers: PcpDomainHelpers) {}

  getIndividualsThatCanHavePcp(election: any, employeeData: any): any[] {
    const pcpDomain = this.pcpDomainHelpers.forData(employeeData);

    const newPlan = () => pcpDomain.pending.plan(election);
    const currentCoveragesPlan = () => pcpDomain.current.electedPlan(election);
    const pendingEmployee = () => pcpDomain.pending.employee();

    const samePlanWasElectedInCurrentCoverages = () => currentCoveragesPlan() && currentCoveragesPlan().PlanID === newPlan().PlanID;
    const differentPlanWasElectedInCurrentCoverages = () => !samePlanWasElectedInCurrentCoverages();

    const ssnsOfAllCoveredIndividuals = () => [pendingEmployee().Ssn, ...election.DependentAssociationList];
    const ssnsOfIndividualsCoveredInCurrentCoverages = () => currentCoveragesPlan().ElectedOption.DependentAssociations.map((assoc: any) => assoc.DependentSsn);
    const ssnsOfNewlyCoveredIndividuals = () => election.DependentAssociationList.filter((ssn: any) => !ssnsOfIndividualsCoveredInCurrentCoverages().includes(ssn));

    const ssnsOfIndividualsThatCanHavePcp = () => differentPlanWasElectedInCurrentCoverages() ? ssnsOfAllCoveredIndividuals() : ssnsOfNewlyCoveredIndividuals();

    const allIndividuals = () => [pendingEmployee(), ...pendingEmployee().Dependents];

    const ssns = ssnsOfIndividualsThatCanHavePcp();

    return allIndividuals().filter((individual: any) => ssns.includes(individual.Ssn));
  }
}
