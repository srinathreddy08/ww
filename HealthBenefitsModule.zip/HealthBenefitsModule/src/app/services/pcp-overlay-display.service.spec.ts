import { TestBed } from '@angular/core/testing';
import { PcpOverlayDisplayService } from './pcp-overlay-display.service';
import { PcpOverlayEnabledService } from './pcp-overlay-enabled.service';
import { ElectionRequiresPcpDataService } from './election-requires-pcp-data.service';

class MockPcpOverlayEnabledService {
  isEnabled(employeeData: any) { return true; }
}

class MockElectionRequiresPcpDataService {
  isRequired(election: any, employeeData: any) { return true; }
}

describe('PcpOverlayDisplayService', () => {
  let service: PcpOverlayDisplayService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PcpOverlayDisplayService,
        { provide: PcpOverlayEnabledService, useClass: MockPcpOverlayEnabledService },
        { provide: ElectionRequiresPcpDataService, useClass: MockElectionRequiresPcpDataService }
      ]
    });
    service = TestBed.inject(PcpOverlayDisplayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true when all conditions are met', () => {
    const result = service.pcpOverlayShouldBeShown({}, {}, () => true);
    expect(result).toBe(true);
  });

  it('should return false when additional conditions are not met', () => {
    const result = service.pcpOverlayShouldBeShown({}, {}, () => false);
    expect(result).toBe(false);
  });
});
