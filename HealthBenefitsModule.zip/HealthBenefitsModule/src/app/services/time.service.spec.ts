import { TestBed } from '@angular/core/testing';
import { TimeService } from './time.service';
import { TimeOffset } from './time-offset.service';

class MockTimeOffset {
  IsOffsetEnabled = true;
  Days = 1;
  Minutes = 60;
}

describe('TimeService', () => {
  let service: TimeService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TimeService,
        { provide: TimeOffset, useClass: MockTimeOffset }
      ]
    });
    service = TestBed.inject(TimeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return the current date with offset', () => {
    const now = new Date();
    const offsetDate = service.now();
    expect(offsetDate.getDate()).toBe(now.getDate() + 1);
    expect(offsetDate.getHours()).toBe(now.getHours() + 1);
  });

  it('should return the current date without offset when offset is disabled', () => {
    service = new TimeService({ IsOffsetEnabled: false, Days: 0, Minutes: 0 } as TimeOffset);
    const now = new Date();
    const offsetDate = service.now();
    expect(offsetDate.getDate()).toBe(now.getDate());
    expect(offsetDate.getHours()).toBe(now.getHours());
  });
});
