import { Injectable } from '@angular/core';
import { EmployeeCoverageService } from './employee-coverage.service';
import { BenefitsService } from './benefits.service';

@Injectable({
  providedIn: 'root'
})
export class AmountBasedBenefitService {
  constructor(
    private employeeCoverageService: EmployeeCoverageService,
    private benefitsService: BenefitsService
  ) {}

  shoppingCartProvider(shoppingCart: any) {
    return {
      getElectedOption: (benefit: any) => {
        const cartItem = shoppingCart[benefit.BenefitID];
        return {
          EmployeePayPeriodCost: cartItem.EmployeePayPeriodCost,
          EmployerAnnualCost: cartItem.EmployerAnnualCost,
          EmployeeAnnualCost: cartItem.EmployeeAnnualCost,
          AmountElected: cartItem.Amount,
          EmployerPayPeriodCost: cartItem.EmployerPayPeriodCost
        };
      }
    };
  }

  domProvider() {
    return {
      getElectedOption: (benefit: any) => {
        if (!benefit.ElectedPlan) {
          return null;
        }
        return benefit.ElectedPlan.ElectedOption;
      }
    };
  }

  forData(employeeData: any, employeeType: string) {
    const service = {
      getHsaBenefit: () => {
        const benefits = this.getBenefits(employeeData, employeeType);
        return benefits.find(this.benefitsService.isHSABenefit);
      },
      getElectionData: (benefit: any, optionDataProvider: any) => {
        if (!benefit) {
          return null;
        }

        const electedOption = optionDataProvider.getElectedOption(benefit);

        if (!electedOption) {
          return null;
        }

        const hsaBenefit = service.getHsaBenefit();

        if (hsaBenefit && hsaBenefit.BenefitID === benefit.BenefitID) {
          const hsaFrontLoadingBenefit = this.getFrontLoadingBenefit(benefit, employeeData, employeeType);

          if (hsaFrontLoadingBenefit) {
            const electedHsaFrontLoadingOption = optionDataProvider.getElectedOption(hsaFrontLoadingBenefit);
            return {
              EmployeePayPeriodCost: electedOption.EmployeePayPeriodCost,
              YearToDateContributions: electedOption.YearToDateContributions + electedHsaFrontLoadingOption.YearToDateContributions,
              YearToDateReconciledContributions: electedOption.YearToDateReconciledContributions + electedHsaFrontLoadingOption.YearToDateReconciledContributions,
              EmployerAnnualCost: electedOption.EmployerAnnualCost + electedHsaFrontLoadingOption.EmployerAnnualCost,
              EmployeeAnnualCost: electedOption.EmployeeAnnualCost + electedHsaFrontLoadingOption.AmountElected,
              AmountElected: electedOption.AmountElected + electedHsaFrontLoadingOption.AmountElected,
              FrontLoading: electedHsaFrontLoadingOption,
              FrontLoadingBenefit: hsaFrontLoadingBenefit,
              EmployerPayPeriodCost: electedOption.EmployerPayPeriodCost
            };
          }
        }

        return electedOption;
      }
    };
    return service;
  }

  getFrontLoadingBenefit(benefit: any, enrollment: any, employeeType: string) {
    const frontLoadingPairsSetting =
      enrollment.Configuration['HB.ConnectHSAAndHSAFrontLoadBenefit'];

    if (!frontLoadingPairsSetting) {
      return null;
    }

    const frontLoadingMapping = Object.fromEntries(
      frontLoadingPairsSetting.split(';').map((pairText: string) => pairText.split(','))
    );

    const frontLoadingBenefitId = frontLoadingMapping[benefit.BenefitID];
    const benefits = this.getBenefits(enrollment, employeeType);
    return benefits[frontLoadingBenefitId];
  }

  private getBenefits(enrollment: any, employeeType: string) {
    let employee;

    if (employeeType === 'ResolveEmployeeCoverage') {
      employee = this.employeeCoverageService.getEmployeeCoverage(enrollment.Employee);
    } else {
      employee = enrollment.Employee[employeeType];
    }

    return employee.LifeEvents[0].EligibleBenefitsMap;
  }
}
