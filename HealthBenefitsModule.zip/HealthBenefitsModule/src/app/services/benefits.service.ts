import { Injectable } from '@angular/core';
import { BenefitCategoryMap } from './benefit-category-map';
import { StringService } from './string.service';
import { find } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class BenefitsService {
  constructor(
    private benefitCategoryMap: BenefitCategoryMap,
    private stringService: StringService
  ) {}

  isBenefitHiddenFromUser(benefit: any): boolean {
    return benefit.BenefitType === 'HSAFL';
  }

  isOptionDerivedBenefit = this.isBenefitOfType('OPTDRV');
  isHSABenefit = this.isBenefitOfType('HSA');
  isHSAFLBenefit = this.isBenefitOfType('HSAFL');
  isAdditionalBenefitCategory = this.isAdditionalBenefitCategory('ADDITIONAL');
  isHCFSABenefit = this.isHCFSABenefit();
  isDCFSABenefit = this.isBenefitPlanTypeEqualsTo(31);
  isLPFSABenefit = this.isBenefitPlanTypeEqualsTo(32);
  isAmountBasedBenefit = this.isBenefitOfType('AMT');
  isAmountDirectedBenefit = this.isBenefitOfType('AMTDRC');
  isOptionDirectedBenefit = this.isBenefitOfType('OPTDRC');
  isBenefitOfMedicalCategory = this.isBenefitOfCategory('MEDICAL');
  isBenefitOfVoluntaryCategory = this.isBenefitOfVoluntaryCategory;
  isBenefitOfCreditCategory = this.isBenefitOfCategory('CREDIT');
  isBenefitOfSurchargeCategory = this.isBenefitOfCategory('SURCHARGE');
  isRXBenefitCategory = this.isBenefitOfCategory('PHARMACY');
  isBenefitOfDentalCategory = this.isBenefitOfCategory('DENTAL');
  isBenefitOfVisionCategory = this.isBenefitOfCategory('VISION');
  isBenefitOfMedicalId = this.isBenefitOfId('MEDICAL');
  isBenefitOfDentalId = this.isBenefitOfId('DENTAL');
  isBenefitMedicalDentalOrVision = this.isBenefitMedicalDentalOrVision;
  isComparisonBenefit = this.isComparisonBenefit;
  isPcpBenefit = this.isPcpBenefit;
  pcpCategories = this.getPcpBenefitCategories();

  private isComparisonBenefit(benefit: any): boolean {
    return (this.benefitCategoryMap[benefit.BenefitCategory] || this.benefitCategoryMap['default']).isComparison;
  }

  private getPcpBenefitCategories(): string[] {
    return ['MEDICAL', 'DENTAL'];
  }

  private isBenefitOfVoluntaryCategory(benefit: any): boolean {
    return this.stringService.startsWith(benefit.BenefitCategory, 'VB_');
  }

  private isPcpBenefit(benefit: any): boolean {
    return (this.benefitCategoryMap[benefit.BenefitCategory] || this.benefitCategoryMap['default']).isPcpCategory;
  }

  private isBenefitMedicalDentalOrVision(benefit: any): boolean {
    return this.isBenefitOfMedicalCategory(benefit) || this.isBenefitOfDentalCategory(benefit) || this.isBenefitOfVisionCategory(benefit);
  }

  private isHCFSABenefit() {
    return (benefit: any): boolean => {
      const isSpendingBenefitCategory = benefit.BenefitCategory === 'SPENDING';
      const isHCFSABenefitPlanType = this.isBenefitPlanTypeEqualsTo(30)(benefit);
      const isHSAFLBenefit = this.isBenefitOfType('HSAFL')(benefit);

      return !this.isHSABenefit(benefit) && !isHSAFLBenefit && isSpendingBenefitCategory && isHCFSABenefitPlanType;
    };
  }

  private isBenefitOfType(benefitType: string) {
    return (benefit: any): boolean => {
      return benefit.BeneFlexYearBenefitTypeInd === benefitType;
    };
  }

  private isAdditionalBenefitCategory(benefitCategory: string) {
    return (benefit: any): boolean => {
      return benefit.BenefitCategory === benefitCategory;
    };
  }

  private isBenefitPlanTypeEqualsTo(planType: number) {
    return (benefit: any): boolean => {
      const covPlan = find(benefit.EligiblePlans, { IsNoCovPlan: false });
      return covPlan && covPlan.Type === planType;
    };
  }

  private isBenefitOfCategory(category: string) {
    return (benefit: any): boolean => {
      return benefit.BenefitCategory === category;
    };
  }

  private isBenefitOfId(benefitId: string) {
    return (benefit: any): boolean => {
      return benefit.BenefitID === benefitId;
    };
  }
}
