import { Injectable } from '@angular/core';
import { EXPERT_GUIDANCE_GLOBAL } from '../constants/expert-guidance-global.constant';

@Injectable({
  providedIn: 'root'
})
export class ExpertGuidanceStateService {
  isDoItYourselfFlow(): boolean {
    return EXPERT_GUIDANCE_GLOBAL.isDoItYourselfFlow;
  }

  useSuggestedPackageResource(): boolean {
    return !!EXPERT_GUIDANCE_GLOBAL.useSuggestedPackageResource;
  }

  parseUseSuggestedPackageResourceParameter(useSuggestedPackageResourceParameter: any): boolean {
    return useSuggestedPackageResourceParameter === undefined ||
           useSuggestedPackageResourceParameter === null ? this.useSuggestedPackageResource() : useSuggestedPackageResourceParameter;
  }
}
