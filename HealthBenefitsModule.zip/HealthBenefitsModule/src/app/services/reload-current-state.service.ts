import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ReloadCurrentStateService {
  constructor(private router: Router) {}

  reloadCurrentState(): Promise<boolean> {
    const currentUrl = this.router.url;
    return this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      return this.router.navigate([currentUrl]);
    });
  }
}
