import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { ReloadCurrentStateService } from './reload-current-state.service';

class MockRouter {
  url = '/test';
  navigateByUrl(url: string, options: any): Promise<boolean> {
    return Promise.resolve(true);
  }
  navigate(commands: any[]): Promise<boolean> {
    return Promise.resolve(true);
  }
}

describe('ReloadCurrentStateService', () => {
  let service: ReloadCurrentStateService;
  let router: Router;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ReloadCurrentStateService,
        { provide: Router, useClass: MockRouter }
      ]
    });
    service = TestBed.inject(ReloadCurrentStateService);
    router = TestBed.inject(Router);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should reload the current state', async () => {
    spyOn(router, 'navigateByUrl').and.callThrough();
    spyOn(router, 'navigate').and.callThrough();

    await service.reloadCurrentState();

    expect(router.navigateByUrl).toHaveBeenCalledWith('/', { skipLocationChange: true });
    expect(router.navigate).toHaveBeenCalledWith(['/test']);
  });
});
