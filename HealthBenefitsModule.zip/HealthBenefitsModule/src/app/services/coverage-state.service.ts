import { Injectable } from '@angular/core';
import { CoverageStateFactoryService } from './coverage-state-factory.service';
import { CoverageSourcesService } from './coverage-sources.service';
import { DisplayedComparisonCategories } from './displayed-comparison-categories';
import { ContentAliasService } from './content-alias.service';
import { CoverageGridConfigService } from './coverage-grid-config.service';

@Injectable({
  providedIn: 'root'
})
export class CoverageStateService {
  constructor(
    private coverageStateFactoryService: CoverageStateFactoryService,
    private coverageSourcesService: CoverageSourcesService,
    private displayedComparisonCategories: DisplayedComparisonCategories,
    private contentAliasService: ContentAliasService,
    private coverageGridConfigService: CoverageGridConfigService
  ) {}

  getCoverageState(employee: any, data: any, isEditable: boolean) {
    const currentCoverage = this.getCurrentCoverage(employee, data, isEditable);
    const categoriesToShow = this.getCategoriesToShow(currentCoverage);

    return {
      currentCoverage,
      categoriesToShow,
      orderedCategoriesToShow: this.getOrderedCategoriesToShow(categoriesToShow),
      showCoverage: this.showCoverage(employee, data, categoriesToShow)
    };
  }

  private showCoverage(employee: any, data: any, categoriesToShow: any): boolean {
    if (!categoriesToShow || Object.keys(categoriesToShow).length === 0) {
      return false;
    }

    if (employee !== data.employeeData.Data.PendingEmployee) {
      return true;
    }

    return this.coverageGridConfigService.forData(data.employeeData).shouldShowCoverage;
  }

  private getCurrentCoverage(employee: any, data: any, isEditable: boolean) {
    const coverageSource = this.getCoverageSource(employee, data, isEditable);
    return this.coverageStateFactoryService.getCoverageByCategories(coverageSource);
  }

  private getCoverageSource(employee: any, data: any, isEditable: boolean) {
    if (isEditable) {
      return this.coverageSourcesService.fromCartElections(data, employee, data.cartData);
    }
    return this.coverageSourcesService.fromDomElections(data.employeeData, employee);
  }

  private getCategoriesToShow(currentCoverage: any) {
    return Object.fromEntries(
      Object.entries(currentCoverage.Categories).filter(([key, category]) =>
        this.displayedComparisonCategories.includes(category.BenefitCategory)
      )
    );
  }

  private getOrderedCategoriesToShow(categoriesToShow: any) {
    return this.displayedComparisonCategories
      .map(categoryName => categoriesToShow[categoryName])
      .filter(Boolean);
  }
}
