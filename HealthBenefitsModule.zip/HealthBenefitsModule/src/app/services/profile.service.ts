import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { PubSubService } from './pubsub.service';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  private profileResourceCache = new Map<string, any>();
  private apiUrl = '/api/profile';

  constructor(private http: HttpClient, private pubsub: PubSubService) {}

  get(): Observable<any> {
    const cacheKey = 'getProfile';
    if (this.profileResourceCache.has(cacheKey)) {
      return this.profileResourceCache.get(cacheKey);
    }
    const request = this.http.get(`${this.apiUrl}/getProfile`).pipe(
      tap(data => this.profileResourceCache.set(cacheKey, data))
    );
    return request;
  }

  save(data: any): Observable<any> {
    this.profileResourceCache.clear();
    return this.http.post(`${this.apiUrl}/saveProfile`, data).pipe(
      tap(() => this.pubsub.publish('profileWasUpdated'))
    );
  }

  acceptTermsAndConditions(): Observable<any> {
    return this.http.post(`${this.apiUrl}/acceptParticipantTermsAndConditions`, {});
  }

  markDomainOutageResponse(): Observable<any> {
    return this.http.post(`${this.apiUrl}/markDomainOutageResponse`, {});
  }

  getProfileLookupData(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getProfileLookupData`);
  }

  getFieldLengthData(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getProfileFieldlengthData`);
  }
}
