import { TestBed } from '@angular/core/testing';
import { ParseLinkService } from './parse-link.service';

describe('ParseLinkService', () => {
  let service: ParseLinkService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ParseLinkService]
    });
    service = TestBed.inject(ParseLinkService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should parse link correctly', () => {
    const link = 'target="_blank" url="http://example.com" title="Example"';
    const parsedLink = service.parseLink(link);
    expect(parsedLink.title).toBe('Example');
    expect(parsedLink.target).toBe('_blank');
    expect(parsedLink.url).toBe('http://example.com');
  });

  it('should open link in new window when target is _blank', () => {
    const link = 'target="_blank" url="http://example.com" title="Example"';
    const parsedLink = service.parseLink(link);
    spyOn(window, 'open');
    spyOn(window.location, 'assign');
    parsedLink.action();
    expect(window.open).toHaveBeenCalledWith('http://example.com');
    expect(window.location.assign).toHaveBeenCalledWith('/dashboard');
  });

  it('should open link in current window when target is not _blank', () => {
    const link = 'target="_self" url="http://example.com" title="Example"';
    const parsedLink = service.parseLink(link);
    spyOn(window.location, 'assign');
    parsedLink.action();
    expect(window.location.assign).toHaveBeenCalledWith('http://example.com');
  });
});
