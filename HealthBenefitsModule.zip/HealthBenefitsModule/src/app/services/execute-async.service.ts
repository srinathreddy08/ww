import { Injectable } from '@angular/core';
import { of, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExecuteAsyncService {
  executeAsync(action: any): Observable<any> {
    if (typeof action !== 'function') {
      return of(action);
    }

    return new Observable(observer => {
      try {
        const result = action();
        observer.next(result);
        observer.complete();
      } catch (error) {
        observer.error(error);
      }
    });
  }
}
