import { Injectable } from '@angular/core';
import { IndividualsThatCanHavePcpByElectionService } from './individuals-that-can-have-pcp-by-election.service';
import { PcpDomainHelpersService } from './pcp-domain-helpers.service';
import { BenefitsService } from './benefits.service';

@Injectable({
  providedIn: 'root'
})
export class ElectionRequiresPcpDataToBeCollectedService {
  constructor(
    private individualsThatCanHavePcpByElection: IndividualsThatCanHavePcpByElectionService,
    private pcpDomainHelpers: PcpDomainHelpersService,
    private benefitsService: BenefitsService
  ) {}

  check(election: any, employeeData: any): boolean {
    const pcpDomain = this.pcpDomainHelpers.forData(employeeData);
    const benefit = pcpDomain.pending.benefit(election);

    const hasIndividualsThatCanHavePcp = (): boolean => {
      const individuals = this.individualsThatCanHavePcpByElection(election, employeeData);
      return individuals.length > 0;
    };

    const planRequiresPcpDataToBeCollected = (): boolean => {
      const newPlan = pcpDomain.pending.plan(election);
      return newPlan.PlanYearDefPCPRequirement === 'R';
    };

    return (
      (this.benefitsService.isBenefitOfMedicalCategory(benefit) && this.benefitsService.isBenefitOfMedicalId(benefit)) ||
      (this.benefitsService.isBenefitOfDentalCategory(benefit) && this.benefitsService.isBenefitOfDentalId(benefit))
    ) &&
    planRequiresPcpDataToBeCollected() &&
    hasIndividualsThatCanHavePcp();
  }
}
