import { Injectable } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { ExpertGuidanceGlobal } from '../constants/expert-guidance-global.constant';
import { MbcContentAndDataService } from './mbc-content-and-data.service';
import { ExecuteWithSpinnerService } from './execute-with-spinner.service';
import { IsDesignV2Service } from './is-design-v2.service';
import { IsBeneficiariesV2Service } from './is-beneficiaries-v2.service';
import { EgBeneficiariesNavigationService } from './eg-beneficiaries-navigation.service';
import { BeneficiaryCollectionRequiredService } from './beneficiary-collection-required.service';

@Injectable({
  providedIn: 'root'
})
export class ExpertGuidanceTransitionService {
  constructor(
    private router: Router,
    private mbcContentAndData: MbcContentAndDataService,
    private executeWithSpinner: ExecuteWithSpinnerService,
    private isDesignV2: IsDesignV2Service,
    private isBeneficiariesV2: IsBeneficiariesV2Service,
    private egBeneficiariesNavigation: EgBeneficiariesNavigationService,
    private beneficiaryCollectionRequired: BeneficiaryCollectionRequiredService
  ) {
    this.setupTransitions();
  }

  private setupTransitions(): void {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.handleNavigationStart(event);
      } else if (event instanceof NavigationEnd) {
        this.handleNavigationEnd(event);
      } else if (event instanceof NavigationError) {
        this.handleNavigationError(event);
      }
    });
  }

  private async handleNavigationStart(event: NavigationStart): Promise<void> {
    const toStateName = event.url;
    ExpertGuidanceGlobal.useSuggestedPackageResource = !!toStateName.includes('useSuggestedPackageResource');
    ExpertGuidanceGlobal.isDoItYourselfFlow = !toStateName.includes('isDoItYourselfFlow') || toStateName.includes('isDoItYourselfFlow=true');

    const enrollment = await this.executeWithSpinner.execute(() => this.mbcContentAndData.getEnrollment().toPromise());
    // Assuming isDesignV2 and isBeneficiariesV2 are functions that return boolean
    const isDesignV2 = this.isDesignV2.check(enrollment, toStateName);
    const isBeneficiariesV2 = this.isBeneficiariesV2.check(enrollment, isDesignV2);
  }

  private handleNavigationEnd(event: NavigationEnd): void {
    const toStateName = event.url;

    if (toStateName.includes('beneficiaries') || toStateName.includes('beneficiaries-review')) {
      const isReviewPage = toStateName.includes('beneficiaries-review');
      this.mbcContentAndData.getEnrollment().toPromise().then(enrollment => {
        const lifeEvent = enrollment.Data.PendingEmployee.LifeEvents[0];
        const benefitIdsToReset = isReviewPage ? this.beneficiaryCollectionRequired.getBeneficiaryCollectionRequiredSetToNoCovIds(lifeEvent) : [];
        this.egBeneficiariesNavigation.initiateBeneficiariesMenu(isReviewPage, benefitIdsToReset);
      });
    }
  }

  private handleNavigationError(event: NavigationError): void {
    const fromStateName = event.url;
    ExpertGuidanceGlobal.useSuggestedPackageResource = !!fromStateName.includes('useSuggestedPackageResource');
    ExpertGuidanceGlobal.isDoItYourselfFlow = !fromStateName.includes('isDoItYourselfFlow') || fromStateName.includes('isDoItYourselfFlow=true');
  }
}
