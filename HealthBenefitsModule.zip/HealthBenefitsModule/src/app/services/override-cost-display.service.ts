import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class OverrideCostDisplayService {
  constructor(private contentAliasService: ContentAliasService) {}

  forData(employeeData: any) {
    const data = this.contentAliasService.forData(employeeData);

    return {
      getOverridenZeroCostLabel: (benefitId: string) => this.getOverridenZeroCostLabel(data, benefitId)
    };
  }

  private getOverridenZeroCostLabel(data: any, benefitId: string): string | null {
    const overrideCostsPointData = data.getAlias('HB.LifeEvent.OverrideZeroCost');
    const benefitsList = overrideCostsPointData.getField('HB.LIFEEVENT.OVERRIDEZEROCOST').asStringArray();
    const overrideCostLabel = overrideCostsPointData.getLinkedContent().value;

    const shouldCostBeOverriden = benefitsList.includes(benefitId);

    return shouldCostBeOverriden ? overrideCostLabel : null;
  }
}
