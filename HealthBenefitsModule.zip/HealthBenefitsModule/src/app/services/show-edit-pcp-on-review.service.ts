import { Injectable } from '@angular/core';
import { ShowEditPcpOverlayIfNeededService } from './show-edit-pcp-overlay-if-needed.service';
import { every } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class ShowEditPcpOnReviewService {
  constructor(private showEditPcpOverlayIfNeeded: ShowEditPcpOverlayIfNeededService) {}

  execute(newElections: any, employeeData: any, shoppingCart: any, isReviewMode: boolean): any {
    if (every(newElections, { benefit: null })) {
      return null;
    }

    const additionalConditions = () => true;
    const showAllIndividualsRequiringPcp = (individuals: any) => individuals;

    return this.showEditPcpOverlayIfNeeded.execute(newElections, employeeData, additionalConditions,
      showAllIndividualsRequiringPcp, shoppingCart.ShoppingCart, isReviewMode);
  }
}
