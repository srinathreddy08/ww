import { Injectable } from '@angular/core';
import { DependentVerificationService } from './dependent-verification.service';
import { StringService } from './string.service';
import { BenefitsService } from './benefits.service';
import { CoverageSourcesService } from './coverage-sources.service';
import { EnrollmentRules } from './enrollment-rules.service';
import { compact, includes, find, map, filter, some, zipObject } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class RequiredDependentVerificationDocumentsService {
  constructor(
    private dependentVerificationService: DependentVerificationService,
    private stringService: StringService,
    private benefitsService: BenefitsService,
    private coverageSourcesService: CoverageSourcesService
  ) {}

  getRequiredDependentVerificationDocuments(employeeData: any, cartData: any): any[] {
    return map(this.getMappedContentForAliases(employeeData, 'HB.CommonElements.DependentVerification.TableData', 'RELATIONSHIPTYPES'), (content, requiredRelTypes) => {
      return {
        Title: content.Title || '',
        Description: content.Copy || '',
        Dependents: this.getDependentsOfTypes(employeeData, cartData, requiredRelTypes)
      };
    }).filter(docType => some(docType.Dependents));
  }

  private getDependentsOfTypes(employeeData: any, cartData: any, requiredRelTypes: any): any[] {
    return map(filter(this.getDependentsFromSourcesByPriority(employeeData), this.isVerificationRequired.bind(this, employeeData, cartData)), 'dependent')
      .map(dependent => this.mapDependent(dependent, requiredRelTypes))
      .filter(dependent => includes(this.stringService.convertArrayStringToArray(requiredRelTypes), dependent.RelationType));
  }

  private mapDependent(dependent: any, requiredRelTypes: any): any {
    return {
      FullName: `${dependent.FirstName} ${dependent.LastName}`,
      Status: this.getDependentStatus(dependent),
      BirthDate: dependent.BirthDate,
      RelationType: dependent.RelationType
    };
  }

  private getDependentStatus(dependent: any): any {
    const depVerificationStatus = dependent.DepVerificationStatus || 'N';
    return {
      Code: depVerificationStatus,
      Title: this.getDocumentStatus(depVerificationStatus),
      Class: this.getDocumentStatusClass(depVerificationStatus)
    };
  }

  private getDocumentStatus(statusCode: string): string {
    const statusDictionary = this.getMappedContentForAliases({}, 'HB.CommonElements.DependentVerification.StatusText', 'DEPVERIFICATIONCODE');
    return statusDictionary[statusCode] || '';
  }

  private getDocumentStatusClass(statusCode: string): any {
    const statusClasses = {
      'I': this.getStatusClass('status-not-approved', 'fa-warning'),
      'D': this.getStatusClass('status-failed', 'fa-warning'),
      'N': this.getStatusClass('status-required', 'fa-circle')
    };
    return statusClasses[statusCode] || '';
  }

  private getStatusClass(spanClass: string, iconClass: string): any {
    return { SpanClass: spanClass, IconClass: iconClass };
  }

  private getDependentsFromSourcesByPriority(employeeData: any): any[] {
    const dependentsFromSources: any[] = [];
    compact(this.getSourcesByPriority(employeeData)).forEach(source => {
      source.Dependents.forEach(dependent => {
        const duplicatedDependent = find(dependentsFromSources, item => item.dependent.Ssn === dependent.Ssn);
        if (duplicatedDependent) {
          duplicatedDependent.source.push(source);
        } else {
          dependentsFromSources.push({ dependent, source: [source] });
        }
      });
    });
    return dependentsFromSources;
  }

  private getSourcesByPriority(employeeData: any): any[] {
    const data = employeeData.Data;
    const futureCoverages = data.FutureCoverages;
    return [data.PendingEmployee, futureCoverages && futureCoverages[0], data.CurrentCoveragesEmployee];
  }

  private isVerificationRequired(employeeData: any, cartData: any, dependentWithSource: any): boolean {
    const dependent = dependentWithSource.dependent;
    return some(dependentWithSource.source, source => this.isVerificationForSourceRequired(employeeData, cartData, dependent, source));
  }

  private isVerificationForSourceRequired(employeeData: any, cartData: any, dependent: any, source: any): boolean {
    const dependentVerification = this.dependentVerificationService.forData(employeeData);
    if (!dependentVerification.dependentRequiresVerificationByStatus(dependent)) {
      return false;
    }
    if (dependentVerification.overlayShowsWhen().dependentIsCovered) {
      if (source === employeeData.Data.PendingEmployee && cartData && cartData.ShoppingCart) {
        return this.dependentEligibleForMedicalDentalOrVision(dependent, employeeData, cartData) && dependentVerification.dependentRequiresVerificationByCoverage(dependent, cartData.ShoppingCart);
      }
      return this.dependentHasMedicalDentalOrVisionCoverage(dependent, source);
    }
    return true;
  }

  private dependentHasMedicalDentalOrVisionCoverage(dependent: any, source: any): boolean {
    return this.checkForMdv(source, benefit => {
      const electedPlan = benefit.ElectedPlan;
      return benefit.IsElected && !electedPlan.IsNoCovPlan && some(electedPlan.ElectedOption.DependentAssociations, dep => dep.DependentSsn === dependent.Ssn);
    });
  }

  private dependentEligibleForMedicalDentalOrVision(dependent: any, employeeData: any, cartData: any): boolean {
    return this.checkForMdv(employeeData.Data.PendingEmployee, benefit => this.coverageSourcesService.isDependentEligibleForRule(dependent, benefit, employeeData));
  }

  private checkForMdv(source: any, functionForCheck: (benefit: any) => boolean): boolean {
    if (!source || !source.LifeEvents[0] || !source.LifeEvents[0].EligibleBenefits) {
      return false;
    }
    const eligibleBenefits = source.LifeEvents[0].EligibleBenefits;
    return some(eligibleBenefits, benefit => this.benefitsService.isBenefitMedicalDentalOrVision(benefit) && functionForCheck(benefit));
  }

  private getMappedContentForAliases(employeeData: any, evaluationPoint: string, keyProperty: string): any {
    const alias = employeeData.ContentAliases[evaluationPoint];
    if (!alias) {
      return {};
    }
    const keys = alias[keyProperty];
    const content = map(alias['CONTENT_ALIAS'], path => employeeData.Content[path] || '');
    return zipObject(keys, content);
  }
}
