import { Injectable } from '@angular/core';
import { EnrollmentRules } from './enrollment-rules.service';
import { ContentAliasService } from './content-alias.service';
import { DepsPendingVerificationService } from './deps-pending-verification.service';
import { DependentVerificationService } from './dependent-verification.service';
import { AmountBasedBenefitService } from './amount-based-benefit.service';
import { OptionStatusService } from './option-status.service';
import { BenefitCategoriesService } from './benefit-categories.service';
import { DcService } from './dc.service';
import { MbcUtilService } from './mbc-util.service';
import { AggregateElections } from './aggregate-elections.service';
import { GenerateCartMap } from './generate-cart-map.service';
import { IsRepriceableBenefit } from './is-repriceable-benefit.service';
import { PcpService } from './pcp.service';
import { BenefitsService } from './benefits.service';
import { BenefitIconService } from './benefit-icon.service';
import { SpendingAccountsService } from './spending-accounts.service';
import { SuppressedBenefitsPlansOptionsService } from './suppressed-benefits-plans-options.service';
import { Flags } from './flags.service';

@Injectable({
  providedIn: 'root'
})
export class LeBenefitsService {
  constructor(
    private enrollmentRules: EnrollmentRules,
    private contentAliasService: ContentAliasService,
    private depsPendingVerificationService: DepsPendingVerificationService,
    private dependentVerificationService: DependentVerificationService,
    private amountBasedBenefitService: AmountBasedBenefitService,
    private optionStatusService: OptionStatusService,
    private benefitCategoriesService: BenefitCategoriesService,
    private dcService: DcService,
    private mbcUtilService: MbcUtilService,
    private aggregateElections: AggregateElections,
    private generateCartMap: GenerateCartMap,
    private isRepriceableBenefit: IsRepriceableBenefit,
    private pcpService: PcpService,
    private benefitsService: BenefitsService,
    private benefitIconService: BenefitIconService,
    private spendingAccountsService: SpendingAccountsService,
    private suppressedBenefitsPlansOptionsService: SuppressedBenefitsPlansOptionsService,
    private flags: Flags
  ) {}

  createBenefitList(parameters: any) {
    const aggregated = this.aggregateElections.createElectionData(parameters);

    if (!parameters.hideNoCovVb) {
      this.setCovImages(aggregated.displayed.voluntaryBenefits, parameters);
    }

    if (!parameters.isCart) {
      this.setFootnotes(aggregated.displayed.paidExceptVoluntaryElections, parameters);
    }

    const paidExceptVoluntaryElections = aggregated.displayed.paidExceptVoluntaryElections;

    this.populateElectionsWithDepsVerifiedOptionCosts(paidExceptVoluntaryElections, parameters);

    return {
      byStatus: this.separateBenefitsByStatus(paidExceptVoluntaryElections),
      beneficiaryData: this.getBeneficiaryData(parameters),
      showSubtotals: this.getShowSubtotals(parameters),
      aggregated: aggregated,
      dcSubTotalTooltipEnabled: this.calculateDcSubTotalTooltipEnabled(paidExceptVoluntaryElections, parameters)
    };
  }

  private setCovImages(voluntaryBenefits: any, parameters: any) {
    voluntaryBenefits.forEach((election: any) => {
      const electedBenefit = election.ElectedBenefit;
      const electedPlan = election.ElectedPlan;
      election.CovImage = this.mbcUtilService.getCoverageImage(electedBenefit, electedPlan, parameters.employeeData, true);
    });
  }

  private calculateDcSubTotalTooltipEnabled(paidExceptVoluntaryElections: any, parameters: any) {
    return paidExceptVoluntaryElections.some((election: any) => {
      return !election.ElectedPlan.IsNoCovPlan && this.dcService.isBenefitDc(election.ElectedBenefit, parameters.employee);
    });
  }

  private setFootnotes(paidExceptVoluntaryElections: any, parameters: any) {
    const electedBenefitsTransformed = this.getElectedDomBenefits(parameters).map(this.transformDOMToCartFormat);
    const footNoteRules = this.enrollmentRules.summaryFootNotes(electedBenefitsTransformed, parameters.employeeData, null, parameters.employee, 'true', 'true');

    paidExceptVoluntaryElections.forEach((election: any) => {
      if (footNoteRules[election.ElectedBenefit.BenefitID]) {
        election.Footnote = footNoteRules[election.ElectedBenefit.BenefitID].Footnote;
        election.ShowNotice = true;
      }
    });
  }

  private getElectedDomBenefits(parameters: any) {
    return parameters.employee.LifeEvents[0].EligibleBenefits.filter((benefit: any) => benefit.IsElected && this.suppressedBenefitsPlansOptionsService.filterByBenefits(benefit, parameters.enrollmentContent));
  }

  private transformDOMToCartFormat(benefit: any) {
    return {
      BenefitID: benefit.BenefitID,
      BenefitCategory: benefit.BenefitCategory,
      DependentAssociationList: benefit.ElectedPlan && benefit.ElectedPlan.ElectedOption.DependentAssociations,
      PlanID: benefit.ElectedPlan && benefit.ElectedPlan.PlanID,
      OptionID: benefit.ElectedPlan && benefit.ElectedPlan.ElectedOption.OptionID,
      Amount: benefit.ElectedPlan && benefit.ElectedPlan.ElectedOption.AmountElected,
      LifeEventDate: benefit.LifeEventDate
    };
  }

  private separateBenefitsByStatus(paidExceptVoluntaryElections: any) {
    const benefitsAvailableToUpdate = paidExceptVoluntaryElections.filter((election: any) => election.IsAvailableToUpdate);
    const benefitsNotAvailableToUpdate = paidExceptVoluntaryElections.filter((election: any) => !election.IsAvailableToUpdate);

    return {
      benefitsAvailableToUpdate,
      benefitsNotAvailableToUpdate
    };
  }

  private getBeneficiaryData(parameters: any) {
    return {
      dom: this.getDomBeneficiaryData(parameters),
      cart: this.getCartBeneficiaryData(parameters)
    };
  }

  private getDomBeneficiaryData(parameters: any) {
    const employee = parameters.employee;
    return {
      beneficiaries: employee.Beneficiaries,
      designations: employee.BeneficiaryDesignations
    };
  }

  private getCartBeneficiaryData(parameters: any) {
    if (!parameters.isCart) {
      return {};
    }

    const cartBeneficiaryData = parameters.cart.BeneficiaryData;

    if (!cartBeneficiaryData) {
      return {};
    }

    return {
      beneficiaries: cartBeneficiaryData.Beneficiaries,
      designations: cartBeneficiaryData.Designations
    };
  }

  private getShowSubtotals(parameters: any) {
    const configName = parameters.isLifeEventPage || parameters.isCart
      ? 'HB.LifeEvent.ChooseBenefits.CostSummarySubTotals'
      : 'HB.LifeEvent.Summary.CostSummarySubTotals';

    return this.contentAliasService.forData(parameters.employeeData).getConfigurationValue(configName) === 'S';
  }

  private populateElectionsWithDepsVerifiedOptionCosts(paidExceptVoluntaryElections: any, parameters: any) {
    paidExceptVoluntaryElections.forEach((election: any) => {
      const employee = { ...parameters.employee };
      const benefit = election.ElectedBenefit;
      const benefitId = benefit.BenefitID;
      const plan = benefit.EligiblePlansMap[election.ElectedPlan.PlanID];
      const option = plan.EligibleOptionsMap[election.ElectedOption.OptionID];

      if (parameters.isCart) {
        const domBenefit = employee.LifeEvents[0].EligibleBenefitsMap[benefitId];
        const cartBenefit = parameters.cart.ShoppingCart.find((item: any) => item.BenefitID === benefitId);
        domBenefit.DependentAssociationList = cartBenefit && cartBenefit.DependentAssociationList || [];
      }

      const derivedOptionDetails = this.depsPendingVerificationService.getVerifiedOptionDetails(
        this.contentAliasService.forData(parameters.employeeData),
        employee,
        benefitId,
        plan.PlanID,
        option.OptionID
      );

      Object.assign(election, derivedOptionDetails);
    });
  }

  getBenefitListData(enrollmentContent: any, employeeType: string, newSuggestedPackage: any, clientCustomBenefitItems: any, isSuggestedPackage: boolean, isBenefitListEditable: boolean) {
    const benefitList = this.createBenefitList({
      cart: newSuggestedPackage,
      employee: enrollmentContent.data[employeeType],
      employeeData: enrollmentContent.contentSource,
      bestMatchData: null,
      isCart: isBenefitListEditable,
      isLifeEventPage: true,
      isEditable: isBenefitListEditable,
      hideNoCovVb: false,
      separateByStatus: false,
      employeeType: employeeType,
      enrollmentContent: enrollmentContent
    });

    const emp = enrollmentContent.data[employeeType];
    const displayedElections = benefitList.aggregated.displayed.employerCostElections;
    const coveredVoluntaryBenefits = benefitList.aggregated.displayed.paidExceptVoluntaryElections.filter(this.isVoluntaryBenefit.bind(this));
    const costElections = displayedElections.filter((election: any) => !this.isVoluntaryBenefit(election));

    return {
      includedItems: this.getIncludedItems(costElections, isSuggestedPackage),
      recommendedItems: this.getRecommendedItems(displayedElections),
      offeredItems: this.getOfferedItems(costElections),
      taxSavingAccountsItems: this.getIncludedTaxSavingAccountsItems(costElections),
      taxSavingAccountsItemsForTile: this.getIncludedTaxSavingAccountsItemsWithFl(benefitList),
      availableTaxSavingAccountsItems: this.getAvailableTaxSavingAccountsItems(costElections),
      availableNonTaxSavingAccountsItems: this.getAvailableNonTaxSavingAccountsItems(costElections),
      clientCustomBenefitsItems: this.getClientCustomBenefitItems(costElections, clientCustomBenefitItems),
      hasAvailableTaxSavingAccountsItems: this.hasAvailableTaxSavingAccountsItems(costElections, isBenefitListEditable, newSuggestedPackage, enrollmentContent),
      hasIncludedTaxSavingAccountsItems: this.hasIncludedTaxSavingAccountsItems(costElections),
      totals: benefitList.aggregated.totals,
      aggregated: benefitList.aggregated,
      beneficiaryData: benefitList.beneficiaryData.dom,
      dcSubTotalTooltipEnabled: benefitList.dcSubTotalTooltipEnabled,
      showSubtotals: benefitList.showSubtotals,
      suggestedPackage: newSuggestedPackage,
      enrollmentContent: enrollmentContent,
      isEditable: isBenefitListEditable,
      coveredVoluntaryBenefits: coveredVoluntaryBenefits,
      displayCosts: emp.SmallMarketData.DisplayCosts
    };
  }

  private hasAvailableTaxSavingAccountsItems(costElections: any, isBenefitListEditable: boolean, newSuggestedPackage: any, enrollmentContent: any) {
    if (!isBenefitListEditable) {
      return true;
    }

    return costElections.some((item: any) => {
      if (this.isTaxSavingAccount(item)) {
        const service = this.spendingAccountsService.forCommonData({
          benefit: item.benefit,
          shoppingCart: newSuggestedPackage.ShoppingCart.reduce((acc: any, curr: any) => {
            acc[curr.BenefitID] = curr;
            return acc;
          }, {}),
          employeeData: enrollmentContent.contentSource
        });
        return service.isEditable();
      }
      return false;
    });
  }

  private hasIncludedTaxSavingAccountsItems(costElections: any) {
    return costElections.some((item: any) => {
      if (this.isTaxSavingAccount(item)) {
        if (this.benefitsService.isHSABenefit(item.benefit)) {
          return item.employeeAnnualCost !== 0 && item.employeePayPeriodCost !== 0;
        }
        return true;
      }
      return false;
    });
  }

  private getIncludedItems(costElections: any, isSuggestedPackage: boolean) {
    if (isSuggestedPackage) {
      return costElections.filter((item: any) => !this.isClientCustomBenefit(item));
    }
    return costElections;
  }

  private getClientCustomBenefitItems(costElections: any, clientCustomBenefitItems: any) {
    return costElections.filter((item: any) => this.isClientCustomBenefit(item, clientCustomBenefitItems));
  }

  private getAvailableTaxSavingAccountsItems(costElections: any) {
    return costElections.filter((item: any) => this.isTaxSavingAccount(item));
  }

  private getRecommendedItems(displayedElections: any) {
    return displayedElections.filter((item: any) => this.isVoluntaryBenefit(item) && this.isRecommended(item) && !this.isTaxSavingAccount(item));
  }

  private getOfferedItems(costElections: any) {
    return costElections.filter((item: any) => this.isOffered(item) && !this.isTaxSavingAccount(item));
  }

  private getAvailableNonTaxSavingAccountsItems(costElections: any) {
    return this.getIncludedItems(costElections, false).filter((item: any) => !this.isTaxSavingAccount(item) && this.isAvailableToChange(item));
  }

  private getIncludedTaxSavingAccountsItems(costElections: any) {
    return this.getIncludedItems(costElections, false).filter((item: any) => this.isTaxSavingAccount(item));
  }

  private getIncludedTaxSavingAccountsItemsWithFl(benefitList: any) {
    return benefitList.aggregated.allBenefitsByGroups.employerCostElections.filter((item: any) => this.filterIncluded(item) && this.isTaxSavingAccount(item));
  }

  private filterIncluded(item: any) {
    return !item.isVoluntary && !item.IsNoCovPlan;
  }

  private isTaxSavingAccount(item: any) {
    return item.benefit.BenefitCategory === 'SPENDING';
  }

  private isAvailableToChange(item: any) {
    return !item.benefit.IsNZ;
  }

  private isVoluntaryBenefit(item: any) {
    return this.benefitsService.isBenefitOfVoluntaryCategory(item.benefit);
  }

  private isOffered(item: any) {
    return item.isNoCov;
  }

  private isRecommended(item: any) {
    return item.isInterested;
  }

  private isClientCustomBenefit(item: any, clientCustomBenefitItems: any) {
    return clientCustomBenefitItems.some((customItem: any) => customItem.BenefitID === item.benefit.BenefitID);
  }
}
