import { Injectable } from '@angular/core';
import { StaticContentService } from './static-content.service';
import { MbcContentAndDataResourceFactory } from './mbc-content-and-data-resource.factory';
import { TransformOpenEnrollmentService } from './transform-open-enrollment.service';
import { ProcessTokensInDataService } from './process-tokens-in-data.service';
import { SupplementalTabService } from './supplemental-tab.service';
import { DomainAvailabilityService } from './domain-availability.service';
import { ContentAliasService } from './content-alias.service';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MbcContentAndDataService {
  private contentAndDataResource: any;
  private contentAndDataResourceForConfirmationFlow: any = null;
  private mbcContentAndDataConfirmationFlowCacheKey = 'mbcContentAndDataConfirmationFlowCache';

  constructor(
    private staticContent: StaticContentService,
    private mbcContentAndDataResourceFactory: MbcContentAndDataResourceFactory,
    private transformOpenEnrollment: TransformOpenEnrollmentService,
    private processTokensInData: ProcessTokensInDataService,
    private supplementalTabService: SupplementalTabService,
    private domainAvailability: DomainAvailabilityService,
    private contentAliasService: ContentAliasService
  ) {
    this.contentAndDataResource = this.mbcContentAndDataResourceFactory.create();
  }

  getData(sectionKey: string, transform?: Function, hardRefresh?: boolean): Observable<any> {
    return this.contentAndDataResource.getData(sectionKey, transform, hardRefresh);
  }

  getProcessedData(sectionKey: string, options?: any): Observable<any> {
    return this.contentAndDataResource.getProcessedData(sectionKey, options);
  }

  getEnrollmentContent(): Observable<any> {
    return this.contentAndDataResource.getEnrollmentContent();
  }

  getEnrollmentContentIgnoringRecentlySubmittedLifeEvent(): Observable<any> {
    const resource = this.contentAndDataResourceForConfirmationFlow || this.contentAndDataResource;
    return resource.getEnrollmentContent();
  }

  getEnrollment(): Observable<any> {
    return this.contentAndDataResource.getEnrollment();
  }

  setSubmittedLifeEvent(data: any, currentLifeEventData: any): void {
    this.processTokensInData.process(data, [this.staticContent, currentLifeEventData]);
    this.transformOpenEnrollment.transform(data);
    this.contentAndDataResource.updateEnrollmentCache(data);
    this.contentAndDataResourceForConfirmationFlow = this.initContentAndDataResourceForConfirmationFlow();
  }

  forgetSubmittedLifeEvent(): void {
    this.contentAndDataResource.clearWholeCache();
    this.clearConfirmationFlowCache();
    if (this.contentAndDataResourceForConfirmationFlow) {
      this.moveConfirmationFlowCacheToRegularCache();
      this.contentAndDataResourceForConfirmationFlow.clearWholeCache();
      this.contentAndDataResourceForConfirmationFlow = null;
    }
  }

  refresh(reload: boolean): void {
    this.contentAndDataResource.refresh(reload);
  }

  clearWholeCache(): void {
    this.contentAndDataResource.clearWholeCache();
  }

  remove(sectionKey: string): void {
    this.contentAndDataResource.remove(sectionKey);
  }

  private clearConfirmationFlowCache(): void {
    // Implement cache clearing logic
  }

  private moveConfirmationFlowCacheToRegularCache(): void {
    const enrollmentData = this.contentAndDataResourceForConfirmationFlow.getCachedEnrollmentData();
    if (enrollmentData) {
      this.contentAndDataResource.updateEnrollmentCache(enrollmentData);
    }
  }

  private initContentAndDataResourceForConfirmationFlow(): any {
    // Implement initialization logic
    return this.mbcContentAndDataResourceFactory.create();
  }
}
