import { Injectable } from '@angular/core';
import { ShowEditPcpOnReviewService } from './show-edit-pcp-on-review.service';
import { BenefitsService } from './benefits.service';
import { PcpOverlayDisplayService } from './pcp-overlay-display.service';
import { MbcContentAndDataService } from './mbc-content-and-data.service';

@Injectable({
  providedIn: 'root'
})
export class PcpService {
  constructor(
    private showEditPcpOnReview: ShowEditPcpOnReviewService,
    private benefitsService: BenefitsService,
    private pcpOverlayDisplayService: PcpOverlayDisplayService,
    private mbcContentAndData: MbcContentAndDataService
  ) {}

  showPcp(benefit: any, suggestedPackage: any): Promise<any> {
    const employeeData = this.mbcContentAndData.getEnrollment();

    return employeeData.$promise.then((data: any) => {
      const benefitCategories = [benefit.BenefitCategory];
      return this.prepareDataAndShowEditPcpOnReview(data, suggestedPackage, false, benefitCategories);
    });
  }

  prepareDataAndShowEditPcpOnReview(employeeData: any, shoppingCart: any, isReviewMode: boolean, benefitCategories: string[]): any {
    const newElections = this.getNewElectionsForBenefitCategories(benefitCategories, shoppingCart);
    return this.showEditPcpOnReview.show(newElections, employeeData, shoppingCart, isReviewMode);
  }

  private getNewElectionsForBenefitCategories(categories: string[], shoppingCart: any): any {
    return categories.reduce((resultObject: any, benefitCategory: string) => {
      resultObject[benefitCategory] = { benefit: this.findBenefit(benefitCategory, shoppingCart) };
      return resultObject;
    }, {});
  }

  private findBenefit(benefitCategory: string, shoppingCart: any): any {
    return shoppingCart.ShoppingCart.find((benefit: any) => benefit.BenefitCategory === benefitCategory);
  }

  isPCPRequired(election: any, benefit: any, employeeData: any): boolean {
    if (!this.benefitsService.isPcpBenefit(benefit)) {
      return false;
    }
    return this.pcpOverlayDisplayService.pcpOverlayShouldBeShown(election, employeeData, this.additionalConditions);
  }

  private additionalConditions(): boolean {
    return true;
  }
}
