import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DcService {
  isBenefitDc(benefit: any, employee: any): boolean {
    const contributionTypes = employee.ContributionTypes;
    return contributionTypes && contributionTypes.includes(benefit.BenefitID);
  }

  getPlanCost(option: any, periodName: string): number {
    const employerCost = option[`Employer${periodName}Cost`] || 0;
    const employeeCost = option[`Employee${periodName}Cost`] || 0;
    return employerCost + employeeCost;
  }

  getPayPeriodPlanCost(option: any): number {
    return this.getPlanCost(option, 'PayPeriod');
  }
}
