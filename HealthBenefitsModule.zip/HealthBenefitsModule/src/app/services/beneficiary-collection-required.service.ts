import { Injectable } from '@angular/core';
import { MbcContentAndData } from './mbc-content-and-data.service';
import { CacheService } from './cache.service';
import { forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BeneficiaryCollectionRequiredService {
  constructor(
    private mbcContentAndData: MbcContentAndData,
    private cacheService: CacheService
  ) {}

  getCacheKey(lifeEvent: any): string {
    return `plansRequiringBeneficiariesAdded.${lifeEvent.LifeEventID}.${lifeEvent.LifeEventDate}.${lifeEvent.LifeEventSequenceNumber}`;
  }

  getSetToNocovCacheKey(lifeEvent: any): string {
    return `plansRequiringBeneficiariesSetToNocov.${lifeEvent.LifeEventID}.${lifeEvent.LifeEventDate}.${lifeEvent.LifeEventSequenceNumber}`;
  }

  clearCache(lifeEvent: any): void {
    this.cacheService.cache.remove(this.getCacheKey(lifeEvent));
    this.cacheService.cache.remove(this.getSetToNocovCacheKey(lifeEvent));
  }

  isBeneficiaryCollectionRequired(lifeEvent: any): boolean {
    const cacheKey = this.getCacheKey(lifeEvent);
    const plans = this.cacheService.cache.get(cacheKey);
    return plans && Object.keys(plans).length > 0;
  }

  getBeneficiaryCollectionRequiredSetToNoCovIds(lifeEvent: any): string[] {
    const cacheKey = this.getSetToNocovCacheKey(lifeEvent);
    const plans = this.cacheService.cache.get(cacheKey) || {};
    return Object.keys(plans);
  }

  setBeneficiaryCollectionRequiredCacheItems(benefitId: string, newCartObject: any): void {
    if (!benefitId) {
      return;
    }

    const newCart$ = newCartObject.$promise;
    const enrollmentContent$ = this.mbcContentAndData.getEnrollmentContent();

    forkJoin({ newCart: newCart$, enrollmentContent: enrollmentContent$ }).pipe(
      map(data => this.beneficiaryCollectionRequiredServiceAsync(data, benefitId))
    ).subscribe();
  }

  private beneficiaryCollectionRequiredServiceAsync(data: any, benefitId: string): void {
    const newCart = data.newCart;
    const enrollmentContent = data.enrollmentContent;
    const newCartItem = newCart.ShoppingCart.find((item: any) => item.BenefitID === benefitId);
    const enrollmentBenefit = enrollmentContent.data.PendingEmployee.LifeEvents[0].EligibleBenefitsMap[benefitId];
    const cacheKey = this.getCacheKey(enrollmentContent.data.PendingEmployee.LifeEvents[0]);
    const setToNoCovCacheKey = this.getSetToNocovCacheKey(enrollmentContent.data.PendingEmployee.LifeEvents[0]);

    if (!this.needToCollect(newCartItem, enrollmentBenefit)) {
      if (this.hasBeneficiaryRequiredPlanButNoCov(newCartItem, enrollmentBenefit)) {
        let plansRequiringBeneficiariesSetToNoCov = this.cacheService.cache.get(setToNoCovCacheKey) || {};
        if (!plansRequiringBeneficiariesSetToNoCov[benefitId]) {
          plansRequiringBeneficiariesSetToNoCov[benefitId] = enrollmentBenefit;
          this.cacheService.cache.put(setToNoCovCacheKey, plansRequiringBeneficiariesSetToNoCov);
        }
      }
      if (this.cacheService.cache.get(cacheKey) && this.cacheService.cache.get(cacheKey)[benefitId]) {
        delete this.cacheService.cache.get(cacheKey)[enrollmentBenefit.BenefitID];
      }
      return;
    } else {
      let plansRequiringBeneficiariesAdded = this.cacheService.cache.get(cacheKey) || {};
      if (!plansRequiringBeneficiariesAdded[benefitId]) {
        plansRequiringBeneficiariesAdded[benefitId] = enrollmentBenefit;
        this.cacheService.cache.put(cacheKey, plansRequiringBeneficiariesAdded);
      }
      return;
    }
  }

  private hasBeneficiaryRequiredPlanButNoCov(newCartItem: any, enrollmentBenefit: any): boolean {
    if (!newCartItem || !enrollmentBenefit) {
      return true;
    }

    const electedPlan = enrollmentBenefit.EligiblePlansMap[newCartItem.PlanID];

    if (electedPlan?.IsNoCovPlan) {
      return enrollmentBenefit.EligiblePlans.some((plan: any) => plan.PlanYearDefBeneRequirement === 'R');
    }

    return false;
  }

  private needToCollect(newCartItem: any, enrollmentBenefit: any): boolean {
    if (!this.hasBeneficiaryRequiredPlanButNoCov(newCartItem, enrollmentBenefit)) {
      const electedPlan = enrollmentBenefit.EligiblePlansMap[newCartItem.PlanID];

      if (electedPlan?.IsNoCovPlan || electedPlan?.PlanYearDefBeneRequirement !== 'R') {
        return false;
      }

      return true;
    }
    return false;
  }
}
