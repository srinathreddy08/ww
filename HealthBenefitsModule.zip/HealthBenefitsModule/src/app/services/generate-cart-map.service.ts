import { Injectable } from '@angular/core';
import { Cart } from '../models/cart.model';

@Injectable({
  providedIn: 'root'
})
export class GenerateCartMapService {
  generateCartMap(cart: Cart): Record<string, any> {
    return cart.ShoppingCart
      .filter(item => !item.IsLostEligibility)
      .reduce((acc, item) => {
        acc[item.BenefitID] = item;
        return acc;
      }, {} as Record<string, any>);
  }
}
