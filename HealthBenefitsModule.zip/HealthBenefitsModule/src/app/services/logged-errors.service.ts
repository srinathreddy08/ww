import { Injectable } from '@angular/core';
import { Md5 } from 'ts-md5/dist/md5';

@Injectable({
  providedIn: 'root'
})
export class LoggedErrorsService {
  private loggedErrors: Set<string> = new Set();

  put(error: Error): void {
    const errorHash = Md5.hashStr(error.message + error.stack);
    this.loggedErrors.add(errorHash);
  }

  isLogged(error: Error): boolean {
    const errorHash = Md5.hashStr(error.message + error.stack);
    return this.loggedErrors.has(errorHash);
  }
}
