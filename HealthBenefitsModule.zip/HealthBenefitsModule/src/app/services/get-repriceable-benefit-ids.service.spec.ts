import { TestBed } from '@angular/core/testing';
import { GetRepriceableBenefitIdsService } from './get-repriceable-benefit-ids.service';
import { GetRepriceBenefitRelationsService } from './get-reprice-benefit-relations.service';

class MockGetRepriceBenefitRelationsService {
  getRepriceBenefitRelations(employeeData: any) {
    return {
      '1': { RelatedBenefits: ['2', '3'] },
      '4': { RelatedBenefits: ['5'] }
    };
  }
}

describe('GetRepriceableBenefitIdsService', () => {
  let service: GetRepriceableBenefitIdsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: GetRepriceBenefitRelationsService, useClass: MockGetRepriceBenefitRelationsService }
      ]
    });
    service = TestBed.inject(GetRepriceableBenefitIdsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return unique benefit IDs', () => {
    const employeeData = {};
    const result = service.getRepriceableBenefitIds(employeeData);
    expect(result).toEqual(['1', '4', '2', '3', '5']);
  });
});
