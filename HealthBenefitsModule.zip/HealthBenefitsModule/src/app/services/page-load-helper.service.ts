import { Injectable } from '@angular/core';
import { PubsubService } from './pubsub.service';
import { SpinnerService } from './spinner.service';

@Injectable({
  providedIn: 'root'
})
export class PageLoadHelperService {
  private pageUrls: Set<string> = new Set();

  constructor(private pubsubService: PubsubService, private spinnerService: SpinnerService) {
    this.pubsubService.subscribe('stateChanged', this.onStateChanged.bind(this));
  }

  loadPageWithSpinner(pageUrl: string): void {
    if (pageUrl && !this.pageUrls.has(pageUrl)) {
      this.spinnerService.showGlobalSpinner();
      this.pageUrls.add(pageUrl);
    }
  }

  private onStateChanged(e: any, data: any): void {
    if (data && this.pageUrls.has(data.toUrl)) {
      this.pageUrls.delete(data.toUrl);
      this.spinnerService.hideGlobalSpinner();
    }
  }
}
