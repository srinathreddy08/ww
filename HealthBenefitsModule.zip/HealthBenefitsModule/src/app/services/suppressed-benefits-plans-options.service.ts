import { Injectable } from '@angular/core';
import { map, some } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class SuppressedBenefitsPlansOptionsService {
  filterByBenefits(benefit: any, enrollmentContent: any): boolean {
    const suppressedBenefitsPlansOptions = this.getSuppressedBenefits(enrollmentContent);
    return !some(suppressedBenefitsPlansOptions, suppressedBenefit => suppressedBenefit === benefit.BenefitID);
  }

  private getSuppressedBenefits(enrollmentContent: any): string[] {
    const suppressedBPO = enrollmentContent.getConfigurationValue('HB.Common.SuppressBPOfromUI');
    return map(suppressedBPO, (bpo: any) => bpo.BENEFITID);
  }
}
