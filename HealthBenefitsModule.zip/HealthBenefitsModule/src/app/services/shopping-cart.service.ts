import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShoppingCartService {
  private apiUrl = '/api/shoppingcart';

  constructor(private http: HttpClient) {}

  get(lifeEvent: any): Observable<any> {
    return this.http.get(`${this.apiUrl}/get`, { params: { action: 'get', ...lifeEvent } });
  }

  visit(options: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/visit`, options);
  }

  batchAdd(options: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/batchAdd`, options);
  }

  submit(lifeEvent: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/submit`, lifeEvent);
  }

  load(lifeEvent: any): Observable<any> {
    return this.http.get(`${this.apiUrl}/load`, { params: { action: 'load', ...lifeEvent } });
  }

  clear(lifeEvent: any): Observable<any> {
    return this.http.get(`${this.apiUrl}/clear`, { params: { action: 'clear', ...lifeEvent } });
  }

  selectPackage(): Observable<any> {
    return this.http.post(`${this.apiUrl}/selectPackage`, {});
  }

  addProvidersForCartItem(options: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/addProvidersForCartItem`, options);
  }

  getProvidersForCartItem(cartItem: any): Observable<any> {
    return this.http.get(`${this.apiUrl}/getProvidersForCartItem`, { params: { action: 'getProvidersForCartItem', ...cartItem } });
  }
}
