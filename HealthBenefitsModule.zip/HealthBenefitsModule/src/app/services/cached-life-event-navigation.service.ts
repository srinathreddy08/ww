import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EmployeeLifeEventActionService } from './employee-life-event-action.service';
import { map, tap } from 'rxjs/operators';
import { BehaviorSubject, forkJoin } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CachedLifeEventNavigationService {
  private useCacheForNextNavLifeEventRequest = false;
  private navLifeEventCache = new Map();
  private lifeEventNavigationCache: any = null;

  constructor(
    private http: HttpClient,
    private employeeLifeEventActionService: EmployeeLifeEventActionService
  ) {}

  getLifeEventNavigation(useCacheForNextRequest: boolean) {
    let promise;

    if (useCacheForNextRequest && this.lifeEventNavigationCache) {
      promise = this.lifeEventNavigationCache;
    } else {
      promise = this.http.get('/api/content/nav-lifeevent', {
        params: {}
      }).pipe(
        tap(response => this.navLifeEventCache.set('navLifeEvent', response))
      );
      this.lifeEventNavigationCache = promise;
    }

    if (!this.useCacheForNextNavLifeEventRequest) {
      this.navLifeEventCache.clear();
    }

    return forkJoin({
      navLifeEvent: promise,
      reinitializationModel: this.employeeLifeEventActionService.getReinitializationModel()
    }).pipe(
      map(response => {
        const navLifeEvent = response.navLifeEvent;
        this.useCacheForNextNavLifeEventRequest = useCacheForNextRequest;
        if (response.reinitializationModel.isReinitialized()) {
          navLifeEvent.data.NavigationStatus = Object.fromEntries(
            Object.entries(navLifeEvent.data.NavigationStatus).map(([tab, value]) => {
              value.IsEnabled = true;
              if (tab !== 'cart') {
                value.SubNav = Object.fromEntries(
                  Object.entries(value.SubNav).map(([subNavKey, subNavItem]) => {
                    subNavItem.IsEnabled = true;
                    return [subNavKey, subNavItem];
                  })
                );
              } else {
                const reviewState = value.SubNav.review;
                if (reviewState) {
                  reviewState.IsEnabled = true;
                }
              }
              return [tab, value];
            })
          );
        }
        return navLifeEvent.data;
      })
    );
  }

  clearLifeEventNavigationCache() {
    this.lifeEventNavigationCache = null;
  }
}
