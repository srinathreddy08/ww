import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class IsEmployeeContributionLabelEnabledService {
  isEmployeeContributionLabelEnabled(enrollmentContent: any): boolean {
    return enrollmentContent.getConfigurationValue('HB.ClientConfiguration')['HB.LIFEEVENT.SUMMARY.COMPANYCONT'] === 'S';
  }
}
