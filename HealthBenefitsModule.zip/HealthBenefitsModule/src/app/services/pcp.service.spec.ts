import { TestBed } from '@angular/core/testing';
import { PcpService } from './pcp.service';
import { ShowEditPcpOnReviewService } from './show-edit-pcp-on-review.service';
import { BenefitsService } from './benefits.service';
import { PcpOverlayDisplayService } from './pcp-overlay-display.service';
import { MbcContentAndDataService } from './mbc-content-and-data.service';

class MockShowEditPcpOnReviewService {
  show() { return true; }
}

class MockBenefitsService {
  isPcpBenefit() { return true; }
}

class MockPcpOverlayDisplayService {
  pcpOverlayShouldBeShown() { return true; }
}

class MockMbcContentAndDataService {
  getEnrollment() { return { $promise: Promise.resolve({}) }; }
}

describe('PcpService', () => {
  let service: PcpService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PcpService,
        { provide: ShowEditPcpOnReviewService, useClass: MockShowEditPcpOnReviewService },
        { provide: BenefitsService, useClass: MockBenefitsService },
        { provide: PcpOverlayDisplayService, useClass: MockPcpOverlayDisplayService },
        { provide: MbcContentAndDataService, useClass: MockMbcContentAndDataService }
      ]
    });
    service = TestBed.inject(PcpService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true for isPCPRequired when conditions are met', () => {
    const result = service.isPCPRequired({}, {}, {});
    expect(result).toBeTrue();
  });
});
