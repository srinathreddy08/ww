import { TestBed } from '@angular/core/testing';
import { AddToCartCounterService } from './add-to-cart-counter.service';

describe('AddToCartCounterService', () => {
  let service: AddToCartCounterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddToCartCounterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should start with no pending actions', () => {
    expect(service.hasPendingActions()).toBeFalse();
  });

  it('should correctly count actions', () => {
    service.startAddToCartAction();
    expect(service.hasPendingActions()).toBeTrue();
    service.finishAddToCartAction();
    expect(service.hasPendingActions()).toBeFalse();
  });
});
