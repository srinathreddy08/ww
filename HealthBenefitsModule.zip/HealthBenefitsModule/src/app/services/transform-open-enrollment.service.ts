import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransformOpenEnrollmentService {
  transform(enrollment: any): void {
    // Implement the transformation logic here
  }
}
