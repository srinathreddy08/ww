import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HsaService {
  private plansIds = {
    hsaEligible: 'CDH',
    hsaNotEligible: 'AAA',
    hsaEligibleByMask: 'ASXMATRIX',
  };

  private expectedPlanIds = ['CDH', 'HDHP', 'HDHP2'];
  private expectedPlanMaskIds = ['ASX', 'MASX'];

  forData(employeeData: any): HsaServiceInstance {
    return new HsaServiceInstance(employeeData, this.plansIds, this.expectedPlanIds, this.expectedPlanMaskIds);
  }
}

export class HsaServiceInstance {
  constructor(
    private employeeData: any,
    private plansIds: any,
    private expectedPlanIds: string[],
    private expectedPlanMaskIds: string[]
  ) {}

  isPlanHsaEligible(planId: string): boolean {
    return this.expectedPlanIds.includes(planId) || this.expectedPlanMaskIds.some(mask => planId.startsWith(mask));
  }

  getEligiblePlanIds(): string[] {
    return this.expectedPlanIds;
  }

  getEligiblePlanMasks(): string[] {
    return this.expectedPlanMaskIds;
  }
}
