import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';
import { StringService } from './string.service';
import { EmployeeStateService } from './employee-state.service';
import { forEach, keyBy, assign, filter, isEmpty, flattenDeep, pick, values } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class BenefitsOptionsService {
  constructor(
    private contentAliasService: ContentAliasService,
    private stringService: StringService,
    private employeeStateService: EmployeeStateService
  ) {}

  overrideOptions(data: any): void {
    const allBenefits = this.employeeStateService.forAllEmployees(data).getAllBenefits();
    const benefitsOverrideOptionValues = this.getOverrideOptionsConfiguration(data);

    forEach(allBenefits, (benefit: any) => {
      const benefitOptionValue = benefitsOverrideOptionValues[benefit.BenefitID];
      if (benefitOptionValue) {
        this.overrideOptionNameForEmployees(benefit, benefitOptionValue, data);
      }
    });
  }

  getOverrideOptionsConfiguration(data: any): any {
    const overrideBenefitsOptionConfiguration = this.contentAliasService.forData(data)
      .getAliasObjectOrDefault('HB.LifeEvent.OptionNameOverride');

    const result: any = {};

    forEach(overrideBenefitsOptionConfiguration, (val: any, key: string) => {
      if (!key) {
        return;
      }

      const overridenValue = this.contentAliasService.forData(data).getContentValue(val.ContentPath);
      if (!overridenValue) {
        return;
      }

      const parts = overridenValue.split(/\ *: */);
      const optionId = parts[0];
      const overrideOptionValue = parts[1];

      const benefitIDs = keyBy(this.stringService.convertArrayStringToArray(key));
      forEach(benefitIDs, (benefitID: string) => {
        const newOption: any = {};
        newOption[optionId] = overrideOptionValue;
        result[benefitID] = assign({}, result[benefitID], newOption);
      });
    });

    return result;
  }

  private overrideOptionForBenefitPlans(employee: any, benefit: any, newContentId: string, optionId: string): void {
    const forEmployee = this.employeeStateService.forEmployee(employee);
    const electedOption = forEmployee.getElectedOptionForBenefit(benefit.BenefitID);

    if (electedOption && electedOption.OptionID === optionId) {
      electedOption.ContentAlias = newContentId;
    }

    const eligiblePlans = forEmployee.getEligiblePlansForBenefit(benefit.BenefitID);
    filter(eligiblePlans, (plan: any) => {
      const option = plan.EligibleOptions.find((opt: any) => opt.OptionID === optionId);
      if (option) {
        option.ContentAlias = newContentId;
      }
    });
  }

  private overrideBenefitOptionsAndContent(employee: any, benefit: any, overrideOptions: any, data: any): void {
    forEach(overrideOptions, (overrideOptionValue: any, optionId: string) => {
      const newContentId = `/overridenPlanOptionValue/${benefit.BenefitID}_${optionId}`;
      data.Content[newContentId] = overrideOptionValue;

      this.overrideOptionForBenefitPlans(employee, benefit, newContentId, optionId);
    });
  }

  private overrideOptionNameForEmployees(benefit: any, overrideOptionsValue: any, data: any): void {
    const allEmployees = flattenDeep(values(pick(data.Employee, ['PendingEmployee', 'PendingLEVEmployee', 'CurrentCoveragesEmployee', 'HistoricalCoverages', 'FutureCoverages'])));

    filter(allEmployees, (employee: any) => {
      if (!isEmpty(employee)) {
        this.overrideBenefitOptionsAndContent(employee, benefit, overrideOptionsValue, data);
      }
    });
  }
}
