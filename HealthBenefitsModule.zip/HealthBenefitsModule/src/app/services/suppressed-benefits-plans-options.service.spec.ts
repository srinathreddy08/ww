import { TestBed } from '@angular/core/testing';
import { SuppressedBenefitsPlansOptionsService } from './suppressed-benefits-plans-options.service';


describe('SuppressedBenefitsPlansOptionsService', () => {
  let service: SuppressedBenefitsPlansOptionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SuppressedBenefitsPlansOptionsService]
    });
    service = TestBed.inject(SuppressedBenefitsPlansOptionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should filter out suppressed benefits', () => {
    const enrollmentContent = {
      getConfigurationValue: () => [{ BENEFITID: '123' }, { BENEFITID: '456' }]
    };
    const benefit = { BenefitID: '123' };
    expect(service.filterByBenefits(benefit, enrollmentContent)).toBeFalse();
  });

  it('should allow non-suppressed benefits', () => {
    const enrollmentContent = {
      getConfigurationValue: () => [{ BENEFITID: '123' }, { BENEFITID: '456' }]
    };
    const benefit = { BenefitID: '789' };
    expect(service.filterByBenefits(benefit, enrollmentContent)).toBeTrue();
  });
});
