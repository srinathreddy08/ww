import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeCoverageService {

  private isFilledEmployee(employee: any): boolean {
    return employee && employee.LifeEvents && employee.LifeEvents[0];
  }

  isCurrentCoverageExists(employee: any): boolean {
    return this.isFilledEmployee(employee.CurrentCoveragesEmployee);
  }

  isFutureCoverageExists(employee: any): boolean {
    return employee.FutureCoverages && employee.FutureCoverages[0] && this.isFilledEmployee(employee.FutureCoverages[0]);
  }

  getEmployeeCoverage(employee: any): any {
    if (this.isCurrentCoverageExists(employee)) {
      return employee.CurrentCoveragesEmployee;
    }
    return this.isFutureCoverageExists(employee) ? employee.FutureCoverages[0] : null;
  }
}
