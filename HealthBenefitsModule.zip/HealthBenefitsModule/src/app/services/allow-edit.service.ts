import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';
import { Flags } from './flags';
import { includes } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class AllowEditService {
  private readonly participantProfileId = '0';
  private readonly dependentsDataId = '1';
  private readonly beneficiariesDataId = '2';

  constructor(private contentAliasService: ContentAliasService, private flags: Flags) {}

  profileEditAllowed(participantData: any): boolean {
    return this.editAllowed(this.participantProfileId)(participantData);
  }

  dependentsEditAllowed(participantData: any): boolean {
    return this.editAllowed(this.dependentsDataId)(participantData);
  }

  beneficiariesEditAllowed(participantData: any): boolean {
    return this.editAllowed(this.beneficiariesDataId)(participantData);
  }

  private editAllowed(dataType: string) {
    return (participantData: any): boolean => {
      const content = this.contentAliasService.forData(participantData);
      const suppressEditValues = content.getConfiguration('Portal.SuppressEditLinks').asStringArray();
      return !includes(suppressEditValues, dataType);
    };
  }
}
