import { TestBed } from '@angular/core/testing';
import { WithoutService } from './without.service';


describe('WithoutService', () => {
  let service: WithoutService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WithoutService]
    });
    service = TestBed.inject(WithoutService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should exclude elements from the first array that are present in the second array', () => {
    const arrayA = [1, 2, 3, 4, 5];
    const arrayB = [2, 4];
    const result = service.execute(arrayA, arrayB);
    expect(result).toEqual([1, 3, 5]);
  });

  it('should return the original array if no elements are present in the second array', () => {
    const arrayA = [1, 2, 3];
    const arrayB = [4, 5];
    const result = service.execute(arrayA, arrayB);
    expect(result).toEqual([1, 2, 3]);
  });

  it('should return an empty array if all elements are present in the second array', () => {
    const arrayA = [1, 2];
    const arrayB = [1, 2];
    const result = service.execute(arrayA, arrayB);
    expect(result).toEqual([]);
  });
});
