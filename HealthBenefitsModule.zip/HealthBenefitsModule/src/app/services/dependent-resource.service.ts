import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CacheService } from './cache.service';

@Injectable({
  providedIn: 'root'
})
export class DependentResourceService {
  private apiUrl = '/api/dependents';

  constructor(private http: HttpClient, private cacheService: CacheService) {}

  addDependent(deps: any[]): Observable<any> {
    return this.http.post(`${this.apiUrl}/add`, { Dependents: deps });
  }

  updateDependent(ssn: string, dep: any, isDomainPageUpdate: boolean): Observable<any> {
    return this.http.post(`${this.apiUrl}/update`, {
      OriginalDependentSsn: ssn,
      UpdatedDependent: dep,
      IsDomainPageUpdate: isDomainPageUpdate
    });
  }

  getRestrictions(lifeEventId: string, lifeEventDate: string): Observable<any> {
    const cacheKey = this.constructGetRestrictionsKey(lifeEventId, lifeEventDate);
    const cachedResponse = this.cacheService.cache.get(cacheKey);
    if (cachedResponse) {
      return cachedResponse;
    }

    const restrictionsRequest = this.http.get(`${this.apiUrl}/getRestrictions`, {
      params: { LifeEventId: lifeEventId, LifeEventDate: lifeEventDate }
    }).pipe(
      map(response => {
        this.cacheService.cache.put(cacheKey, response);
        return response;
      })
    );

    this.cacheService.cache.put(cacheKey, restrictionsRequest);
    return restrictionsRequest;
  }

  private constructGetRestrictionsKey(lifeEventId: string, lifeEventDate: string): string {
    return `dependentResourceService.getRestrictions.${lifeEventDate}.${lifeEventId}`;
  }
}
