import { TestBed } from '@angular/core/testing';
import { ShowEditPcpOnReviewService } from './show-edit-pcp-on-review.service';
import { ShowEditPcpOverlayIfNeededService } from './show-edit-pcp-overlay-if-needed.service';
import { of } from 'rxjs';

class MockShowEditPcpOverlayIfNeededService {
  execute() {
    return of(true);
  }
}

describe('ShowEditPcpOnReviewService', () => {
  let service: ShowEditPcpOnReviewService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ShowEditPcpOnReviewService,
        { provide: ShowEditPcpOverlayIfNeededService, useClass: MockShowEditPcpOverlayIfNeededService }
      ]
    });
    service = TestBed.inject(ShowEditPcpOnReviewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return null if all new elections have null benefits', () => {
    const result = service.execute([{ benefit: null }], {}, {}, false);
    expect(result).toBeNull();
  });

  it('should call showEditPcpOverlayIfNeeded if not all benefits are null', () => {
    const result = service.execute([{ benefit: {} }], {}, { ShoppingCart: {} }, false);
    expect(result).toBeTruthy();
  });
});
