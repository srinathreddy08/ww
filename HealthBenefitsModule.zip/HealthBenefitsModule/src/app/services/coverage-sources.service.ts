import { Injectable } from '@angular/core';
import { DependentService } from './dependent.service';
import { ParticipantEligibilityService } from './participant-eligibility.service';
import { DependencyTracker } from './dependency-tracker';
import { EnrollmentRules } from './enrollment-rules';
import { cloneDeep, keyBy, mapValues, filter, find, some } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class CoverageSourcesService {
  constructor(
    private dependentService: DependentService,
    private participantEligibilityService: ParticipantEligibilityService,
    private dependencyTracker: DependencyTracker,
    private enrollmentRules: EnrollmentRules
  ) {}

  fromCartElections(data: any, employee: any, cart: any) {
    const lifeEvent = employee.LifeEvents[0];
    const eligibleBenefits = lifeEvent.EligibleBenefitsMap;
    const participantEligibility = this.participantEligibilityService.forData(data.employeeData);

    return {
      employeeData: data.employeeData,
      employee: employee,
      elections: this.getElections(cart, eligibleBenefits, employee, data),
      editable: true,
      isParticipantEditable: (benefitId: string) => this.isParticipantEditable(benefitId, eligibleBenefits, participantEligibility),
      isDependentEditable: (dependent: any, benefitId: string) => this.isDependentEditable(dependent, benefitId, eligibleBenefits, data),
      isDependentEligible: (dependent: any, benefit: any) => this.isDependentEligibleForRule(dependent, benefit, data.employeeData),
      bestMatch: {
        MEDICAL: data.bestMatchData && data.bestMatchData.AllMedicalMatches
      }
    };
  }

  private getElections(cart: any, eligibleBenefits: any, employee: any, data: any) {
    return mapValues(keyBy(cart.ShoppingCart, 'BenefitID'), (cartItem: any) => {
      const benefit = eligibleBenefits[cartItem.BenefitID];
      const election = cloneDeep(cartItem);

      election.DependentAssociationList = filter(cartItem.DependentAssociationList, (ssn: string) => {
        const dependent = find(employee.Dependents, { Ssn: ssn });
        return dependent && this.isDependentEligible(dependent, benefit, data.employeeData);
      });

      return election;
    });
  }

  private isParticipantEditable(benefitId: string, eligibleBenefits: any, participantEligibility: any): boolean {
    const benefit = eligibleBenefits[benefitId];

    return some(benefit.EligiblePlans, (plan: any) =>
      some(plan.EligibleOptions, (option: any) =>
        participantEligibility.isParticipantEligibleForOption(benefit, option.OptionID)
      )
    );
  }

  private isDependentEditable(dependent: any, benefitId: string, eligibleBenefits: any, data: any): boolean {
    const benefit = eligibleBenefits[benefitId];

    if (!this.isDependentEligible(dependent, benefit, data.employeeData)) {
      return false;
    }

    if (!data.restrictionsData) {
      return true;
    }

    const dependentRestrictions = this.dependentService.getDependentRestrictions(dependent, data.restrictionsData);

    if (!dependentRestrictions) {
      return true;
    }

    const hasCoverage = some(benefit.ElectedPlan.ElectedOption.DependentAssociations, { DependentSsn: dependent.Ssn });

    return this.dependentService.canEditCoverage(hasCoverage, dependentRestrictions.CoverageRule);
  }

  fromDomElections(employeeData: any, employee: any) {
    return {
      employeeData: employeeData,
      employee: employee,
      elections: this.getDomElections(employee),
      editable: false,
      isParticipantEditable: () => false,
      isDependentEditable: () => false,
      isDependentEligible: () => true
    };
  }

  private getDomElections(employee: any) {
    return mapValues(keyBy(filter(employee.LifeEvents[0].EligibleBenefits, 'ElectedPlan'), 'BenefitID'), (benefit: any) => {
      const electedPlan = benefit.ElectedPlan;
      const electedOption = electedPlan.ElectedOption;

      return {
        BenefitID: benefit.BenefitID,
        BenefitCategory: benefit.BenefitCategory,
        PlanID: electedPlan.PlanID,
        OptionID: electedOption.OptionID,
        DependentAssociationList: mapValues(electedOption.DependentAssociations, 'DependentSsn')
      };
    });
  }

  fromDomElectionsForConfirmation(employeeData: any, employee: any) {
    const domElections = this.fromDomElections(employeeData, employee);
    domElections.isDependentEligible = (dependent: any, benefit: any) => this.isDependentEligibleForRule(dependent, benefit, employeeData);

    return domElections;
  }

  private isDependentEligible(dependent: any, benefit: any, employeeData: any): boolean {
    if (benefit.CovPlanCount === 0) {
      return false;
    }

    return this.isDependentEligibleForRule(dependent, benefit, employeeData);
  }

  private isDependentEligibleForRule(dependent: any, benefit: any, employeeData: any): boolean {
    const eligibility = this.enrollmentRules.dependentBenefitCategoryEligibility(dependent, employeeData, benefit.BenefitCategory);

    return eligibility && eligibility.includes(benefit.BenefitID);
  }
}
