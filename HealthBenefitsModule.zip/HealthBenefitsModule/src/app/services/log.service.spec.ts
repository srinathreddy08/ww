import { TestBed } from '@angular/core/testing';
import { LogService } from './log.service';
import { CookieService } from 'ngx-cookie-service';

class MockCookieService {
  private cookies: Record<string, string> = {};

  get(name: string): string {
    return this.cookies[name] || '';
  }

  set(name: string, value: string): void {
    this.cookies[name] = value;
  }
}

const mockLogSources = { source1: true, source2: false };

describe('LogService', () => {
  let service: LogService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        LogService,
        { provide: CookieService, useClass: MockCookieService },
        { provide: 'logSources', useValue: mockLogSources }
      ]
    });
    service = TestBed.inject(LogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should log messages when log source is enabled', () => {
    const logger = service.getLogger('source1');
    spyOn(console, 'log');
    logger.log('test message');
    expect(console.log).toHaveBeenCalledWith('source1', 'test message');
  });

  it('should not log messages when log source is disabled', () => {
    const logger = service.getLogger('source2');
    spyOn(console, 'log');
    logger.log('test message');
    expect(console.log).not.toHaveBeenCalled();
  });

  // Additional tests can be added here to test the service methods
});
