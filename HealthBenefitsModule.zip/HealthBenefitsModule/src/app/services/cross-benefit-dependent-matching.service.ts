import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class CrossBenefitDependentMatchingService {
  constructor(private contentAliasService: ContentAliasService) {}

  forEmployee(employeeData: any) {
    const benefitTierDepMatch = this.contentAliasService.forData(employeeData)
      .getConfigurationValue('HB.LifeEvent.BenefitTierDepMatch');

    const benefitsIds = benefitTierDepMatch && this.getBenefitsIds(benefitTierDepMatch.VALUE);

    const primaryBenefitId = benefitsIds && benefitsIds[0];
    const childBenefitId = benefitsIds && benefitsIds[1];

    return {
      getBenefitsShouldBeMatched: () => this.getBenefitsShouldBeMatched(primaryBenefitId, childBenefitId),
      restrictPlanSelectionAccordingToDependentMatching: (benefitId: string, shoppingCart: any[]) => this.restrictPlanSelectionAccordingToDependentMatching(benefitId, shoppingCart, primaryBenefitId, childBenefitId),
      isValidCart: (shoppingCart: any[]) => this.isValidCart(shoppingCart, primaryBenefitId, childBenefitId),
      getMatchingConfiguration: () => this.getMatchingConfiguration(primaryBenefitId, childBenefitId)
    };
  }

  private getBenefitsIds(matchingBenefits: any[]): string[] | null {
    if (!matchingBenefits || !Array.isArray(matchingBenefits) || !matchingBenefits.length) {
      return null;
    }

    const filteredArr = matchingBenefits.filter(Boolean).map(x => x.replace('[', '').replace(']', ''));
    return filteredArr.length ? filteredArr[0].trim().split(':') : null;
  }

  private restrictPlanSelectionAccordingToDependentMatching(benefitId: string, shoppingCart: any[], primaryBenefitId: string, childBenefitId: string): boolean {
    if (!this.getBenefitsShouldBeMatched(primaryBenefitId, childBenefitId)) {
      return false;
    }

    if (benefitId !== childBenefitId) {
      return false;
    }

    const primaryBenefit = this.getPrimaryBenefit(shoppingCart, primaryBenefitId);
    if (!primaryBenefit) {
      return false;
    }

    return primaryBenefit.IsNoCov;
  }

  private getMatchingConfiguration(primaryBenefitId: string, childBenefitId: string) {
    return {
      benefitsShouldBeMatched: this.getBenefitsShouldBeMatched(primaryBenefitId, childBenefitId),
      primaryBenefitId,
      childBenefitId
    };
  }

  private getBenefitsShouldBeMatched(primaryBenefitId: string, childBenefitId: string): boolean {
    return !!primaryBenefitId && !!childBenefitId;
  }

  private isValidCart(shoppingCart: any[], primaryBenefitId: string, childBenefitId: string): boolean {
    const primaryBenefit = this.getPrimaryBenefit(shoppingCart, primaryBenefitId);
    const childBenefit = this.getChildBenefit(shoppingCart, childBenefitId);

    if (!primaryBenefit || !childBenefit) {
      return true;
    }

    if (childBenefit.IsNoCov) {
      return true;
    }

    return !primaryBenefit.IsNoCov && this.hasSameDependents(primaryBenefit, childBenefit);
  }

  private getPrimaryBenefit(shoppingCart: any[], primaryBenefitId: string) {
    return this.getBenefit(shoppingCart, primaryBenefitId);
  }

  private getChildBenefit(shoppingCart: any[], childBenefitId: string) {
    return this.getBenefit(shoppingCart, childBenefitId);
  }

  private getBenefit(shoppingCart: any[], id: string) {
    return shoppingCart.find(item => item.BenefitID === id);
  }

  private hasSameDependents(primaryBenefit: any, childBenefit: any): boolean {
    const primaryDependents = primaryBenefit.DependentAssociationList;
    const childDependents = childBenefit.DependentAssociationList;

    return !primaryDependents.some(dep => !childDependents.includes(dep)) &&
           !childDependents.some(dep => !primaryDependents.includes(dep));
  }
}
