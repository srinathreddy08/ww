import { Injectable } from '@angular/core';
import { StaticContent } from './static-content.service';
import { ContentAliasService } from './content-alias.service';
import { BenefitCategoriesService } from './benefit-categories.service';

@Injectable({
  providedIn: 'root'
})
export class BenefitCarrierDataService {
  constructor(
    private staticContent: StaticContent,
    private contentAliasService: ContentAliasService,
    private benefitCategoriesService: BenefitCategoriesService
  ) {}

  dataFor(benefit: any, selectedPlan: any, employeeData: any, employeeType: string) {
    const benefitId = benefit.BenefitID;
    const benefitData = employeeData.Data[employeeType].LifeEvents[0].EligibleBenefits.find(
      (eligibleBenefit: any) => eligibleBenefit.BenefitID === benefitId
    );
    const benefitPlanCarrier = benefitData && benefitData.EligiblePlans[0].CarrierID;
    const isSupplemental = benefit.BenefitCategory === 'SUPPLEMENTAL';

    const metlifeSpecialBenefitsMap: Record<string, string> = {
      ACCIDENT: 'Accident',
      CRITILL: 'Critical',
      HOSPITAL: 'Hospital'
    };

    const isMetlifeSpecialBenefit = (): string | false => {
      if (!isSupplemental) {
        return false;
      }

      if (benefitPlanCarrier && selectedPlan.Carrier.CarrierId !== 'METLIFE') {
        return false;
      }

      return metlifeSpecialBenefitsMap[benefitId];
    };

    const getCarrierLogo = (): string | null => {
      const carrierData = benefitPlanCarrier && selectedPlan.Carrier.CarrierContent;
      if (!carrierData) {
        return null;
      }

      const carrierLogo = carrierData.CarrierLogo;
      if (!carrierLogo) {
        return null;
      }

      return carrierLogo.MediaId;
    };

    const getLogo = (): string | null => {
      if (!isSupplemental) {
        return null;
      }

      const carrierLogo = getCarrierLogo();
      if (carrierLogo) {
        return carrierLogo;
      }

      if (isMetlifeSpecialBenefit()) {
        return this.staticContent.Images['MetLife-logo-blue-PMS285'].MediaId;
      }

      return null;
    };

    const category = () => {
      return this.benefitCategoriesService.GetCategoryByName(benefit.BenefitCategory);
    };

    const hasContent = (alias: string) => {
      const data = this.contentAliasService.forData(employeeData);
      return data.getObject(alias);
    };

    const getAlias = (aliasSource: any) => {
      const ownAliasPrefix = aliasSource.ownAliasPrefix();
      let alias;

      if (ownAliasPrefix) {
        alias = `${ownAliasPrefix}.${benefitId}`;

        if (hasContent(alias)) {
          return alias;
        }
      }

      if (isMetlifeSpecialBenefit()) {
        const id = metlifeSpecialBenefitsMap[benefitId];
        alias = aliasSource.metlife(id);

        if (hasContent(alias)) {
          return alias;
        }
      }

      return null;
    };

    const extraCopyAliasSource = {
      ownAliasPrefix: () => category().BenefitAliasPrefix,
      metlife: (id: string) => `HB.LifeEvents.VoluntaryBenefits.${id}.MetlifeCopy`
    };

    const agreementAliasSource = {
      ownAliasPrefix: () => category().AgreementAliasPrefix,
      metlife: (id: string) => `HB.LifeEvents.VoluntaryBenefits.${id}${id === 'Accident' ? '.MetLifeAgreement' : '.MetlifeAgreement'}`
    };

    const getAliases = () => {
      return {
        AgreementAlias: getAlias(agreementAliasSource),
        ExtraCopyAlias: getAlias(extraCopyAliasSource)
      };
    };

    return {
      Aliases: getAliases(),
      LogoMediaId: getLogo()
    };
  }
}
