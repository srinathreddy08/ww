import { Injectable } from '@angular/core';
import { ParseLinkService } from './parse-link.service';
import { EmployeeStateService } from './employee-state.service';
import { cloneDeep, forEach, includes, map, keyBy, mapValues, toArray, compact } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class CarrierOverrideService {
  constructor(
    private parseLinkService: ParseLinkService,
    private employeeStateService: EmployeeStateService
  ) {}

  allOverrides(enrollmentContent: any): void {
    const overrideContentProperties = this.getOverrideContentProperties(enrollmentContent);
    const internetAddressOverrideProperties = this.getInternetAddressOverrideProperties(enrollmentContent);

    const allBenefitsWithLifeEvent = this.employeeStateService.forAllEmployees(enrollmentContent.contentSource).getAllBenefitsInLifeEvents();

    forEach(allBenefitsWithLifeEvent, (benefitItem: any) => {
      const benefit = benefitItem.benefit;
      const lifeEvent = benefitItem.lifeEvent;
      this.getAllPlansForBenefitWithElected(benefit).forEach((plan: any) => {
        this.overrideCarrierInPlan(plan, benefit, lifeEvent, overrideContentProperties, internetAddressOverrideProperties, enrollmentContent);
      });
    });
  }

  private overrideCarrierInPlan(plan: any, benefit: any, lifeEvent: any, overrideContentProperties: any, internetAddressOverrideProperties: any, enrollmentContent: any): void {
    const carrier = cloneDeep(lifeEvent.Carriers[plan.CarrierID]);
    if (!carrier) {
      return;
    }
    let carrierContent = cloneDeep(enrollmentContent.getContentObject(carrier.CarrierAlias));
    delete carrier.CarrierAlias;
    delete plan.CarrierID;
    plan.Carrier = carrier;

    carrier.InternetAdress = this.getInternetAddress(carrier, lifeEvent, internetAddressOverrideProperties);
    this.overrideContentFields(carrier, carrierContent, overrideContentProperties, benefit);
    carrier.CarrierContent = carrierContent;
  }

  private overrideContentFields(carrier: any, carrierContent: any, overrideContentProperties: any, benefit: any): void {
    const contentProperty = this.getContentPropertyItem(carrier, overrideContentProperties, benefit);

    if (!contentProperty) {
      return;
    }

    const allFieldsAreEmpty = Object.keys(contentProperty).every(key => {
      if (typeof contentProperty[key] === 'object') {
        return Object.keys(contentProperty[key]).every(subkey => !contentProperty[subkey]);
      }
      return !contentProperty[key];
    });

    if (allFieldsAreEmpty) {
      carrierContent = null;
      return;
    }

    carrierContent.CarrierLogo = this.getCarrierLogo(contentProperty, carrierContent);
    carrierContent.LongName = contentProperty.LongName || carrierContent.LongName;
    carrierContent.ShortName = contentProperty.ShortName || carrierContent.ShortName;
  }

  private getCarrierLogo(contentProperty: any, carrierContent: any): any {
    const newCarrierLogo = contentProperty.CarrierLogo;
    const isCarrierLogoConfigured = newCarrierLogo && newCarrierLogo.MediaId;
    return isCarrierLogoConfigured ? newCarrierLogo : carrierContent.CarrierLogo;
  }

  private getContentPropertyItem(carrier: any, overrideContentProperties: any, benefit: any): any {
    const item = overrideContentProperties[carrier.CarrierId];
    if (!item) {
      return null;
    }

    if (!item.BenefitCategories) {
      return item;
    }

    if (includes(item.BenefitCategories, benefit.BenefitCategory)) {
      return item;
    }

    return null;
  }

  private getInternetAddress(carrier: any, lifeEvent: any, internetAddressOverrideProperties: any): string {
    const carrierToOverride = internetAddressOverrideProperties.find((prop: any) => prop.planYear === lifeEvent.PlanYear && prop.carrierID === carrier.CarrierId);
    return carrierToOverride ? carrierToOverride.link : carrier.InternetAdress;
  }

  private getAllPlansForBenefitWithElected(benefit: any): any[] {
    return benefit.ElectedPlan ? [...benefit.EligiblePlans, benefit.ElectedPlan] : benefit.EligiblePlans;
  }

  private getOverrideContentProperties(enrollmentContent: any): any {
    return mapValues(keyBy(enrollmentContent.getAliasObject('HB.LifeEvent.CarrierNameOverride'), 'HB.LIFEEVENT.CARRIERNAMEOVERRIDE'), (item: any) => {
      const content = cloneDeep(enrollmentContent.getContentObject(item.CONTENT_ALIAS));
      content.BenefitCategories = content.BenefitCategory ? map(content.BenefitCategory.split(','), (cat: string) => cat.trim()) : null;
      delete content.BenefitCategory;
      return content;
    });
  }

  private getInternetAddressOverrideProperties(enrollmentContent: any): any[] {
    return compact(toArray(mapValues(enrollmentContent.getAliasObject('HB.LifeEvent.CarrierURLOverride'), 'ContentPath')).map((value: any, key: string) => {
      const valueContent = enrollmentContent.getContentObject(value);
      return valueContent && valueContent.Link ? {
        planYear: parseInt(valueContent['Plan Year']),
        link: this.parseLinkService.parseLink(valueContent.Link).url,
        carrierID: key.split(':')[0]
      } : null;
    }));
  }
}
