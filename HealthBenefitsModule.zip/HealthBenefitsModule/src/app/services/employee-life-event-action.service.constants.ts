import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeLifeEventActionServiceConstants {
  types = ['TYPE1', 'TYPE2', 'TYPE3']; // Example types, replace with actual constants
}
