import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OptionStatusService {
  isAvailableForUpdate(option: { Status: string }): boolean {
    return ['A', 'E'].includes(option.Status);
  }
}
