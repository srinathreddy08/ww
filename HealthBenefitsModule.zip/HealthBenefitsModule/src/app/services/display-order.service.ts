import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DisplayOrderService {
  getDisplayOrderMap(configuration: any): Record<string, number> | null {
    const benefitDisplayOrderOverrideConfig = configuration['HB.LifeEvent.BenefitDisplayOrderOverride'];
    if (!benefitDisplayOrderOverrideConfig) {
      return null;
    }

    const displayOrderMap: Record<string, number> = {};
    for (const item of benefitDisplayOrderOverrideConfig) {
      const displayOrder = parseInt(item['DISPLAY_ORDER'], 10);
      if (!isNaN(displayOrder)) {
        displayOrderMap[item['HB.LIFEEVENT.BENEFITDISPLAYORDEROVERRIDE']] = displayOrder;
      }
    }
    return displayOrderMap;
  }
}
