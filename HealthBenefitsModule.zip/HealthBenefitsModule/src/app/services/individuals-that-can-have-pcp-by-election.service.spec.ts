import { TestBed } from '@angular/core/testing';
import { IndividualsThatCanHavePcpByElectionService } from './individuals-that-can-have-pcp-by-election.service';
import { PcpDomainHelpers } from './pcp-domain-helpers.service';

class MockPcpDomainHelpers {
  forData(employeeData: any) {
    return {
      pending: {
        plan: (election: any) => ({ PlanID: 'newPlanId' }),
        employee: () => ({ Ssn: '123', Dependents: [{ Ssn: '456' }] })
      },
      current: {
        electedPlan: (election: any) => ({ PlanID: 'currentPlanId', ElectedOption: { DependentAssociations: [{ DependentSsn: '789' }] } })
      }
    };
  }
}

describe('IndividualsThatCanHavePcpByElectionService', () => {
  let service: IndividualsThatCanHavePcpByElectionService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        IndividualsThatCanHavePcpByElectionService,
        { provide: PcpDomainHelpers, useClass: MockPcpDomainHelpers }
      ]
    });
    service = TestBed.inject(IndividualsThatCanHavePcpByElectionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return individuals that can have PCP', () => {
    const election = { DependentAssociationList: ['456', '789'] };
    const employeeData = {};
    const result = service.getIndividualsThatCanHavePcp(election, employeeData);
    expect(result).toEqual([{ Ssn: '123', Dependents: [{ Ssn: '456' }] }]);
  });
});
