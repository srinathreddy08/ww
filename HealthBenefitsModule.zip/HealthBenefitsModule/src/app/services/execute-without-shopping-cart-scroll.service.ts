import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ExecuteWithoutShoppingCartScrollService {
  private needToShowWidget = true;

  execute(action: () => Promise<any>): Promise<any> {
    this.needToShowWidget = false;
    return action().finally(() => {
      this.needToShowWidget = true;
    });
  }

  needToShowWidgetStatus(): boolean {
    return this.needToShowWidget;
  }
}
