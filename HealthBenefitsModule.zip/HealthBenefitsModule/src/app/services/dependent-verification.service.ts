import { Injectable } from '@angular/core';
import { TimeService } from './time.service';
import { ContentAliasService } from './content-alias.service';
import { OverlayService } from './overlay.service';
import { LifeEventVerificationService } from './life-event-verification.service';
import { of } from 'rxjs';
import { comparisonBenefitCategories, displayedComparisonCategories } from './constants';

@Injectable({
  providedIn: 'root'
})
export class DependentVerificationService {
  constructor(
    private timeService: TimeService,
    private contentAliasService: ContentAliasService,
    private overlayService: OverlayService,
    private lifeEventVerificationService: LifeEventVerificationService
  ) {}

  forData(employeeData: any) {
    const content = this.contentAliasService.forData(employeeData);
    const isVerificationDocumentsToggle = content.getConfigurationValue('HB.VerificationDocuments.Toggle') === 'Yes';

    return {
      dependentIsCountedAsUnverified: (dependent: any, elections: any, benefitCategory: string) => this.dependentIsCountedAsUnverified(dependent, elections, benefitCategory, isVerificationDocumentsToggle, employeeData),
      isDependentPending: (dependent: any) => this.isDependentPending(dependent, isVerificationDocumentsToggle, employeeData),
      dependentRequiresVerificationByCoverage: (dependent: any, elections: any) => this.dependentRequiresVerificationByCoverage(dependent, elections),
      dependentRequiresVerificationByStatus: (dependent: any) => this.dependentRequiresVerificationByStatus(dependent, content),
      isDependentVerificationEnabled: () => this.isDependentVerificationEnabled(isVerificationDocumentsToggle, employeeData),
      showDependentVerificationOverlayForNewlyAddedDependents: (initialElections: any, newElections: any) => this.showDependentVerificationOverlayForNewlyAddedDependents(initialElections, newElections, isVerificationDocumentsToggle, employeeData),
      showDependentVerificationOverlayForNewlyCoveredDependents: (initialElections: any, newElections: any, shoppingCart: any) => this.showDependentVerificationOverlayForNewlyCoveredDependents(initialElections, newElections, shoppingCart, isVerificationDocumentsToggle, employeeData),
      overlayShowsWhen: () => this.overlayShowsWhen(content),
      getVerificationDocumentsToggle: () => isVerificationDocumentsToggle,
      showOverlayOnPlanChange: (benefitId: string, shoppingCart: any) => this.showOverlayOnPlanChange(benefitId, shoppingCart, isVerificationDocumentsToggle, employeeData),
      isCurrentCoverageHaveNotDevForDependent: (dep: any) => this.isCurrentCoverageHaveNotDevForDependent(dep, employeeData)
    };
  }

  private showOverlay(employeeData: any, isVerificationDocumentsToggle: boolean) {
    return this.overlayService.open('/life-event/views/dependent-verification-overlay', {
      employeeData,
      isVerificationDocumentsToggle
    });
  }

  private overlayShowsWhen(content: any) {
    return content.getConfiguration('HB.LifeEvent.LEDepVerificationTrigger').asSwitch({
      dependentIsAdded: '0',
      dependentIsCovered: '1'
    });
  }

  private dependentIsCountedAsUnverified(dependent: any, elections: any, benefitCategory: string, isVerificationDocumentsToggle: boolean, employeeData: any): boolean {
    if (isVerificationDocumentsToggle) {
      return this.isDependentVerificationEnabledPerBenefit(dependent, elections, benefitCategory, employeeData);
    }
    return false;
  }

  private isDependentVerificationEnabledPerBenefit(dependent: any, elections: any, benefitCategory: string, employeeData: any): boolean {
    const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
    const smallMarketData = empData.SmallMarketData;
    let listOfBenefitsEnabledForVerification = [];
    if (smallMarketData.BenefitsWithVerificationEnabled !== null) {
      listOfBenefitsEnabledForVerification = smallMarketData.BenefitsWithVerificationEnabled.split(',');
    }
    const currentElectionByBenefitCategory = Object.values(elections).find((election: any) => election.BenefitCategory === benefitCategory);
    if (listOfBenefitsEnabledForVerification.length === 0) return false;

    return smallMarketData.DepEligVerificationType === 'PEND' &&
      listOfBenefitsEnabledForVerification.includes(currentElectionByBenefitCategory.BenefitCategory) &&
      currentElectionByBenefitCategory &&
      currentElectionByBenefitCategory.DependentAssociationList &&
      currentElectionByBenefitCategory.DependentAssociationList.includes(dependent.Ssn) &&
      this.dependentRequiresVerificationByStatus(dependent, this.contentAliasService.forData(employeeData));
  }

  private dependentRequiresVerificationByStatus(dependent: any, content: any): boolean {
    if (this.dependentIsExemptedFromVerification(dependent, content)) {
      return false;
    }
    return dependent.DepVerificationStatus !== 'Y';
  }

  private dependentIsExemptedFromVerification(dependent: any, content: any): boolean {
    const relationTypesExemptFromDependentVerification = content.getConfiguration('HB.LifeEvent.RelationTypesExemptFromDependentVerification').asStringArray();
    return relationTypesExemptFromDependentVerification.includes(dependent.RelationType);
  }

  private dependentRequiresVerificationByCoverage(dependent: any, elections: any): boolean {
    return this.dependentIsCovered(dependent, elections);
  }

  private dependentIsCovered(dependent: any, elections: any): boolean {
    const dependentIsCoveredInCart = this.dependentIsCoveredIn(elections);
    return dependentIsCoveredInCart(dependent);
  }

  private isDependentPending(dependent: any, isVerificationDocumentsToggle: boolean, employeeData: any): boolean {
    if (!this.isDependentVerificationEnabled(isVerificationDocumentsToggle, employeeData)) return false;
    return this.dependentRequiresVerificationByStatus(dependent, this.contentAliasService.forData(employeeData));
  }

  private isDependentVerificationEnabled(isVerificationDocumentsToggle: boolean, employeeData: any): boolean {
    if (isVerificationDocumentsToggle) {
      const empData = employeeData.Data.PendingEmployee || employeeData.Data.FutureCoverages[0] || employeeData.Data.CurrentCoveragesEmployee;
      const smallMarketData = empData.SmallMarketData;
      return smallMarketData.DepEligVerificationType === 'PEND';
    }
    return false;
  }

  private showOverlayOnPlanChange(benefitId: string, shoppingCart: any, isVerificationDocumentsToggle: boolean, employeeData: any) {
    let shouldShowOverlay = false;
    if (isVerificationDocumentsToggle) {
      const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
      const smallMarketData = empData.SmallMarketData;
      let listOfBenefitsEnabledForVerification;

      if (smallMarketData && empData.LifeEvents[0].LifeEventVerificationStatus !== 'Y') {
        listOfBenefitsEnabledForVerification = smallMarketData.BenefitsWithVerificationEnabled !== null ? smallMarketData.BenefitsWithVerificationEnabled.split(',') : [];
        const currentPlanId = empData.LifeEvents[0].EligibleBenefits.find((benefit: any) => benefit.BenefitID === benefitId).ElectedPlan.PlanID;
        const newPlanId = shoppingCart.find((election: any) => election.BenefitID === benefitId).PlanID;

        if (smallMarketData.LifeEventVerificationType === 'ADD') {
          shouldShowOverlay = listOfBenefitsEnabledForVerification &&
            listOfBenefitsEnabledForVerification.includes(benefitId) &&
            this.lifeEventVerificationService.isLeHasLeIdForLev(smallMarketData, empData.LifeEvents[0]) &&
            currentPlanId === 'NOCOV' &&
            newPlanId !== 'NOCOV';
        } else {
          shouldShowOverlay = listOfBenefitsEnabledForVerification &&
            listOfBenefitsEnabledForVerification.includes(benefitId) &&
            this.lifeEventVerificationService.isLeHasLevType(smallMarketData) &&
            this.lifeEventVerificationService.isLeHasLeIdForLev(smallMarketData, empData.LifeEvents[0]) &&
            currentPlanId !== newPlanId;
        }
      }
    }

    if (shouldShowOverlay) {
      return this.showOverlay(employeeData, isVerificationDocumentsToggle);
    }

    return of(null);
  }

  private showDependentVerificationOverlayForNewlyAddedDependents(initialElections: any, newElections: any, isVerificationDocumentsToggle: boolean, employeeData: any) {
    let shouldShowOverlay = false;
    if (isVerificationDocumentsToggle) {
      const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
      const smallMarketData = empData.SmallMarketData;

      const isDepEligibleVerificationType = smallMarketData && (smallMarketData.DepEligVerificationType === 'PEND' || smallMarketData.DepEligVerificationType === 'NOPEND');
      shouldShowOverlay = isDepEligibleVerificationType &&
        this.overlayShowsWhen(this.contentAliasService.forData(employeeData)).dependentIsAdded &&
        this.newUnverifiedDependentsWereAdded(initialElections, newElections, employeeData);
    }

    if (shouldShowOverlay) {
      return this.showOverlay(employeeData, isVerificationDocumentsToggle);
    }

    return of(null);
  }

  private showDependentVerificationOverlayForNewlyCoveredDependents(initialElections: any, newElections: any, shoppingCart: any, isVerificationDocumentsToggle: boolean, employeeData: any) {
    let shouldShowOverlay = false;
    if (isVerificationDocumentsToggle) {
      const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
      const smallMarketData = empData.SmallMarketData;
      let listOfBenefitsEnabledForVerification;
      let isDepEligibleVerificationType;
      let lifeEventVerificationType;

      if (smallMarketData) {
        isDepEligibleVerificationType = smallMarketData.DepEligVerificationType === 'PEND' || smallMarketData.DepEligVerificationType === 'NOPEND';
        lifeEventVerificationType = smallMarketData.LifeEventVerificationType;
        listOfBenefitsEnabledForVerification = smallMarketData.BenefitsWithVerificationEnabled !== null ? smallMarketData.BenefitsWithVerificationEnabled.split(',') : [];

        shouldShowOverlay = this.overlayShowsWhen(this.contentAliasService.forData(employeeData)).dependentIsCovered &&
          isDepEligibleVerificationType &&
          shoppingCart.some((election: any) => election.IsChanged === true && listOfBenefitsEnabledForVerification && listOfBenefitsEnabledForVerification.includes(election.BenefitID)) &&
          this.newElectionsThatNeedVerificationPerBenefit(initialElections, newElections, listOfBenefitsEnabledForVerification, employeeData);

        if (!shouldShowOverlay && lifeEventVerificationType !== 'NOLEV' && empData.LifeEvents[0].LifeEventVerificationStatus !== 'Y') {
          shouldShowOverlay = this.lifeEventVerificationService.isLeHasLeIdForLev(smallMarketData, empData.LifeEvents[0]) &&
            (shoppingCart.some((election: any) => election.IsChanged === true && listOfBenefitsEnabledForVerification && listOfBenefitsEnabledForVerification.includes(election.BenefitID)) &&
              (this.isThereNewElectionsForEmployee(initialElections, newElections, listOfBenefitsEnabledForVerification, lifeEventVerificationType, employeeData) ||
                this.isCoverageAddedOrDroppedForDependentWhileLEVEnabled(newElections, listOfBenefitsEnabledForVerification, lifeEventVerificationType, employeeData)));
        }
      }
    }

    if (shouldShowOverlay) {
      return this.showOverlay(employeeData, isVerificationDocumentsToggle);
    }

    return of(null);
  }

  private newUnverifiedDependentsWereAdded(updatedDependents: any, employeeData: any): boolean {
    const dependentsBeforeSave = employeeData.Data.PendingEmployee.Dependents;

    const newDependents = updatedDependents.filter((a: any) => !dependentsBeforeSave.some((d: any) => d.Ssn === a.Ssn));

    return newDependents.some((dependent: any) => this.dependentRequiresVerificationByStatus(dependent, this.contentAliasService.forData(employeeData)));
  }

  private isCoverageAddedOrDroppedForDependentWhileLEVEnabled(newElections: any, listOfBenefitsEnabledForVerification: any, lifeEventVerificationType: string, employeeData: any): boolean {
    const currentEligibleBenefits = employeeData.Data.PendingEmployee.LifeEvents[0].EligibleBenefits.filter((benefit: any) => listOfBenefitsEnabledForVerification && listOfBenefitsEnabledForVerification.includes(benefit.BenefitID));

    return newElections.some((election: any) => {
      const electionFromDom = currentEligibleBenefits.find((benefit: any) => benefit.BenefitID === election.BenefitID);
      if (!electionFromDom) return false;
      const dependentAssociationListFromDom = electionFromDom.ElectedPlan.ElectedOption.DependentAssociations.map((dep: any) => dep.DependentSsn);
      const isAddedBen = election.DependentAssociationList.filter((d: any) => !dependentAssociationListFromDom.includes(d)).length > 0;
      const isDroppedBen = dependentAssociationListFromDom.filter((d: any) => !election.DependentAssociationList.includes(d)).length > 0;

      return lifeEventVerificationType !== 'ADD' ? isAddedBen || isDroppedBen : isAddedBen;
    });
  }

  private isThereNewElectionsForEmployee(initialElections: any, newElections: any, listOfBenefitsEnabledForVerification: any, lifeEventVerificationType: string, employeeData: any): boolean {
    const noCoveragePlanId = 'NOCOV';
    const filteredInitialElections = Array.isArray(initialElections) ? initialElections.filter((election: any) => election.PlanID !== noCoveragePlanId) : Object.values(initialElections).filter((election: any) => election.PlanID !== noCoveragePlanId);
    const newAddedElections = newElections.filter((election: any) => election.PlanID !== noCoveragePlanId);
    const droppedElections = newElections.filter((election: any) => election.PlanID === noCoveragePlanId);

    if (lifeEventVerificationType === 'ADD') {
      return newAddedElections.some((newAddedElection: any) => !filteredInitialElections.some((filteredInitialElection: any) => filteredInitialElection.BenefitID === newAddedElection.BenefitID) && listOfBenefitsEnabledForVerification.includes(newAddedElection.BenefitID));
    } else if (lifeEventVerificationType === 'BOTH' || lifeEventVerificationType === 'ANY') {
      return newAddedElections.some((newAddedElection: any) => !filteredInitialElections.some((filteredInitialElection: any) => filteredInitialElection.BenefitID === newAddedElection.BenefitID) && listOfBenefitsEnabledForVerification.includes(newAddedElection.BenefitID)) ||
        filteredInitialElections.some((filteredInitialElection: any) => droppedElections.some((droppedElection: any) => droppedElection.BenefitID === filteredInitialElection.BenefitID) && listOfBenefitsEnabledForVerification.includes(filteredInitialElection.BenefitID));
    } else {
      return false;
    }
  }

  private newElectionsThatNeedVerificationPerBenefit(initialElections: any, newElections: any, listOfBenefitsEnabledForVerification: any, employeeData: any): boolean {
    const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
    const filteredNewElectionByBenefitsWithVerificationEnabled = newElections.filter((election: any) => listOfBenefitsEnabledForVerification.includes(election.BenefitCategory) && election.PlanID !== 'NOCOV');
    let filteredInitialElectionByBenefitsWithVerificationEnabled = [];

    for (let i = 0, n = filteredNewElectionByBenefitsWithVerificationEnabled.length; i < n; i++) {
      const initialElectionThatWasChanged = Object.values(initialElections).filter((election: any) => election.BenefitCategory === filteredNewElectionByBenefitsWithVerificationEnabled[i].BenefitCategory);
      if (initialElectionThatWasChanged.length > 0) {
        filteredInitialElectionByBenefitsWithVerificationEnabled.push(initialElectionThatWasChanged[0]);
      }
    }
    if (filteredInitialElectionByBenefitsWithVerificationEnabled.length === 0) return false;

    return filteredNewElectionByBenefitsWithVerificationEnabled.some((election: any) => {
      const currentInitialElection = filteredInitialElectionByBenefitsWithVerificationEnabled.find((el: any) => el.BenefitCategory === election.BenefitCategory);
      if (!currentInitialElection) return false;
      return empData.Dependents.filter((dependent: any) => this.dependentRequiresVerificationByStatus(dependent, this.contentAliasService.forData(employeeData)))
        .filter((dep: any) => empData.LifeEvents[0].LifeEventID === '55' && !this.isCurrentCoverageHaveNotDevForDependent(dep, employeeData))
        .filter((dep: any) => !currentInitialElection.DependentAssociationList.includes(dep.Ssn))
        .filter((dep: any) => election.DependentAssociationList.includes(dep.Ssn))
        .length > 0;
    });
  }

  private isCurrentCoverageHaveNotDevForDependent(dep: any, employeeData: any): boolean {
    const currentCoveragesEmployee = employeeData.Data.CurrentCoveragesEmployee;
    const futureCoveragesEmployee = employeeData.Data.FutureCoverages[0];

    return (
      currentCoveragesEmployee &&
      currentCoveragesEmployee.SmallMarketData.DepEligVerificationType === 'NODEV' &&
      (
        currentCoveragesEmployee.LifeEvents[0].EligibleBenefits
          .filter((benefit: any) => displayedComparisonCategories.includes(benefit.BenefitCategory))
          .some((benefit: any) =>
            benefit.ElectedPlan.ElectedOption.DependentAssociations.find((dependent: any) => dependent.DependentSsn === dep.Ssn)
          ) ||
        (
          futureCoveragesEmployee &&
          futureCoveragesEmployee.LifeEvents[0].PlanYear !== futureCoveragesEmployee.PlanYearInfo.NextPlanYear &&
          futureCoveragesEmployee.LifeEvents[0].EligibleBenefits
            .filter((benefit: any) => displayedComparisonCategories.includes(benefit.BenefitCategory))
            .some((benefit: any) =>
              benefit.ElectedPlan.ElectedOption.DependentAssociations.find((dependent: any) => dependent.DependentSsn === dep.Ssn)
            )
        )
      )
    );
  }

  private dependentIsCoveredIn(elections: any) {
    return (dependent: any) => {
      return elections.filter((election: any) => this.benefitSupportsDocumentVerification(election))
        .map((election: any) => election.DependentAssociationList)
        .flat()
        .includes(dependent.Ssn);
    };
  }

  private benefitSupportsDocumentVerification(election: any): boolean {
    return comparisonBenefitCategories.includes(election.BenefitCategory);
  }
}
