import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { MbcContentAndDataService } from './mbc-content-and-data.service';
import { DependentService } from './dependent.service';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class QuestionService {
  private questionResourceUrl = '/api/questionnaire';

  constructor(
    private http: HttpClient,
    private mbcContentAndData: MbcContentAndDataService,
    private dependentService: DependentService,
    private contentAliasService: ContentAliasService
  ) {}

  save(answers: any, effectiveDate: string): Observable<any> {
    const data = { answers, effectiveDate };
    return this.http.post(`${this.questionResourceUrl}/save`, data).pipe(
      map(() => {
        const newAnswers = { ...answers };
        this.mbcContentAndData.getEnrollment().subscribe(enrollmentData => {
          const questionnaires = enrollmentData.Data.PendingEmployee.Questionnaires;
          questionnaires.forEach((questionnaire: any) => {
            Object.keys(questionnaire.Answers).forEach(key => {
              if (answers[key]) {
                questionnaire.Answers[key].Value = newAnswers[key].Value;
                questionnaire.Answers[key].SubValue = newAnswers[key].SubValue;
                delete newAnswers[key];
              }
            });
          });
          const newAnswersQuestionnaireName = 'newAnswers';
          questionnaires[newAnswersQuestionnaireName] = questionnaires[newAnswersQuestionnaireName] || { Answers: {}, Type: newAnswersQuestionnaireName };
          const newAnswersQuestionnaire = questionnaires[newAnswersQuestionnaireName].Answers;
          Object.keys(newAnswers).forEach(key => {
            newAnswersQuestionnaire[key] = {
              Value: newAnswers[key].Value,
              SubValue: newAnswers[key].SubValue,
              IsReadOnly: false
            };
          });
        });
      })
    );
  }

  answersChanged(oldQuestions: any, questions: any): boolean {
    const oldAnswers = this.getAnswers(oldQuestions);
    const answers = this.getAnswers(questions);
    return Object.keys(answers).some(key => {
      const oldAnswer = oldAnswers[key];
      return oldAnswer.Value !== answers[key].Value || oldAnswer.SubValue !== answers[key].SubValue;
    });
  }

  getAnswers(questions: any): any {
    return questions.reduce((acc: any, q: any) => {
      acc[q.Question.Key] = q.Answer;
      return acc;
    }, {});
  }

  getQuestionsForDisplay(questionnaires: any, allQuestions: any, data: any, checkSpouseDependents: boolean): any {
    const questionsToBeShown = this.getKeysToBeShown(allQuestions, data, checkSpouseDependents);
    this.setAnswersFromQuestionnaires(questionsToBeShown, questionnaires);
    return questionsToBeShown;
  }

  private setAnswersFromQuestionnaires(questions: any, questionnaires: any): void {
    const allQuestionnaires = this.getAllQuestionnaires(questionnaires);
    questions.forEach((question: any) => {
      const initialAnswer = allQuestionnaires[question.Question.Key];
      question.InitiallyAnswerIsExisting = initialAnswer ? { ...initialAnswer } : undefined;
      question.Answer = initialAnswer ? { ...initialAnswer } : { Value: null };
    });
  }

  private getAllQuestionnaires(questionnaires: any): any {
    return questionnaires.reduce((acc: any, questionnaire: any) => {
      Object.keys(questionnaire.Answers).forEach(key => {
        acc[key] = { ...questionnaire.Answers[key] };
      });
      return acc;
    }, {});
  }

  private getKeysToBeShown(allQuestions: any, data: any, checkSpouseDependents: boolean): any {
    let result = allQuestions.filter((q: any) => q);
    if (checkSpouseDependents && !this.participantHasAnySpouseDependents(data)) {
      result = this.removeTheSpouseQuestionKeys(result);
    }
    return this.getKeysThatAreConfiguredToBeShown(result);
  }

  private getKeysThatAreConfiguredToBeShown(questions: any): any {
    return questions.filter((q: any) => q.DisplayEnabled);
  }

  private removeTheSpouseQuestionKeys(questions: any): any {
    const spouseQuestions = [
      'HB.Common.CommonTerms.SPTobaccoQuestion',
      'HB.Common.CommonTerms.SPCessationQuestion',
      'HB.Common.CommonTerms.SPSurchargeQuestion'
    ];
    return questions.filter((q: any) => !spouseQuestions.includes(q.ContentEP));
  }

  private participantHasAnySpouseDependents(data: any): boolean {
    const participant = data.Data.PendingEmployee || data.Data.CurrentCoveragesEmployee || data.Data.FutureCoverages && data.Data.FutureCoverages[0];
    if (!participant || !participant.Dependents) {
      return false;
    }
    return participant.Dependents.some((dep: any) => this.dependentService.getSpouseRelationTypes().includes(dep.RelationType));
  }

  isQuestionDisplayEnabled(configuration: any, contentName: string): boolean {
    const clientConfiguration = configuration['HB.ClientConfiguration'];
    return clientConfiguration && clientConfiguration[contentName.toUpperCase() + 'FLAG'] === 'S';
  }

  createSingleQuestion(contentName: string, contentControlName: string | null, employeeData: any): any {
    const configuration = employeeData.Configuration;
    const dataContent = this.contentAliasService.forData(employeeData);
    const questionData = dataContent.getEvaluationPointValue(contentName);
    if (!questionData) {
      return null;
    }
    let displayEnabled, isEditable;
    if (contentControlName) {
      const contentControl = dataContent.getConfigurationValue(contentControlName);
      displayEnabled = contentControl.DISPLAY_ENABLED === 'True';
      isEditable = contentControl.ISEDITABLE === 'True';
    } else {
      displayEnabled = this.isQuestionDisplayEnabled(configuration, contentName);
      isEditable = true;
    }
    return {
      ContentEP: contentName,
      Question: questionData,
      DisplayEnabled: displayEnabled,
      IsEditable: isEditable
    };
  }

  createEditableQuestions(questions: any, answers: any): any {
    return questions.map((val: any) => ({
      Question: val,
      Answer: answers ? { ...answers[val.Key] } : this.createEmptyAnswer(),
      DisplayEnabled: true,
      IsEditable: true,
      MultipleOptionLogic: this.getMultipleLogic(val)
    }));
  }

  private createEmptyAnswer(): any {
    return {
      IsReadOnly: false,
      Value: '',
      SubValue: ''
    };
  }

  private getMultipleLogic(question: any): any {
    if (question.Key === 'COVERED_EXPENSES') {
      const singleOptionId = '4';
      return {
        SingleOptionId: singleOptionId,
        MapSubValuesToValue: (selectedValues: any) => {
          if (selectedValues.length === 1 && selectedValues[0] === singleOptionId) {
            return singleOptionId;
          }
          return (4 - selectedValues.length).toString();
        },
        MapValueToSubValues: (value: any) => {
          if (value === singleOptionId) {
            return singleOptionId;
          }
          const subValues = [];
          for (let i = 1; i <= 4 - value; i++) {
            subValues.push(i);
          }
          return subValues.join(',');
        }
      };
    }
    return null;
  }

  getConfigureHealthQuestionsByEventLogic(employeeData: any): boolean {
    const dataContent = this.contentAliasService.forData(employeeData);
    const configuration = dataContent.getConfigurationValue('HB.HealthQuestions.ConfigureHealthQuestionsByEventLogic');
    if (!configuration) {
      return false;
    }
    const settings = configuration['HB.HEALTHQUESTIONS.CONFIGUREHEALTHQUESTIONSBYEVENTLOGIC'];
    return settings && settings[0] === 'T';
  }
}
