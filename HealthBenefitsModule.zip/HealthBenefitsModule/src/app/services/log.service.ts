import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';

interface LogSource {
  name: string;
  isEnabledByDefault: boolean;
  isEnabled: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class LogService {
  private devToolsLoggerName = 'MBCDevTools';
  private currentLogSources: Record<string, LogSource>;
  private loggedItems: string[] = [];
  private loggers: Record<string, any>;

  constructor(private cookieService: CookieService, private logSources: Record<string, boolean>) {
    this.currentLogSources = this.createLogSources();
    this.loggers = Object.keys(this.currentLogSources).reduce((acc, logSourceName) => {
      acc[logSourceName] = this.createLogger(logSourceName);
      return acc;
    }, {} as Record<string, any>);
  }

  clear(): void {
    this.loggedItems = [];
  }

  getLoggedItems(): any[] {
    return this.loggedItems.map(item => JSON.parse(item));
  }

  getLogSources(): Record<string, LogSource> {
    return this.currentLogSources;
  }

  setLogSources(newLogSources: Record<string, LogSource>): void {
    this.currentLogSources = newLogSources;
    const changedLogSourceNames = Object.keys(this.currentLogSources)
      .filter(logSourceName => this.currentLogSources[logSourceName].isEnabledByDefault !== this.currentLogSources[logSourceName].isEnabled);
    this.cookieService.set('debugLog', changedLogSourceNames.join(','));
  }

  getLogger(logSourceName: string): any {
    let logger = this.loggers[logSourceName];
    if (!logger) {
      this.loggers[this.devToolsLoggerName].warn(`Creating logger (enabled by default) for unknown log source ${logSourceName}. Known are [${Object.keys(this.logSources).join(', ')}]. Register log source in logSources.js or fix the name.`);
      this.logSources[logSourceName] = true;
      this.currentLogSources[logSourceName] = {
        name: logSourceName,
        isEnabledByDefault: true,
        isEnabled: true
      };
      logger = this.createLogger(logSourceName);
      this.loggers[logSourceName] = logger;
    }
    return logger;
  }

  private createLogSources(): Record<string, LogSource> {
    const changedLogSourceNamesAsObject = this.cookieService.get('debugLog').split(',').reduce((acc, logSourceName) => {
      if (logSourceName.trim()) {
        acc[logSourceName.trim()] = true;
      }
      return acc;
    }, {} as Record<string, boolean>);

    return Object.keys(this.logSources).reduce((acc, logSourceName) => {
      acc[logSourceName] = {
        name: logSourceName,
        isEnabledByDefault: this.logSources[logSourceName],
        isEnabled: changedLogSourceNamesAsObject[logSourceName] !== undefined ? !this.logSources[logSourceName] : this.logSources[logSourceName]
      };
      return acc;
    }, {} as Record<string, LogSource>);
  }

  private createLogger(logSourceName: string): any {
    const commonArgs = [logSourceName];
    return {
      log: this.createLoggerFunction('log', logSourceName, commonArgs),
      info: this.createLoggerFunction('info', logSourceName, commonArgs),
      warn: this.createLoggerFunction('warn', logSourceName, commonArgs),
      error: this.createLoggerFunction('error', logSourceName, commonArgs),
      debug: this.createLoggerFunction('debug', logSourceName, commonArgs)
    };
  }

  private createLoggerFunction(level: string, logSourceName: string, commonArgs: string[]): (...args: any[]) => void {
    return (...args: any[]) => {
      if (!this.isLogEnabled(logSourceName)) {
        return;
      }
      console[level](...commonArgs, ...args);
      this.loggedItems.push(JSON.stringify({
        source: logSourceName,
        level: level,
        time: new Date(),
        details: args
      }));
    };
  }

  private isLogEnabled(logSourceName: string): boolean {
    return this.currentLogSources[logSourceName]?.isEnabled;
  }
}
