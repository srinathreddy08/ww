import { TestBed } from '@angular/core/testing';
import { HsaService, HsaServiceInstance } from './hsa.service';

describe('HsaService', () => {
  let service: HsaService;
  let serviceInstance: HsaServiceInstance;

  const employeeData = {
    Configuration: {
      'HB.Common.HSADisplay': ['CDH', 'HDHP', 'HDHP2', 'ASX*', 'MASX*']
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HsaService]
    });
    service = TestBed.inject(HsaService);
    serviceInstance = service.forData(employeeData);
  });

  describe('hsaPlansEligibility', () => {
    it('should return true when plan is HSA Eligible', () => {
      expect(serviceInstance.isPlanHsaEligible('CDH')).toBe(true);
    });

    it('should return false when plan is NOT HSA Eligible', () => {
      expect(serviceInstance.isPlanHsaEligible('AAA')).toBe(false);
    });

    it('should return true when plan is HSA Eligible by mask', () => {
      expect(serviceInstance.isPlanHsaEligible('ASXMATRIX')).toBe(true);
    });
  });

  describe('hsaPlansArrayFilter', () => {
    it('should return only plans ids', () => {
      const eligPlanIds = serviceInstance.getEligiblePlanIds();
      expect(arraysAreEqual(eligPlanIds, ['CDH', 'HDHP', 'HDHP2'])).toBe(true);
    });

    it('should return only masked plans ids', () => {
      const eligPlanIds = serviceInstance.getEligiblePlanMasks();
      expect(arraysAreEqual(eligPlanIds, ['ASX', 'MASX'])).toBe(true);
    });
  });

  function arraysAreEqual(arr1: string[], arr2: string[]): boolean {
    return arr1.length === arr2.length && arr1.every(value => arr2.includes(value));
  }
});
