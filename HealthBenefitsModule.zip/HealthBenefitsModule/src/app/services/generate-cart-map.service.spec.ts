import { TestBed } from '@angular/core/testing';
import { GenerateCartMapService } from './generate-cart-map.service';
import { Cart } from '../models/cart.model';

describe('GenerateCartMapService', () => {
  let service: GenerateCartMapService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GenerateCartMapService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should generate a cart map', () => {
    const cart: Cart = {
      ShoppingCart: [
        { BenefitID: '1', IsLostEligibility: false },
        { BenefitID: '2', IsLostEligibility: true },
        { BenefitID: '3', IsLostEligibility: false }
      ]
    };
    const result = service.generateCartMap(cart);
    expect(result).toEqual({
      '1': { BenefitID: '1', IsLostEligibility: false },
      '3': { BenefitID: '3', IsLostEligibility: false }
    });
  });
});
