import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ParseLinkService {
  parseLink(link: string): { title: string; target: string; url: string; action: () => void } {
    const targetReg = /target="(.*?)"/;
    const urlReg = /url="(.*?)"/;
    const titleReg = /title="(.*?)"/;

    const targetMatch = link.match(targetReg);
    const urlMatch = link.match(urlReg);
    const titleMatch = link.match(titleReg);

    const target = targetMatch ? targetMatch[1] : '';
    const url = urlMatch ? urlMatch[1] : '';
    const title = titleMatch ? titleMatch[1] : '';

    return {
      title,
      target,
      url,
      action: target === '_blank' ? this.openLinkInNewWindow.bind(this, url) : this.openLinkInCurrentWindow.bind(this, url)
    };
  }

  private openLinkInNewWindow(url: string): void {
    window.open(url);
    window.location.href = '/dashboard';
  }

  private openLinkInCurrentWindow(url: string): void {
    window.location.href = url;
  }
}
