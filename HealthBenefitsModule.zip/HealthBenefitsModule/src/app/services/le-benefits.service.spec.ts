import { TestBed } from '@angular/core/testing';
import { LeBenefitsService } from './le-benefits.service';
import { EnrollmentRules } from './enrollment-rules.service';
import { ContentAliasService } from './content-alias.service';
import { DepsPendingVerificationService } from './deps-pending-verification.service';
import { DependentVerificationService } from './dependent-verification.service';
import { AmountBasedBenefitService } from './amount-based-benefit.service';
import { OptionStatusService } from './option-status.service';
import { BenefitCategoriesService } from './benefit-categories.service';
import { DcService } from './dc.service';
import { MbcUtilService } from './mbc-util.service';
import { AggregateElections } from './aggregate-elections.service';
import { GenerateCartMap } from './generate-cart-map.service';
import { IsRepriceableBenefit } from './is-repriceable-benefit.service';
import { PcpService } from './pcp.service';
import { BenefitsService } from './benefits.service';
import { BenefitIconService } from './benefit-icon.service';
import { SpendingAccountsService } from './spending-accounts.service';
import { SuppressedBenefitsPlansOptionsService } from './suppressed-benefits-plans-options.service';
import { Flags } from './flags.service';

class MockService {}

fdescribe('LeBenefitsService', () => {
  let service: LeBenefitsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        LeBenefitsService,
        { provide: EnrollmentRules, useClass: MockService },
        { provide: ContentAliasService, useClass: MockService },
        { provide: DepsPendingVerificationService, useClass: MockService },
        { provide: DependentVerificationService, useClass: MockService },
        { provide: AmountBasedBenefitService, useClass: MockService },
        { provide: OptionStatusService, useClass: MockService },
        { provide: BenefitCategoriesService, useClass: MockService },
        { provide: DcService, useClass: MockService },
        { provide: MbcUtilService, useClass: MockService },
        { provide: AggregateElections, useClass: MockService },
        { provide: GenerateCartMap, useClass: MockService },
        { provide: IsRepriceableBenefit, useClass: MockService },
        { provide: PcpService, useClass: MockService },
        { provide: BenefitsService, useClass: MockService },
        { provide: BenefitIconService, useClass: MockService },
        { provide: SpendingAccountsService, useClass: MockService },
        { provide: SuppressedBenefitsPlansOptionsService, useClass: MockService },
        { provide: Flags, useClass: MockService }
      ]
    });
    service = TestBed.inject(LeBenefitsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // Additional tests can be added here to test the service methods
});
