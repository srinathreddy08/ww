import { Injectable } from '@angular/core';
import { DependencyTracker } from './dependency-tracker.service';
import { CoverageGridConfigService } from './coverage-grid-config.service';
import { LogService } from './log.service';
import { cloneDeep, keys, omit, some, includes } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class DeferredCoverageService {
  private logger = this.logService.getLogger('WhosCovered.Deferred');
  private isDeferredCoverageModeEnabled: boolean;
  private availableBenefitCategories = ['MEDICAL', 'DENTAL', 'VISION', 'U65MED', 'O65MED'];
  private savedDeferredCoveragesList: any = {};
  private tempDeferredCoveragesList: any = {};
  private coverageEligibility: any = {};
  private initialElections: any;
  private stateVersion = this.dependencyTracker.value(0);

  constructor(
    private dependencyTracker: DependencyTracker,
    private coverageGridConfigService: CoverageGridConfigService,
    private logService: LogService
  ) {}

  config(employeeData: any): void {
    this.isDeferredCoverageModeEnabled = this.coverageGridConfigService.forData(employeeData).isDeferredCoverageModeEnabled;
  }

  setInitialElections(elections: any): void {
    this.versionIncrementation(() => {
      this.removeDeferredCoveragesWhichIsAlreadyCovered(elections);
      this.tempDeferredCoveragesList = cloneDeep(this.savedDeferredCoveragesList);
      this.logger.debug('setInitialElections, elections', this.tempDeferredCoveragesList, elections);
      this.initialElections = elections;
    })();
  }

  setCoverageEligibility(benefitId: string, participantEligibility: boolean, dependentsEligibility: any): void {
    this.versionIncrementation(() => {
      this.coverageEligibility[benefitId] = {
        participantEligibility,
        dependentsEligibility
      };
      this.logger.debug('setCoverageEligibility', this.coverageEligibility);
    })();
  }

  setParticipantCoverage(value: boolean, benefitId: string): void {
    this.versionIncrementation(() => {
      if (!value) {
        delete this.tempDeferredCoveragesList[benefitId];
        this.logger.debug('setParticipantCoverage', value, benefitId, this.tempDeferredCoveragesList);
        return;
      }

      if (!this.tempDeferredCoveragesList[benefitId]) {
        this.tempDeferredCoveragesList[benefitId] = { DependentAssociationList: {} };
      }

      this.logger.debug('setParticipantCoverage', value, benefitId, this.tempDeferredCoveragesList);
    })();
  }

  setDependentCoverage(value: boolean, benefitId: string, dependentId: string): void {
    this.versionIncrementation(() => {
      if (!this.isDependentEligible(benefitId, dependentId)) {
        return;
      }

      if (value) {
        this.setParticipantCoverage(true, benefitId);
        this.tempDeferredCoveragesList[benefitId].DependentAssociationList[dependentId] = true;
        return;
      }

      if (this.tempDeferredCoveragesList[benefitId]) {
        delete this.tempDeferredCoveragesList[benefitId].DependentAssociationList[dependentId];

        if (this.participantIsNotEligibleAndNoDependents(benefitId)) {
          this.setParticipantCoverage(false, benefitId);
        }
      }

      this.logger.debug('setDependentCoverage', value, benefitId, dependentId, this.tempDeferredCoveragesList);
    })();
  }

  doesParticipantHaveDeferredCoverage(benefitId: string): boolean {
    return this.versionChecker(() => {
      if (!this.isDeferredCoverageModeEnabled) {
        return false;
      }

      const result = this.doesCoverageContainBenefit(this.tempDeferredCoveragesList, benefitId);
      this.logger.debug('doesParticipantHaveDeferredCoverage', benefitId, result);
      return result;
    })();
  }

  doesDependentHaveDeferredCoverage(benefitId: string, dependentId: string): boolean {
    return this.versionChecker(() => {
      if (!this.isDeferredCoverageModeEnabled) {
        return false;
      }

      const result = this.doesParticipantHaveDeferredCoverage(benefitId) && this.tempDeferredCoveragesList[benefitId].DependentAssociationList[dependentId];
      this.logger.debug('doesDependentHaveDeferredCoverage', benefitId, dependentId, result);
      return result;
    })();
  }

  shouldWorkWithDeferredElection(electionItem: any): boolean {
    return this.versionChecker(() => {
      if (!this.isDeferredCoverageModeEnabled || !this.initialElections) {
        return false;
      }

      if (Array.isArray(electionItem)) {
        return electionItem.every((election: any) => {
          const benefitId = election.BenefitId;
          return this.initialElections[benefitId] && includes(this.availableBenefitCategories, election.BenefitCategory) && this.initialElections[benefitId].IsNoCov;
        });
      }

      const initialElection = this.initialElections[electionItem];
      return initialElection && includes(this.availableBenefitCategories, initialElection.BenefitCategory) && initialElection.IsNoCov;
    })();
  }

  getSavedDeferredCoverages(): any {
    return this.versionChecker(() => this.savedDeferredCoveragesList)();
  }

  getTempDeferredCoverages(): any {
    return this.versionChecker(() => {
      return mapValues(this.tempDeferredCoveragesList, (v: any) => {
        return {
          DependentAssociationList: keys(v.DependentAssociationList).filter((key: string) => v.DependentAssociationList[key])
        };
      });
    })();
  }

  doesParticipantHaveSavedDeferredCoverage(benefitId: string): boolean {
    return this.versionChecker(() => {
      if (!this.isDeferredCoverageModeEnabled) {
        return false;
      }

      const result = this.doesCoverageContainBenefit(this.savedDeferredCoveragesList, benefitId);
      this.logger.debug('doesParticipantHaveSavedDeferredCoverage', benefitId, result);
      return result;
    })();
  }

  save(): void {
    this.versionIncrementation(() => {
      this.logger.debug('savedDeferredCoveragesList', this.savedDeferredCoveragesList);
      this.savedDeferredCoveragesList = cloneDeep(this.tempDeferredCoveragesList);
      this.logger.debug('save', this.savedDeferredCoveragesList);
    })();
  }

  clear(): void {
    this.versionIncrementation(() => {
      this.savedDeferredCoveragesList = {};
      this.tempDeferredCoveragesList = {};
      this.coverageEligibility = {};
      this.initialElections = {};
    })();
  }

  private doesCoverageContainBenefit(coverageList: any, benefitId: string | string[]): boolean {
    if (!benefitId) {
      return keys(coverageList).length > 0;
    }

    if (typeof benefitId === 'string') {
      return coverageList.hasOwnProperty(benefitId);
    }

    if (Array.isArray(benefitId)) {
      return some(benefitId, (id: string) => coverageList.hasOwnProperty(id));
    }

    return false;
  }

  private isDependentEligible(benefitId: string, dependentId: string): boolean {
    return this.coverageEligibility[benefitId] && this.coverageEligibility[benefitId].dependentsEligibility[dependentId];
  }

  private participantIsNotEligibleAndNoDependents(benefitId: string): boolean {
    const coverageEligibilityItem = this.coverageEligibility[benefitId];
    const coverage = this.tempDeferredCoveragesList[benefitId];

    if (coverageEligibilityItem && coverageEligibilityItem.participantEligibility) {
      return false;
    }

    return coverage && keys(coverage.DependentAssociationList).length === 0;
  }

  private removeDeferredCoveragesWhichIsAlreadyCovered(elections: any): void {
    const coveredElections = keys(elections).filter(key => !elections[key].IsNoCov);
    this.savedDeferredCoveragesList = omit(this.savedDeferredCoveragesList, coveredElections);
  }

  private versionIncrementation(action: Function): Function {
    return (...args: any[]) => {
      this.stateVersion.write(this.stateVersion() + 1);
      this.logger.debug('callWithDependencyTrackerCounterIncrementation', this.stateVersion());
      return action.apply(this, args);
    };
  }

  private versionChecker(action: Function): Function {
    return (...args: any[]) => {
      this.logger.debug('callWithDependencyTrackerTriggering', this.stateVersion());
      this.stateVersion();
      return action.apply(this, args);
    };
  }
}
