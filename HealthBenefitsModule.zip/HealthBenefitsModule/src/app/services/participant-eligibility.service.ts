import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class ParticipantEligibilityService {
  private retireeSplitOptionIdentifiers = {
    'U65MED': 'HB.Common.CommonTerms.Under65RetireeOptionIdentifier',
    'O65MED': 'HB.Common.CommonTerms.Over65RetireeOptionIdentifier',
    'DENTAL': 'HB.Common.CommonTerms.RetireeDentalOptionIdentifier',
    'VISION': 'HB.Common.CommonTerms.RetireeVisionOptionIdentifier'
  };

  constructor(private contentAliasService: ContentAliasService) {}

  forData(employeeData: any) {
    const data = this.contentAliasService.forData(employeeData);

    return {
      isParticipantEligibleForOption: (benefit: any, optionId: string) => this.isParticipantEligibleForOption(data, benefit, optionId)
    };
  }

  private isParticipantEligibleForOption(data: any, benefit: any, optionId: string): boolean {
    const retireeOptionIdentifierEp = this.retireeSplitOptionIdentifiers[benefit.BenefitCategory];

    if (!retireeOptionIdentifierEp) {
      return true;
    }

    const optionIdPart = this.retireeOptionIdPart(data, retireeOptionIdentifierEp, benefit);

    if (!optionIdPart) {
      return true;
    }

    return optionId.includes(optionIdPart.value);
  }

  private retireeOptionIdPart(data: any, retireeOptionIdentifierEp: string, benefit: any): any {
    const retireeOptionConfig = data.getAlias(retireeOptionIdentifierEp);

    if (!retireeOptionConfig.value) {
      return null;
    }

    if (typeof retireeOptionConfig.value === 'string') {
      return retireeOptionConfig.getContent();
    }

    const applicableBenefitIds = retireeOptionConfig.getField(retireeOptionIdentifierEp.toUpperCase()).asStringArray();

    if (!applicableBenefitIds.includes(benefit.BenefitID)) {
      return null;
    }

    return retireeOptionConfig.getLinkedContent();
  }
}
