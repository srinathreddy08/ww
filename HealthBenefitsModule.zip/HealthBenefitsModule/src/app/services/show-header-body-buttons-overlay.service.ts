import { Injectable } from '@angular/core';
import { OverlayService } from './overlay.service';
import { Observable } from 'rxjs';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShowHeaderBodyButtonsOverlayService {
  constructor(private overlayService: OverlayService) {}

  showHeaderBodyButtonsOverlay(params: any): Observable<any> {
    const template = params.template ? params.template : '/shared/views/overlay/headerBodyButtonsOverlay';
    this.overlayService.open(template, params);
    return of(null); // Simulating the promise resolution
  }
}
