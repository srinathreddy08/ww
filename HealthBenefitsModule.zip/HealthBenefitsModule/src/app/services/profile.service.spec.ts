import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ProfileService } from './profile.service';
import { PubSubService } from './pubsub.service';

class MockPubSubService {
  publish(event: string) {}
}

describe('ProfileService', () => {
  let service: ProfileService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        ProfileService,
        { provide: PubSubService, useClass: MockPubSubService }
      ]
    });
    service = TestBed.inject(ProfileService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch profile data', () => {
    const mockData = { name: 'John Doe' };
    service.get().subscribe(data => {
      expect(data).toEqual(mockData);
    });
    const req = httpMock.expectOne('/api/profile/getProfile');
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should save profile data and publish event', () => {
    const mockData = { name: 'John Doe' };
    const pubsubSpy = spyOn(TestBed.inject(PubSubService), 'publish');
    service.save(mockData).subscribe();
    const req = httpMock.expectOne('/api/profile/saveProfile');
    expect(req.request.method).toBe('POST');
    req.flush({});
    expect(pubsubSpy).toHaveBeenCalledWith('profileWasUpdated');
  });
});
