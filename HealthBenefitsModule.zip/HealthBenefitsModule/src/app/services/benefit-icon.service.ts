import { Injectable } from '@angular/core';
import { BenefitCategoriesService } from './benefit-categories.service';
import { BenefitPropertyMap } from './benefit-property-map';

@Injectable({
  providedIn: 'root'
})
export class BenefitIconService {
  constructor(
    private benefitCategoriesService: BenefitCategoriesService,
    private benefitPropertyMap: BenefitPropertyMap
  ) {}

  getIcon(benefit: any): string {
    return this.getIconByBenefitId(benefit.BenefitID)
      || this.benefitCategoriesService.GetCategoryByName(benefit.BenefitCategory).icon
      || this.benefitCategoriesService.GetDefaultCategory().icon;
  }

  private getIconByBenefitId(benefitId: string): string | null {
    return this.benefitPropertyMap[benefitId]?.icon || null;
  }
}
