import { TestBed } from '@angular/core/testing';
import { ParticipantEligibilityService } from './participant-eligibility.service';
import { ContentAliasService } from './content-alias.service';

class MockContentAliasService {
  forData(employeeData: any) {
    return {
      getAlias: (alias: string) => ({
        value: 'someValue',
        getContent: () => ({ value: 'someContent' }),
        getField: (field: string) => ({
          asStringArray: () => ['benefit1', 'benefit2']
        }),
        getLinkedContent: () => ({ value: 'linkedContent' })
      })
    };
  }
}

describe('ParticipantEligibilityService', () => {
  let service: ParticipantEligibilityService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ParticipantEligibilityService,
        { provide: ContentAliasService, useClass: MockContentAliasService }
      ]
    });
    service = TestBed.inject(ParticipantEligibilityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true for eligible option', () => {
    const result = service.forData({}).isParticipantEligibleForOption({ BenefitCategory: 'U65MED', BenefitID: 'benefit1' }, 'someOptionId');
    expect(result).toBe(true);
  });

  it('should return false for ineligible option', () => {
    const result = service.forData({}).isParticipantEligibleForOption({ BenefitCategory: 'U65MED', BenefitID: 'benefit3' }, 'someOptionId');
    expect(result).toBe(false);
  });
});
