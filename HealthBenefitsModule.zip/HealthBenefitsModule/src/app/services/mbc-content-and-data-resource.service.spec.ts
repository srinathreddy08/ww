import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { MbcContentAndDataResourceService } from './mbc-content-and-data-resource.service';
import { StaticContentService } from './static-content.service';
import { TransformOpenEnrollmentService } from './transform-open-enrollment.service';
import { PubSubService } from './pubsub.service';
import { ProcessTokensInDataService } from './process-tokens-in-data.service';
import { ContentAliasService } from './content-alias.service';
import { ReloadCurrentStateService } from './reload-current-state.service';

class MockService {}

describe('MbcContentAndDataResourceService', () => {
  let service: MbcContentAndDataResourceService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        MbcContentAndDataResourceService,
        { provide: StaticContentService, useClass: MockService },
        { provide: TransformOpenEnrollmentService, useClass: MockService },
        { provide: PubSubService, useClass: MockService },
        { provide: ProcessTokensInDataService, useClass: MockService },
        { provide: ContentAliasService, useClass: MockService },
        { provide: ReloadCurrentStateService, useClass: MockService }
      ]
    });
    service = TestBed.inject(MbcContentAndDataResourceService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch processed data', () => {
    const mockData = { key: 'value' };
    service.getProcessedData('testKey').subscribe(data => {
      expect(data).toEqual(mockData);
    });
    const req = httpMock.expectOne('/api/content/testKey');
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  // Add more tests to cover various cases
});
