import { Injectable } from '@angular/core';
import { AddToCartCounterService } from './add-to-cart-counter.service';
import { ExecuteWithSpinnerIfDisplayingService } from './execute-with-spinner-if-displaying.service';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ExecuteAddToCartActionService {
  constructor(
    private addToCartCounter: AddToCartCounterService,
    private executeWithSpinnerIfDisplaying: ExecuteWithSpinnerIfDisplayingService
  ) {}

  executeAddToCartAction(action: () => Observable<any>): Observable<any> {
    this.addToCartCounter.startAddToCartAction();

    return this.executeWithSpinnerIfDisplaying.execute(action).pipe(
      finalize(() => this.addToCartCounter.finishAddToCartAction())
    );
  }
}
