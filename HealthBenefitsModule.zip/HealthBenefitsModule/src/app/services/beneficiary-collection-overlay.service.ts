import { Injectable } from '@angular/core';
import { MbcContentAndDataService } from './mbc-content-and-data.service';
import { ShowHeaderBodyButtonsOverlayService } from './show-header-body-buttons-overlay.service';
import { ExecuteWithoutShoppingCartScrollService } from './execute-without-shopping-cart-scroll.service';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BeneficiaryCollectionOverlayService {
  constructor(
    private mbcContentAndData: MbcContentAndDataService,
    private showHeaderBodyButtonsOverlay: ShowHeaderBodyButtonsOverlayService,
    private executeWithoutShoppingCartScroll: ExecuteWithoutShoppingCartScrollService
  ) {}

  beneficiaryCollectionOverlay(benefitId: string, newCartObject: any): void {
    if (!benefitId) {
      return;
    }

    const promises = {
      newCart: newCartObject.$promise,
      enrollmentContent: this.mbcContentAndData.getEnrollmentContent()
    };

    forkJoin(promises).subscribe(data => this.beneficiaryCollectionOverlayAsync(data, benefitId));
  }

  private beneficiaryCollectionOverlayAsync(data: any, benefitId: string): void {
    if (!this.needShowOverlay(data, benefitId)) {
      return;
    }

    const ep = data.enrollmentContent.getEvaluationPointValue('HB.LifeEvent.BeneficiaryRequirementReminderOverlay');

    this.executeWithoutShoppingCartScroll.execute(() => {
      return this.showHeaderBodyButtonsOverlay.show({
        header: ep.Title,
        body: ep.Copy,
        noButton: {
          shouldShowCloseButton: true,
          hideBottomNoButton: true
        }
      });
    });
  }

  private needShowOverlay(data: any, benefitId: string): boolean {
    const newCart = data.newCart;
    const enrollmentContent = data.enrollmentContent;

    const newCartItem = newCart.ShoppingCart.find((item: any) => item.BenefitID === benefitId);
    const enrollmentBenefit = enrollmentContent.data.PendingEmployee.LifeEvents[0].EligibleBenefitsMap[benefitId];

    if (!newCartItem || !enrollmentBenefit) {
      return false;
    }

    const electedPlan = enrollmentBenefit.EligiblePlansMap[newCartItem.PlanID];

    if (electedPlan.IsNoCovPlan || electedPlan.PlanYearDefBeneRequirement !== 'R') {
      return false;
    }

    if (newCart.BeneficiaryData.Designations && newCart.BeneficiaryData.Designations[benefitId]) {
      return false;
    }

    return true;
  }
}
