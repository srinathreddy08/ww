import { Injectable } from '@angular/core';
import { EventService } from './event.service';

@Injectable({
  providedIn: 'root'
})
export class PcpUpdatedEventService {
  constructor(private eventService: EventService) {}

  createPcpUpdatedEvent() {
    return this.eventService.createEvent('pcpUpdated');
  }
}
