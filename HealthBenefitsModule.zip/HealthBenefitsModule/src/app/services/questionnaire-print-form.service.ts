import { Injectable } from '@angular/core';
import { QuestionService } from './question.service';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class QuestionnairePrintFormService {
  private submitCache: any = null;

  constructor(
    private questionService: QuestionService,
    private contentAliasService: ContentAliasService
  ) {}

  fillSubmitCache(enrollment: any): void {
    this.submitCache = this.getQuestions(enrollment, 'PendingEmployee');
  }

  getQuestions(enrollment: any, employeeType: string): { questions: any; title: string } {
    const questionsData = this.questionService.getDataForMyInformation(enrollment, employeeType);
    const questions = Object.fromEntries(Object.entries(this.questionService.filterAndSortQuestions(questionsData)).map(([key, question]) => [key, this.mapQuestion(question)]));
    const enrollmentContent = this.contentAliasService.forData(enrollment);
    const title = enrollmentContent.getEvaluationPointValue('HB.LifeEvent.GetStarted.WhosCovered.MyBenefitsHeader');
    return {
      questions,
      title
    };
  }

  getSubmitCache(): any {
    return this.submitCache;
  }

  private mapQuestion(question: any): { title: string; answers: any } {
    return {
      title: question.Question.Text,
      answers: question.Question.Options[question.Answer.Value]
    };
  }
}
