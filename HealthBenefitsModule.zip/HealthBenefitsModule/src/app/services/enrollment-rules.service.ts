import { Injectable } from '@angular/core';
import { RulesEngine } from './rules-engine.service';
import { MbcUtilService } from './mbc-util.service';
import { MbcContentAndDataService } from './mbc-content-and-data.service';
import { BenefitCategoriesService } from './benefit-categories.service';
import { TimeService } from './time.service';
import { EmployeeCoverageService } from './employee-coverage.service';
import { DeferredCoverageService } from './deferred-coverage.service';
import { LoggerService } from './logger.service';
import { getCoveredDependentCounts } from './dependent-counts.service';
import { isDependentVerificationEnabled } from './verification.service';

@Injectable({
  providedIn: 'root'
})
export class EnrollmentRulesService {
  constructor(
    private rulesEngine: RulesEngine,
    private mbcUtilService: MbcUtilService,
    private mbcContentAndData: MbcContentAndDataService,
    private benefitCategoriesService: BenefitCategoriesService,
    private timeService: TimeService,
    private employeeCoverageService: EmployeeCoverageService,
    private deferredCoverageService: DeferredCoverageService,
    private logger: LoggerService
  ) {}

  lifeEventDateOffset(lifeEventType: any, lifeEventDate: string, lifeEventCategory: string, employee: any, data: any): any {
    const lifeEventDateParts = lifeEventDate.split('/') || [];
    const currentPlanYearBeginDateParts = employee.PlanYearInfo.CurrentPlanYearBeginDate.split('/') || [];

    const params = {
      LEDateOffsetData: {
        LifeEventDate: new Date(lifeEventDateParts[2], lifeEventDateParts[0] - 1, lifeEventDateParts[1]),
        LifeEventCategory: lifeEventCategory,
        EmpCgData_Usercode_1: employee.EmpCgData_Usercode_1,
        EmpCgData_Usercode_2: employee.EmpCgData_Usercode_2,
        FirstDateOfCurrentPlanYear: employee.PlanYearInfo.CurrentPlanYearBeginDate,
        FirstDateOfNextPlanYear: employee.PlanYearInfo.NextPlanYearBeginDate,
        LastDateOfCurrentPlanYear: employee.PlanYearInfo.CurrentPlanYearEndDate,
        LastDateOfNextPlanYear: employee.PlanYearInfo.NextPlanYearEndDate,
        LifeEventID: lifeEventType.LifeEventId,
        DaysToInit: lifeEventType.DaysToInit,
        DaysToComplete: lifeEventType.DaysToComplete,
        DaysAfterInit: lifeEventType.DaysAfterInit,
        CompanyOneCode: employee.SmallMarketData?.CompanyOneCode,
        CurrentCoverageExists: this.employeeCoverageService.isCurrentCoverageExists(data.Data),
        FutureCoverageExists: this.employeeCoverageService.isFutureCoverageExists(data.Data),
        FutureCoverageLifeEventID: this.getFutureCoverageLifeEventID(data),
        FutureCoverageLifeEventCategory: this.getFutureCoverageLifeEventCategory(data),
        FutureCoverageLifeEventDate: this.getFutureCoverageLifeEventDate(data),
        DateOfFirstCoverage: employee.DateOfFirstCoverage,
        DateOfRetireeCoverage: employee.DateOfRetireeCoverage,
        CurrentControlledGroupStatus: employee.CurrentControlledGroupStatus,
        GlogFlag: employee.SmallMarketData?.GlogFlag,
        OngoingStartDate: employee.SmallMarketData?.OngoingStartDate && new Date(employee.SmallMarketData.OngoingStartDate)
      }
    };

    params.LEDateOffsetData.MonthsLEDateIsFarFromCurrentPLanYearBeginDate = parseInt(lifeEventDateParts[0]) - parseInt(currentPlanYearBeginDateParts[0]) + 1;

    const lePlanYearData =
      employee.SmallMarketData.PlanYears.find(x => new Date(lifeEventDate) >= new Date(x.StartDate) && new Date(lifeEventDate) <= new Date(x.EndDate)) ||
      employee.SmallMarketData.PlanYears.find(x => new Date(employee.DateOfFirstCoverage) >= new Date(x.StartDate) && new Date(employee.DateOfFirstCoverage) <= new Date(x.EndDate));

    params.LEDateOffsetData.RuleForEmpInitiatedEvents = employee.SmallMarketData.LifeEventRules[lePlanYearData.PlanYear][lifeEventType.LifeEventId] || employee.SmallMarketData.RuleForEmpInitiatedEvents;

    return this.rulesEngine.evaluate(data, 'HB.LifeEvent.LEDateOffset', params);
  }

  private getFutureCoverageLifeEventID(data: any): string {
    if (this.employeeCoverageService.isFutureCoverageExists(data.Data)) {
      return data.Data.FutureCoverages[0].LifeEvents[0].LifeEventID;
    }
    return '';
  }

  private getFutureCoverageLifeEventCategory(data: any): string {
    if (this.employeeCoverageService.isFutureCoverageExists(data.Data)) {
      return data.Data.FutureCoverages[0].LifeEvents[0].LifeEventCategory;
    }
    return '';
  }

  private getFutureCoverageLifeEventDate(data: any): Date {
    if (this.employeeCoverageService.isFutureCoverageExists(data.Data)) {
      return data.Data.FutureCoverages[0].LifeEvents[0].LifeEventDate;
    }
    return new Date();
  }

  // Additional methods would be similarly refactored and implemented here...
}
