import { Injectable } from '@angular/core';
import { StaticContentService } from './static-content.service';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class MbcUtilService {
  constructor(
    private staticContent: StaticContentService,
    private contentAliasService: ContentAliasService
  ) {}

  capitalizeFirstLetter(str: string): string {
    if (!str) {
      return '';
    }
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }

  capitalizeWord(str: string): string {
    if (!str) {
      return '';
    }
    return str.toUpperCase();
  }

  getCoverageImage(benefit: any, plan: any, employeeData: any, isVb: boolean): any {
    const electionDetails = {
      BenefitContentAlias: benefit.ContentAlias,
      BenefitType: benefit.BenefitType,
      BenefitCategory: benefit.BenefitCategory,
      PlanType: plan?.Type,
      CarrierContent: plan?.Carrier?.CarrierContent
    };
    return this.getElectionCoverageImage(electionDetails, employeeData, isVb);
  }

  getElectionCoverageImage(electionDetails: any, employeeData: any, isVb: boolean): any {
    return this.getCarrierLogo(electionDetails) ||
           this.getBenefitLogo(electionDetails, employeeData) ||
           this.getNoCovLogo(electionDetails, isVb) ||
           this.getEmptyImg();
  }

  private getCarrierLogo(electionDetails: any): any {
    return this.getLogo(electionDetails.CarrierContent, 'CarrierLogo');
  }

  private getBenefitLogo(electionDetails: any, employeeData: any): any {
    const dataContent = this.contentAliasService.forData(employeeData);
    const benefitData = dataContent.getContentObject(electionDetails.BenefitContentAlias);
    return this.getLogo(benefitData, 'BenefitLogo');
  }

  private getNoCovLogo(electionDetails: any, isVb: boolean): any {
    if (!this.staticContent.Images) {
      return null;
    }
    const categoryNoSpaces = electionDetails.BenefitCategory.replace(/ /g, '');
    const keyEnding = isVb ? '_Off' : '_On';
    const staticImg = this.staticContent.Images[categoryNoSpaces + keyEnding] ||
                      this.staticContent.Images[categoryNoSpaces + '_' + electionDetails.PlanType + keyEnding] ||
                      this.staticContent.Images[categoryNoSpaces + '_' + electionDetails.BenefitType + keyEnding];
    return staticImg ? {
      LogoSrc: '/media/' + staticImg.MediaId,
      Alt: staticImg.Alt
    } : null;
  }

  private getEmptyImg(): any {
    return {
      LogoSrc: null,
      Alt: null
    };
  }

  private getLogo(content: any, logoField: string): any {
    if (!content) {
      return null;
    }
    const logo = content[logoField];
    if (!logo || this.isEmptyBase64Logo(logo)) {
      return null;
    }
    return {
      Alt: logo.Alt || content.ShortName,
      LogoSrc: logo.IsBase64 && logo.LogoSrc
        ? 'data:image/jpeg;base64,' + logo.LogoSrc
        : '/media/' + logo.MediaId
    };
  }

  private isEmptyBase64Logo(logo: any): boolean {
    return logo.IsBase64 && !logo.LogoSrc;
  }

  mapGenericVBImage(category: string, planType: string, benefitType: string, isNoCov: boolean): string {
    const categoryNoSpaces = category.replace(/ /g, '');
    if (!this.staticContent.Images) {
      return '';
    }
    return this.staticContent.Images[categoryNoSpaces + '_Off'] ||
           this.staticContent.Images[categoryNoSpaces + '_' + planType + '_Off'] ||
           this.staticContent.Images[categoryNoSpaces + '_' + benefitType + '_Off'] || '';
  }

  getVBAliasMap(): Record<string, string> {
    return {
      'VB_AUTO': 'HB.LifeEvent.VoluntaryBenefits.AutoHome',
      'VB_HOME': 'HB.LifeEvent.VoluntaryBenefits.AutoHome',
      'VB_PET': 'HB.LifeEvent.VoluntaryBenefits.Pet',
      'VB_PERSONALPROTECTION': 'HB.LifeEvent.VoluntaryBenefits.PersonalProtection',
      'VB_SUPPLEMENTAL': 'HB.LifeEvent.VoluntaryBenefits.Supplemental'
    };
  }
}
