import { Injectable } from '@angular/core';
import { LoggerService } from './logger.service';
import { StringService } from './string.service';
import { FeatureTogglesService } from './feature-toggles.service';

@Injectable({
  providedIn: 'root'
})
export class ContentAliasService {
  constructor(
    private logger: LoggerService,
    private stringService: StringService,
    private featureToggles: FeatureTogglesService
  ) {}

  forData(data: any): ContentWrapper {
    return data instanceof ContentWrapper ? data : new ContentWrapper(data, this.logger, this.stringService, this.featureToggles);
  }
}

export class ContentWrapper {
  data: any;
  contentSource: any;

  constructor(
    private data: any,
    private logger: LoggerService,
    private stringService: StringService,
    private featureToggles: FeatureTogglesService
  ) {
    if (!data) {
      this.logError('forData, data missing');
    }

    if (data) {
      if (!data.Data) {
        this.logError('forData, data.Data missing');
      }

      if (!data.Content) {
        this.logError('forData, data.Content missing');
      }

      if (!data.ContentAliases) {
        this.logError('forData, data.ContentAliases missing');
      }

      if (!data.Configuration) {
        this.logError('forData, data.Configuration missing');
      }
    }

    this.data = data?.Data;
    this.contentSource = data;
  }

  getContentValue(aliasPath: string): any {
    if (aliasPath === undefined) {
      this.logError('getContentValue(aliasPath), aliasPath === undefined');
    }

    if (aliasPath === null) {
      this.logError('getContentValue(aliasPath), aliasPath === null');
    }

    if (aliasPath && this.data && this.data.Content && this.data.Content[aliasPath] === undefined) {
      this.logError('getContentValue(aliasPath), data.Content[aliasPath] === undefined, aliasPath=' + aliasPath);
    }

    return aliasPath && this.data?.Content[aliasPath];
  }

  private logError(errorMessage: string): void {
    if (this.featureToggles.contentAliasServiceErrorLogging) {
      this.logger.error('contentAliasService: ' + errorMessage);
    }
  }

  // Additional methods from the original ContentWrapper can be added here
}
