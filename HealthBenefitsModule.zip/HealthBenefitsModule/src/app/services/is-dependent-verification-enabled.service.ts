import { Injectable } from '@angular/core';
import { DependentVerificationService } from './dependent-verification.service';

@Injectable({
  providedIn: 'root'
})
export class IsDependentVerificationEnabledService {
  constructor(private dependentVerificationService: DependentVerificationService) {}

  isVerificationEnabled(employee: any): boolean {
    return this.dependentVerificationService
      .forData(employee)
      .isDependentVerificationEnabled();
  }
}
