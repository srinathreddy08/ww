import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AddToCartCounterService {
  private actionsCounter = 0;

  hasPendingActions(): boolean {
    return this.actionsCounter !== 0;
  }

  startAddToCartAction(): void {
    this.actionsCounter++;
  }

  finishAddToCartAction(): void {
    this.actionsCounter--;
  }
}
