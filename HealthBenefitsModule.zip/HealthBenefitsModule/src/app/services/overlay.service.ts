import { Injectable } from '@angular/core';
import { EventService } from './event.service';
import { SpinnerService } from './spinner.service';
import { TemplateService } from './template.service';
import { PubSubService } from './pubsub.service';

@Injectable({
  providedIn: 'root'
})
export class OverlayService {
  private overlay: any = null;
  private overlayClosedPromise: Promise<any> | null = null;
  private overlayClosedResolve: ((value?: any) => void) | null = null;
  private overlayClosedReject: ((reason?: any) => void) | null = null;

  constructor(
    private eventService: EventService,
    private spinnerService: SpinnerService,
    private templateService: TemplateService,
    private pubSubService: PubSubService
  ) {}

  open(viewUrl: string, overlayViewModel: any, options?: any): Promise<any> {
    this.overlayClosedPromise = new Promise((resolve, reject) => {
      this.overlayClosedResolve = resolve;
      this.overlayClosedReject = reject;
    });

    return this.templateService.loadTemplate(viewUrl)
      .then(() => {
        const isAllowedPromise = options?.isAllowedToShowAfterTemplateIsLoaded
          ? Promise.resolve(options.isAllowedToShowAfterTemplateIsLoaded())
          : Promise.resolve(true);

        return isAllowedPromise.then((allowedToShow) => {
          if (allowedToShow) {
            this.overlay = {
              viewUrl: viewUrl,
              model: overlayViewModel,
              onLoad: this.onLoad.bind(this)
            };
            this.eventService.publish('overlayService.contextUpdated');
          } else {
            this.closeRejected();
          }
          return this.overlayClosedPromise;
        });
      })
      .finally(this.onClosed.bind(this));
  }

  close(result?: any): void {
    if (this.overlayClosedResolve) {
      this.overlayClosedResolve(result);
      this.closeOverlay();
    }
  }

  closeRejected(reason?: any): void {
    if (this.overlayClosedReject) {
      this.overlayClosedReject(reason);
      this.closeOverlay();
    }
  }

  private closeOverlay(): void {
    this.overlay = null;
    this.overlayClosedPromise = null;
    this.overlayClosedResolve = null;
    this.overlayClosedReject = null;
    this.eventService.publish('overlayService.contextUpdated');
    this.pubSubService.publish('onOverlayClose');
  }

  getContext(): any {
    return this.overlay;
  }

  isOverlayOpened(): boolean {
    return !!this.overlay;
  }

  private onLoad(): void {
    const spinnerAction = this.spinnerService.pauseDisplayingSpinner();
    document.body.classList.add('is-popup-open');
    spinnerAction.complete();
  }

  private onClosed(): void {
    document.body.classList.remove('is-popup-open');
  }
}
