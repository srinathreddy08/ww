import { TestBed } from '@angular/core/testing';
import { RequiredDependentVerificationDocumentsService } from './required-dependent-verification-documents.service';
import { DependentVerificationService } from './dependent-verification.service';
import { StringService } from './string.service';
import { BenefitsService } from './benefits.service';
import { CoverageSourcesService } from './coverage-sources.service';

class MockDependentVerificationService {
  forData() {
    return {
      dependentRequiresVerificationByStatus: () => true,
      overlayShowsWhen: () => ({ dependentIsCovered: true }),
      dependentRequiresVerificationByCoverage: () => true
    };
  }
}

class MockStringService {
  convertArrayStringToArray() {
    return ['RELATIONSHIPTYPE1', 'RELATIONSHIPTYPE2'];
  }
}

class MockBenefitsService {
  isBenefitMedicalDentalOrVision() {
    return true;
  }
}

class MockCoverageSourcesService {
  isDependentEligibleForRule() {
    return true;
  }
}

describe('RequiredDependentVerificationDocumentsService', () => {
  let service: RequiredDependentVerificationDocumentsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        RequiredDependentVerificationDocumentsService,
        { provide: DependentVerificationService, useClass: MockDependentVerificationService },
        { provide: StringService, useClass: MockStringService },
        { provide: BenefitsService, useClass: MockBenefitsService },
        { provide: CoverageSourcesService, useClass: MockCoverageSourcesService }
      ]
    });
    service = TestBed.inject(RequiredDependentVerificationDocumentsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get required dependent verification documents', () => {
    const employeeData = { ContentAliases: {}, Data: { PendingEmployee: {}, CurrentCoveragesEmployee: {}, FutureCoverages: [{}] } };
    const cartData = { ShoppingCart: [] };
    const result = service.getRequiredDependentVerificationDocuments(employeeData, cartData);
    expect(result).toBeDefined();
  });
});
