import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { FeatureDefaults } from './feature-defaults';

@Injectable({
  providedIn: 'root'
})
export class FeatureTogglesService {
  private featureOverridesCookieName = 'features';

  constructor(private cookieService: CookieService, private featureDefaults: FeatureDefaults) {}

  getFeatures(): Record<string, boolean> {
    return { ...this.getFeatureOverrides(), ...this.featureDefaults };
  }

  private getFeatureOverrides(): Record<string, boolean> {
    const featureOverridesString = this.cookieService.get(this.featureOverridesCookieName);

    if (!featureOverridesString) {
      return {};
    }

    return featureOverridesString.split(',').reduce((acc, featureOverrideString) => {
      const [key, value] = featureOverrideString.split(':');
      acc[key] = value === 'true';
      return acc;
    }, {} as Record<string, boolean>);
  }

  setFeatureOverrides(desiredState: Record<string, boolean>): void {
    const overrides = Object.keys(desiredState)
      .filter(key => desiredState[key] !== this.featureDefaults[key])
      .map(key => `${key}:${desiredState[key]}`);

    if (overrides.length > 0) {
      this.cookieService.set(this.featureOverridesCookieName, overrides.join(','), { path: '/' });
    } else {
      this.cookieService.delete(this.featureOverridesCookieName, '/');
    }
  }

  clearFeatureOverrides(): void {
    this.cookieService.delete(this.featureOverridesCookieName, '/');
  }

  getOverriddenFeatures(): string[] {
    return Object.keys(this.getFeatureOverrides()).filter(key => this.getFeatureOverrides()[key] !== this.featureDefaults[key]);
  }
}
