import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { EmployeeLifeEventActionServiceConstants } from './employee-life-event-action.service.constants';
import { RouterTestingModule } from '@angular/router/testing';

fdescribe('EmployeeLifeEventActionService', () => {
  let employeeLifeEventActionServiceConstants: EmployeeLifeEventActionServiceConstants;
  let router: Router;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [EmployeeLifeEventActionServiceConstants]
    });
    employeeLifeEventActionServiceConstants = TestBed.inject(EmployeeLifeEventActionServiceConstants);
    router = TestBed.inject(Router);
  });

  it('should have constants with a maximum length of 40', () => {
    const constants = [...employeeLifeEventActionServiceConstants.types, ...getPageVisitIds()];

    constants.forEach(constant => {
      expect(constant.length).toBeLessThan(41, `Constant "${constant}" is too long, maximum length is 40`);
    });

    function getPageVisitIds(): string[] {
      const allStates = router.config;

      return allStates
        .filter(state => state.path && state.path.startsWith('expert-guidance.'))
        .map(state => state.data?.pageVisitId)
        .filter(id => !!id);
    }
  });
});
