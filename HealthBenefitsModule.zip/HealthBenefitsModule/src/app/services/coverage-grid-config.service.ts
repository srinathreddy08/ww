import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class CoverageGridConfigService {
  constructor(
    private contentAliasService: ContentAliasService,
    private cookieService: CookieService
  ) {}

  forData(employeeData: any) {
    const data = this.contentAliasService.forData(employeeData);

    const coverageGridConfig = data.getConfiguration('HB.LifeEvent.WhosCovered.CoverageGridConfig').asNumber();
    const expandCoverageGridConfig = data.getConfiguration('HB.LifeEvent.WhosCoveredGridOverride').asStringArray();

    return {
      shouldShowCoverage: this.shouldShowCoverage(coverageGridConfig),
      shouldDefaultToBestMatchPlan: this.shouldDefaultToBestMatchPlan(coverageGridConfig),
      shouldBeExpandedInLifeEventPage: this.shouldBeExpandedInLifeEventPage(expandCoverageGridConfig, coverageGridConfig),
      shouldBeExpandedInDomainPage: this.shouldBeExpandedInDomainPage(expandCoverageGridConfig),
      isDeferredCoverageModeEnabled: this.getIsDeferredCoverageModeEnabled(coverageGridConfig)
    };
  }

  private shouldShowCoverage(coverageGridConfig: number): boolean {
    return coverageGridConfig !== 0;
  }

  private shouldDefaultToBestMatchPlan(coverageGridConfig: number): boolean {
    return coverageGridConfig === 2;
  }

  private shouldBeExpandedInLifeEventPage(expandCoverageGridConfig: string[], coverageGridConfig: number): boolean {
    return expandCoverageGridConfig.includes('0') || this.getIsDeferredCoverageModeEnabled(coverageGridConfig);
  }

  private shouldBeExpandedInDomainPage(expandCoverageGridConfig: string[]): boolean {
    return expandCoverageGridConfig.includes('1');
  }

  private getIsDeferredCoverageModeEnabled(coverageGridConfig: number): boolean {
    return coverageGridConfig === 3;
  }
}
