import { TestBed } from '@angular/core/testing';
import { NavigationService } from './navigation.service';
import { RouterTestingModule } from '@angular/router/testing';
import { ShoppingCartService } from './shopping-cart.service';
import { MbcContentAndDataService } from './mbc-content-and-data.service';
import { LogService } from './log.service';
import { EmployeeCoverageService } from './employee-coverage.service';
import { DomainAvailabilityService } from './domain-availability.service';
import { PensionPaymentsService } from './pension-payments.service';
import { DbTaxViewValueService } from './db-tax-view-value.service';
import { ContentAliasService } from './content-alias.service';
import { ExecuteWithSpinnerService } from './execute-with-spinner.service';
import { DbContextService } from './db-context.service';
import { OnlineCommencementService } from './online-commencement.service';
import { RequiredDependentVerificationDocumentsService } from './required-dependent-verification-documents.service';
import { CachedLifeEventNavigationService } from './cached-life-event-navigation.service';
import { EnrollmentNavigationService } from './enrollment-navigation.service';

class MockShoppingCartService {}
class MockMbcContentAndDataService {}
class MockLogService {
  getLogger() {
    return { debug: () => {} };
  }
}
class MockEmployeeCoverageService {}
class MockDomainAvailabilityService {}
class MockPensionPaymentsService {}
class MockDbTaxViewValueService {}
class MockContentAliasService {}
class MockExecuteWithSpinnerService {}
class MockDbContextService {}
class MockOnlineCommencementService {}
class MockRequiredDependentVerificationDocumentsService {}
class MockCachedLifeEventNavigationService {}
class MockEnrollmentNavigationService {}

describe('NavigationService', () => {
  let service: NavigationService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        NavigationService,
        { provide: ShoppingCartService, useClass: MockShoppingCartService },
        { provide: MbcContentAndDataService, useClass: MockMbcContentAndDataService },
        { provide: LogService, useClass: MockLogService },
        { provide: EmployeeCoverageService, useClass: MockEmployeeCoverageService },
        { provide: DomainAvailabilityService, useClass: MockDomainAvailabilityService },
        { provide: PensionPaymentsService, useClass: MockPensionPaymentsService },
        { provide: DbTaxViewValueService, useClass: MockDbTaxViewValueService },
        { provide: ContentAliasService, useClass: MockContentAliasService },
        { provide: ExecuteWithSpinnerService, useClass: MockExecuteWithSpinnerService },
        { provide: DbContextService, useClass: MockDbContextService },
        { provide: OnlineCommencementService, useClass: MockOnlineCommencementService },
        { provide: RequiredDependentVerificationDocumentsService, useClass: MockRequiredDependentVerificationDocumentsService },
        { provide: CachedLifeEventNavigationService, useClass: MockCachedLifeEventNavigationService },
        { provide: EnrollmentNavigationService, useClass: MockEnrollmentNavigationService }
      ]
    });
    service = TestBed.inject(NavigationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // Additional tests can be added here to test the service methods
});
