import { Injectable } from '@angular/core';
import { LogService } from './log.service';
import { ExpertGuidanceResource } from './expert-guidance-resource.service';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShoppingCartExpertGuidanceService {
  isExpertGuidance = true;
  cacheKeyPrefix = 'EG';

  constructor(private logService: LogService, private expertGuidanceResource: ExpertGuidanceResource) {}

  get() {
    return this.expertGuidanceResource.getSuggestedPackage();
  }

  visit(options: any) {
    this.logService.getLogger('MissingShoppingCartFunctionInExpertGuidanceFlow').info('visit', options);
    return of(null);
  }

  batchAdd(options: any) {
    return this.expertGuidanceResource.updateSuggestedPackage(options);
  }

  submit(lifeEvent: any) {
    this.logService.getLogger('MissingShoppingCartFunctionInExpertGuidanceFlow').info('submit', lifeEvent);
    return of(null);
  }

  load(lifeEvent: any) {
    this.logService.getLogger('MissingShoppingCartFunctionInExpertGuidanceFlow').info('load/calling getSuggestedPackage', lifeEvent);
    return this.expertGuidanceResource.getSuggestedPackage();
  }

  clear() {
    return this.expertGuidanceResource.clearPackage();
  }
}
