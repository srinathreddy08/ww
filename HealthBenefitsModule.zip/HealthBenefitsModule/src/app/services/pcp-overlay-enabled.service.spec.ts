import { TestBed } from '@angular/core/testing';
import { PcpOverlayEnabledService } from './pcp-overlay-enabled.service';
import { ContentAliasService } from './content-alias.service';

class MockContentAliasService {
  forData(employeeData: any) {
    return {
      getConfigurationValue: (key: string) => 'S'
    };
  }
}

describe('PcpOverlayEnabledService', () => {
  let service: PcpOverlayEnabledService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PcpOverlayEnabledService,
        { provide: ContentAliasService, useClass: MockContentAliasService }
      ]
    });
    service = TestBed.inject(PcpOverlayEnabledService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true when PCPDisplay is S', () => {
    const result = service.isPcpOverlayEnabled({});
    expect(result).toBeTrue();
  });
});
