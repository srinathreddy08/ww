import { TestBed } from '@angular/core/testing';
import { ShoppingCartExpertGuidanceService } from './shopping-cart-expert-guidance.service';
import { LogService } from './log.service';
import { ExpertGuidanceResource } from './expert-guidance-resource.service';
import { of } from 'rxjs';

class MockLogService {
  getLogger() {
    return {
      info: (message: string, data: any) => {}
    };
  }
}

class MockExpertGuidanceResource {
  getSuggestedPackage() {
    return of({});
  }
  updateSuggestedPackage(options: any) {
    return of({});
  }
  clearPackage() {
    return of({});
  }
}

describe('ShoppingCartExpertGuidanceService', () => {
  let service: ShoppingCartExpertGuidanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ShoppingCartExpertGuidanceService,
        { provide: LogService, useClass: MockLogService },
        { provide: ExpertGuidanceResource, useClass: MockExpertGuidanceResource }
      ]
    });
    service = TestBed.inject(ShoppingCartExpertGuidanceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get suggested package', () => {
    service.get().subscribe(data => {
      expect(data).toBeDefined();
    });
  });

  it('should log visit', () => {
    const logSpy = spyOn(TestBed.inject(LogService).getLogger(), 'info');
    service.visit({});
    expect(logSpy).toHaveBeenCalledWith('visit', {});
  });

  it('should submit and log', () => {
    const logSpy = spyOn(TestBed.inject(LogService).getLogger(), 'info');
    service.submit({});
    expect(logSpy).toHaveBeenCalledWith('submit', {});
  });
});
