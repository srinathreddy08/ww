import { TestBed } from '@angular/core/testing';
import { QuestionnairePrintFormService } from './questionnaire-print-form.service';
import { QuestionService } from './question.service';
import { ContentAliasService } from './content-alias.service';

class MockQuestionService {
  getDataForMyInformation(enrollment: any, employeeType: string) {
    return {};
  }
  filterAndSortQuestions(questionsData: any) {
    return {};
  }
}

class MockContentAliasService {
  forData(enrollment: any) {
    return {
      getEvaluationPointValue: (key: string) => 'My Benefits Header'
    };
  }
}

describe('QuestionnairePrintFormService', () => {
  let service: QuestionnairePrintFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        QuestionnairePrintFormService,
        { provide: QuestionService, useClass: MockQuestionService },
        { provide: ContentAliasService, useClass: MockContentAliasService }
      ]
    });
    service = TestBed.inject(QuestionnairePrintFormService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // Additional tests can be added here to test the service methods
});
