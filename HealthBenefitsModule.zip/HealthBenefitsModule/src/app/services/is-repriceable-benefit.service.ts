import { Injectable } from '@angular/core';
import { BenefitCategoriesService } from './benefit-categories.service';
import { GetRepriceableBenefitIdsService } from './get-repriceable-benefit-ids.service';

@Injectable({
  providedIn: 'root'
})
export class IsRepriceableBenefitService {
  constructor(
    private benefitCategoriesService: BenefitCategoriesService,
    private getRepriceableBenefitIdsService: GetRepriceableBenefitIdsService
  ) {}

  forData(employeeData: any): (benefit: any) => boolean {
    const repriceableBenefitIds = this.getRepriceableBenefitIdsService.getRepriceableBenefitIds(employeeData);

    return (benefit: any) => {
      return this.benefitCategoriesService.isAccountBased(benefit) ||
             repriceableBenefitIds.includes(benefit.BenefitID);
    };
  }
}
