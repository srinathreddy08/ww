import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class AnnualAmountDisplayService {
  constructor(private contentAliasService: ContentAliasService) {}

  showAnnualAmounts(data: any): boolean {
    return this.contentAliasService.forData(data).getConfigurationValue('HB.AnnualAmountsDisplay') === 'E';
  }
}
