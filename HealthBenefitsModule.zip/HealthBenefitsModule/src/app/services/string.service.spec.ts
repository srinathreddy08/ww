import { TestBed } from '@angular/core/testing';
import { StringService } from './string.service';

describe('StringService', () => {
  let service: StringService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StringService]
    });
    service = TestBed.inject(StringService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should convert array string to array', () => {
    const result = service.convertArrayStringToArray('["item1", "item2"]');
    expect(result).toEqual(['item1', 'item2']);
  });

  it('should check if string ends with substring', () => {
    expect(service.endsWith('hello world', 'world')).toBe(true);
    expect(service.endsWith('hello world', 'hello')).toBe(false);
  });

  it('should check if string starts with substring', () => {
    expect(service.startsWith('hello world', 'hello')).toBe(true);
    expect(service.startsWith('hello world', 'world')).toBe(false);
  });

  it('should detect HTML tags', () => {
    expect(service.containsHtmlTags('<div>')).toBe(true);
    expect(service.containsHtmlTags('plain text')).toBe(false);
  });

  it('should match wildcard pattern', () => {
    expect(service.wildCardMatch('he*o', 'hello')).toBe(true);
    expect(service.wildCardMatch('he*o', 'world')).toBe(false);
  });

  it('should match wildcard pattern array', () => {
    expect(service.wildCardMatchArray(['he*o', 'wo*ld'], 'hello')).toBe(true);
    expect(service.wildCardMatchArray(['he*o', 'wo*ld'], 'world')).toBe(true);
    expect(service.wildCardMatchArray(['he*o', 'wo*ld'], 'test')).toBe(false);
  });
});
