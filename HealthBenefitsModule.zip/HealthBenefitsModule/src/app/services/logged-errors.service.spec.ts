import { TestBed } from '@angular/core/testing';
import { LoggedErrorsService } from './logged-errors.service';

describe('LoggedErrorsService', () => {
  let service: LoggedErrorsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoggedErrorsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should log an error', () => {
    const error = new Error('Test error');
    service.put(error);
    expect(service.isLogged(error)).toBeTrue();
  });

  it('should return false for unlogged errors', () => {
    const error = new Error('Unlogged error');
    expect(service.isLogged(error)).toBeFalse();
  });
});
