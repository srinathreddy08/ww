import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';
import { MbcContentAndData } from './mbc-content-and-data.service';
import { StringService } from './string.service';

@Injectable({
  providedIn: 'root'
})
export class CharitableBenefitsService {
  constructor(
    private contentAliasService: ContentAliasService,
    private mbcContentAndData: MbcContentAndData,
    private stringService: StringService
  ) {}

  forBenefit(benefit: any, employeeData: any) {
    const content = this.contentAliasService.forData(employeeData);

    return {
      showPerPayPeriod: () => this.isNoOptionForBenefit('HB.LifeEvent.LumpsumBenefits', benefit, content),
      showMaxAmount: () => this.isNoOptionForBenefit('HB.LifeEvent.SuppressMaxAmount', benefit, content),
      showCalcButton: () => this.isNoOptionForBenefit('HB.LifeEvent.SuppressCalcButton', benefit, content)
    };
  }

  private isNoOptionForBenefit(configName: string, benefit: any, content: any): boolean {
    const configValue = content.getConfigurationValue(configName);
    if (!configValue) {
      return true;
    }

    const configurationOption = this.stringService.convertArrayStringToArray(configValue);
    if (!configurationOption) {
      return true;
    }

    return !this.stringService.wildCardMatchArray(configurationOption, benefit.BenefitID);
  }
}
