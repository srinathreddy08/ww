import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { EnrollmentRules } from './enrollment-rules.service';
import { BenefitsOptionsService } from './benefits-options.service';

@Injectable({
  providedIn: 'root'
})
export class DepsPendingVerificationService {
  private cachedOptions: Record<string, any> = {};
  private emptyVerifiedDetails = {
    VerifiedAnnualCost: 0,
    VerifiedPPCost: 0,
    VerifiedOptionID: '',
    ElectedOption: {
      VerifiedAnnualCost: 0,
      VerifiedPPCost: 0,
      VerifiedOptionID: ''
    }
  };

  constructor(
    private http: HttpClient,
    private enrollmentRules: EnrollmentRules,
    private benefitsOptionsService: BenefitsOptionsService
  ) {}

  createCache(enrollmentContent: any): Observable<any> {
    const enrollment = enrollmentContent.contentSource;

    if (!this.isDependentVerificationEnabled(enrollment)) {
      return of(this.cachedOptions);
    }

    const data = enrollment.Data;
    const promises = [
      this.addVerifiedOptionsDetailsToCacheForEmployee(data.PendingEmployee, enrollmentContent),
      this.addVerifiedOptionsDetailsToCacheForEmployee(data.CurrentCoveragesEmployee, enrollmentContent),
      this.addVerifiedOptionsDetailsToCacheForEmployee(data.FutureCoverages && data.FutureCoverages[0], enrollmentContent)
    ];

    return of(Promise.all(promises)).pipe(switchMap(() => of(this.cachedOptions)));
  }

  private addVerifiedOptionsDetailsToCacheForEmployee(employee: any, enrollmentContent: any): Promise<void> {
    if (!employee) {
      return Promise.resolve();
    }

    const lifeEvent = employee.LifeEvents[0];
    const eligibleBenefitsMap = lifeEvent.EligibleBenefitsMap;

    return Promise.all(
      Object.values(eligibleBenefitsMap)
        .filter((benefit: any) => this.isBenefitCoveredAndComparison(benefit, benefit.ElectedPlan))
        .map((benefit: any) => this.addBenefitToCache(benefit, employee, lifeEvent, enrollmentContent))
    ).then(() => {});
  }

  private addBenefitToCache(benefit: any, employee: any, lifeEvent: any, enrollmentContent: any): Promise<void> {
    const benefitId = benefit.BenefitID;
    const electedPlan = benefit.ElectedPlan;
    const electedOptionId = electedPlan.ElectedOption.OptionID;
    const derivedOptionId = this.getDerivedOptionId(enrollmentContent.contentSource, employee, benefit);

    if (derivedOptionId === electedOptionId) {
      return Promise.resolve();
    }

    const derivedOption = lifeEvent.EligibleBenefitsMap[benefitId].EligiblePlansMap[electedPlan.PlanID].EligibleOptionsMap[derivedOptionId];

    if (!derivedOption) {
      return this.requestDerivedOption(employee, lifeEvent, benefitId, electedPlan.PlanID, derivedOptionId, enrollmentContent);
    }

    return Promise.resolve();
  }

  private requestDerivedOption(employee: any, lifeEvent: any, benefitId: string, planId: string, derivedOptionId: string, enrollmentContent: any): Promise<void> {
    return this.http.get(`/api/depsPendingVerification/GetVerifiedOptionCosts`, {
      params: {
        ControlId: employee.CompanyID || lifeEvent.ControlID,
        Ssn: employee.Ssn,
        LifeEventId: lifeEvent.LifeEventID,
        LifeEventDate: lifeEvent.LifeEventDate,
        BenefitId: benefitId,
        PlanId: planId,
        OptionId: derivedOptionId
      }
    }).toPromise().then((costs: any) => this.processCosts(costs, benefitId, planId, derivedOptionId, enrollmentContent));
  }

  private processCosts(costs: any, benefitId: string, planId: string, derivedOptionId: string, enrollmentContent: any): void {
    if (!costs) {
      return;
    }

    const optionDescription = this.getOptionDescriptionOverride(enrollmentContent.contentSource, benefitId, derivedOptionId) ||
                              enrollmentContent.getContentString(costs.OptionAlias) ||
                              costs.OptionDescription;

    if (optionDescription) {
      this.setDerivedOptionCache(costs, optionDescription, benefitId, planId, derivedOptionId);
    }
  }

  private setDerivedOptionCache(costs: any, description: string, benefitId: string, planId: string, derivedOptionId: string): void {
    const derivedOptionDetails = {
      VerifiedAnnualCost: costs.AnnualCost,
      VerifiedPPCost: costs.PayPeriodCost,
      VerifiedOptionID: description,
      ElectedOption: {
        VerifiedAnnualCost: costs.AnnualCost,
        VerifiedPPCost: costs.PayPeriodCost,
        VerifiedOptionID: description
      }
    };

    const cacheKey = this.getOptionKey(lifeEvent.LifeEventID, lifeEvent.LifeEventDate, benefitId, planId, derivedOptionId);
    this.cachedOptions[cacheKey] = derivedOptionDetails;
  }

  getVerifiedOptionDetails(enrollmentContent: any, employee: any, benefitId: string, planId: string, optionId: string): any {
    const enrollment = enrollmentContent.contentSource;
    if (!this.isDependentVerificationEnabled(enrollment)) {
      return null;
    }

    const lifeEvent = employee.LifeEvents[0];
    const benefit = lifeEvent.EligibleBenefitsMap[benefitId];
    const plan = benefit.EligiblePlansMap[planId];
    if (!this.isBenefitCoveredAndComparison(benefit, plan)) {
      return null;
    }

    const derivedOptionId = this.getDerivedOptionId(enrollment, employee, benefit);
    if (derivedOptionId === optionId) {
      return null;
    }

    const derivedOption = lifeEvent.EligibleBenefitsMap[benefitId].EligiblePlansMap[plan.PlanID].EligibleOptionsMap[derivedOptionId];
    if (derivedOption) {
      return this.createDetailsFromOption(derivedOption, enrollmentContent);
    }

    const cacheKey = this.getOptionKey(lifeEvent.LifeEventID, lifeEvent.LifeEventDate, benefitId, planId, derivedOptionId);
    return this.cachedOptions[cacheKey] || this.emptyVerifiedDetails;
  }

  private createDetailsFromOption(option: any, enrollmentContent: any): any {
    const description = this.getOptionDescriptionOverride(enrollmentContent.contentSource, option.BenefitID, option.OptionID) ||
                        enrollmentContent.getContentString(option.ContentAlias) ||
                        option.OptionYearDefDescr1;

    return {
      VerifiedAnnualCost: option.EmployeeAnnualCost,
      VerifiedPPCost: option.EmployeePayPeriodCost,
      VerifiedOptionID: description,
      ElectedOption: {
        VerifiedAnnualCost: option.EmployeeAnnualCost,
        VerifiedPPCost: option.EmployeePayPeriodCost,
        VerifiedOptionID: description
      }
    };
  }

  private getOptionDescriptionOverride(enrollment: any, benefitId: string, optionId: string): string | null {
    const benefitsOverrideOptionValues = this.benefitsOptionsService.getOverrideOptionsConfiguration(enrollment);
    if (!benefitsOverrideOptionValues) {
      return null;
    }

    const benefitOverrideOptionValues = benefitsOverrideOptionValues[benefitId];
    if (!benefitOverrideOptionValues) {
      return null;
    }

    return benefitOverrideOptionValues[optionId];
  }

  private getDerivedOptionId(enrollment: any, employee: any, benefit: any): string {
    if ((!benefit.DependentAssociationList || !benefit.DependentAssociationList.length) && benefit.ElectedPlan.ElectedOption.DependentAssociations) {
      benefit.DependentAssociationList = benefit.ElectedPlan.ElectedOption.DependentAssociations.map((assoc: any) => assoc.DependentSsn);
    }

    const eligibleBenefitsMap = employee.LifeEvents[0].EligibleBenefitsMap;
    return this.enrollmentRules.deriveOption(eligibleBenefitsMap, benefit.BenefitID, enrollment, 'true', 'false', employee);
  }

  private getOptionKey(lifeEventId: string, lifeEventDate: string, benefitId: string, planId: string, optionId: string): string {
    return `${lifeEventId}|${lifeEventDate}|${benefitId}|${planId}|${optionId}`;
  }

  private isBenefitCoveredAndComparison(benefit: any, electedPlan: any): boolean {
    const isComparisonBenefit = comparisonBenefitCategories.includes(benefit.BenefitCategory);
    const isCovered = !electedPlan.IsNoCovPlan;
    return isComparisonBenefit && isCovered;
  }

  private isDependentVerificationEnabled(enrollment: any): boolean {
    // Implement the logic to check if dependent verification is enabled
    return true; // Placeholder
  }
}
