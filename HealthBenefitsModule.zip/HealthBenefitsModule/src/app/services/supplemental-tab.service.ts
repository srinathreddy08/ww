import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class SupplementalTabService {
  constructor(private contentAliasService: ContentAliasService) {}

  forEnrollment(enrollment: any): { showSeparateTab: boolean; showHealthInsuranceSubTab: boolean } {
    const enrollmentContent = this.contentAliasService.forData(enrollment);

    const supplementalBenefitsPresented = enrollment.Data.CurrentCoveragesEmployee &&
      enrollment.Data.CurrentCoveragesEmployee.LifeEvents[0].EligibleBenefits.some((benefit: any) => benefit.BenefitCategory === 'SUPPLEMENTAL');

    const showSeparateTab = enrollmentContent.getConfigurationValue('HB.LifeEvent.Summary.SupplementalCoverages') === 'Y';

    return {
      showSeparateTab: showSeparateTab && supplementalBenefitsPresented,
      showHealthInsuranceSubTab: !showSeparateTab && supplementalBenefitsPresented
    };
  }
}
