import { TestBed } from '@angular/core/testing';
import { IsQuarterlyOrSemiAnnualService } from './is-quarterly-or-semi-annual.service';

describe('IsQuarterlyOrSemiAnnualService', () => {
  let service: IsQuarterlyOrSemiAnnualService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [IsQuarterlyOrSemiAnnualService]
    });
    service = TestBed.inject(IsQuarterlyOrSemiAnnualService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true if quarterly is defined', () => {
    const employeeData = {
      SmallMarketData: {
        CompanyPlanYearQuestions: [
          { BenefitId: 'HSA', Seq: 1, Answer: 'Quarterly' }
        ]
      }
    };
    expect(service.isQuarterlyOrSemiAnnual(employeeData)).toBeTrue();
  });

  it('should return true if semi-annual is defined', () => {
    const employeeData = {
      SmallMarketData: {
        CompanyPlanYearQuestions: [
          { BenefitId: 'HSA', Seq: 1, Answer: 'Semi-Annual' }
        ]
      }
    };
    expect(service.isQuarterlyOrSemiAnnual(employeeData)).toBeTrue();
  });

  it('should return false if neither is defined', () => {
    const employeeData = {
      SmallMarketData: {
        CompanyPlanYearQuestions: [
          { BenefitId: 'HSA', Seq: 1, Answer: 'Monthly' }
        ]
      }
    };
    expect(service.isQuarterlyOrSemiAnnual(employeeData)).toBeFalse();
  });
});
