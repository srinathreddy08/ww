import { Injectable, OnDestroy } from '@angular/core';
import { LifeEventService } from './life-event.service';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

interface BenefitAccessor {
  cartItem: () => any;
  applyChanges: (item: any) => any;
}

@Injectable({
  providedIn: 'root'
})
export class AccountContributionBenefitsService implements OnDestroy {
  private benefitAccessors: { [key: string]: BenefitAccessor } = {};

  constructor(private lifeEventService: LifeEventService) {}

  registerBenefit(scope: any, benefitId: string, benefitAccessor: BenefitAccessor): void {
    scope.$on('$destroy', () => {
      if (this.benefitAccessors[benefitId] === benefitAccessor) {
        delete this.benefitAccessors[benefitId];
      }
    });

    this.benefitAccessors[benefitId] = benefitAccessor;
  }

  recalcSuppressed(benefitId: string, shoppingCart: any[]): boolean {
    const behavior = this.getAccountContributionBenefitBehavior(benefitId, shoppingCart);
    return behavior.recalcSuppressed;
  }

  getItemsToAddToCart(cartItem: any, getAdditionalItemsToAddToCart: Function, lifeEvent: any, content: any, shoppingCart: any[], doReprice: boolean, opt: any, frontLoadAmountForHsa: any): Observable<any[]> {
    const currentBenefitId = cartItem.BenefitID;
    const behavior = this.getAccountContributionBenefitBehavior(currentBenefitId, shoppingCart);
    const benefits = behavior.getBenefits();

    const items = benefits.map((accessor: BenefitAccessor, benefitId: string) => {
      const sourceCartItem = benefitId === currentBenefitId ? cartItem : accessor.cartItem();
      return {
        accessor,
        cartItem: { ...sourceCartItem }
      };
    });

    const cartItems = items.map(item => item.cartItem);

    const repriceCall = doReprice ?
      behavior.recalculateOptionCosts(lifeEvent, cartItems, opt, frontLoadAmountForHsa) :
      of(cartItems.map(item => this.lifeEventService.convertCartItemToOption(item)));

    return repriceCall.pipe(
      map(calculatedItems => {
        cartItems.forEach((item, index) => {
          const calculatedOption = calculatedItems[index];
          Object.assign(item, calculatedOption);
        });

        const itemsToAddToCart = items.map(item => item.accessor.applyChanges(item.cartItem));
        const activeItem = itemsToAddToCart.find(item => item.BenefitID === currentBenefitId);

        return [].concat(itemsToAddToCart, getAdditionalItemsToAddToCart(activeItem));
      })
    );
  }

  private getAccountContributionBenefitBehavior(benefitId: string, shoppingCart: any[]) {
    return {
      recalcSuppressed: false,
      getBenefits: () => this.getBenefitAccessors((itemBenefitId: string) => itemBenefitId === benefitId),
      recalculateOptionCosts: (lifeEvent: any, items: any[], opt: any, frontLoadAmountForHsa: any) => {
        return this.lifeEventService.recalculateOptionCostFromCartItem(lifeEvent, items[0], null, opt, frontLoadAmountForHsa)
          .pipe(map(recalculatedOption => [recalculatedOption]));
      }
    };
  }

  private getBenefitAccessors(filter: (benefitId: string) => boolean): BenefitAccessor[] {
    return Object.keys(this.benefitAccessors)
      .filter(filter)
      .map(benefitId => this.benefitAccessors[benefitId]);
  }

  ngOnDestroy(): void {
    // Cleanup logic if needed
  }
}
