import { TestBed } from '@angular/core/testing';
import { TransformOpenEnrollmentService } from './transform-open-enrollment.service';

const mockEnrollment = {
  Data: {
    CurrentCoveragesEmployee: {
      LifeEvents: [
        {
          EligibleBenefitsMap: {
            'MEDICAL': {
              EligiblePlansMap: {
                'CDHH003E01': {
                  Carrier: {
                    CarrierContent: {
                      LongName: 'AETNA_TEST_LONG',
                      ShortName: 'AETNA_TEST_SHORT',
                      CarrierLogo: { LogoSrc: '' }
                    }
                  }
                }
              }
            },
            'VISION': {
              ElectedPlan: {
                Carrier: {
                  CarrierContent: {
                    LongName: 'Aetna',
                    ShortName: 'Aetna',
                    CarrierLogo: { LogoSrc: '' }
                  }
                }
              }
            },
            'ACCIDENT': {
              EligiblePlansMap: {
                'COVN035001': {
                  Carrier: {
                    CarrierContent: {
                      LongName: 'Voya Financial overrided',
                      ShortName: 'Voya Financial Short',
                      CarrierLogo: { LogoSrc: '' }
                    }
                  }
                }
              }
            }
          }
        }
      ]
    }
  }
};

describe('TransformOpenEnrollmentService', () => {
  let service: TransformOpenEnrollmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TransformOpenEnrollmentService]
    });
    service = TestBed.inject(TransformOpenEnrollmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should transform enrollment data correctly', () => {
    service.transform(mockEnrollment);
    const medicalPlan = mockEnrollment.Data.CurrentCoveragesEmployee.LifeEvents[0].EligibleBenefitsMap['MEDICAL'].EligiblePlansMap['CDHH003E01'];
    expect(medicalPlan.Carrier.CarrierContent.LongName).toBe('AETNA_TEST_LONG');
    expect(medicalPlan.Carrier.CarrierContent.ShortName).toBe('AETNA_TEST_SHORT');

    const visionPlan = mockEnrollment.Data.CurrentCoveragesEmployee.LifeEvents[0].EligibleBenefitsMap['VISION'].ElectedPlan;
    expect(visionPlan.Carrier.CarrierContent.LongName).toBe('Aetna');
    expect(visionPlan.Carrier.CarrierContent.ShortName).toBe('Aetna');

    const accidentPlan = mockEnrollment.Data.CurrentCoveragesEmployee.LifeEvents[0].EligibleBenefitsMap['ACCIDENT'].EligiblePlansMap['COVN035001'];
    expect(accidentPlan.Carrier.CarrierContent.LongName).toBe('Voya Financial overrided');
    expect(accidentPlan.Carrier.CarrierContent.ShortName).toBe('Voya Financial Short');
  });
});
