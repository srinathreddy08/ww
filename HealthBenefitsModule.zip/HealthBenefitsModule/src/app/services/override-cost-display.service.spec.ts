import { TestBed } from '@angular/core/testing';
import { OverrideCostDisplayService } from './override-cost-display.service';
import { ContentAliasService } from './content-alias.service';

class MockContentAliasService {
  forData(employeeData: any) {
    return {
      getAlias: (alias: string) => ({
        getField: (field: string) => ({
          asStringArray: () => ['benefit1', 'benefit2']
        }),
        getLinkedContent: () => ({ value: 'Overridden Cost Label' })
      })
    };
  }
}

describe('OverrideCostDisplayService', () => {
  let service: OverrideCostDisplayService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        OverrideCostDisplayService,
        { provide: ContentAliasService, useClass: MockContentAliasService }
      ]
    });
    service = TestBed.inject(OverrideCostDisplayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return overridden cost label for benefit1', () => {
    const result = service.forData({}).getOverridenZeroCostLabel('benefit1');
    expect(result).toBe('Overridden Cost Label');
  });

  it('should return null for non-overridden benefit', () => {
    const result = service.forData({}).getOverridenZeroCostLabel('benefit3');
    expect(result).toBeNull();
  });
});
