import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { parseISO, isSameDay, isBefore } from 'date-fns';

@Injectable({
  providedIn: 'root'
})
export class CoverageEffectiveDateService {
  constructor(private router: Router) {}

  private parseDate(date: string): Date {
    return parseISO(date);
  }

  private allBenefitsEffectiveDateIsSameAndLessOrEqualThanLifeEventDate(employee: any, electionData: any[]): boolean {
    const lifeEventDate = this.parseDate(employee.LifeEvents[0].LifeEventDate);

    const isSameDate = electionData.map(benefit => benefit.ElectedOption.BenefitEffectiveDate)
      .every((date, _, arr) => isSameDay(this.parseDate(date), this.parseDate(arr[0])));

    const lessOrEqualThanLifeEventDate = electionData.every(benefit => {
      const benefitEffectiveDate = this.parseDate(benefit.ElectedOption.BenefitEffectiveDate);
      return isBefore(benefitEffectiveDate, lifeEventDate) || isSameDay(benefitEffectiveDate, lifeEventDate);
    });

    return lessOrEqualThanLifeEventDate && isSameDate;
  }

  private effectiveDateDisplayModeEnum = {
    disabled: 1,
    commonEffectiveDate: 2,
    effectiveDateForEachBenefit: 3
  };

  private isDisplayCoverageEffectiveDateSuppressed(data: any): boolean {
    return data.Configuration['HB.Summary.DisplayCoverageEffectiveDate'] !== 'T';
  }

  private showOnPages(model: any): boolean {
    return model.employee === model.data.Employee.CurrentCoveragesEmployee && this.router.url !== '/life-event/choose-benefits' ||
      ['/life-event/confirmation', '/life-event/review', '/expert-guidance/package-review', '/expert-guidance/confirmation', '/health-benefits/summary']
        .some(route => route === this.router.url);
  }

  private getEffectiveDateDisplayMode(model: any): number {
    if (!model.employee ||
      this.isDisplayCoverageEffectiveDateSuppressed(model.data) ||
      !this.showOnPages(model)
    ) {
      return this.effectiveDateDisplayModeEnum.disabled;
    }
    if (model.employee.LifeEvents[0].LifeEventDate && this.allBenefitsEffectiveDateIsSameAndLessOrEqualThanLifeEventDate(model.employee, model.electionData)) {
      return this.effectiveDateDisplayModeEnum.commonEffectiveDate;
    }

    return this.effectiveDateDisplayModeEnum.effectiveDateForEachBenefit;
  }

  getCoverageEffectiveDateInfo(model: any) {
    const displayMode = this.getEffectiveDateDisplayMode(model);
    return {
      showCommonEffectiveDate: displayMode === this.effectiveDateDisplayModeEnum.commonEffectiveDate,
      showBenefitsEffectiveDate: displayMode === this.effectiveDateDisplayModeEnum.effectiveDateForEachBenefit,
      commonEffectiveDate: model.employee && model.employee.LifeEvents[0].LifeEventDate
    };
  }
}
