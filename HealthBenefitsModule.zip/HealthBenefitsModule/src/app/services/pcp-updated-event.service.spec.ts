import { TestBed } from '@angular/core/testing';
import { PcpUpdatedEventService } from './pcp-updated-event.service';
import { EventService } from './event.service';

class MockEventService {
  createEvent(eventName: string) {
    return `Event ${eventName} created`;
  }
}

describe('PcpUpdatedEventService', () => {
  let service: PcpUpdatedEventService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PcpUpdatedEventService,
        { provide: EventService, useClass: MockEventService }
      ]
    });
    service = TestBed.inject(PcpUpdatedEventService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should create pcpUpdated event', () => {
    const result = service.createPcpUpdatedEvent();
    expect(result).toBe('Event pcpUpdated created');
  });
});
