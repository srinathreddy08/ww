import { TestBed } from '@angular/core/testing';
import { ContentAliasService, ContentWrapper } from './content-alias.service';
import { LoggerService } from './logger.service';
import { StringService } from './string.service';
import { FeatureTogglesService } from './feature-toggles.service';

class MockLoggerService {
  error(message: string) {}
}

class MockStringService {}

class MockFeatureTogglesService {
  contentAliasServiceErrorLogging = true;
}

describe('ContentAliasService', () => {
  let service: ContentAliasService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ContentAliasService,
        { provide: LoggerService, useClass: MockLoggerService },
        { provide: StringService, useClass: MockStringService },
        { provide: FeatureTogglesService, useClass: MockFeatureTogglesService }
      ]
    });
    service = TestBed.inject(ContentAliasService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should wrap data in ContentWrapper', () => {
    const data = { Data: {}, Content: {}, ContentAliases: {}, Configuration: {} };
    const wrapper = service.forData(data);
    expect(wrapper).toBeInstanceOf(ContentWrapper);
  });

  // Additional tests can be added here to test the service methods
});
