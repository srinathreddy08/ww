import { Injectable } from '@angular/core';
import { DependentResourceService } from './dependent-resource.service';
import { ContentAliasService } from './content-alias.service';
import { LogService } from './log.service';
import { StaticContent } from './static-content.service';
import { cloneDeep, map, find, includes, pickBy } from 'lodash';
import { format } from 'date-fns';

@Injectable({
  providedIn: 'root'
})
export class DependentService {
  private spouseCodes = ['S', 'SSNT', 'DPT', 'SST', 'DPNT'];
  private spouseRelationTypes = ['SP', 'DP', 'SGSP'];
  private logger = this.logService.getLogger('DependentUser.Coverage');

  constructor(
    private dependentResourceService: DependentResourceService,
    private contentAliasService: ContentAliasService,
    private logService: LogService,
    private staticContent: StaticContent
  ) {}

  addDependent(dependentsArray: any[]): any {
    return this.dependentResourceService.addDependent(map(dependentsArray, this.cloneAndChangeDependentBeforeSave));
  }

  updateDependent(originalDependentSsn: string, dependentFormData: any, isDomainPage: boolean): any {
    this.logger.debug('saveDependent()');

    const dependentToSave = this.cloneAndChangeDependentBeforeSave(dependentFormData);

    dependentToSave.Ssn = dependentFormData.IsDummySSN && !dependentFormData.Ssn ?
      originalDependentSsn :
      dependentFormData.Ssn;
    dependentToSave.SuppressRecalc = isDomainPage;

    this.logger.debug('isDomainPage', isDomainPage);

    return this.dependentResourceService.updateDependent(originalDependentSsn, dependentToSave, isDomainPage);
  }

  private cloneAndChangeDependentBeforeSave(dependentFormData: any): any {
    const resultDependent = cloneDeep(dependentFormData);

    this.setNullAddressIfSame(resultDependent);
    this.removeStateIfCountryHasNoStates(resultDependent);
    this.formatBirthDate(resultDependent);

    return resultDependent;
  }

  private removeStateIfCountryHasNoStates(resultDependent: any): void {
    if (resultDependent.Address) {
      const countryRecord = this.staticContent.Countries[resultDependent.Address.Country || 'USA'];
      if (!countryRecord) {
        resultDependent.Address.State = null;
      } else {
        const states = countryRecord.States;
        if (!states || states.length === 0 || !find(states, { StateProvinceCode: resultDependent.Address.State })) {
          resultDependent.Address.State = null;
        }
      }
    }
  }

  private setNullAddressIfSame(resultDependent: any): void {
    if (resultDependent.SameAddress) {
      resultDependent.Address = null;
    }
    delete resultDependent.SameAddress;
  }

  private formatBirthDate(resultDependent: any): void {
    resultDependent.BirthDate = format(new Date(resultDependent.BirthDate), 'MM/dd/yyyy');
  }

  getDependentRestrictions(dep: any, restrictions: any): any {
    return this.getDependentRestrictionsByCode(dep.RelationshipCode, restrictions);
  }

  getDependentRestrictionsByCode(code: string, restrictions: any): any {
    return restrictions.DependentRestrictions && restrictions.DependentRestrictions[code];
  }

  canEditCoverage(hasCoverage: boolean, coverageRule: string): boolean {
    const coverageRules = {
      addOnly: 'A',
      dropOnly: 'D',
      addAndDrop: 'B',
      notEditable: 'N'
    };

    const canAddCoverage = coverageRule === coverageRules.addAndDrop || coverageRule === coverageRules.addOnly;
    const canDropCoverage = coverageRule === coverageRules.addAndDrop || coverageRule === coverageRules.dropOnly;

    return hasCoverage ? canDropCoverage : canAddCoverage;
  }

  getSpouseCodes(): string[] {
    return this.spouseCodes;
  }

  getSpouseRelationTypes(): string[] {
    return this.spouseRelationTypes;
  }

  getAvailableRelationships(employeeData: any, dependentRestrictions: any): any {
    if (!dependentRestrictions) {
      return {};
    }

    const content = this.contentAliasService.forData(employeeData);
    const dependentRelationshipsContent =
      content.getObjectOrDefault('HB.Common.CommonTerms.RelationshipDependent');

    return pickBy(dependentRelationshipsContent, (v, relationshipCode) =>
      includes(dependentRestrictions.AvailableRelationshipCodes, relationshipCode)
    );
  }
}
