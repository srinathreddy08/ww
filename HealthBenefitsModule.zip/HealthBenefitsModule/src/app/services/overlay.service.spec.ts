import { TestBed } from '@angular/core/testing';
import { OverlayService } from './overlay.service';
import { EventService } from './event.service';
import { SpinnerService } from './spinner.service';
import { TemplateService } from './template.service';
import { PubSubService } from './pubsub.service';

class MockService {}

describe('OverlayService', () => {
  let service: OverlayService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        OverlayService,
        { provide: EventService, useClass: MockService },
        { provide: SpinnerService, useClass: MockService },
        { provide: TemplateService, useClass: MockService },
        { provide: PubSubService, useClass: MockService }
      ]
    });
    service = TestBed.inject(OverlayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // Additional tests can be added here to test the service methods
});
