import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class PcpOverlayEnabledService {
  constructor(private contentAliasService: ContentAliasService) {}

  isPcpOverlayEnabled(employeeData: any): boolean {
    const contentData = this.contentAliasService.forData(employeeData);
    return contentData.getConfigurationValue('HB.LifeEvent.PCPDisplay') === 'S';
  }
}
