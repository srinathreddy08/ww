import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ShoppingCartAmountItemService {
  createNoCovItem(benefit: any, lifeEvent: any): any {
    const noCovPlan = this.getNoCovPlan(benefit);

    return {
      BenefitID: benefit.BenefitID,
      PlanID: noCovPlan.PlanID,
      OptionID: noCovPlan.EligibleOptions[0].OptionID,
      Amount: 0,
      AmountInforce: 0,
      EmployeeAnnualCost: 0,
      EmployeePayPeriodCost: 0,
      EmployerAnnualCost: 0,
      EmployerPayPeriodCost: 0,
      AmountElected: 0,
      AmountPended: 0,
      PremiumMonthly: 0,
      PremiumAnnual: 0,
      AdministrativeCostMonthly: 0,
      AdministrativeCostAnnual: 0,
      PendedEmployeePayPeriodCost: 0,
      PendedEmployeeAnnualCost: 0,
      DependentAssociationList: [],
      ControlID: lifeEvent.ControlID,
      LifeEventDate: lifeEvent.LifeEventDate,
      LifeEventID: lifeEvent.LifeEventID
    };
  }

  private getNoCovPlan(benefit: any): any {
    return benefit.EligiblePlans.find((plan: any) => plan.IsNoCovPlan);
  }
}
