import { TestBed } from '@angular/core/testing';
import { ProcessTokensInDataService } from './process-tokens-in-data.service';
import { FormatFilter } from './format-filter.service';
import { compact } from 'lodash';

class MockFormatFilter {
  format(value: string, dataSources: any[], flag: boolean): string {
    return value.replace(/\{\{(.*?)\}\}/g, 'replaced');
  }
}

describe('ProcessTokensInDataService', () => {
  let service: ProcessTokensInDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ProcessTokensInDataService,
        { provide: FormatFilter, useClass: MockFormatFilter }
      ]
    });
    service = TestBed.inject(ProcessTokensInDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should process tokens in data', () => {
    const data = { Content: { key: '{{token}}' } };
    const result = service.processTokensInData(data, [{}]);
    expect(result.Content.key).toBe('replaced');
  });
});
