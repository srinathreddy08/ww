import { Injectable } from '@angular/core';
import { BenefitsService } from './benefits.service';
import { BenefitCategoryMap } from './benefit-category-map';
import { map, keys } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class BenefitCategoriesService {
  constructor(
    private benefitsService: BenefitsService,
    private benefitCategoryMap: BenefitCategoryMap
  ) {}

  LifeInsurance = this.getCategoryByName('LIFE INSURANCE');

  isLifeInsuranceCategory(categoryName: string): boolean {
    const categoryData = this.benefitCategoryMap[categoryName];
    return categoryData ? !!categoryData.isLifeInsuranceCategory : false;
  }

  getDefaultCategory(): any {
    return this.benefitCategoryMap['default'];
  }

  getCategoryByName(categoryName: string): any {
    return this.benefitCategoryMap[categoryName] || this.getDefaultCategory();
  }

  isAmountBased(benefit: any): boolean {
    return this.isLifeInsuranceCategory(benefit.BenefitCategory) && this.benefitsService.isAmountBasedBenefit(benefit);
  }

  isAccountBased(benefit: any): boolean {
    return this.isAmountBased(benefit) || benefit.BenefitCategory === 'SPENDING';
  }

  getBenefitIds(employee: any, categories: string[]): string[] {
    const lifeEvent = employee.LifeEvents[0];
    return keys(map(lifeEvent.EligibleBenefitsMap, (benefit) => {
      return categories.includes(benefit.BenefitCategory) ? benefit : null;
    })).filter(Boolean);
  }
}
