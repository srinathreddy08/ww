import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Logger } from '@angular/core';
import { LoggedErrorsService } from './logged-errors.service';
import { ProfileService } from './profile.service';
import { MbcContentAndDataService } from './mbc-content-and-data.service';
import { FlagsService } from './flags.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MbcLogService {
  private errorsLog: string[] = [];
  private stateChangeCache: any[] = [];
  private stateChangeCacheDelay = 200;

  constructor(
    private http: HttpClient,
    private router: Router,
    private logger: Logger,
    private loggedErrors: LoggedErrorsService,
    private profileService: ProfileService,
    private mbcContentAndData: MbcContentAndDataService,
    private flags: FlagsService
  ) {}

  private addErrorMessage(message: string): void {
    const formattedMessage = message.replace(/\r\n/g, '\n').replace(/\n/g, '\n');
    this.errorsLog.push(`[${new Date().toLocaleString()}] ${formattedMessage}`);
  }

  private logMessage(message: string, logTarget: 'info' | 'warn' | 'error', serverAction: string): void {
    this.logger[logTarget](message);
    this.http.post(`/api/log/${serverAction}`, { message }).pipe(
      catchError(err => of(`Error logging message: ${err}`))
    ).subscribe();
  }

  logInfo(message: string): void {
    this.logMessage(message, 'info', 'message');
  }

  logPendoInfo(message: string): void {
    this.http.post('/api/log/pendoInfo', { Message: message }).pipe(
      catchError(err => of(`Error logging Pendo info: ${err}`))
    ).subscribe();
  }

  logWarning(message: string): void {
    this.logMessage(message, 'warn', 'warning');
  }

  logError(message: string, obj?: any): void {
    if (obj) {
      message += ` JSON[${JSON.stringify(obj)}]`;
    }
    this.logger.error(message);
    this.addErrorMessage(message);
    const error = { message, stack: null };
    if (!this.loggedErrors.isLogged(error)) {
      this.http.post('/api/log/error', { Message: message }).pipe(
        catchError(err => of(`Error logging error: ${err}`))
      ).subscribe(() => {
        this.loggedErrors.put(error);
      });
    }
  }

  logStateChange(fromUrl: string, toUrl: string, duration: number): void {
    const record = {
      time: new Date(),
      data: {
        fromUrl: (fromUrl || '').replace('~2F', '/'),
        toUrl: toUrl.replace('~2F', '/'),
        duration
      }
    };
    this.stateChangeCache.push(record);
    setTimeout(() => this.processCache(), this.stateChangeCacheDelay * 2);
  }

  private processCache(): void {
    const now = new Date();
    const items = this.stateChangeCache.filter(record => now.getTime() - record.time.getTime() >= this.stateChangeCacheDelay);
    this.stateChangeCache = this.stateChangeCache.filter(record => now.getTime() - record.time.getTime() < this.stateChangeCacheDelay);
    const compactedRecords = this.compactRecords(items.map(item => item.data));
    compactedRecords.forEach(record => this.putStateChangeRecordToLog(record));
  }

  private compactRecords(records: any[]): any[] {
    const recordsWithMergedDoubles = this.mergeDoubles(records);
    return this.mergeChains(recordsWithMergedDoubles);
  }

  private mergeDoubles(sourceRecords: any[]): any[] {
    return Array.from(new Set(sourceRecords.map(record => JSON.stringify(record)))).map(record => JSON.parse(record)).map(value => {
      const duration = sourceRecords.filter(record => record.fromUrl === value.fromUrl && record.toUrl === value.toUrl).reduce((sum, record) => sum + record.duration, 0);
      return { fromUrl: value.fromUrl, toUrl: value.toUrl, duration };
    });
  }

  private mergeChains(sourceRecords: any[]): any[] {
    let recordsForIteration = sourceRecords;
    while (true) {
      const pair = recordsForIteration.map(record => {
        const matchedRecord = recordsForIteration.find(secondRecord => record.toUrl === secondRecord.fromUrl && record !== secondRecord && record.fromUrl !== secondRecord.toUrl && record.fromUrl !== record.toUrl && secondRecord.fromUrl !== secondRecord.toUrl);
        return matchedRecord ? { from: record, to: matchedRecord } : null;
      }).filter(Boolean)[0];
      if (!pair) {
        return recordsForIteration;
      }
      const resultRecord = { fromUrl: pair.from.fromUrl, toUrl: pair.to.toUrl, duration: pair.from.duration + pair.to.duration };
      recordsForIteration = recordsForIteration.filter(record => record !== pair.to && record !== pair.from).concat(resultRecord);
    }
  }

  private putStateChangeRecordToLog(record: any): void {
    const promises = {
      profile: this.profileService.get().toPromise(),
      client: this.flags.isImpersonation || this.flags.isProxySimulation ? this.mbcContentAndData.get('client').toPromise() : Promise.resolve(null)
    };
    Promise.all([promises.profile, promises.client]).then(([profile, client]) => {
      this.http.post('/api/log/stateChange', {
        PathFrom: record.fromUrl || '',
        PathTo: record.toUrl,
        Duration: record.duration || 0,
        VisitorFakeSsn: profile.Data.Ssn,
        CompanyId: this.flags.companyId,
        ProxyVisitorId: client ? client.Data.GlobalProfileId : ''
      }).pipe(
        catchError(err => of(`Error logging state change: ${err}`))
      ).subscribe();
    });
  }

  throwError(errorMessage: string, jsonObj?: any): void {
    let message = errorMessage;
    if (jsonObj) {
      message += ` JSON[${JSON.stringify(jsonObj)}]`;
    }
    this.addErrorMessage(message);
    this.router.navigate(['error'], { queryParams: { message: errorMessage } });
    throw new Error(message);
  }

  addErrorsLog(message: string, obj?: any): void {
    if (obj) {
      message += ` JSON[${JSON.stringify(obj)}]`;
    }
    this.addErrorMessage(message);
  }

  addInfoLog(message: string, obj?: any): void {
    if (obj) {
      message += ` JSON[${JSON.stringify(obj)}]`;
    }
    this.logger.info(message);
    this.addErrorMessage(message);
  }

  getErrorsLog(): string[] {
    return this.errorsLog;
  }
}
