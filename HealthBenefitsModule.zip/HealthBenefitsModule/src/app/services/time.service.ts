import { Injectable } from '@angular/core';
import { TimeOffset } from './time-offset.service';

@Injectable({
  providedIn: 'root'
})
export class TimeService {
  constructor(private timeOffset: TimeOffset) {}

  now(): Date {
    const result = new Date();

    if (!this.isOffsetEnabled()) {
      return result;
    }

    result.setDate(result.getDate() + this.timeOffset.Days);
    result.setTime(result.getTime() + this.timeOffset.Minutes * 60 * 1000);
    return result;
  }

  isOffsetEnabled(): boolean {
    return this.timeOffset.IsOffsetEnabled;
  }
}
