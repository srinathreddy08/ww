import { Injectable } from '@angular/core';
import { DependentVerificationService } from './dependent-verification.service';
import { BenefitCategoriesService } from './benefit-categories.service';

@Injectable({
  providedIn: 'root'
})
export class GetCoveredDependentCountsService {
  constructor(
    private dependentVerificationService: DependentVerificationService,
    private benefitCategoriesService: BenefitCategoriesService
  ) {}

  getCoveredDependentCounts(employee: any, elections: any, employeeData: any, benefitCategory: any, ignorePendingVerification: string, leCompleteMode: string) {
    if (!employee) {
      employee = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
    }

    const relationTypes = {
      spouse: 'SP',
      sameSexSpouse: 'SGSP',
      domesticPartner: 'DP',
      domesticPartnerChild: 'CDP',
      disabledDomesticPartnerChild: 'DCDP',
      child: 'CH',
      disabledChild: 'DISCH',
      fs: 'FS',
      ld: 'LD',
      sameSexChild: 'SGCH'
    };

    const dependents = ignorePendingVerification === 'true' ? this.getDependentsIgnoreVerification(employee) : this.getDependents(employee, employeeData, elections, benefitCategory);
    const unverifiedDependents = this.getUnverifiedDependents(employee, employeeData, elections, benefitCategory);
    const coveredDependents = this.getCoveredDependents(dependents, elections, employee, benefitCategory, leCompleteMode);
    const coveredUnverifiedDependents = this.getCoveredUnverifiedDependents(unverifiedDependents, elections, employee, benefitCategory);

    return {
      AllSpouses: this.dependentTypeCount(coveredDependents, [relationTypes.spouse, relationTypes.sameSexSpouse, relationTypes.domesticPartner]),
      Spouses: this.dependentTypeCount(coveredDependents, [relationTypes.spouse]),
      DomesticPartners: this.dependentTypeCount(coveredDependents, [relationTypes.domesticPartner]),
      SameSexSpouses: this.dependentTypeCount(coveredDependents, [relationTypes.sameSexSpouse]),
      AllChildren: this.dependentTypeCount(coveredDependents, [relationTypes.domesticPartnerChild, relationTypes.disabledDomesticPartnerChild, relationTypes.child, relationTypes.disabledChild, relationTypes.fs, relationTypes.ld]),
      Children: this.dependentTypeCount(coveredDependents, [relationTypes.child, relationTypes.disabledChild, relationTypes.fs, relationTypes.ld]),
      DomesticPartnerChildren: this.dependentTypeCount(coveredDependents, [relationTypes.domesticPartnerChild, relationTypes.disabledDomesticPartnerChild]),
      SameSexChildren: this.dependentTypeCount(coveredDependents, [relationTypes.sameSexChild]),
      UnverifiedAllSpouses: this.unverifiedDependentTypeCount(coveredUnverifiedDependents, [relationTypes.spouse, relationTypes.sameSexSpouse, relationTypes.domesticPartner]),
      UnverifiedSpouses: this.unverifiedDependentTypeCount(coveredUnverifiedDependents, [relationTypes.spouse]),
      UnverifiedDomesticPartners: this.unverifiedDependentTypeCount(coveredUnverifiedDependents, [relationTypes.domesticPartner]),
      UnverifiedSameSexSpouses: this.unverifiedDependentTypeCount(coveredUnverifiedDependents, [relationTypes.sameSexSpouse]),
      UnverifiedAllChildren: this.unverifiedDependentTypeCount(coveredUnverifiedDependents, [relationTypes.domesticPartnerChild, relationTypes.disabledDomesticPartnerChild, relationTypes.child, relationTypes.disabledChild, relationTypes.fs, relationTypes.ld]),
      UnverifiedChildren: this.unverifiedDependentTypeCount(coveredUnverifiedDependents, [relationTypes.child, relationTypes.disabledChild, relationTypes.fs, relationTypes.ld]),
      UnverifiedDomesticPartnerChildren: this.unverifiedDependentTypeCount(coveredUnverifiedDependents, [relationTypes.domesticPartnerChild, relationTypes.disabledDomesticPartnerChild]),
      UnverifiedSameSexChildren: this.unverifiedDependentTypeCount(coveredUnverifiedDependents, [relationTypes.sameSexChild]),
      AllDependents: Object.keys(coveredDependents).length
    };
  }

  private getDependents(employee: any, employeeData: any, elections: any, benefitCategory: any) {
    return employee.Dependents.filter((dependent: any) => !this.isVerificationRequiredForDependent(dependent, employee, employeeData, elections, benefitCategory)).reduce((acc: any, dependent: any) => {
      acc[dependent.Ssn] = dependent;
      return acc;
    }, {});
  }

  private getUnverifiedDependents(employee: any, employeeData: any, elections: any, benefitCategory: any) {
    return employee.Dependents.filter((dependent: any) => this.isVerificationRequiredForDependent(dependent, employee, employeeData, elections, benefitCategory)).reduce((acc: any, dependent: any) => {
      acc[dependent.Ssn] = dependent;
      return acc;
    }, {});
  }

  private isVerificationRequiredForDependent(dependent: any, employee: any, employeeData: any, elections: any, benefitCategory: any) {
    if (employee.LifeEvents[0].LifeEventID === '55' && this.dependentVerificationService.forData(employeeData).isCurrentCoverageHaveNotDevForDependent(dependent)) return false;

    return this.dependentVerificationService
      .forData(employeeData)
      .dependentIsCountedAsUnverified(dependent, elections, benefitCategory);
  }

  private getDependentsIgnoreVerification(employee: any) {
    return employee.Dependents.reduce((acc: any, dependent: any) => {
      acc[dependent.Ssn] = dependent;
      return acc;
    }, {});
  }

  private dependentTypeCount(coveredDependents: any, relationshipCodes: string[]) {
    const relationshipCodesMap = relationshipCodes.reduce((acc: any, code: string) => {
      acc[code] = true;
      return acc;
    }, {});

    return Object.values(coveredDependents).filter((dependent: any) => relationshipCodesMap[dependent.RelationType]).length;
  }

  private unverifiedDependentTypeCount(coveredUnverifiedDependents: any, relationshipCodes: string[]) {
    const relationshipCodesMap = relationshipCodes.reduce((acc: any, code: string) => {
      acc[code] = true;
      return acc;
    }, {});

    return Object.values(coveredUnverifiedDependents).filter((dependent: any) => relationshipCodesMap[dependent.RelationType]).length;
  }

  private getCoveredDependents(dependents: any, elections: any, employee: any, benefitCategory: any, leCompleteMode: string) {
    const benefitIds = this.benefitCategoriesService.getBenefitIds(employee, benefitCategory);

    const coveredDependentsSsns = elections
      .filter((election: any) => benefitIds.includes(election.BenefitId))
      .flatMap((election: any) => election.DependentAssociationList)
      .map((association: any) => association.DependentSsn);

    if (leCompleteMode === 'true') {
      return coveredDependentsSsns.reduce((acc: any, ssn: string) => {
        if (dependents[ssn]) {
          acc[ssn] = dependents[ssn];
        }
        return acc;
      }, {});
    } else {
      return coveredDependentsSsns.reduce((acc: any, ssn: string) => {
        if (dependents[ssn]) {
          acc[ssn] = dependents[ssn];
        }
        return acc;
      }, {});
    }
  }

  private getCoveredUnverifiedDependents(unverifiedDependents: any, elections: any, employee: any, benefitCategory: any) {
    const benefitIds = this.benefitCategoriesService.getBenefitIds(employee, benefitCategory);

    const coveredDependentsSsns = elections
      .filter((election: any) => benefitIds.includes(election.BenefitId))
      .flatMap((election: any) => election.DependentAssociationList)
      .map((association: any) => association.DependentSsn);

    return coveredDependentsSsns.reduce((acc: any, ssn: string) => {
      if (unverifiedDependents[ssn]) {
        acc[ssn] = unverifiedDependents[ssn];
      }
      return acc;
    }, {});
  }
}
