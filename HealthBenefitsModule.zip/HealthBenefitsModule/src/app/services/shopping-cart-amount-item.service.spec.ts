import { TestBed } from '@angular/core/testing';
import { ShoppingCartAmountItemService } from './shopping-cart-amount-item.service';

describe('ShoppingCartAmountItemService', () => {
  let service: ShoppingCartAmountItemService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ShoppingCartAmountItemService]
    });
    service = TestBed.inject(ShoppingCartAmountItemService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should create a no coverage item', () => {
    const benefit = {
      BenefitID: 'benefit1',
      EligiblePlans: [
        { PlanID: 'plan1', IsNoCovPlan: false },
        { PlanID: 'plan2', IsNoCovPlan: true, EligibleOptions: [{ OptionID: 'option1' }] }
      ]
    };
    const lifeEvent = {
      ControlID: 'control1',
      LifeEventDate: '2023-01-01',
      LifeEventID: 'event1'
    };
    const noCovItem = service.createNoCovItem(benefit, lifeEvent);
    expect(noCovItem.PlanID).toBe('plan2');
    expect(noCovItem.OptionID).toBe('option1');
    expect(noCovItem.Amount).toBe(0);
  });
});
