import { Injectable } from '@angular/core';
import { reject, includes } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class WithoutService {
  execute(a: any[], b: any[]): any[] {
    return reject(a, x => includes(b, x));
  }
}
