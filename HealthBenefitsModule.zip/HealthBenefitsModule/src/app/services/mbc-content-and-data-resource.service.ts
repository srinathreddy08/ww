import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { StaticContentService } from './static-content.service';
import { TransformOpenEnrollmentService } from './transform-open-enrollment.service';
import { PubSubService } from './pubsub.service';
import { ProcessTokensInDataService } from './process-tokens-in-data.service';
import { ContentAliasService } from './content-alias.service';
import { ReloadCurrentStateService } from './reload-current-state.service';

@Injectable({
  providedIn: 'root'
})
export class MbcContentAndDataResourceService {
  private cache = new Map<string, any>();

  constructor(
    private http: HttpClient,
    private staticContentService: StaticContentService,
    private transformOpenEnrollmentService: TransformOpenEnrollmentService,
    private pubsub: PubSubService,
    private processTokensInDataService: ProcessTokensInDataService,
    private contentAliasService: ContentAliasService,
    private reloadCurrentStateService: ReloadCurrentStateService
  ) {}

  getProcessedData(sectionKey: string, options: any = {}): Observable<any> {
    return this.getProcessedDataCore(sectionKey, {
      hardRefresh: options.hardRefresh,
      getData: () => {
        return this.http.get(`/api/content/${sectionKey}`).pipe(
          map((sourceData: any) => {
            const additionalData = options.additionalDataSources ? options.additionalDataSources : [];
            return this.processTokensInDataService.process(sourceData, additionalData);
          })
        );
      }
    });
  }

  getData(sectionKey: string, transform?: (data: any) => any, hardRefresh?: boolean): Observable<any> {
    return this.getProcessedDataCore(sectionKey, {
      hardRefresh,
      getData: () => {
        return this.http.get(`/api/content/${sectionKey}`).pipe(
          map(data => transform ? transform(data) : data)
        );
      }
    });
  }

  refresh(reload: boolean): void {
    this.clearWholeCache();
    if (reload) {
      this.reloadCurrentStateService.reload();
    }
  }

  private clearWholeCache(): void {
    this.cache.clear();
  }

  private getProcessedDataCore(sectionKey: string, options: any): Observable<any> {
    if (options.hardRefresh) {
      this.remove(sectionKey);
    }

    const cachedData = this.getCachedData(sectionKey);
    if (cachedData) {
      return of(cachedData);
    }

    return this.updateCache(sectionKey, options.getData());
  }

  private getCachedData(sectionKey: string): any {
    return this.cache.get(`transformed.${sectionKey}`);
  }

  private remove(sectionKey: string): void {
    this.cache.delete(`transformed.${sectionKey}`);
    this.cache.delete(`/api/content/${sectionKey}`);
  }

  private updateCache(sectionKey: string, data$: Observable<any>): Observable<any> {
    this.pubsub.publish('mbcContentAndData.cache.updating', { key: sectionKey });

    return data$.pipe(
      map(newData => {
        this.pubsub.publish('mbcContentAndData.cache.updated', { key: sectionKey, newData });
        this.cache.set(`transformed.${sectionKey}`, newData);
        return newData;
      }),
      catchError(error => {
        console.error('Error updating cache:', error);
        return of(null);
      })
    );
  }

  getEnrollmentContent(): Observable<any> {
    return this.getEnrollment().pipe(
      map(data => this.contentAliasService.forData(data))
    );
  }

  getEnrollment(): Observable<any> {
    return this.getData('enrollment', this.transformOpenEnrollmentService.transform);
  }

  updateEnrollmentCache(data: any): void {
    this.updateCache('enrollment', of(data));
  }

  getCachedEnrollmentData(): any {
    return this.getCachedData('enrollment');
  }
}
