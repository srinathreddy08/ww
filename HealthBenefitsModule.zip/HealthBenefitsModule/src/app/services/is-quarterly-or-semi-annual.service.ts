import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class IsQuarterlyOrSemiAnnualService {
  isQuarterlyOrSemiAnnual(employeeData: any): boolean {
    const isQuarterlyDefined = employeeData.SmallMarketData.CompanyPlanYearQuestions.some((question: any) =>
      question.BenefitId === 'HSA' && question.Seq === 1 && question.Answer === 'Quarterly'
    );
    const isSemiAnnualDefined = employeeData.SmallMarketData.CompanyPlanYearQuestions.some((question: any) =>
      question.BenefitId === 'HSA' && question.Seq === 1 && question.Answer === 'Semi-Annual'
    );
    return isQuarterlyDefined || isSemiAnnualDefined;
  }
}
