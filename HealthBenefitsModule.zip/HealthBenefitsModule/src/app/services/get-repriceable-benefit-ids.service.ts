import { Injectable } from '@angular/core';
import { GetRepriceBenefitRelationsService } from './get-reprice-benefit-relations.service';

@Injectable({
  providedIn: 'root'
})
export class GetRepriceableBenefitIdsService {
  constructor(private getRepriceBenefitRelations: GetRepriceBenefitRelationsService) {}

  getRepriceableBenefitIds(employeeData: any): string[] {
    const repriceBenefitRelations = this.getRepriceBenefitRelations.getRepriceBenefitRelations(employeeData);

    const relatedBenefits = repriceBenefitRelations
      .flatMap((relation: any) => relation.RelatedBenefits);

    return Array.from(new Set([
      ...Object.keys(repriceBenefitRelations),
      ...relatedBenefits
    ]));
  }
}
