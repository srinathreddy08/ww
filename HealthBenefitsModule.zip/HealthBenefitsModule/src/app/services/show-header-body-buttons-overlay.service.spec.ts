import { TestBed } from '@angular/core/testing';
import { ShowHeaderBodyButtonsOverlayService } from './show-header-body-buttons-overlay.service';
import { OverlayService } from './overlay.service';
import { of } from 'rxjs';

class MockOverlayService {
  open(template: string, params: any) {}
}

describe('ShowHeaderBodyButtonsOverlayService', () => {
  let service: ShowHeaderBodyButtonsOverlayService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ShowHeaderBodyButtonsOverlayService,
        { provide: OverlayService, useClass: MockOverlayService }
      ]
    });
    service = TestBed.inject(ShowHeaderBodyButtonsOverlayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should open overlay with default template', () => {
    const overlaySpy = spyOn(TestBed.inject(OverlayService), 'open');
    service.showHeaderBodyButtonsOverlay({}).subscribe();
    expect(overlaySpy).toHaveBeenCalledWith('/shared/views/overlay/headerBodyButtonsOverlay', {});
  });

  it('should open overlay with custom template', () => {
    const overlaySpy = spyOn(TestBed.inject(OverlayService), 'open');
    const customTemplate = '/custom/template/path';
    service.showHeaderBodyButtonsOverlay({ template: customTemplate }).subscribe();
    expect(overlaySpy).toHaveBeenCalledWith(customTemplate, { template: customTemplate });
  });
});
