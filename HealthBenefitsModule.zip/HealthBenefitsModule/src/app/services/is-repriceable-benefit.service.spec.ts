import { TestBed } from '@angular/core/testing';
import { IsRepriceableBenefitService } from './is-repriceable-benefit.service';
import { BenefitCategoriesService } from './benefit-categories.service';
import { GetRepriceableBenefitIdsService } from './get-repriceable-benefit-ids.service';

class MockBenefitCategoriesService {
  isAccountBased(benefit: any) {
    return benefit.type === 'account';
  }
}

class MockGetRepriceableBenefitIdsService {
  getRepriceableBenefitIds(employeeData: any) {
    return ['123', '456'];
  }
}

describe('IsRepriceableBenefitService', () => {
  let service: IsRepriceableBenefitService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        IsRepriceableBenefitService,
        { provide: BenefitCategoriesService, useClass: MockBenefitCategoriesService },
        { provide: GetRepriceableBenefitIdsService, useClass: MockGetRepriceableBenefitIdsService }
      ]
    });
    service = TestBed.inject(IsRepriceableBenefitService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true for account-based benefits', () => {
    const benefit = { type: 'account', BenefitID: '789' };
    const isRepriceable = service.forData({})(benefit);
    expect(isRepriceable).toBeTrue();
  });

  it('should return true for repriceable benefit IDs', () => {
    const benefit = { type: 'non-account', BenefitID: '123' };
    const isRepriceable = service.forData({})(benefit);
    expect(isRepriceable).toBeTrue();
  });

  it('should return false for non-repriceable benefits', () => {
    const benefit = { type: 'non-account', BenefitID: '789' };
    const isRepriceable = service.forData({})(benefit);
    expect(isRepriceable).toBeFalse();
  });
});
