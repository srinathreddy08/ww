import { TestBed } from '@angular/core/testing';
import { GetRepriceBenefitRelationsService } from './get-reprice-benefit-relations.service';
import { ContentAliasService } from './content-alias.service';

class MockContentAliasService {
  forData(employeeData: any) {
    return {
      getConfiguration: (key: string) => ({
        value: '[1:2,3],[4:5]'
      })
    };
  }
}

describe('GetRepriceBenefitRelationsService', () => {
  let service: GetRepriceBenefitRelationsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: ContentAliasService, useClass: MockContentAliasService }
      ]
    });
    service = TestBed.inject(GetRepriceBenefitRelationsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should parse reprice benefit relations correctly', () => {
    const employeeData = {};
    const result = service.getRepriceBenefitRelations(employeeData);
    expect(result).toEqual({
      '1': { ElectedBenefitId: '1', RelatedBenefits: ['2', '3'] },
      '4': { ElectedBenefitId: '4', RelatedBenefits: ['5'] }
    });
  });
});
