import { Injectable } from '@angular/core';
import { PcpOverlayEnabledService } from './pcp-overlay-enabled.service';
import { ElectionRequiresPcpDataService } from './election-requires-pcp-data.service';

@Injectable({
  providedIn: 'root'
})
export class PcpOverlayDisplayService {
  constructor(
    private pcpOverlayEnabled: PcpOverlayEnabledService,
    private electionRequiresPcpData: ElectionRequiresPcpDataService
  ) {}

  pcpOverlayShouldBeShown(election: any, employeeData: any, additionalConditions: () => boolean): boolean {
    return election &&
      this.pcpOverlayEnabled.isEnabled(employeeData) &&
      this.electionRequiresPcpData.isRequired(election, employeeData) &&
      additionalConditions();
  }
}
