import { TestBed } from '@angular/core/testing';
import { MbcUtilService } from './mbc-util.service';
import { StaticContentService } from './static-content.service';
import { ContentAliasService } from './content-alias.service';

class MockStaticContentService {
  Images = {
    'Category_Off': { MediaId: '123', Alt: 'Category Off' },
    'Category_PlanType_Off': { MediaId: '456', Alt: 'PlanType Off' },
    'Category_BenefitType_Off': { MediaId: '789', Alt: 'BenefitType Off' }
  };
}

class MockContentAliasService {
  forData(employeeData: any) {
    return {
      getContentObject: (alias: string) => ({ BenefitLogo: { Alt: 'Benefit Logo', MediaId: '101' } })
    };
  }
}

describe('MbcUtilService', () => {
  let service: MbcUtilService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MbcUtilService,
        { provide: StaticContentService, useClass: MockStaticContentService },
        { provide: ContentAliasService, useClass: MockContentAliasService }
      ]
    });
    service = TestBed.inject(MbcUtilService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should capitalize the first letter of a string', () => {
    expect(service.capitalizeFirstLetter('test')).toBe('Test');
  });

  it('should capitalize a word', () => {
    expect(service.capitalizeWord('test')).toBe('TEST');
  });

  it('should return the correct coverage image', () => {
    const benefit = { ContentAlias: 'alias', BenefitType: 'type', BenefitCategory: 'category' };
    const plan = { Type: 'planType', Carrier: { CarrierContent: 'carrierContent' } };
    const employeeData = {};
    const image = service.getCoverageImage(benefit, plan, employeeData, false);
    expect(image.LogoSrc).toBe('/media/101');
  });

  // Additional tests can be added here to test the service methods
});
