import { Injectable } from '@angular/core';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class GetRepriceBenefitRelationsService {
  constructor(private contentAliasService: ContentAliasService) {}

  getRepriceBenefitRelations(employeeData: any): Record<string, any> {
    const repriceableBenefitIdsConfiguration = this.contentAliasService.forData(employeeData)
      .getConfiguration('HB.LifeEvent.RepriceableBenefitIDs');

    return this.allMatches(repriceableBenefitIdsConfiguration.value, /\[ *(.*?) *\]/g)
      .map(match => this.parseRelationship(match[1]))
      .reduce((acc, relation) => {
        acc[relation.ElectedBenefitId] = relation;
        return acc;
      }, {} as Record<string, any>);
  }

  private parseRelationship(config: string): any {
    const parts = config.split(/\ *: */);
    const electedBenefitId = parts[0];

    const hasAdditionalBenefits = parts.length > 1;

    if (!hasAdditionalBenefits) {
      return this.benefitWithNoRelatedBenefits(electedBenefitId);
    }

    return {
      ElectedBenefitId: electedBenefitId,
      RelatedBenefits: parts[1].split(/\ *, */)
    };
  }

  private benefitWithNoRelatedBenefits(benefitId: string): any {
    return {
      ElectedBenefitId: benefitId,
      RelatedBenefits: []
    };
  }

  private allMatches(str: string, regex: RegExp): RegExpExecArray[] {
    const result: RegExpExecArray[] = [];
    let match: RegExpExecArray | null;

    while ((match = regex.exec(str)) !== null) {
      result.push(match);
    }

    return result;
  }
}
