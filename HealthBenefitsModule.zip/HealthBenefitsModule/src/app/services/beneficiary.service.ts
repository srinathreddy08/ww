import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ShoppingCartService } from './shopping-cart.service';
import { MbcContentAndData } from './mbc-content-and-data.service';
import { BenefitCategoriesService } from './benefit-categories.service';
import { ExpertGuidanceState } from './expert-guidance-state.service';
import { map } from 'lodash';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BeneficiaryService {
  private readonly apiUrl = '/api/beneficiaries';

  constructor(
    private http: HttpClient,
    private shoppingCartService: ShoppingCartService,
    private mbcContentAndData: MbcContentAndData,
    private benefitCategoriesService: BenefitCategoriesService,
    private expertGuidanceState: ExpertGuidanceState
  ) {}

  saveShoppingCartBeneficiaries(lifeEventId: string, lifeEventSeqNo: string, lifeEventDate: string, data: any, oldBeneficiaries: any): Observable<any> {
    this.shoppingCartService.clearCartCache(lifeEventId, lifeEventSeqNo, lifeEventDate);

    const clearedData = {
      Beneficiaries: this.getBeneficiariesBasedOnDesignations(data, oldBeneficiaries),
      Designations: data.Designations
    };

    return this.http.post(`${this.apiUrl}/saveShoppingCartBeneficiaries`, {
      LifeEventDate: lifeEventDate,
      Data: clearedData,
      IsExpertGuidance: this.expertGuidanceState.useSuggestedPackageResource()
    });
  }

  saveCurrentBeneficiaries(data: any, lifeEventDate: string): Observable<any> {
    this.mbcContentAndData.remove('enrollment');
    const clonedData = { ...data, lifeEventDate };
    return this.http.post(`${this.apiUrl}/saveCurrentBeneficiaries`, clonedData);
  }

  planSupportsBeneficiaries(benefit: any, plan: any): boolean {
    if (plan.IsNoCovPlan) {
      return false;
    }

    const category = this.benefitCategoriesService.GetCategoryByName(benefit.BenefitCategory);

    if (!category.HasBeneficiaries) {
      return false;
    }

    const beneficiariesEnabledOptions = ['O', 'R'];
    return beneficiariesEnabledOptions.includes(plan.PlanYearDefBeneRequirement);
  }

  getAsyncValidateSsnDuplicationForLe(): (beneficiarySsn: string, originalBeneficiarySsn: string, isTrust: boolean) => Observable<any> {
    return (beneficiarySsn, originalBeneficiarySsn, isTrust) => {
      return this.http.post(`${this.apiUrl}/validateSsnDuplication`, {
        Ssn: beneficiarySsn,
        OriginalSsn: originalBeneficiarySsn,
        IsLifeEvent: true,
        IsTrust: isTrust
      });
    };
  }

  asyncValidateSsnDuplication(beneficiarySsn: string, originalBeneficiarySsn: string, isTrust: boolean): Observable<any> {
    return this.http.post(`${this.apiUrl}/validateSsnDuplication`, {
      Ssn: beneficiarySsn,
      OriginalSsn: originalBeneficiarySsn,
      IsTrust: isTrust
    });
  }

  compareSsnWithExisting(beneficiarySsn: string, existingList: string[]): Observable<any> {
    const params = {
      BeneficiarySsn: { Ssn: beneficiarySsn },
      ExistingList: map(existingList, ssn => ({ Ssn: ssn }))
    };

    return this.http.post(`${this.apiUrl}/compareSsnWithExisting`, params);
  }

  private getBeneficiariesBasedOnDesignations(data: any, oldBeneficiaries: any): any {
    return map(data.Beneficiaries, (beneficiary) => {
      const hasDesignations = map(data.Designations, (designation) => designation.Id === beneficiary.Id).some(Boolean);
      const isOldBeneficiary = oldBeneficiaries && oldBeneficiaries[beneficiary.Id];
      return hasDesignations || isOldBeneficiary ? beneficiary : null;
    }).filter(Boolean);
  }
}
