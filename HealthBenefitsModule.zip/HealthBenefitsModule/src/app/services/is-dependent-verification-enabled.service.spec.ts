import { TestBed } from '@angular/core/testing';
import { IsDependentVerificationEnabledService } from './is-dependent-verification-enabled.service';
import { DependentVerificationService } from './dependent-verification.service';

class MockDependentVerificationService {
  forData(employee: any) {
    return {
      isDependentVerificationEnabled: () => true
    };
  }
}

describe('IsDependentVerificationEnabledService', () => {
  let service: IsDependentVerificationEnabledService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        IsDependentVerificationEnabledService,
        { provide: DependentVerificationService, useClass: MockDependentVerificationService }
      ]
    });
    service = TestBed.inject(IsDependentVerificationEnabledService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true if dependent verification is enabled', () => {
    const employee = {};
    expect(service.isVerificationEnabled(employee)).toBeTrue();
  });
});
