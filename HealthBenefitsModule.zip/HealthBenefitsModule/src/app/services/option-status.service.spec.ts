import { TestBed } from '@angular/core/testing';
import { OptionStatusService } from './option-status.service';

describe('OptionStatusService', () => {
  let service: OptionStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OptionStatusService]
    });
    service = TestBed.inject(OptionStatusService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true for status A', () => {
    expect(service.isAvailableForUpdate({ Status: 'A' })).toBe(true);
  });

  it('should return true for status E', () => {
    expect(service.isAvailableForUpdate({ Status: 'E' })).toBe(true);
  });

  it('should return false for other statuses', () => {
    expect(service.isAvailableForUpdate({ Status: 'B' })).toBe(false);
    expect(service.isAvailableForUpdate({ Status: 'C' })).toBe(false);
  });
});
