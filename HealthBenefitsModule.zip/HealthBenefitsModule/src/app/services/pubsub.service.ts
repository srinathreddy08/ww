import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { filter } from 'rxjs/operators';

export type PubsubEventHandler<T> = (event: string, data: T) => void;

@Injectable({
  providedIn: 'root'
})
export class PubsubService {
  private isActive: boolean = true;
  private eventBus = new Subject<[string, unknown]>();
  private subscriptions: Record<string, Set<PubsubEventHandler<unknown>>> = {};

  constructor() {
    this.eventBus
      .pipe(
        filter(([eventName]) => (eventName in this.subscriptions))
      )
      .subscribe(([eventName, payload]) => {
        this.subscriptions[eventName]
          .forEach(handler => handler(eventName, payload));
      });
  }

  subscribe<T>(event: string, handler: PubsubEventHandler<T>) {
    const eventHandlers = this.subscriptions[event] || new Set();
    eventHandlers.add(handler);
    this.subscriptions[event] = eventHandlers;
  }

  publish<T>(event: string, data: T = null) {
    if (!this.isActive) {
      return null;
    }
    this.eventBus.next([event, data]);
  }

  unsubscribe<T>(event: string, handler: PubsubEventHandler<T>) {
    const eventHandlers = this.subscriptions[event];

    if (!!eventHandlers?.size) {
      eventHandlers.delete(handler);

      if (!eventHandlers.size) {
        delete this.subscriptions[event];
      }
    }
  }

  switchOff() {
    this.isActive = false;
  }
}
