import { TestBed } from '@angular/core/testing';
import { IsEmployeeContributionLabelEnabledService } from './is-employee-contribution-label-enabled.service';

describe('IsEmployeeContributionLabelEnabledService', () => {
  let service: IsEmployeeContributionLabelEnabledService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IsEmployeeContributionLabelEnabledService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true if configuration value is S', () => {
    const enrollmentContent = {
      getConfigurationValue: (key: string) => ({ 'HB.LIFEEVENT.SUMMARY.COMPANYCONT': 'S' })
    };
    expect(service.isEmployeeContributionLabelEnabled(enrollmentContent)).toBeTrue();
  });

  it('should return false if configuration value is not S', () => {
    const enrollmentContent = {
      getConfigurationValue: (key: string) => ({ 'HB.LIFEEVENT.SUMMARY.COMPANYCONT': 'N' })
    };
    expect(service.isEmployeeContributionLabelEnabled(enrollmentContent)).toBeFalse();
  });
});
