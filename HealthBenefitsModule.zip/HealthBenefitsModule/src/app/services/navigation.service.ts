import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { ShoppingCartService } from './shopping-cart.service';
import { MbcContentAndDataService } from './mbc-content-and-data.service';
import { LogService } from './log.service';
import { EmployeeCoverageService } from './employee-coverage.service';
import { DomainAvailabilityService } from './domain-availability.service';
import { PensionPaymentsService } from './pension-payments.service';
import { DbTaxViewValueService } from './db-tax-view-value.service';
import { ContentAliasService } from './content-alias.service';
import { ExecuteWithSpinnerService } from './execute-with-spinner.service';
import { DbContextService } from './db-context.service';
import { OnlineCommencementService } from './online-commencement.service';
import { RequiredDependentVerificationDocumentsService } from './required-dependent-verification-documents.service';
import { CachedLifeEventNavigationService } from './cached-life-event-navigation.service';
import { EnrollmentNavigationService } from './enrollment-navigation.service';

@Injectable({
  providedIn: 'root'
})
export class NavigationService {
  private logger = this.logService.getLogger('NavigationService');
  private megaNav: any = {};
  private currentPortalSection: any = null;
  private currentTab: any = {};
  private currentSubtab: any = {};
  private currentPageTitle: string | undefined;
  private mobileHeader = {
    title: '',
    subtitle: '',
    exitText: '',
    search: true,
    alertText: ''
  };
  private pendingUpdateMobileHeaderAction: any;

  constructor(
    private router: Router,
    private shoppingCartService: ShoppingCartService,
    private mbcContentAndData: MbcContentAndDataService,
    private logService: LogService,
    private employeeCoverageService: EmployeeCoverageService,
    private domainAvailability: DomainAvailabilityService,
    private pensionPayments: PensionPaymentsService,
    private dbTaxViewValue: DbTaxViewValueService,
    private contentAliasService: ContentAliasService,
    private executeWithSpinner: ExecuteWithSpinnerService,
    private dbContextService: DbContextService,
    private onlineCommencementService: OnlineCommencementService,
    private requiredDependentVerificationDocuments: RequiredDependentVerificationDocumentsService,
    private cachedLifeEventNavigationService: CachedLifeEventNavigationService,
    private enrollmentNavigationService: EnrollmentNavigationService
  ) {}

  getMegaNav() {
    return this.megaNav;
  }

  getCurrentlySelectedTab() {
    return this.currentTab;
  }

  getCurrentlySelectedSubtab() {
    return this.currentSubtab;
  }

  getCurrentlySelectedPageTitle() {
    return this.currentPageTitle;
  }

  getMobileHeader() {
    return this.mobileHeader;
  }

  updateGlobalNavigation(skipHardRefresh: boolean) {
    this.logger.debug('updateGlobalNavigation');
    return this.getGlobalNavigationUpdates(skipHardRefresh).then((navUpdates) => {
      this.logger.debug('updateGlobalNavigation', 'applying navUpdates');
      navUpdates();
      this.logger.debug('updateGlobalNavigation', 'applied navUpdates');
      if (this.pendingUpdateMobileHeaderAction) {
        this.logger.debug('updateGlobalNavigation', 'has pendingUpdateMobileHeaderAction, calling it');
        this.pendingUpdateMobileHeaderAction(this.megaNav);
      }
    });
  }

  private getGlobalNavigationUpdates(skipHardRefresh: boolean) {
    const navPromise = this.mbcContentAndData.getMegaNavPromise(!skipHardRefresh);
    return Promise.all([
      navPromise,
      this.getEnrollmentIfAvailable(),
      this.updateHealthBenefitsNavigationIfAvailable(),
      this.calculatePensionPaymentsDataIfAvailable(),
      this.getDbDocumentPlanList(),
      this.getHealthDocumentList()
    ]).then((results) => {
      return () => {
        this.logger.debug('navUpdates', this.megaNav, results[0]);
        this.megaNav = results[0];
        this.updateDocUpload();
        this.updateHeaderFooter();
        this.copyExtraPortalSections();
        this.updateDbMenuItems();
        this.updateCurrentPortalSection();
      };
    });
  }

  private updateDocUpload() {
    const navigation = this.megaNav.Data.Navigation;
    const docUploadListItem = this.deepSearch(navigation.MegaNav, 'DOCUPLOAD', 'Id', 'Items');
    if (!docUploadListItem || !docUploadListItem.Items || docUploadListItem.Items.length === 0) {
      return;
    }
    this.updateRolDocUploadLink(docUploadListItem);
    this.updateHealthDocUploadLink(docUploadListItem);
  }

  private updateRolDocUploadLink(docUploadListItem: any) {
    const linkId = 'ROL_UPLOAD';
    const pensionRequiredFiles = this.getDbDocumentPlanList();
    let hideRol = true;
    if (pensionRequiredFiles && pensionRequiredFiles.Data && pensionRequiredFiles.Data.Plans) {
      const dbDocumentsForUploadExist = pensionRequiredFiles.Data.Plans.some((plan: any) => {
        const isWetFlow = this.onlineCommencementService.getWetFLowStatus(plan.WetFlowConfiguration, false);
        return !isWetFlow && plan.RequiredDocuments.some((item: any) => item.Status === 0 || item.Status === 4);
      });
      hideRol = !dbDocumentsForUploadExist;
    }
    if (hideRol) {
      const rolUpload = docUploadListItem.Items.find((item: any) => item.Id === linkId);
      if (rolUpload) {
        rolUpload.Ignore = true;
      }
      const tab = this.megaNav.Data.DocuploadNavigation.find((item: any) => item.Key.toUpperCase() === linkId);
      if (tab) {
        tab.Hidden = true;
      }
    }
  }

  private updateHealthDocUploadLink(docUploadListItem: any) {
    const linkId = 'DEP_VERIFY';
    const requiredFiles = this.getHealthDocumentList();
    let hide = true;
    if (requiredFiles) {
      const hbDocumentsForUploadExist = requiredFiles.some((documents: any) => documents.Dependents && documents.Dependents.length > 0);
      hide = !hbDocumentsForUploadExist;
    }
    if (hide) {
      const rolUpload = docUploadListItem.Items.find((item: any) => item.Id === linkId);
      if (rolUpload) {
        rolUpload.Ignore = true;
      }
      const tab = this.megaNav.Data.DocuploadNavigation.find((item: any) => item.Key.toUpperCase() === linkId);
      if (tab) {
        tab.Hidden = true;
      }
    }
  }

  private updateHeaderFooter() {
    this.logger.debug('updateHeaderFooter', 'before', this.megaNav.Header, this.megaNav.Footer);
    const navigation = this.megaNav.Data.Navigation;
    this.megaNav.Header = this.groupBy(navigation.MegaNav.Items, 'ColumnOrder');
    this.megaNav.Footer = this.groupBy(navigation.Footer.Items, 'ColumnOrder');
    this.logger.debug('updateHeaderFooter', 'after', this.megaNav.Header, this.megaNav.Footer);
    this.notifyMeganavUpdated();
  }

  private copyExtraPortalSections() {
    this.logger.debug('copyExtraPortalSections', 'before', this.currentPortalSection['my-account'], this.currentPortalSection['voluntary-benefits']);
    this.currentPortalSection['my-account'] = this.megaNav.Data.AccountNavigation;
    this.currentPortalSection['voluntary-benefits'] = this.megaNav.Data.VbNavigation;
    this.currentPortalSection['documents-upload'] = this.megaNav.Data.DocuploadNavigation;
    this.logger.debug('copyExtraPortalSections', 'after', this.currentPortalSection['my-account'], this.currentPortalSection['voluntary-benefits']);
  }

  private updateDbMenuItems() {
    const navigation = this.megaNav.Data.Navigation;
    const dbPlanLinkListItem = this.deepSearch(navigation.MegaNav, 'DBPLANLINKLIST', 'Id', 'Items');
    const dbPaymentsLinkListItem = this.deepSearch(navigation.MegaNav, 'DBPAYLINKLIST', 'Id', 'Items');
    if (dbPlanLinkListItem) {
      const dbPlanLinkList = this.megaNav.Content[dbPlanLinkListItem.ContentAlias];
      const dbPlanOverviewItem = this.currentPortalSection['db-plan'].find((item: any) => item.Key === 'overview');
      dbPlanOverviewItem.Name = dbPlanLinkList[0].Text;
      const estimateItem = this.currentPortalSection['db-plan'].find((item: any) => item.Key === 'estimates');
      estimateItem.Name = dbPlanLinkList[1].Text;
      const myDataItem = this.currentPortalSection['db-plan'].find((item: any) => item.Key === 'my-data');
      myDataItem.Name = dbPlanLinkList[2].Text;
      if (dbPlanLinkList.length > 3) {
        const myElection = this.currentPortalSection['db-plan'].find((item: any) => item.Key === 'my-election');
        myElection.Name = dbPlanLinkList[3].Text;
      }
    }
    if (dbPaymentsLinkListItem) {
      const dbPaymentsLinkList = this.megaNav.Content[dbPaymentsLinkListItem.ContentAlias];
      const paymentsOverviewItem = this.currentPortalSection['pension-payments'].find((item: any) => item.Key === 'overview');
      paymentsOverviewItem.Name = dbPaymentsLinkList[0].Text;
      const paymentTaxesSuppressed = this.calculatePensionPaymentsDataIfAvailable().paymentTaxesSuppressed;
      if (!paymentTaxesSuppressed) {
        const taxWithholding = this.currentPortalSection['pension-payments'].find((item: any) => item.Key === 'tax-withholding');
        taxWithholding.Name = dbPaymentsLinkList[1].Text;
      }
      const paymentMethodSuppressed = this.calculatePensionPaymentsDataIfAvailable().paymentMethodSuppressed;
      if (!paymentMethodSuppressed) {
        const paymentMethodItem = this.currentPortalSection['pension-payments'].find((item: any) => item.Key === 'payment-method');
        paymentMethodItem.Name = paymentTaxesSuppressed ? dbPaymentsLinkList[1].Text : dbPaymentsLinkList[2].Text;
      }
    }
  }

  private updateCurrentPortalSection() {
    this.logger.debug('updateCurrentPortalSection', this.currentPortalSection);
    if (!this.currentPortalSection) {
      this.logger.debug('updateCurrentPortalSection', 'skipping');
      return;
    }
    this.currentPortalSection = this.currentPortalSection;
    this.logger.debug('updateCurrentPortalSection', 'after', this.currentPortalSection);
  }

  private getEnrollmentIfAvailable() {
    return this.domainAvailability.get().then((availability) => {
      if (!availability.HbAvailable) {
        return Promise.resolve();
      }
      return this.mbcContentAndData.getEnrollment();
    });
  }

  private updateHealthBenefitsNavigationIfAvailable() {
    this.logger.debug('updateHealthBenefitsNavigationIfAvailable');
    return Promise.all([
      this.getEnrollmentIfAvailable(),
      this.mbcContentAndData.getMegaNavPromise()
    ]).then((results) => {
      const enrollment = results[0];
      const navData = results[1];
      if (!enrollment) {
        return;
      }
      if (!this.employeeCoverageService.isCurrentCoverageExists(enrollment.Employee) && this.employeeCoverageService.isFutureCoverageExists(enrollment.Employee)) {
        this.logger.debug('updateHealthBenefitsNavigationIfAvailable', 'HEALTHANDBENEFITS', 'before', navData.Data.Navigation.MegaNav.Items);
        navData.Data.Navigation.MegaNav.Items.filter((item: any) => item.Id === 'HEALTHANDBENEFITS').forEach((item: any) => {
          item.Items = item.Items.filter((subItem: any) => subItem.Id === 'HEALTHSUMMARY');
        });
        this.logger.debug('updateHealthBenefitsNavigationIfAvailable', 'HEALTHANDBENEFITS', 'after', navData.Data.Navigation.MegaNav.Items);
      }
    });
  }

  private calculatePensionPaymentsDataIfAvailable() {
    return this.domainAvailability.get().then((availability) => {
      if (!availability.DbAvailable) {
        return Promise.resolve({
          paymentTaxesSuppressed: false,
          paymentMethodSuppressed: false
        });
      }
      return this.pensionPayments.getPensionPayments().then((pensionPaymentsResponse) => {
        return {
          paymentTaxesSuppressed: this.paymentTaxesSuppressed(pensionPaymentsResponse),
          paymentMethodSuppressed: this.paymentMethodSuppressed(pensionPaymentsResponse)
        };
      });
    });
  }

  private paymentTaxesSuppressed(pensionPaymentsResponse: any) {
    const taxSuppressConfig = pensionPaymentsResponse.Configuration['DB.Tax.StateTaxSuppressConfiguration'];
    if (!taxSuppressConfig) {
      return false;
    }
    return taxSuppressConfig.TAXES_CONFIG === this.dbTaxViewValue.Suppress;
  }

  private paymentMethodSuppressed(pensionPaymentsResponse: any) {
    return pensionPaymentsResponse.commonConfig.paymentMethod.suppressed;
  }

  private getDbDocumentPlanList() {
    return this.domainAvailability.get().then((availability) => {
      if (!availability.DbAvailable) {
        return null;
      }
      return this.dbContextService.getPromise().then(() => {
        if (!this.dbContextService.IsOnlineCommencement() || this.dbContextService.IsInROLProxy()) {
          return null;
        }
        return this.onlineCommencementService.getRequiredDocumentsData(true);
      });
    });
  }

  private getHealthDocumentList() {
    return this.domainAvailability.get().then((response) => {
      if (!response.HbAvailable) {
        return null;
      }
      return this.mbcContentAndData.getEnrollment().then((employeeData) => {
        return this.getCartDataIfAvailable(employeeData).then((cartData) => {
          return this.requiredDependentVerificationDocuments.getRequiredDependentVerificationDocuments(employeeData, cartData);
        });
      });
    });
  }

  private getCartDataIfAvailable(employeeData: any) {
    const pendingEmployee = employeeData.Data.PendingEmployee;
    if (!pendingEmployee) {
      return Promise.resolve(null);
    }
    const lifeEvent = pendingEmployee.LifeEvents[0];
    return this.shoppingCartService.get(lifeEvent.LifeEventID, lifeEvent.LifeEventSequenceNumber, lifeEvent.LifeEventDate);
  }

  private deepSearch(element: any, matchingValue: string, matchingFieldName: string, childFieldName: string) {
    if (element[matchingFieldName] && element[matchingFieldName].toLowerCase() === matchingValue.toLowerCase()) {
      return element;
    } else if (element[childFieldName]) {
      let result = null;
      element[childFieldName].forEach((item: any) => {
        const innerResult = this.deepSearch(item, matchingValue, matchingFieldName, childFieldName);
        if (innerResult) {
          result = innerResult;
        }
      });
      return result;
    }
    return null;
  }

  private groupBy(array: any[], key: string) {
    return array.reduce((result, currentValue) => {
      (result[currentValue[key]] = result[currentValue[key]] || []).push(currentValue);
      return result;
    }, {});
  }

  private notifyMeganavUpdated() {
    this.logger.debug('notifyMeganavUpdated');
    // Implement event broadcasting logic here
  }
}
