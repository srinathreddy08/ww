import { Injectable } from '@angular/core';

interface EmployeeData {
  Employee: Record<string, any>;
}

interface Election {
  BenefitID: string;
  PlanID: string;
}

@Injectable({
  providedIn: 'root'
})
export class PcpDomainHelpersService {
  forData(employeeData: EmployeeData) {
    const accessor = (employeeFieldName: string) => {
      const employee = () => employeeData.Employee[employeeFieldName];

      const lifeEvent = () => {
        const e = employee();
        return e && e.LifeEvents[0];
      };

      const benefit = (election: Election) => {
        const le = lifeEvent();
        return le && le.EligibleBenefitsMap[election.BenefitID];
      };

      const plan = (election: Election) => {
        const b = benefit(election);
        return b && b.EligiblePlansMap[election.PlanID];
      };

      const electedPlan = (election: Election) => {
        const b = benefit(election);
        return b && b.ElectedPlan;
      };

      return {
        employee,
        lifeEvent,
        benefit,
        plan,
        electedPlan
      };
    };

    return {
      current: accessor('CurrentCoveragesEmployee'),
      pending: accessor('PendingEmployee')
    };
  }
}
