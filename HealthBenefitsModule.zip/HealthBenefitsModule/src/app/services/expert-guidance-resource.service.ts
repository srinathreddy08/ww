import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ExpertGuidanceResourceService {
  private stepDataCache = this.createEmptyCache();

  constructor(private http: HttpClient) {}

  getStepList(): Observable<any> {
    if (!this.stepDataCache.stepsStatuses) {
      this.setStepsStatuses(this.http.get('/api/guidedshopping/getStepsStatuses'));
    }
    return this.stepDataCache.stepsStatuses;
  }

  getStep(stepUrl: string): Observable<any> {
    if (!this.stepDataCache.stepsData[stepUrl]) {
      this.stepDataCache.stepsData[stepUrl] = this.http.get(`/api/guidedshopping/getStepData?stepUrl=${stepUrl}`)
        .pipe(map(this.mapStepData));
    }
    return this.stepDataCache.stepsData[stepUrl];
  }

  saveAnswers(stepUrl: string, answers: any): Observable<any> {
    Object.keys(answers).forEach(key => {
      this.stepDataCache.answersSavedLocally[key] = answers[key];
    });

    const mappedAnswers = Object.keys(answers).map(key => this.mapAnswer(answers[key]));
    return this.setStepsStatuses(this.http.post('/api/guidedshopping/saveAnswers', mappedAnswers));
  }

  private mapStepData(step: any): any {
    return {
      url: step.Url,
      questions: step.Questions.map(this.mapQuestion)
    };
  }

  private mapQuestion(question: any): any {
    return {
      config: {
        control: question.Control,
        title: question.Title,
        subtitle: question.Subtitle,
        answerType: question.AnswerType,
        answers: question.AnswerOptions.map((answer: any) => ({
          id: String(answer.ValueId),
          title: answer.Title,
          hint: answer.Hint,
          icon: answer.Icon,
          isNoneAnswer: answer.IsNoneAnswer
        }))
      },
      savedAnswer: this.getSavedAnswer(question)
    };
  }

  private getSavedAnswer(question: any): any {
    const answerSavedLocally = this.stepDataCache.answersSavedLocally[question.AnswerType];
    if (typeof answerSavedLocally === 'object') {
      return answerSavedLocally;
    }
    return question.UserProvidedAnswer === null ? null : {
      Text: question.UserProvidedAnswer.Value,
      SecondText: question.UserProvidedAnswer.SubAnswer
    };
  }

  private mapAnswer(answer: any): any {
    return {
      AnswerType: answer.Type,
      Value: answer.Text,
      SubAnswer: answer.SecondText
    };
  }

  private setStepsStatuses(query: Observable<any>): Observable<any> {
    this.stepDataCache.stepsStatuses = query.pipe(
      map(stepList => stepList.map((stepInfo: any) => ({
        url: stepInfo.Url,
        isFilled: stepInfo.IsFilled
      })))
    );
    return this.stepDataCache.stepsStatuses;
  }

  private createEmptyCache(): any {
    return {
      stepsStatuses: null,
      stepsData: {},
      answersSavedLocally: {}
    };
  }

  // Additional methods would be similarly refactored and implemented here...
}
