import { Injectable } from '@angular/core';
import { BenefitsService } from './benefits.service';
import _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class AggregateElectionsService {
  constructor(private benefitsService: BenefitsService) {}

  aggregate(electionData: any[], hideNoCovVb: boolean) {
    const employeeCostType = 'Employee';
    const employerCostType = 'Employer';
    const payPeriodCostType = 'PayPeriod';
    const annualCostType = 'Annual';

    const allBenefitsByGroups = this.getAllBenefitsByGroups(electionData, hideNoCovVb);

    return {
      displayed: _(allBenefitsByGroups)
        .mapValues(this.filterDisplayedElections.bind(this))
        .value(),
      allBenefitsByGroups: allBenefitsByGroups,
      totals: {
        perPayPeriod: this.getTotals(payPeriodCostType, electionData),
        annual: this.getTotals(annualCostType, electionData)
      }
    };
  }

  private getAllBenefitsByGroups(electionData: any[], hideNoCovVb: boolean) {
    return {
      charges: this.getCharges(electionData),
      credits: this.getCredits(electionData),
      employerCostElections: this.getEmployerCostElections(electionData),
      voluntaryBenefits: this.getVoluntaryBenefits(electionData, hideNoCovVb),
      paidExceptVoluntaryElections: this.getPaidExceptVoluntaryElections(electionData, hideNoCovVb)
    };
  }

  private getCreditBenefitFilter() {
    return this.getCategoryFilter('CREDIT');
  }

  private getChargeBenefitFilter() {
    return this.getCategoryFilter('SURCHARGE');
  }

  private getCredits(electionData: any[]) {
    return _(this.getNonzeroElections(electionData))
      .filter(this.getCreditBenefitFilter())
      .value();
  }

  private getCharges(electionData: any[]) {
    return _(this.getNonzeroElections(electionData))
      .filter(this.getChargeBenefitFilter())
      .value();
  }

  private getNonzeroElections(electionData: any[]) {
    return _(electionData)
      .filter(election => {
        return election.ElectedOption &&
          this.getCost(election, 'Employee', 'Annual') &&
          this.getCost(election, 'Employee', 'PayPeriod');
      })
      .value();
  }

  private getEmployerCostElections(electionData: any[]) {
    return _(electionData)
      .reject(this.getCreditBenefitFilter())
      .reject(this.getChargeBenefitFilter())
      .value();
  }

  private getVoluntaryBenefitsWithElectedPlan(electionData: any[]) {
    return _(this.getEmployerCostElections(electionData))
      .filter(this.isVoluntaryElection)
      .filter(election => election.ElectedPlan)
      .value();
  }

  private getPaidExceptVoluntaryElections(electionData: any[], hideNoCovVb: boolean) {
    return _(this.getEmployerCostElections(electionData))
      .filter(election => {
        if (!this.isVoluntaryElection(election)) {
          return true;
        }

        if (hideNoCovVb) {
          return false;
        } else {
          return !(election.ElectedPlan && election.ElectedPlan.IsNoCovPlan);
        }
      })
      .value();
  }

  private getVoluntaryBenefits(electionData: any[], hideNoCovVb: boolean) {
    return _(this.getVoluntaryBenefitsWithElectedPlan(electionData))
      .filter(election => {
        return hideNoCovVb ?
          !election.ElectedPlan.IsNoCovPlan :
          election.ElectedPlan.IsNoCovPlan && election.IsInterested;
      })
      .value();
  }

  private getPaidElections(electionData: any[]) {
    return _(this.getPaidExceptVoluntaryElections(electionData, false))
      .union(this.getVoluntaryBenefits(electionData, false))
      .value();
  }

  private getTaxSavingsElections(electionData: any[]) {
    return _(this.getPaidExceptVoluntaryElections(electionData, false))
      .filter(this.isTaxSavingAccount)
      .value();
  }

  private isTaxSavingAccount(election: any) {
    return election.ElectedBenefit.BenefitCategory === 'SPENDING';
  }

  private getBeforeTaxElections(electionData: any[]) {
    return _(this.getPaidElections(electionData))
      .filter(this.getTaxFilter(true))
      .value();
  }

  private getAfterTaxElections(electionData: any[]) {
    return _(this.getPaidElections(electionData))
      .filter(this.getTaxFilter(false))
      .value();
  }

  private getMiscTaxElections(electionData: any[]) {
    return _(this.getPaidElections(electionData))
      .filter(this.getTaxFilter(null))
      .value();
  }

  private getYourCostsElections(electionData: any[]) {
    return _(this.getPaidElections(electionData))
      .union(this.getCredits(electionData), this.getCharges(electionData))
      .value();
  }

  private getCost(election: any, personCostType: string, periodCostType: string) {
    return election.ElectedOption[personCostType + periodCostType + 'Cost'];
  }

  private getCategoryFilter(category: string) {
    return (election: any) => election.ElectedBenefit.BenefitCategory === category;
  }

  private isVoluntaryElection(election: any) {
    return election.ElectedBenefit.BenefitCategory.indexOf('VB_') === 0;
  }

  private getTaxFilter(value: boolean | null) {
    return (election: any) => election.ElectedOption.IsPreTax === value;
  }

  private getTotals(periodCostType: string, electionData: any[]) {
    return {
      beforeTax: this.getTotal('Employee', this.getBeforeTaxElections(electionData), periodCostType),
      afterTax: this.getTotal('Employee', this.getAfterTaxElections(electionData), periodCostType),
      misc: this.getTotal('Employee', this.getMiscTaxElections(electionData), periodCostType),
      paid: this.getTotal('Employee', this.getPaidElections(electionData), periodCostType),
      your: this.getTotal('Employee', this.getYourCostsElections(electionData), periodCostType),
      taxSavings: this.getTotal('Employee', this.getTaxSavingsElections(electionData), periodCostType),
      employer: this.getTotal('Employer', this.getEmployerCostElections(electionData), periodCostType)
    };
  }

  private getTotal(personCostType: string, elections: any[], periodCostType: string) {
    return _(elections)
      .reduce((total, election) => total + this.getCost(election, personCostType, periodCostType), 0);
  }

  private filterDisplayedElections(elections: any[]) {
    return _(elections)
      .reject(data => this.benefitsService.isBenefitHiddenFromUser(data.ElectedBenefit))
      .value();
  }
}
