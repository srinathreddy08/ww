import { TestBed } from '@angular/core/testing';
import { EmployeeCoverageService } from './employee-coverage.service';

describe('EmployeeCoverageService', () => {
  let service: EmployeeCoverageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeeCoverageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // Additional tests can be added here to test the service methods
});
