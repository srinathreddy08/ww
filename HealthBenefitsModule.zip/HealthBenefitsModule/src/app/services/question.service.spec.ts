import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { QuestionService } from './question.service';
import { MbcContentAndDataService } from './mbc-content-and-data.service';
import { DependentService } from './dependent.service';
import { ContentAliasService } from './content-alias.service';

class MockMbcContentAndDataService {}
class MockDependentService {
  getSpouseRelationTypes() { return ['spouse']; }
}
class MockContentAliasService {
  forData(employeeData: any) {
    return {
      getEvaluationPointValue: (contentName: string) => ({ Key: contentName }),
      getConfigurationValue: (contentControlName: string) => ({ DISPLAY_ENABLED: 'True', ISEDITABLE: 'True' })
    };
  }
}

describe('QuestionService', () => {
  let service: QuestionService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        QuestionService,
        { provide: MbcContentAndDataService, useClass: MockMbcContentAndDataService },
        { provide: DependentService, useClass: MockDependentService },
        { provide: ContentAliasService, useClass: MockContentAliasService }
      ]
    });
    service = TestBed.inject(QuestionService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should save answers', () => {
    const answers = { question1: { Value: 'Yes', SubValue: '' } };
    const effectiveDate = '2023-01-01';
    service.save(answers, effectiveDate).subscribe();
    const req = httpMock.expectOne('/api/questionnaire/save');
    expect(req.request.method).toBe('POST');
    req.flush({});
  });

  // Additional tests can be added here to test the service methods
});
