import { TestBed } from '@angular/core/testing';
import { SupplementalTabService } from './supplemental-tab.service';
import { ContentAliasService } from './content-alias.service';

class MockContentAliasService {
  forData(enrollment: any) {
    return {
      getConfigurationValue: (key: string) => 'Y'
    };
  }
}

describe('SupplementalTabService', () => {
  let service: SupplementalTabService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        SupplementalTabService,
        { provide: ContentAliasService, useClass: MockContentAliasService }
      ]
    });
    service = TestBed.inject(SupplementalTabService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should determine tab visibility correctly', () => {
    const enrollment = {
      Data: {
        CurrentCoveragesEmployee: {
          LifeEvents: [{
            EligibleBenefits: [{ BenefitCategory: 'SUPPLEMENTAL' }]
          }]
        }
      }
    };
    const result = service.forEnrollment(enrollment);
    expect(result.showSeparateTab).toBe(true);
    expect(result.showHealthInsuranceSubTab).toBe(false);
  });
});
