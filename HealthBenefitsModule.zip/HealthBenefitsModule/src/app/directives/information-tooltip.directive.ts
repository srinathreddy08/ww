import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';
import { Popper } from '@popperjs/core';

@Directive({
  selector: '[appInformationTooltip]'
})
export class InformationTooltipDirective {
  private closeEvent = 'informationTooltip.closeHelp';

  constructor(private el: ElementRef, private renderer: Renderer2) {
    this.initializePopovers();
  }

  @HostListener('click', ['$event'])
  onClick(event: MouseEvent) {
    event.stopPropagation();
    const tooltip = this.el.nativeElement.querySelector('div');
    if (tooltip) {
      const isVisible = tooltip.style.display === 'block';
      this.renderer.setStyle(tooltip, 'display', isVisible ? 'none' : 'block');
      if (!isVisible) {
        document.dispatchEvent(new CustomEvent(this.closeEvent));
      }
    }
  }

  @HostListener('document:click')
  onDocumentClick() {
    const tooltip = this.el.nativeElement.querySelector('div');
    if (tooltip) {
      this.renderer.setStyle(tooltip, 'display', 'none');
    }
  }

  private initializePopovers() {
    const popovers = document.querySelectorAll('.information-tooltip');
    popovers.forEach(popover => {
      const button = popover.querySelector('.fa-info-circle');
      const tooltip = popover.querySelector('.information-tooltip-content');
      if (button && tooltip) {
        Popper.createPopper(button, tooltip, {
          placement: 'top',
          modifiers: [{
            name: 'offset',
            options: { offset: [0, 8] }
          }]
        });
      }
    });
  }
}
