import { InformationTooltipDirective } from './information-tooltip.directive';
import { ElementRef, Renderer2 } from '@angular/core';

describe('InformationTooltipDirective', () => {
  let directive: InformationTooltipDirective;
  let elementRef: ElementRef;
  let renderer: Renderer2;

  beforeEach(() => {
    elementRef = new ElementRef(document.createElement('div'));
    renderer = jasmine.createSpyObj('Renderer2', ['setStyle']);
    directive = new InformationTooltipDirective(elementRef, renderer);
  });

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });

  it('should toggle tooltip visibility on click', () => {
    const tooltip = document.createElement('div');
    elementRef.nativeElement.appendChild(tooltip);
    directive.onClick(new MouseEvent('click'));
    expect(renderer.setStyle).toHaveBeenCalledWith(tooltip, 'display', 'block');
    directive.onClick(new MouseEvent('click'));
    expect(renderer.setStyle).toHaveBeenCalledWith(tooltip, 'display', 'none');
  });

  it('should hide tooltip on document click', () => {
    const tooltip = document.createElement('div');
    elementRef.nativeElement.appendChild(tooltip);
    directive.onDocumentClick();
    expect(renderer.setStyle).toHaveBeenCalledWith(tooltip, 'display', 'none');
  });
});
