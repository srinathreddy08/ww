export interface DisplayedComparisonCategories {
  id: string;
  name: string;
}
