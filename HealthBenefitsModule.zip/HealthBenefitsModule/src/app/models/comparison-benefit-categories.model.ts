export type ComparisonBenefitCategories = string[];
