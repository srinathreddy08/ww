import { InjectionToken } from '@angular/core';

export const TIME_OFFSET_TOKEN = new InjectionToken<number>('timeOffset');
