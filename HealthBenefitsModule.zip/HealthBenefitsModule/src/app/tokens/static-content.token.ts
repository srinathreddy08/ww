import { InjectionToken } from '@angular/core';
import { IStaticContent } from '../common-dto/static';

export const STATIC_CONTENT_TOKEN = new InjectionToken<IStaticContent>('staticContent');
