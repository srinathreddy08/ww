import { Pipe, PipeTransform } from '@angular/core';
import { CurrencyPipe, DatePipe } from '@angular/common';

@Pipe({
  name: 'format'
})
export class FormatPipe implements PipeTransform {
  constructor(private currencyPipe: CurrencyPipe, private datePipe: DatePipe) {}

  transform(value: any, dataSources: any, replaceWhenEmpty: boolean): any {
    if (typeof value !== 'string') {
      return value;
    }

    return dataSources.reduce((currentValue: string, dataSource: any) => {
      const executeFormatter = this.getFormatter(currentValue, dataSource, replaceWhenEmpty);
      return executeFormatter();
    }, value);
  }

  private getFormatter(value: string, dataSource: any, replaceWhenEmpty: boolean) {
    if (!Array.isArray(dataSource) && typeof dataSource !== 'object') {
      dataSource = [dataSource];
    }

    return () => {
      if (Array.isArray(dataSource)) {
        return this.replaceArrayElementTokens(value, dataSource);
      }

      if (replaceWhenEmpty) {
        try {
          return this.replaceObjectElementTokens(value, dataSource);
        } catch (ex) {
          console.error(ex);
          return null;
        }
      } else {
        return this.replaceObjectElementTokens(value, dataSource);
      }
    };
  }

  private replaceArrayElementTokens(value: string, dataSource: any[]): string {
    return value.replace(/\$([0-9]+)/g, (matchedString, key) => {
      const index = parseInt(key, 10);
      return (index >= 0 && index < dataSource.length) ? dataSource[index] : matchedString;
    });
  }

  private replaceObjectElementTokens(value: string, dataSource: any): string {
    return value.replace(/\[\$([^$]+)\$\]/g, (matchedString, key) => {
      const segments = key.split(':');
      const format = this.extractFormat(segments);
      let currentData;

      if (replaceWhenEmpty) {
        currentData = this.executeExpression(segments, dataSource);

        if (typeof currentData === 'undefined' || currentData === null) {
          console.error(`"${matchedString}" was evaluated to ${currentData}`);
          throw new Error(`"${matchedString}" was evaluated to ${currentData}`);
        }

        return this.applyFormat(currentData, format);
      } else {
        try {
          currentData = this.executeExpression(segments, dataSource);

          if (!currentData) {
            return matchedString;
          }
          return this.applyFormat(currentData, format) || matchedString;
        } catch (e) {
          return matchedString;
        }
      }
    });
  }

  private applyFormat(currentData: any, format: string | null): any {
    if (!format) {
      return currentData;
    }

    switch (format) {
      case 'currency':
        return this.currencyPipe.transform(currentData, '$');
      case 'date':
        return this.datePipe.transform(new Date(Date.parse(currentData)), 'MMMM dd, yyyy');
      default:
        return currentData;
    }
  }

  private executeExpression(segments: string[], dataSource: any): any {
    let result = dataSource;
    let i = 0;

    while (result && i < segments.length) {
      const currentSegment = segments[i];
      const fieldValue = result[currentSegment];

      if (fieldValue === 0 || fieldValue === null) {
        return '0';
      }

      result = fieldValue || result[currentSegment];
      i++;
    }

    return result;
  }

  private extractFormat(segments: string[]): string | null {
    const lastSegment = segments[segments.length - 1];
    if (lastSegment.indexOf('format') === -1) {
      return null;
    }

    const result = lastSegment.split(' ')[1];
    segments.splice(-1, 1);
    return result;
  }
}
