import { FormatPipe } from './format.pipe';
import { CurrencyPipe, DatePipe } from '@angular/common';

describe('FormatPipe', () => {
  let pipe: FormatPipe;
  let currencyPipe: CurrencyPipe;
  let datePipe: DatePipe;

  beforeEach(() => {
    currencyPipe = new CurrencyPipe('en-US');
    datePipe = new DatePipe('en-US');
    pipe = new FormatPipe(currencyPipe, datePipe);
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  // Add more tests to cover various cases
});
