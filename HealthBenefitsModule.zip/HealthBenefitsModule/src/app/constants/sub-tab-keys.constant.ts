export const SUB_TAB_KEYS = {
  SUMMARY: 'summary'
};
