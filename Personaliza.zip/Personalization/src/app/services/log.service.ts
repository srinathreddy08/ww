import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { LogSources } from '../config/log-sources.config';
import { mapValues, pickBy, keys, uniq } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class LogService {
  private devToolsLoggerName = 'MBCDevTools';
  private currentLogSources = this.createLogSources();
  private loggedItems: string[] = [];
  private loggers = mapValues(this.currentLogSources, (x, logSourceName) => this.createLogger(logSourceName));

  constructor(private cookieService: CookieService) {}

  clear(): void {
    this.loggedItems = [];
  }

  getLoggedItems(): any[] {
    return this.loggedItems.map(item => JSON.parse(item));
  }

  getLogSources(): any {
    return this.currentLogSources;
  }

  setLogSources(newLogSources: any): void {
    this.currentLogSources = newLogSources;
    const changedLogSourceNames = keys(pickBy(this.currentLogSources, logSource => logSource.isEnabledByDefault !== logSource.isEnabled));
    this.cookieService.set('debugLog', changedLogSourceNames.join(','));
  }

  getLogger(logSourceName: string): any {
    let logger = this.loggers[logSourceName];
    if (!logger) {
      this.loggers[this.devToolsLoggerName].warn(`Creating logger (enabled by default) for unknown log source ${logSourceName}. Known are [${LogSources.join(', ')}]. Register log source in logSources.js or fix the name.`);
      LogSources[logSourceName] = true;
      this.currentLogSources[logSourceName] = {
        name: logSourceName,
        isEnabledByDefault: true,
        isEnabled: true
      };
      logger = this.createLogger(logSourceName);
      this.loggers[logSourceName] = logger;
    }
    return logger;
  }

  private createLogSources(): any {
    const changedLogSourceNamesAsObject = uniq((this.cookieService.get('debugLog') || '').split(',').map(logSourceName => logSourceName.trim()).filter(Boolean)).reduce((acc, logSourceName) => {
      acc[logSourceName] = true;
      return acc;
    }, {});

    return mapValues(LogSources, (isEnabledByDefault, logSourceName) => ({
      name: logSourceName,
      isEnabledByDefault,
      isEnabled: logSourceName in changedLogSourceNamesAsObject ? !isEnabledByDefault : isEnabledByDefault
    }));
  }

  private createLogger(logSourceName: string): any {
    const commonArgs = [logSourceName];
    return {
      log: this.createLoggerFunction('log'),
      info: this.createLoggerFunction('info'),
      warn: this.createLoggerFunction('warn'),
      error: this.createLoggerFunction('error'),
      debug: this.createLoggerFunction('debug')
    };

    function createLoggerFunction(level: string): (...args: any[]) => void {
      return (...args: any[]) => {
        if (!this.isLogEnabled(logSourceName)) {
          return;
        }
        console[level](...commonArgs, ...args);
        this.loggedItems.push(JSON.stringify({
          source: logSourceName,
          level,
          time: new Date(),
          details: args
        }));
      };
    }
  }

  private isLogEnabled(logSourceName: string): boolean {
    return this.currentLogSources[logSourceName]?.isEnabled;
  }
}
