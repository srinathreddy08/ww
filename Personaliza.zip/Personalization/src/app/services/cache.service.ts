import { Injectable } from '@angular/core';

export interface ICache {
  info: () => any;
  put: (key: string, value: any) => void;
  get: (key: string) => any;
  remove: (key: string) => void;
  removeAll: () => void;
  destroy: () => void;
}

@Injectable({
  providedIn: 'root'
})
export class CacheService implements ICache {
  private cache: Map<string, any> = new Map();

  info() {
    return {
      size: this.cache.size
    };
  }

  put(key: string, value: any): void {
    this.cache.set(key, value);
  }

  get(key: string): any {
    return this.cache.get(key);
  }

  remove(key: string): void {
    this.cache.delete(key);
  }

  removeAll(): void {
    this.cache.clear();
  }

  destroy(): void {
    this.cache.clear();
  }
}
