import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransformOpenEnrollmentService {
  transform(enrollment: any): void {
    // Implement transformation logic here
    // Example: Override carrier details
    const lifeEvents = enrollment?.Data?.CurrentCoveragesEmployee?.LifeEvents || [];
    lifeEvents.forEach(lifeEvent => {
      const benefitsMap = lifeEvent.EligibleBenefitsMap || {};
      Object.keys(benefitsMap).forEach(benefitKey => {
        const benefit = benefitsMap[benefitKey];
        const plansMap = benefit.EligiblePlansMap || {};
        Object.keys(plansMap).forEach(planKey => {
          const plan = plansMap[planKey];
          if (plan.Carrier) {
            plan.Carrier.CarrierContent.LongName = 'Overridden Long Name';
            plan.Carrier.CarrierContent.ShortName = 'Overridden Short Name';
            plan.Carrier.CarrierContent.CarrierLogo.LogoSrc = '';
          }
        });
      });
    });
  }
}
