import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { FEATURE_DEFAULTS } from '../config/feature-defaults.config';
import { mapValues, fromPairs, pickBy, keys } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class FeatureTogglesService {
  private featureOverridesCookieName = 'features';

  constructor(private cookieService: CookieService) {}

  getFeatures(): Record<string, boolean> {
    return { ...this.getFeatureOverrides(), ...FEATURE_DEFAULTS };
  }

  private getFeatureOverrides(): Record<string, boolean> {
    const featureOverridesString = this.cookieService.get(this.featureOverridesCookieName);

    if (!featureOverridesString) {
      return {};
    }

    return mapValues(fromPairs(featureOverridesString.split(',').map(pair => pair.split(':'))), value => value === 'true');
  }

  setFeatureOverrides(desiredState: Record<string, boolean>): void {
    const overrides = keys(pickBy(FEATURE_DEFAULTS, (defaultValue, featureName) => desiredState[featureName] !== undefined && desiredState[featureName] !== defaultValue))
      .map(featureName => `${featureName}:${desiredState[featureName]}`);

    if (overrides.length > 0) {
      this.cookieService.set(this.featureOverridesCookieName, overrides.join(','), undefined, '/');
    } else {
      this.cookieService.delete(this.featureOverridesCookieName, '/');
    }
  }

  clearFeatureOverrides(): void {
    this.cookieService.delete(this.featureOverridesCookieName, '/');
  }

  getOverridenFeatures(): string[] {
    return keys(pickBy(FEATURE_DEFAULTS, (defaultValue, featureName) => this.getFeatureOverrides()[featureName] !== undefined && this.getFeatureOverrides()[featureName] !== defaultValue));
  }
}
