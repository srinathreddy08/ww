import { Injectable } from '@angular/core';
import { FormatPipe } from '../pipes/format.pipe';
import { compact } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class ProcessTokensInDataService {
  constructor(private formatPipe: FormatPipe) {}

  processTokensInData(data: any, dataSourcesForTokenReplacement: any[]): any {
    dataSourcesForTokenReplacement = compact(dataSourcesForTokenReplacement);

    if (data && data.Content && dataSourcesForTokenReplacement.length > 0) {
      this.applyFormatFilter(data.Content, dataSourcesForTokenReplacement);
    }

    return data;
  }

  private applyFormatFilter(value: any, dataSourcesForTokenReplacement: any[]): void {
    for (const key in value) {
      if (!value.hasOwnProperty(key)) {
        continue;
      }

      if (typeof value[key] === 'object') {
        this.applyFormatFilter(value[key], dataSourcesForTokenReplacement);
      }

      if (typeof value[key] === 'string') {
        value[key] = this.replaceTokens(value[key], dataSourcesForTokenReplacement);
      }
    }
  }

  private replaceTokens(value: string, dataSourcesForTokenReplacement: any[]): string {
    return this.formatPipe.transform(value, dataSourcesForTokenReplacement, false);
  }
}
