import { TestBed } from '@angular/core/testing';
import { TransformOpenEnrollmentService } from './transform-open-enrollment.service';

describe('TransformOpenEnrollmentService', () => {
  let service: TransformOpenEnrollmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TransformOpenEnrollmentService);
  });

  it('should transform enrollment data correctly', () => {
    const enrollment = {
      Data: {
        CurrentCoveragesEmployee: {
          LifeEvents: [
            {
              EligibleBenefitsMap: {
                MEDICAL: {
                  EligiblePlansMap: {
                    CDHH003E01: {
                      Carrier: {
                        CarrierContent: {
                          LongName: '',
                          ShortName: '',
                          CarrierLogo: { LogoSrc: '' }
                        }
                      }
                    }
                  }
                }
              }
            }
          ]
        }
      }
    };

    service.transform(enrollment);

    const medicalPlan = enrollment.Data.CurrentCoveragesEmployee.LifeEvents[0].EligibleBenefitsMap.MEDICAL.EligiblePlansMap.CDHH003E01;
    expect(medicalPlan.Carrier.CarrierContent.LongName).toBe('Overridden Long Name');
    expect(medicalPlan.Carrier.CarrierContent.ShortName).toBe('Overridden Short Name');
    expect(medicalPlan.Carrier.CarrierContent.CarrierLogo.LogoSrc).toBe('');
  });
});
