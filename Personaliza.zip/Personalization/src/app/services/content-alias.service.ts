import { Injectable } from '@angular/core';
import { LogService } from './log.service';
import { StringService } from './string.service';
import { FeatureTogglesService } from './feature-toggles.service';

@Injectable({
  providedIn: 'root'
})
export class ContentAliasService {
  constructor(
    private logger: LogService,
    private stringService: StringService,
    private featureToggles: FeatureTogglesService
  ) {}

  forData(data: any): ContentWrapper {
    return data instanceof ContentWrapper ? data : new ContentWrapper(data, this.logger, this.stringService, this.featureToggles);
  }
}

export class ContentWrapper {
  private data: any;
  private contentSource: any;

  constructor(
    private sourceData: any,
    private logger: LogService,
    private stringService: StringService,
    private featureToggles: FeatureTogglesService
  ) {
    this.data = sourceData?.Data;
    this.contentSource = sourceData;
    this.validateData(sourceData);
  }

  private validateData(data: any): void {
    if (!data) {
      this.logError('forData, data missing');
    }

    if (data) {
      if (!data.Data) {
        this.logError('forData, data.Data missing');
      }

      if (!data.Content) {
        this.logError('forData, data.Content missing');
      }

      if (!data.ContentAliases) {
        this.logError('forData, data.ContentAliases missing');
      }

      if (!data.Configuration) {
        this.logError('forData, data.Configuration missing');
      }
    }
  }

  getContentValue(aliasPath: string): any {
    if (aliasPath === undefined || aliasPath === null) {
      this.logError(`getContentValue(aliasPath), aliasPath is ${aliasPath}`);
    }

    if (aliasPath && this.contentSource && this.contentSource.Content && this.contentSource.Content[aliasPath] === undefined) {
      this.logError(`getContentValue(aliasPath), data.Content[aliasPath] === undefined, aliasPath=${aliasPath}`);
    }

    return aliasPath && this.contentSource?.Content[aliasPath];
  }

  private logError(errorMessage: string): void {
    if (this.featureToggles.contentAliasServiceErrorLogging) {
      this.logger.error('contentAliasService: ' + errorMessage);
    }
  }

  // Additional methods from the original ContentWrapper can be implemented here
}
