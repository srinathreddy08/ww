import { Injectable } from '@angular/core';
import { map, flattenDeep, some } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class StringService {
  convertArrayStringToArray(arrayString: string): string[] {
    const arrayItems = arrayString.replace('[', '').replace(']', '').split(',');
    return map(arrayItems, item => item.trim().replace(/"/g, '')).filter(item => item !== '');
  }

  convertSeveralArraysOfStringToArray(arrayOfStrings: string[]): string[] {
    return flattenDeep(map(arrayOfStrings, this.convertArrayStringToArray));
  }

  endsWith(subjectString: string, subString: string): boolean {
    if (!subjectString || !subString) {
      return false;
    }
    const position = subjectString.length - subString.length;
    return position >= 0 && subjectString.indexOf(subString, position) !== -1;
  }

  startsWith(subjectString: string, subString: string): boolean {
    if (!subjectString || !subString) {
      return false;
    }
    return subjectString.indexOf(subString) === 0;
  }

  containsHtmlTags(string: string): boolean {
    return string.includes('</') || string.includes('/>') || string.includes('&lt;');
  }

  wildCardMatch(pattern: string, source: string): boolean {
    if (!pattern) {
      return false;
    }
    try {
      const regexpPattern = pattern.replace('.', '\.').replace('*', '.*');
      return new RegExp('^' + regexpPattern + '$').test(source);
    } catch (exception) {
      console.debug('stringService.wildCardMatch: invalid pattern:', pattern);
      console.debug(exception);
      return false;
    }
  }

  wildCardMatchArray(patternArray: string[], source: string): boolean {
    return some(patternArray, pattern => this.wildCardMatch(pattern, source));
  }
}
