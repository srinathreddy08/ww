import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { StaticContentService } from './static-content.service';
import { MbcContentAndDataResourceFactory } from './mbc-content-and-data-resource.factory';
import { TransformOpenEnrollmentService } from './transform-open-enrollment.service';
import { ProcessTokensInDataService } from './process-tokens-in-data.service';
import { SupplementalTabService } from './supplemental-tab.service';
import { DomainAvailabilityService } from './domain-availability.service';
import { ContentAliasService } from './content-alias.service';

@Injectable({
  providedIn: 'root'
})
export class MbcContentAndDataService {
  private contentAndDataResource = this.mbcContentAndDataResourceFactory.create();
  private contentAndDataResourceForConfirmationFlow: any = null;
  private mbcContentAndDataConfirmationFlowCacheKey = 'mbcContentAndDataConfirmationFlowCache';

  constructor(
    private staticContentService: StaticContentService,
    private mbcContentAndDataResourceFactory: MbcContentAndDataResourceFactory,
    private transformOpenEnrollmentService: TransformOpenEnrollmentService,
    private processTokensInDataService: ProcessTokensInDataService,
    private supplementalTabService: SupplementalTabService,
    private domainAvailabilityService: DomainAvailabilityService,
    private contentAliasService: ContentAliasService
  ) {}

  getData(sectionKey: string, transform?: Function, hardRefresh?: boolean): Observable<any> {
    return this.contentAndDataResource.getData(sectionKey, transform, hardRefresh);
  }

  getProcessedData(sectionKey: string, options?: any): Observable<any> {
    return this.contentAndDataResource.getProcessedData(sectionKey, options);
  }

  getEnrollmentContent(): Observable<any> {
    return this.contentAndDataResource.getEnrollmentContent();
  }

  getEnrollmentContentIgnoringRecentlySubmittedLifeEvent(): Observable<any> {
    const resource = this.contentAndDataResourceForConfirmationFlow || this.contentAndDataResource;
    return resource.getEnrollmentContent();
  }

  getEnrollment(): Observable<any> {
    return this.contentAndDataResource.getEnrollment();
  }

  setSubmittedLifeEvent(data: any, currentLifeEventData: any): void {
    this.processTokensInDataService.process(data, [this.staticContentService, currentLifeEventData]);
    this.transformOpenEnrollmentService.transform(data);
    data.$promise = of(data);
    this.contentAndDataResource.updateEnrollmentCache(data);
    this.contentAndDataResourceForConfirmationFlow = this.initContentAndDataResourceForConfirmationFlow();
  }

  forgetSubmittedLifeEvent(): void {
    this.contentAndDataResource.clearWholeCache();
    this.clearConfirmationFlowCache();

    if (this.contentAndDataResourceForConfirmationFlow) {
      this.moveConfirmationFlowCacheToRegularCache();
      this.contentAndDataResourceForConfirmationFlow.clearWholeCache();
      this.contentAndDataResourceForConfirmationFlow = null;
    }
  }

  refresh(reload: boolean): void {
    this.contentAndDataResource.refresh(reload);
  }

  clearWholeCache(): void {
    this.contentAndDataResource.clearWholeCache();
  }

  remove(sectionKey: string): void {
    this.contentAndDataResource.remove(sectionKey);
  }

  private clearConfirmationFlowCache(): void {
    // Implement cache clearing logic
  }

  private initContentAndDataResourceForConfirmationFlow(): any {
    // Implement initialization logic
    return this.mbcContentAndDataResourceFactory.create();
  }

  private moveConfirmationFlowCacheToRegularCache(): void {
    const enrollmentData = this.contentAndDataResourceForConfirmationFlow.getCachedEnrollmentData();
    if (enrollmentData) {
      this.contentAndDataResource.updateEnrollmentCache(enrollmentData);
    }
  }

  getMegaNavPromise(hardRefresh: boolean): Observable<any> {
    return this.domainAvailabilityService.get().pipe(
      switchMap(domainAvailabilityResult => {
        if (domainAvailabilityResult.HbAvailable) {
          return this.getEnrollment().pipe(
            switchMap(enrollment => this.getData('nav',
              this.supplementalTabService.forEnrollment(enrollment).showSeparateTab
                ? this.transformMegaNavSeparateTab
                : this.transformMegaNavSubTab,
              hardRefresh))
          );
        } else {
          return this.getData('nav');
        }
      }),
      catchError(error => {
        console.error('Error fetching MegaNav:', error);
        return of(null);
      })
    );
  }

  private transformMegaNavSeparateTab(data: any): any {
    // Implement transformation logic
    return data;
  }

  private transformMegaNavSubTab(data: any): any {
    // Implement transformation logic
    return data;
  }

  getHbNavigationPromise(): Observable<any> {
    return this.getEnrollment().pipe(
      switchMap(enrollment => this.getData('nav-hb', this.transformHbNavigation(enrollment))),
      catchError(error => {
        console.error('Error fetching HbNavigation:', error);
        return of(null);
      })
    );
  }

  private transformHbNavigation(enrollment: any): (data: any) => any {
    return (data: any) => {
      if (this.supplementalTabService.forEnrollment(enrollment).showHealthInsuranceSubTab) {
        data.HBNavigation = data.HBNavigation.filter((nav: any) => nav.Key !== 'supplemental');
        return data;
      }

      const healthInsuranceTab = data.HBNavigation.find((nav: any) => nav.Key === 'healthinsurance');
      if (!healthInsuranceTab) {
        return data;
      }

      healthInsuranceTab.SubNav = healthInsuranceTab.SubNav.filter((subNav: any) => subNav.Key !== 'supplemental');

      if (!healthInsuranceTab.SubNav.length) {
        data.HBNavigation = data.HBNavigation.filter((nav: any) => nav.Key !== 'healthinsurance');
      }

      const enrollmentContent = this.contentAliasService.forData(enrollment);
      const epSupplementalTabTitle = this.getEpSupplementalTabTitle(enrollmentContent);

      if (!epSupplementalTabTitle) {
        return data;
      }

      const supplementalTab = data.HBNavigation.find((nav: any) => nav.Key === 'supplemental');

      if (!supplementalTab) {
        return data;
      }

      supplementalTab.Name = epSupplementalTabTitle;

      return data;
    };
  }

  private getEpSupplementalTabTitle(enrollmentContent: any): string {
    const value = enrollmentContent.getEvaluationPointValue('HB.Common.CommonTerms.SupplementalCategory');
    return value && value.Title;
  }
}
