import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { StaticContentService } from './static-content.service';
import { TransformOpenEnrollmentService } from './transform-open-enrollment.service';
import { PubsubService } from './pubsub.service';
import { ProcessTokensInDataService } from './process-tokens-in-data.service';
import { ContentAliasService } from './content-alias.service';
import { ReloadCurrentStateService } from './reload-current-state.service';

@Injectable({
  providedIn: 'root'
})
export class MbcContentAndDataResourceFactory {
  constructor(
    private http: HttpClient,
    private staticContentService: StaticContentService,
    private transformOpenEnrollmentService: TransformOpenEnrollmentService,
    private pubsubService: PubsubService,
    private processTokensInDataService: ProcessTokensInDataService,
    private contentAliasService: ContentAliasService,
    private reloadCurrentStateService: ReloadCurrentStateService
  ) {}

  create(cache: Map<string, any>): any {
    return {
      remove: (sectionKey: string) => this.remove(sectionKey, cache),
      clearWholeCache: () => this.clearWholeCache(cache),
      refresh: (reload: boolean) => this.refresh(reload, cache),
      getData: (sectionKey: string, transform?: Function, hardRefresh?: boolean) => this.getData(sectionKey, transform, hardRefresh, cache),
      getProcessedData: (sectionKey: string, options?: any) => this.getProcessedData(sectionKey, options, cache),
      getEnrollment: () => this.getEnrollment(cache),
      getEnrollmentContent: () => this.getEnrollmentContent(cache),
      updateEnrollmentCache: (data: any) => this.updateEnrollmentCache(data, cache),
      getCachedEnrollmentData: () => this.getCachedEnrollmentData(cache)
    };
  }

  private getData(sectionKey: string, transform: Function, hardRefresh: boolean, cache: Map<string, any>): Observable<any> {
    if (hardRefresh) {
      this.remove(sectionKey, cache);
    }

    const cachedData = this.getCachedData(sectionKey, cache);
    if (cachedData) {
      return of(cachedData);
    }

    return this.http.get(`/api/content/${sectionKey}`).pipe(
      map(data => this.processContent(data, sectionKey, transform)),
      catchError(error => {
        console.error('Error fetching data:', error);
        return of(null);
      })
    );
  }

  private getProcessedData(sectionKey: string, options: any, cache: Map<string, any>): Observable<any> {
    options = options || {};
    return this.getData(sectionKey, options.transform, options.hardRefresh, cache).pipe(
      map(data => this.processTokensInDataService.process(data, options.additionalDataSources)),
      catchError(error => {
        console.error('Error processing data:', error);
        return of(null);
      })
    );
  }

  private processContent(data: any, sectionKey: string, transform: Function): any {
    if (sectionKey === 'dashboard' || sectionKey === 'enrollment') {
      const clonedData = JSON.parse(JSON.stringify(data));
      this.pubsubService.publish('mbcContentAndDataReloaded', { key: sectionKey, contentData: clonedData });
    }

    return transform ? transform(data) : data;
  }

  private refresh(reload: boolean, cache: Map<string, any>): void {
    this.clearWholeCache(cache);
    if (reload) {
      this.reloadCurrentStateService.reload();
    }
  }

  private clearWholeCache(cache: Map<string, any>): void {
    cache.clear();
  }

  private remove(sectionKey: string, cache: Map<string, any>): void {
    cache.delete(`transformed.${sectionKey}`);
    cache.delete(`/api/content/${sectionKey}`);
  }

  private getCachedData(sectionKey: string, cache: Map<string, any>): any {
    return cache.get(`transformed.${sectionKey}`);
  }

  private updateEnrollmentCache(data: any, cache: Map<string, any>): void {
    this.updateCache('enrollment', data, cache);
  }

  private getCachedEnrollmentData(cache: Map<string, any>): any {
    return this.getCachedData('enrollment', cache);
  }

  private updateCache(sectionKey: string, data: any, cache: Map<string, any>): void {
    this.pubsubService.publish('mbcContentAndData.cache.updating', { key: sectionKey });
    cache.set(`transformed.${sectionKey}`, data);
    this.pubsubService.publish('mbcContentAndData.cache.updated', { key: sectionKey, newData: data });
  }

  private getEnrollment(cache: Map<string, any>): Observable<any> {
    return this.getData('enrollment', this.transformOpenEnrollmentService.transform, false, cache);
  }

  private getEnrollmentContent(cache: Map<string, any>): Observable<any> {
    return this.getEnrollment(cache).pipe(
      map(data => this.contentAliasService.forData(data)),
      catchError(error => {
        console.error('Error fetching enrollment content:', error);
        return of(null);
      })
    );
  }
}
