export interface StaticContent {
  terms: Record<string, string>;
  authTerms: Record<string, string>;
  gender: Record<string, string>;
  maritalStatus: Record<string, string>;
  comparisonSortBy: Record<string, string>;
  messageCenterCategories: Record<string, string>;
  messageCenterContactUs: Record<string, string>;
  proxy: Record<string, string>;
  sortBy: Record<string, string>;
  countries: Country[];
  images: Record<string, Image>;
  dcPlanTypes: Record<string, string>;
  monthsNames: Record<string, string>;
}

export interface Country {
  // Define properties for Country interface
}

export interface Image {
  // Define properties for Image interface
}
