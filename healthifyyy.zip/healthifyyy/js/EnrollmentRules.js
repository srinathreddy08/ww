﻿'use strict';
angular.module('mercer.services').service('EnrollmentRules', ['RulesEngine', 'mbcUtilService', 'mbcContentAndData', '$q', 'benefitCategoriesService', 'timeService', 'comparisonBenefitCategories', 'employeeCoverageService', 'getCoveredDependentCounts', 'isDependentVerificationEnabled', 'deferredCoverageService', '$log',
    function (RulesEngine, mbcUtilService, mbcContentAndData, $q, benefitCategoriesService, timeService, comparisonBenefitCategories, employeeCoverageService, getCoveredDependentCounts, isDependentVerificationEnabled, deferredCoverageService, $log) {
        return {
            LEDateOffset: lifeEventDateOffset,
            deriveOption: deriveOption,
            dependentBenefitCategoryEligibility: dependentBenefitCategoryEligibility,
            lifeEventIncrementValidation: lifeEventIncrementValidation,
            summaryFootNotes: summaryFootNotes,
            crossBenefitCheck: crossBenefitCheck,
            crossBenefitPlanDisable: crossBenefitPlanDisable,
            customAutoElections: customAutoElections,
            spendingAcctCalculation: spendingAcctCalculation,
            getAMTBenefitMaxContribution: getAMTBenefitMaxContribution
        };

        function getAMTBenefitMaxContribution(shoppingCart, benefitId, data) {
            var params = {
                CrossBenefitData: getCrossBenefitData(shoppingCart, data.Data.PendingEmployee)
            };
            params.ELEMENT_DATA = params.CrossBenefitData;

            var result = RulesEngine.evaluateFiltered(data, 'HB.LifeEvent.AMTBenefitMaxContribution', params, isRuleForBenefit);

            return _.isArray(result)
                ? _.some(result, function () { return true; })
                    ? result[0]
                    : null
                : result;

            function isRuleForBenefit(item) {
                return item.attributes['HB.LIFEEVENT.AMTBENEFITMAXCONTRIBUTION'] === benefitId;
            }
        }

        function lifeEventDateOffset(lifeEventType, lifeEventDate, lifeEventCategory, employee, data) {
            //lifeEventDate and CurrentPlanYearBeginDate should be in MM/DD/YYYY format
            var lifeEventDateParts = lifeEventDate && lifeEventDate.split('/') || [];
            var currentPlanYearBeginDateParts = employee.PlanYearInfo.CurrentPlanYearBeginDate && employee.PlanYearInfo.CurrentPlanYearBeginDate.split('/') || [];
            var getFutureCoverageLifeEventID = function (data) {
                var lifeEventID = '';
                if (employeeCoverageService.isFutureCoverageExists(data.Data)) {
                    lifeEventID = data.Data.FutureCoverages[0].LifeEvents[0].LifeEventID;
                }
                return lifeEventID;
            };

            var getFutureCoverageLifeEventCategory = function (data) {
                var lifeEventCategory = '';
                if (employeeCoverageService.isFutureCoverageExists(data.Data)) {
                    lifeEventCategory = data.Data.FutureCoverages[0].LifeEvents[0].LifeEventCategory;
                }
                return lifeEventCategory;
            };

            var getFutureCoverageLifeEventDate = function (data) {
                var lifeEventDate = new Date();
                if (employeeCoverageService.isFutureCoverageExists(data.Data)) {
                    lifeEventDate = data.Data.FutureCoverages[0].LifeEvents[0].LifeEventDate;
                }
                return lifeEventDate;
            };

            var params = {
                LEDateOffsetData: {
                    LifeEventDate: new Date(lifeEventDateParts[2], lifeEventDateParts[0] - 1, lifeEventDateParts[1]),
                    LifeEventCategory: lifeEventCategory,
                    EmpCgData_Usercode_1: employee.EmpCgData_Usercode_1,
                    EmpCgData_Usercode_2: employee.EmpCgData_Usercode_2,
                    FirstDateOfCurrentPlanYear: employee.PlanYearInfo.CurrentPlanYearBeginDate,
                    FirstDateOfNextPlanYear: employee.PlanYearInfo.NextPlanYearBeginDate,
                    LastDateOfCurrentPlanYear: employee.PlanYearInfo.CurrentPlanYearEndDate,
                    LastDateOfNextPlanYear: employee.PlanYearInfo.NextPlanYearEndDate,
                    LifeEventID: lifeEventType.LifeEventId,
                    DaysToInit: lifeEventType.DaysToInit,
                    DaysToComplete: lifeEventType.DaysToComplete,
                    DaysAfterInit: lifeEventType.DaysAfterInit,
                    //RuleForEmpInitiatedEvents: employee.SmallMarketData && employee.SmallMarketData.RuleForEmpInitiatedEvents,
                    CompanyOneCode: employee.SmallMarketData && employee.SmallMarketData.CompanyOneCode,
                    CurrentCoverageExists: employeeCoverageService.isCurrentCoverageExists(data.Data),
                    FutureCoverageExists: employeeCoverageService.isFutureCoverageExists(data.Data),
                    FutureCoverageLifeEventID: getFutureCoverageLifeEventID(data),
                    FutureCoverageLifeEventCategory: getFutureCoverageLifeEventCategory(data),
                    FutureCoverageLifeEventDate: getFutureCoverageLifeEventDate(data),
                    DateOfFirstCoverage: employee.DateOfFirstCoverage,
                    DateOfRetireeCoverage: employee.DateOfRetireeCoverage,
                    CurrentControlledGroupStatus: employee.CurrentControlledGroupStatus,
                    GlogFlag: employee.SmallMarketData && employee.SmallMarketData.GlogFlag,
                    OngoingStartDate: employee.SmallMarketData && employee.SmallMarketData.OngoingStartDate && new Date(employee.SmallMarketData.OngoingStartDate)
                }
            };

            params.LEDateOffsetData.MonthsLEDateIsFarFromCurrentPLanYearBeginDate = parseInt(lifeEventDateParts[0]) - parseInt(currentPlanYearBeginDateParts[0]) + 1;

            var lePlanYearData =
                employee.SmallMarketData.PlanYears.filter(x => new Date(lifeEventDate) >= new Date(x.StartDate) && new Date(lifeEventDate) <= new Date(x.EndDate)).shift()
                ||
                employee.SmallMarketData.PlanYears.filter(x => new Date(employee.DateOfFirstCoverage) >= new Date(x.StartDate) && new Date(employee.DateOfFirstCoverage) <= new Date(x.EndDate)).shift();

            params.LEDateOffsetData.RuleForEmpInitiatedEvents = employee.SmallMarketData.LifeEventRules[lePlanYearData.PlanYear][lifeEventType.LifeEventId] || employee.SmallMarketData.RuleForEmpInitiatedEvents;

            return RulesEngine.evaluate(data, 'HB.LifeEvent.LEDateOffset', params);
        }

        function deriveOption(currentElections, benefitId, enrollmentData, ignorePendingVerification, leCompleteMode, employee) {
            var currentElection = currentElections[benefitId];

            var benefitCategory = currentElection.BenefitCategory;

            var ruleResult = evaluateRule();

            if (!ruleResult) {
                return currentElection.OptionID;
            }

            return _.isArray(ruleResult) ? ruleResult[0] : ruleResult;

            function evaluateRule() {
                var isComparisonBenefit = _(comparisonBenefitCategories).includes(benefitCategory);
                if (isComparisonBenefit) {
                    return RulesEngine.evaluate(enrollmentData, getDeriveOptionJavascriptRuleName(), getParameters());
                }

                return RulesEngine.evaluateFiltered(enrollmentData, getDeriveOptionJavascriptRuleName(), getParameters(), isRuleForTheBenefit);

                function isRuleForTheBenefit(rule) {
                    var benefitIdAttributeName = getDeriveOptionJavascriptRuleName().toUpperCase();

                    return rule.attributes[benefitIdAttributeName] === benefitId;
                }
            }

            function getParameters() {
                if (!employee) {
                    employee = enrollmentData.Data.PendingEmployee;
                    if (!employee || !employee.Addresses) {
                        employee = enrollmentData.Data.CurrentCoveragesEmployee;
                    }
                    if (!employee || !employee.Addresses) {
                        employee = enrollmentData.Data.FutureCoverages[0];
                    }
                }

                var optionData = {
                    BenefitId: currentElection.BenefitID,
                    PlanId: currentElection.PlanID,
                    EmpCgData_Usercode_1: employee.EmpCgData_Usercode_1,
                    EmpCgData_Usercode_2: employee.EmpCgData_Usercode_2,
                    EmpCgData_Usercode_3: employee.EmpCgData_Usercode_3,
                    EmpCgData_Usercode_4: employee.EmpCgData_Usercode_4,
                    EmpCgData_Usercode_20: employee.EmpCgData_Usercode_20,
                    EmpCgData_Usercode_21: employee.EmpCgData_Usercode_21,
                    EmpCgData_Usercode_22: employee.EmpCgData_Usercode_22,
                    EmpCgData_Status_3: employee.EmpCgData_Status_3,
                    EmpCgData_Status_6: employee.EmpCgData_Status_6,
                    EmployeeState: (employee.Addresses && employee.Addresses[0] !== undefined) ? employee.Addresses[0].State : null,
                    EmployerState: (employee.CompanyAddress && employee.CompanyAddress !== undefined) ? employee.CompanyAddress.State : null,
                    Location: employee.Location,
                    UnionCode: employee.UnionCode,
                    PayStatusCode: employee.PayStatusCode,
                    SalaryHourlyCode: employee.SalaryHourlyCode,
                    ControlledGroupStatus: employee.ControlledGroupStatus,
                    ReferenceNumber: employee.ReferenceNumber,
                    IsMedicareEligibleByAge: employee.IsMedicareEligibleByAge,
                    IsMedicareEligibleByAgeAsOfDateEntered: employee.IsMedicareEligibleByAgeAsOfDateEntered,
                    LifeEventId: employee.LifeEvents[0].LifeEventID,
                    DPFlag: employee.SmallMarketData && employee.SmallMarketData.DPFlag,
                    CompanyOneCode: employee.SmallMarketData && employee.SmallMarketData.CompanyOneCode,
                    Tier: employee.SmallMarketData && employee.SmallMarketData.Tier,
                    WorkCode: employee.WorkCode,
                    GlogFlag: employee.SmallMarketData && employee.SmallMarketData.GlogFlag,
                    OngoingStartDate: employee.SmallMarketData && employee.SmallMarketData.OngoingStartDate && new Date(employee.SmallMarketData.OngoingStartDate)
                };

                var u65Category = 'U65MED';
                var o65Category = 'O65MED';

                var paramsChanges = isRetireeSplitBenefit()
                    ? formDeriveRetireeSplitParams()
                    : formDeriveParams();

                _.assign(optionData, paramsChanges);

                return isRetireeSplitBenefit()
                    ? { DeriveRetireeSplitOptionData: optionData }
                    : { DeriveOptionData: optionData };

                function isRetireeSplitBenefit() {
                    return benefitCategory === o65Category ||
                        benefitCategory === u65Category;
                }

                function formDeriveRetireeSplitParams() {
                    var u65Counts = getCounts(u65Category);
                    var o65Counts = getCounts(o65Category);

                    return {
                        SpousePartnerUnder65Count: u65Counts.AllSpouses,
                        SpousePartnerOver65Count: o65Counts.AllSpouses,
                        ChildUnder65Count: u65Counts.AllChildren,
                        ChildOver65Count: o65Counts.AllChildren,
                        UnverifiedSpousePartnerUnder65Count: u65Counts.UnverifiedAllSpouses,
                        UnverifiedSpousePartnerOver65Count: o65Counts.UnverifiedAllSpouses,
                        UnverifiedChildUnder65Count: u65Counts.UnverifiedAllChildren,
                        UnverifiedChildOver65Count: o65Counts.UnverifiedAllChildren,
                        IsRetireeOver65: getAgeByBirthDateString(employee.BirthDate) >= 65
                    };
                }

                function formDeriveParams() {
                    var counts = getCounts(benefitCategory);

                    return {
                        SpouseCount: counts.Spouses,
                        SameSexSpouseCount: counts.SameSexSpouses,
                        SameSexChildCount: counts.SameSexChildren,
                        DomesticPartnerCount: counts.DomesticPartners,
                        DomesticPartnerChildCount: counts.DomesticPartnerChildren,
                        ChildCount: counts.Children,
                        UnverifiedSpouseCount: counts.UnverifiedSpouses,
                        UnverifiedSameSexSpouseCount: counts.UnverifiedSameSexSpouses,
                        UnverifiedSameSexChildCount: counts.UnverifiedSameSexChildren,
                        UnverifiedDomesticPartnerCount: counts.UnverifiedDomesticPartners,
                        UnverifiedDomesticPartnerChildCount: counts.UnverifiedDomesticPartnerChildren,
                        UnverifiedChildCount: counts.UnverifiedChildren,
                        DependentCount: counts.AllDependents
                    };
                }

                function getCounts(category) {
                    if (ignorePendingVerification === "true") {
                        return getCoveredDependentCounts(employee, currentElections, enrollmentData, category, "true", leCompleteMode);
                    } else {
                        return getCoveredDependentCounts(employee, currentElections, enrollmentData, category);
                    }
                }

            }

            function getDeriveOptionJavascriptRuleName() {
                return 'HB.LifeEvent.' + benefitCategory + 'DeriveOption';
            }
        }

        function dependentBenefitCategoryEligibility(dependent, data, benefitCategory) {
            var defaultRuleBenefitIds = getBenefitIdsFromRule('HB.LifeEvent.DepBenefitElig');

            var perCategoryRuleName = 'HB.LifeEvent.Dep' + benefitCategory + 'BenefitElig';

            if (!RulesEngine.ruleExists(data, perCategoryRuleName)) {
                return mergeArrays(defaultRuleBenefitIds);
            }

            var perCategoryBenefitIds = getBenefitIdsFromRule(perCategoryRuleName);

            return mergeArrays([perCategoryBenefitIds, defaultRuleBenefitIds]);

            function getBenefitIdsFromRule(ruleName) {
                var ruleResult = RulesEngine.evaluate(data, ruleName, getParams());

                if (!_.isArray(ruleResult)) {
                    ruleResult = [ruleResult];
                }

                return _(ruleResult).map(parseArrayFromString).value();
            }

            function getParams() {
                var pendingEmployee = data.Data.PendingEmployee;
                var lifeEvent = pendingEmployee.LifeEvents[0];
                var currentCoveragesEmployee = data.Data.CurrentCoveragesEmployee;

                var lifeEventDate = getDateFromString(lifeEvent.LifeEventDate);
                var dateEntered = getDateFromString(lifeEvent.DateEntered);
                var dependentAsEmployee = _.find(pendingEmployee.DependentCoverageAsEmployee, { RealSsn: dependent.Ssn }) || {};

                var birthDate = getDateFromString(dependent.BirthDate);

                var depAgeAsOfLifeEventDate = RulesEngine.Age(birthDate, lifeEventDate);
                var depAgeAsOfDateEntered = RulesEngine.Age(birthDate, dateEntered);

                var yearEndDate = pendingEmployee.SmallMarketData.YearEndDate;
                if (typeof yearEndDate === 'string') {
                    yearEndDate = new Date(moment(yearEndDate));
                }

                var depAgeAsOfNextYearEnd = lifeEvent.IsOpenEnrollment ?
                                    RulesEngine.Age(birthDate, yearEndDate) : RulesEngine.Age(birthDate, RulesEngine.AddYear(yearEndDate));

                return {
                    DependentEligData: {
                        RelationType: dependent.RelationType,
                        RelationshipCode: dependent.RelationshipCode,
                        HasCoverageAsEmployee: dependent.HasCoverageAsEmployee,
                        HICN: dependent.HICN,
                        IsMedicareEligibleByAge: dependent.IsMedicareEligibleByAge,
                        IsMedicareEligibleByAgeAsOfDateEntered: dependent.IsMedicareEligibleByAgeAsOfDateEntered,
                        LifeEventId: lifeEvent.LifeEventID,
                        DependentEffDate_Usercode_1: dependent.UserCode1,
                        DepVerificationStatus: dependent.DepVerificationStatus,

                        //Add additional params
                        DepDOB: birthDate,
                        DepSsn: dependent.Ssn,
                        ParentSsn: dependent.ParentSsn,
                        LifeEventDate: lifeEventDate,
                        DepAgeAsOfToday: RulesEngine.Age(birthDate, timeService.now()),

                        //Per Mercer these two parameters should be the same calculation
                        DepAgeAsOfLifeEventDate: depAgeAsOfLifeEventDate,
                        DepAgeAsOfCurrentPlanYear: depAgeAsOfLifeEventDate,
                        DepAgeAsOfDateEntered: depAgeAsOfDateEntered,

                        DepAgeAsOfLastDayOfMonthOfLifeEventDate: calculateDepAgeAsOfLastDayOfMonthOfLifeEventDate(),

                        //(not 1A) Mercer needs to update their DOM to calculate this
                        //DepAgeAsOfCurrentPlanYearEnd: '',

                        EmpCgData_Usercode_20: pendingEmployee.EmpCgData_Usercode_20,
                        EmpCgData_Usercode_4: pendingEmployee.EmpCgData_Usercode_4,
                        EmpCgData_Usercode_3: pendingEmployee.EmpCgData_Usercode_3,
                        EmpCgData_Usercode_2: pendingEmployee.EmpCgData_Usercode_2,
                        EmpCgData_Usercode_1: pendingEmployee.EmpCgData_Usercode_1,
                        EmpCgData_Status_3: pendingEmployee.EmpCgData_Status_3,
                        EmpCgData_Status_6: pendingEmployee.EmpCgData_Status_6,
                        UnionCode: pendingEmployee.UnionCode,
                        WorkCode: pendingEmployee.WorkCode,
                        ReferenceNumber: pendingEmployee.ReferenceNumber,
                        ControlledGroupStatus: pendingEmployee.ControlledGroupStatus,

                        CoverageAsEmployee: getCoverageAsEmployee(),

                        PtcpntSalary1: pendingEmployee.Salary1,
                        PtcpntSalary2: pendingEmployee.Salary2,
                        PtcpntRate1: pendingEmployee.Rate1,
                        PtcpntRate2: pendingEmployee.Rate2,

                        DepSalary1AsEmployee: dependentAsEmployee.Salary1,
                        DepSalary2AsEmployee: dependentAsEmployee.Salary2,
                        DepRate1AsEmployee: dependentAsEmployee.Rate1,
                        DepRate2AsEmployee: dependentAsEmployee.Rate2,
                        DepUnionCodeAsEmployee: dependentAsEmployee.UnionCode,

                        BenefitsCoveredBySpouse: dependent.BenefitsCoveredBySpouse,
                        MedicareEligibilityStatus: dependent.MedicareEligibilityStatus,
                        MedicareEligibilityStatusDate: dependent.MedicareEligibilityStatusDate,
                        DPFlag: pendingEmployee.SmallMarketData && pendingEmployee.SmallMarketData.DPFlag,
                        EligFactor4AsEmployee: dependentAsEmployee.SmallMarketData && dependentAsEmployee.SmallMarketData.EligFactor4,
                        EligFactor5AsEmployee: dependentAsEmployee.SmallMarketData && dependentAsEmployee.SmallMarketData.EligFactor5,
                        CompanyOneCode: pendingEmployee.SmallMarketData && pendingEmployee.SmallMarketData.CompanyOneCode,
                        StateOfResidence: pendingEmployee.Addresses && pendingEmployee.Addresses[0] && pendingEmployee.Addresses[0].State,
                        Questionnaires: pendingEmployee.Questionnaires,
                        DepAgeAsOfNextYearEnd: depAgeAsOfNextYearEnd,
                        CurrentBenefitCoverage: getCurrentBenefitCoverage(),
                        GlogFlag: pendingEmployee.SmallMarketData && pendingEmployee.SmallMarketData.GlogFlag,
                        OngoingStartDate: pendingEmployee.SmallMarketData && pendingEmployee.SmallMarketData.OngoingStartDate && new Date(pendingEmployee.SmallMarketData.OngoingStartDate),
                        DepEligVerificationType: pendingEmployee.SmallMarketData && pendingEmployee.SmallMarketData.DepEligVerificationType,
                        LifeEventVerificationType: pendingEmployee.SmallMarketData && pendingEmployee.SmallMarketData.LifeEventVerificationType,
                        BenefitsWithVerificationEnabled: pendingEmployee.SmallMarketData && pendingEmployee.SmallMarketData.BenefitsWithVerificationEnabled,
                        LifeEventsWithVerificationEnabled: pendingEmployee.SmallMarketData && pendingEmployee.SmallMarketData.LifeEventsWithVerificationEnabled
                    }
                };

                function getCurrentBenefitCoverage() {
                    var coveredBenefits = [];
                    if (currentCoveragesEmployee && currentCoveragesEmployee.LifeEvents[0]) {
                        _.forEach(currentCoveragesEmployee.LifeEvents[0].EligibleBenefits, function (eligibleBenefit) {
                            if (eligibleBenefit && eligibleBenefit.ElectedPlan && !eligibleBenefit.ElectedPlan.IsNoCovPlan) {
                                if (_(eligibleBenefit.ElectedPlan.ElectedOption.DependentAssociations).some({ DependentSsn: dependent.Ssn })) {
                                    coveredBenefits.push(eligibleBenefit.BenefitID);
                                }
                            }
                        });
                    }
                    return coveredBenefits;
                }

                function calculateDepAgeAsOfLastDayOfMonthOfLifeEventDate() {
                    var firstOfMonthFollowing = RulesEngine.FirstOfMonthFollowing(lifeEventDate);
                    var age = RulesEngine.Age(birthDate, firstOfMonthFollowing);

                    if (birthDate.getMonth() == firstOfMonthFollowing &&
                        birthDate.getDate() == firstOfMonthFollowing) {
                        //If birthdate is on the first of the month, subtract a year since the calculatino is for the last day of the month
                        return age - 1;
                    }

                    return age;
                }

                function getCoverageAsEmployee() {
                    if (!dependentAsEmployee.LifeEvents)
                        return [];

                    return _(dependentAsEmployee.LifeEvents[0].EligibleBenefits)
                        .map(function (item) {
                            var benefit = {
                                BenefitId: item.BenefitID,
                                PlanId: item.ElectedPlan.PlanID,
                                OptionId: item.ElectedPlan.ElectedOption.OptionID
                            };

                            return benefit;
                        })
                        .value();
                }
            }
        }

        function lifeEventIncrementValidation(benefitId, planId, abountBox, employeeData) {
            var params = getLifeEventIncrementValidationParams(benefitId, planId, abountBox, employeeData.Employee.PendingEmployee);
            var aliasString = RulesEngine.evaluate(employeeData, 'HB.LifeEvent.IncrementValidation', params);
            if (aliasString.length > 0) {
                var parseStr = aliasString.split(';');
                if (parseStr.length > 1 && parseStr[0] === benefitId) {
                    return parseStr[1];
                }
            }
            return "";
        }

        function summaryFootNotes(elections, data, bestMatch, employeeData, populateDepVerificationData, leCompleteMode) {
            var dependentMap = _(employeeData.Dependents)
                .keyBy('Ssn')
                .value();
            return _(elections)
                .keyBy('BenefitID')
                .mapValues(function (election) {
                    return {
                        Notice: getMessage('Black', employeeData),
                        Footnote: getMessage('Grey', employeeData)
                    };

                    function getBenefit() {
                        return employeeData.LifeEvents[0].EligibleBenefitsMap[election.BenefitID];
                    }

                    function getPlan() {
                        var benefit = getBenefit();
                        return benefit && benefit.EligiblePlansMap[election.PlanID];
                    }

                    function getOption() {
                        var plan = getPlan();
                        return plan && plan.EligibleOptionsMap[election.OptionID];
                    }

                    function getIsCoveringSsSpouse() {
                        return getCoveredDependents()
                            .filter(function (dependent) {
                                return dependent.RelationType === 'SP' &&
                                    dependent.RelationshipCode.indexOf('SS') === 0;
                            })
                            .some();
                    }

                    function getIsCoveringDp() {
                        return getCoveredDependents()
                            .filter(function (dependent) {
                                return dependent.RelationType === 'DP';
                            })
                            .some();
                    }

                    function getIsCoveringSpouse() {
                        return getCoveredDependents()
                            .filter(function (dependent) {
                                return dependent.RelationType === 'SP';
                            })
                            .some();
                    }

                    function getCoveredDependents() {
                        return _(election.DependentAssociationList)
                            .map(function (dependentSsn) {
                                return dependentMap[dependentSsn];
                            })
                            .compact();
                    }

                    function getVerificationEnabled(benefitId) {
                        return (employeeData.SmallMarketData &&
                            employeeData.SmallMarketData.BenefitsWithVerificationEnabled &&
                            _(employeeData.SmallMarketData.BenefitsWithVerificationEnabled.split(','))
                                .includes(benefitId));
                    }

                    function getBestMatchPlanId() {
                        if (!bestMatch) {
                            return null;
                        }

                        var benefit = getBenefit();

                        if (!benefit) {
                            $log.error('EnrollmentRules: getBenefit() returns empty'); // VM
                            return null;
                        }

                        if (benefit.BenefitCategory === 'MEDICAL') {
                            if (bestMatch.AllMedicalMatches) {
                                return bestMatch.AllMedicalMatches.join(',');
                            }
                            else {
                                return bestMatch.Medical;
                            }
                        }

                        if (benefitCategoriesService.IsLifeInsuranceCategory(benefit.BenefitCategory)) {
                            var bestMatchExpense = bestMatch.LifeInsurance || 'False';
                            if (bestMatchExpense != 'True') {
                                return null;
                            }

                            return getPlan().PlanID;
                        }

                        if (benefit.BenefitCategory === 'DISABILITY') {
                            var shortTermDisabilityPlanType = 13;
                            var longTermDisabilityPlanType = 15;
                            var planType = getPlan().Type;

                            if (planType === shortTermDisabilityPlanType) {
                                return bestMatch.ShortTermDisability;
                            }

                            if (planType === longTermDisabilityPlanType) {
                                return bestMatch.LongTermDisability;
                            }
                        }

                        return null;
                    }

                    function getAmountElected() {
                        if (getBenefit().BenefitCategory == 'SPENDING') {
                            return election.Amount;
                        } else {
                            return getOptionField('AmountElected');
                        }
                    }

                    function getOptionField(fieldName) {
                        var option = getOption();

                        return option && option[fieldName];
                    }

                    function setUnumCrossBenefitWarning(election, data) {
                        if (data.Content["UnumCrossBenefitList"]) {
                            var checks = data.Content["UnumCrossBenefitList"];
                            var result = _.some(checks, function (check) {
                                return election.LifeEventDate === check.LifeEventDate && employeeData.LifeEvents[0].LifeEventSequenceNumber === check.LeSeqNo && election.BenefitID === check.BenefitId;
                            });
                            return result;
                        }
                        return false;
                    }

                    function getParams(employee) {
                        var unverifiedDepCovered = false;
                        if (isDependentVerificationEnabled(data)) {
                            if (_(comparisonBenefitCategories).includes(election.BenefitCategory)) {
                                var derivedVerifiedOption = deriveOption(_(elections).keyBy("BenefitID").value(), election.BenefitID, data, "true", leCompleteMode, employee);
                                if (derivedVerifiedOption !== election.OptionID && !election.IsNoCov) {
                                    var option = getPlan().EligibleOptionsMap[derivedVerifiedOption];
                                    if (option == null) {
                                        if (!employeeData.LifeEvents[0].EligibleBenefitsMap[election.BenefitID].ElectedPlan.IsNoCovPlan) {
                                            unverifiedDepCovered = true;
                                        }
                                    } else {
                                        unverifiedDepCovered = true;
                                    }
                                }
                            }
                        };

                        return {
                            SummaryFootnoteData: {
                                BenefitId: election.BenefitID,
                                PlanId: election.PlanID,
                                OptionId: election.OptionID,
                                IsCoveringSpouse: getIsCoveringSpouse(),
                                IsCoveringDP: getIsCoveringDp(),
                                IsCoveringSSSpouse: getIsCoveringSsSpouse(),
                                BestMatchPlanId: getBestMatchPlanId() || '',
                                AmountElected: getAmountElected(),
                                PendedStatus: getOptionField('EOIPendingStatus'),
                                PendedAmount: getOptionField('AmountPended'),
                                EmployerContrib: getOptionField('EmployerAnnualCost'),
                                EmpCgData_Usercode_2: employeeData.EmpCgData_Usercode_2,
                                EmpCgData_Usercode_1: employeeData.EmpCgData_Usercode_1,
                                UnumCrossBenefitWarning: setUnumCrossBenefitWarning(election, data),
                                UnverifiedDepCovered: unverifiedDepCovered,
                                CompanyOneCode: employeeData.SmallMarketData && employeeData.SmallMarketData.CompanyOneCode,
                                ContainsDeferredCoverages: deferredCoverageService.doesParticipantHaveSavedDeferredCoverage(election.BenefitID),
                                CompanyPlanYearQuestions: employeeData.SmallMarketData && employeeData.SmallMarketData.CompanyPlanYearQuestions,
                                IsShortPlanYear: employeeData.SmallMarketData && employeeData.SmallMarketData.IsShortPlanYear,
                                HasOEWindow: employeeData.SmallMarketData && employeeData.SmallMarketData.HasOEWindow,
                                DepEligVerificationType: employeeData.SmallMarketData && employeeData.SmallMarketData.DepEligVerificationType,
                                LifeEventVerificationType: employeeData.SmallMarketData && employeeData.SmallMarketData.LifeEventVerificationType,
                                VerificationEnabled: getVerificationEnabled(election.BenefitID),
                                BenefitsWithVerificationEnabled: employeeData.SmallMarketData && employeeData.SmallMarketData.BenefitsWithVerificationEnabled,
                                DisplayCosts: employeeData.SmallMarketData && employeeData.SmallMarketData.DisplayCosts

                            }
                        };
                    }

                    function getMessage(messageType, employee) {
                        var messageKey = RulesEngine.evaluate(data, 'HB.LifeEvent.Summary.' + messageType + 'BoxRule', getParams(employee));
                        if (!messageKey) {
                            return '';
                        }

                        return 'HB.LifeEvent.Summary.' + messageType + 'Box.' + messageKey;
                    }
                })
                .value();
        }

        function crossBenefitCheck(elections, data, employeeType) {
            if (!employeeType) {
                employeeType = 'PendingEmployee';
            }

            var params = {
                CrossBenefitData: getCrossBenefitData(elections, _(data.Data).get(employeeType))
            };
            params.ELEMENT_DATA = params.CrossBenefitData;

            var disableResponse = RulesEngine.evaluate(data, 'HB.LifeEvent.CrossBenefitCheck.Disable', params);
            var messageResponse = RulesEngine.evaluate(data, 'HB.LifeEvent.CrossBenefitCheck.Message', params);

            function transformResponse(type, originalData) {
                var transform = {}
                _.forEach(originalData, function (jsResponse) {
                    var msg = [], alias;
                    if (jsResponse) {
                        msg = jsResponse.split(';');
                        //Length must be 2 or it is bad data
                        if (msg.length === 2) {
                            alias = 'HB.LifeEvent.ChooseBenefits.CrossCheck' + type;

                            if (data.ContentAliases[alias] && data.ContentAliases[alias][msg[1]]) {
                                transform[msg[0]] = transform[msg[0]] || [];
                                transform[msg[0]].push({
                                    'ContentAlias': alias + '.' + msg[1],
                                    'DisplayOrder': data.ContentAliases[alias][msg[1]].DisplayOrder
                                });
                            }
                        }
                    }
                });

                _.forEach(transform, function (res) {
                    _.sortBy(res, 'DisplayOrder');
                });

                return transform;
            }

            var response = {
                Disable: transformResponse('Disable', disableResponse),
                Message: transformResponse('Message', messageResponse)
            };

            return response;
        }

        function crossBenefitPlanDisable(elections, employee, data) {
            var params = {
                CrossBenefitData: getCrossBenefitData(elections, employee)
            };

            params.ELEMENT_DATA = params.CrossBenefitData;

            var supressedPlans = getRulePlans('HB.LifeEvent.CrossBenefit.SuppressPlans');
            var restrictToPlans = getRulePlans('HB.LifeEvent.CrossBenefit.RestrictToPlans');

            return isPlanDisabled;

            function parsePairs(ruleValues) {
                return _(ruleValues)
                    .compact()
                    .map(function (ruleValue) {
                        return ruleValue.split(';');
                    })
                    .compact()
                    .flattenDeep();
            }

            function parsePlansMapping(allPairs) {
                function getAllDistinctPlans(mappingsWithSameBenefitId) {
                    return _(mappingsWithSameBenefitId)
                        .map(function (benefitWithPlans) {
                            return benefitWithPlans.Plans.split(',');
                        })
                        .flattenDeep()
                        .uniq()
                        .keyBy()
                        .value();
                }

                return allPairs
                    .map(function (pair) {
                        var parts = pair.split(':');
                        return {
                            BenefitId: parts[0],
                            Plans: parts[1]
                        };
                    })
                    .groupBy('BenefitId')
                    .mapValues(function (mappingsWithSameBenefitId, benefitId) {
                        return {
                            BenefitId: benefitId,
                            Plans: getAllDistinctPlans(mappingsWithSameBenefitId)
                        };
                    })
                    .value();
            }

            function getRulePlans(ruleName) {
                var ruleValues = RulesEngine.evaluate(data, ruleName, params);
                var allPairs = parsePairs(_.isArray(ruleValues) ? ruleValues : [ruleValues]);

                return parsePlansMapping(allPairs);
            }

            function isPlanDisabled(benefit, plan) {
                var planId = plan.PlanID;
                var benefitId = benefit.BenefitID;

                if (supressedPlans[benefitId]) {
                    return supressedPlans[benefitId].Plans[planId];
                }

                if (restrictToPlans[benefitId]) {
                    if (hasRestrictToPlans()) {
                        return !restrictToPlans[benefitId].Plans[planId];
                    }
                }

                return false;

                function hasRestrictToPlans() {
                    return _(restrictToPlans[benefitId].Plans)
                        .filter(function (x, restrictPlanId) {
                            return benefit.EligiblePlansMap[restrictPlanId];
                        })
                        .some();
                }
            }
        }

        function customAutoElections(changedElection, elections, employee, data) {
            var params = {
                CrossBenefitData: getCrossBenefitData(elections, employee)
            };

            params.CrossBenefitData.BenefitId = changedElection.BenefitID;
            params.CrossBenefitData.PlanId = changedElection.PlanID;
            params.CrossBenefitData.OptionId = changedElection.OptionID;
            params.ELEMENT_DATA = params.CrossBenefitData;

            var ruleValues = RulesEngine.evaluate(data, 'HB.ChooseBenefits.CustomAutoelects', params);

            return _(ruleValues)
                .compact()
                .map(function (value) {
                    return value.split(';');
                })
                .reject(function (parts) { return parts.length < 3; })
                .map(function (parts) {
                    return {
                        AutoBenefitID: parts[0],
                        AutoPlanID: parts[1],
                        AutoOptionID: parts[2],
                        IncludeDepsInd: parts[3]
                    };
                })
                .value();
        }

        function spendingAcctCalculation(frequency, employee, benefit, value, data) {

            // OLD SIGS
            //HB.LifeEvent.SpendingAcctPPCalculations: 
            //"fn.If(true,fn.Division(fn.Subtraction(obj.PerPayPeriodData.EmployeeAnnualContrib,obj.PerPayPeriodData.FSAYearToDateAmt),obj.PerPayPeriodData.NumPayPeriodsLeft) , 0)"

            //HB.LifeEvent.SpendingAcctAnnualCalculations: 
            //"fn.If(true,fn.Subtraction(fn.Multiplication(obj.AnnualCalcData.EmployeePerPayPeriodContrib,obj.AnnualCalcData.NumPayPeriodsLeft),obj.AnnualCalcData.FSAYearToDateAmt) , 0)"

            // NEW SIGS 8/22
            // HB.LifeEvent.SpendingAcctPPCalculations:
            // "fn.IsEqual(obj.DeriveOptionData.BenefitId,'MEDICAL')"

            // HB.LifeEvent.SpendingAcctAnnualCalculations:
            // "fn.If(true,fn.Subtraction(fn.Multiplication(obj.AnnualCalcData.EmployeePerPayPeriodContrib,obj.AnnualCalcData.NumPayPeriodsLeft),obj.AnnualCalcData.FSAYearToDateAmt),0)"

            // NEW SIGS 8/26
            // HB.LifeEvent.SpendingAcctPPPCalculations: 
            // "fn.If(true,fn.Division(fn.Subtraction(obj.PerPayPeriodData.EmployeeAnnualContrib,obj.PerPayPeriodData.FSAYearToDateAmt),obj.PerPayPeriodData.NumPayPeriodsLeft),0)"

            // HB.LifeEvent.SpendingAcctAnnualCalculations: 
            // "fn.If(true,fn.Subtraction(fn.Multiplication(obj.AnnualCalcData.EmployeePerPayPeriodContrib,obj.AnnualCalcData.NumPayPeriodsLeft),obj.AnnualCalcData.FSAYearToDateAmt),0)"

            // return the account calculation as 'PPP' or 'Annual' based of the HB.LIFEEVENT.AMTELECTEDFREQUENCY in the Configuration Object (frequency)
            // if 'A', calculate per pay period.
            // if 'P', calculate annual.



            if (frequency === 'A') {
                var params = { PerPayPeriodData: {} };
                params.PerPayPeriodData.EmployeeAnnualContrib = value; // benefit.ElectedPlan.ElectedOption.EmployeeAnnualCost;
                params.PerPayPeriodData.FSAYearToDateAmt = !benefit.ElectedPlan ? 0 : benefit.ElectedPlan.ElectedOption.YearToDateContributions;
                params.PerPayPeriodData.BenefitId = benefit.BenefitID;
                params.PerPayPeriodData.NumPayPeriodsLeft = employee.RemainingPayPeriods;
                params.PerPayPeriodData.PayFrequency = employee.PayGroupFrequency;
                params.PerPayPeriodData.TotalPayPeriods = employee.TotalPayPeriods;
                params.PerPayPeriodData.LifeEventId = employee.LifeEvents[0].LifeEventID;
                params.PerPayPeriodData.LifeEventCategory = employee.LifeEvents[0].LifeEventCategory;
                params.PerPayPeriodData.CompanyOneCode = employee.SmallMarketData && employee.SmallMarketData.CompanyOneCode;
                return RulesEngine.evaluate(data, 'HB.LifeEvent.SpendingAcctPPPCalculations', params);
            }
            else if (frequency === 'P') {
                var params = { AnnualCalcData: {} };
                params.AnnualCalcData.EmployeePerPayPeriodContrib = value; // '';
                params.AnnualCalcData.FSAYearToDateAmt = !benefit.ElectedPlan ? 0 : (!benefit.ElectedPlan.IsNoCovPlan && benefit.ElectedPlan.ElectedOption.YearToDateContributions) ? benefit.ElectedPlan.ElectedOption.YearToDateContributions : 0;
                params.AnnualCalcData.BenefitId = benefit.BenefitID;
                params.AnnualCalcData.NumPayPeriodsLeft = employee.RemainingPayPeriods;
                params.AnnualCalcData.PayFrequency = employee.PayGroupFrequency;
                params.AnnualCalcData.TotalPayPeriods = employee.TotalPayPeriods;
                params.AnnualCalcData.LifeEventId = employee.LifeEvents[0].LifeEventID;
                params.AnnualCalcData.LifeEventCategory = employee.LifeEvents[0].LifeEventCategory;
                params.AnnualCalcData.CompanyOneCode = employee.SmallMarketData && employee.SmallMarketData.CompanyOneCode;
                return RulesEngine.evaluate(data, 'HB.LifeEvent.SpendingAcctAnnualCalculations', params);
            }


            return 0;

        }

        function getCrossBenefitData(elections, employee) {
            var lifeEvent = employee.LifeEvents[0];
            var benefitsById = lifeEvent.EligibleBenefitsMap;

            return {
                Dependents: employee.Dependents,
                EmpCgData_Usercode_2: employee.EmpCgData_Usercode_2,
                EmpCgData_Usercode_1: employee.EmpCgData_Usercode_1,
                EmpCgData_Usercode_20: employee.EmpCgData_Usercode_20,
                EmpCgData_Status_3: employee.EmpCgData_Status_3,
                Location: employee.Location,
                UnionCode: employee.UnionCode,
                EmployeeState: employee.Addresses && employee.Addresses[0] && employee.Addresses[0].State,
                EmployerState: employee.CompanyAddress && employee.CompanyAddress.State,
                PayStatusCode: employee.PayStatusCode,
                SalaryHourlyCode: employee.SalaryHourlyCode,
                ControlledGroupStatus: employee.ControlledGroupStatus,
                IsMedicareEligibleByAge: employee.IsMedicareEligibleByAge,
                AgeOfParticipant: getAgeByBirthDateString(employee.BirthDate),
                AgeAsOfPlanYearBeginSM: employee.SmallMarketData && employee.SmallMarketData.YearBeginDate && RulesEngine.Age(getDateFromString(employee.BirthDate), getDateFromString(employee.SmallMarketData.YearBeginDate)),
                AgeAsOfPlanYearEndSM: employee.SmallMarketData && employee.SmallMarketData.YearEndDate && RulesEngine.Age(getDateFromString(employee.BirthDate), getDateFromString(employee.SmallMarketData.YearEndDate)),
                AgeAsOfLifeEventDate: RulesEngine.Age(getDateFromString(employee.BirthDate), new Date(lifeEvent.LifeEventDate)),
                AgeAsOfDateEntered: RulesEngine.Age(getDateFromString(employee.BirthDate), new Date(lifeEvent.DateEntered)),
                AgeOfSpousePartner: getAgeOfSpousePartner(),
                ElectedBenefits: getElibibleBenefits(),
                DPFlag: employee.SmallMarketData && employee.SmallMarketData.DPFlag,
                EligFactor5: employee.SmallMarketData && employee.SmallMarketData.EligFactor5,
                SitusState: employee.SmallMarketData && employee.SmallMarketData.SitusState,
                CompanyOneCode: employee.SmallMarketData && employee.SmallMarketData.CompanyOneCode,
                LifeEventId: lifeEvent.LifeEventID,
                LifeEventDate: new Date(lifeEvent.LifeEventDate),
                CurrentPlanYearBeginDate: extractPlanYearBeginDate(employee.PlanYearInfo),
                CurrentPlanYearEndDate: extractPlanYearEndDate(employee.PlanYearInfo),
                LastDayOfMonthOfLifeEventDate: RulesEngine.LastDayOfMonth(new Date(lifeEvent.LifeEventDate)),
                HSALimit1: employee.SmallMarketData && employee.SmallMarketData.HSALimit1,
                HSALimit2: employee.SmallMarketData && employee.SmallMarketData.HSALimit2,
                HSALimit3: employee.SmallMarketData && employee.SmallMarketData.HSALimit3,
                HSALimit4: employee.SmallMarketData && employee.SmallMarketData.HSALimit4,
                WorkCode: employee.WorkCode,
                CompanyPlanYearQuestions: employee.SmallMarketData && employee.SmallMarketData.CompanyPlanYearQuestions,
                FrozenPlanYearData: employee.FrozenPlanYearData,
                Questionnaires: employee.Questionnaires,
                CompanyEmpSecondaryStatusCode: employee.CompanyEmpSecondaryStatusCode,
                GlogFlag: employee.SmallMarketData && employee.SmallMarketData.GlogFlag,
                OngoingStartDate: employee.SmallMarketData && employee.SmallMarketData.OngoingStartDate && new Date(employee.SmallMarketData.OngoingStartDate),
                CovidVaccineStatus: employee.CovidVaccineStatus
            };

            function extractPlanYearBeginDate(planYearInfo) {
                return (planYearInfo && planYearInfo.CurrentPlanYearBeginDate) ? new Date(planYearInfo.CurrentPlanYearBeginDate) : null;
            }

            function extractPlanYearEndDate(planYearInfo) {
                return (planYearInfo && planYearInfo.CurrentPlanYearEndDate) ? new Date(planYearInfo.CurrentPlanYearEndDate) : null;
            }

            function getAgeOfSpousePartner() {
                var spousePartner = getSpousePartner();

                return spousePartner && getAgeByBirthDateString(spousePartner.BirthDate);
            }

            function getSpousePartner() {
                return _(employee.Dependents)
                    .filter(function (dependent) {
                        return isOfType('SP') ||
                            isOfType('DP') ||
                            isOfType('SGSP');

                        function isOfType(relationType) {
                            return dependent.RelationType === relationType;
                        }
                    })
                    .head();
            }

            function getElibibleBenefits() {
                return _(elections)
                    .map(function (cartItem) {
                        var election = {
                            BenefitId: cartItem.BenefitID,
                            PlanId: cartItem.PlanID,
                            OptionId: cartItem.OptionID,
                            DependentAssociationList: cartItem.DependentAssociationList,
                            BenefitGroupingID: getElectedBenefit().BenefitGroupingID
                        };

                        if (amountIsPrecalculated()) {
                            var option = getElectedOption();
                            election.AmountElected = option.AmountElected;
                            election.AmountInforce = option.AmountInforce;
                            election.EOIPendingStatus = option.EOIPendingStatus;
                            election.EmployerAnnualCost = option.EmployerAnnualCost;
                        } else {
                            election.AmountElected = cartItem.Amount;
                            election.AmountInforce = cartItem.AmountInforce;
                            election.EOIPendingStatus = cartItem.EOIPendingStatus;
                            election.EmployerAnnualCost = cartItem.EmployerAnnualCost;
                        }

                        return election;

                        function getElectedBenefit() {
                            return benefitsById[cartItem.BenefitID];
                        }

                        function getElectedOption() {
                            var electedBenefit = getElectedBenefit();
                            var electedPlan = electedBenefit && electedBenefit.EligiblePlansMap[cartItem.PlanID];
                            return electedPlan && electedPlan.EligibleOptionsMap[cartItem.OptionID];
                        }

                        function isAmountBased() {
                            var electedBenefit = getElectedBenefit();

                            return electedBenefit.BenefitCategory === 'SPENDING' ||
                                electedBenefit.BenefitType === 'AmountBased';
                        }

                        function amountIsPrecalculated() {
                            return getElectedOption() && !isAmountBased();
                        }
                    })
                    .value();
            }
        }

        function getAgeByBirthDateString(birthDate) {
            return RulesEngine.Age(getDateFromString(birthDate), timeService.now());
        }

        function getDateFromString(dateString) {
            var dateParts = dateString && dateString.split('/') || [];
            var date = new Date(parseInt(dateParts[2], 10), parseInt(dateParts[0], 10) - 1, parseInt(dateParts[1], 10));
            return date;
        }

        function getLifeEventIncrementValidationParams(benefitId, planId, amountBox, employee) {
            return {
                GoalIncrementValidationData: {
                    BenefitId: benefitId,
                    PlanId: planId,
                    OptionId: amountBox.CoverageOption.OptionID,
                    AmountElected: amountBox.AmountEntered,
                    EmpCgData_Usercode_1: employee.EmpCgData_Usercode_1,
                    EmpCgData_Usercode_2: employee.EmpCgData_Usercode_2,
                    EmpCgData_Usercode_3: employee.EmpCgData_Usercode_3,
                    EmpCgData_Usercode_4: employee.EmpCgData_Usercode_4,
                    EmpCgData_Usercode_20: employee.EmpCgData_Usercode_20,
                    EmpCgData_Status_3: employee.EmpCgData_Status_3,
                    Location: employee.Location,
                    UnionCode: employee.UnionCode,
                    EmployeeState: employee.Addresses[0].State,
                    EmployerState: employee.CompanyAddress.State,
                    PayStatusCode: employee.PayStatusCode,
                    SalaryHourlyCode: employee.SalaryHourlyCode,
                    CompanyOneCode: employee.SmallMarketData && employee.SmallMarketData.CompanyOneCode,
                    IncrementAmount: employee.LifeEvents[0].EligibleBenefitsMap[benefitId].EligiblePlansMap[planId].IncrementAmount
                }
            };
        }

        function parseArrayFromString(str) {
            var commaSeparatedElements = str.replace(/[\[\]]/g, '');

            return !!commaSeparatedElements ? commaSeparatedElements.split(',') : [];
        }

        function mergeArrays(arrays) {
            return _(arrays)
                .flattenDeep()
                .uniq()
                .value();
        }
    }]);