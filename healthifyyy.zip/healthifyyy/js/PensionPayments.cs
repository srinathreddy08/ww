namespace Mercer.MBC.UI.Models.Data.DB
{
    using System.Collections.Generic;

    public class PensionPayments
    {
        public List<PaymentInfo> History { get; set; }

        public List<PaymentStream> Summary { get; set; }
  
        public List<Account> AvailableAccounts { get; set; }

        public Dictionary<string, Content> PlanContents { get; set; }
    }
}