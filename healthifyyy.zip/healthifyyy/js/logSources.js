﻿'use strict';
angular.module('mercer.db.shared').constant('logSources', {
    "MBCDevTools": true,
    "CartValidationService": false,
    "ChatService": false,
    "CheckCartConsistency": false,
    "DomDataLifeCycle": false,
    "Routing": false,
    "SpinnerService": false,
    "WhosCovered.CoverageState": false,
    "WhosCovered.Deferred": false,
    "DependentUser.Coverage": false,
    "NavigationService": false,
    "TransformOpenEnrollment": true,
    "PCE": true,
    "AutocompleteService": false,
    "MissingShoppingCartFunctionInExpertGuidanceFlow": false
});