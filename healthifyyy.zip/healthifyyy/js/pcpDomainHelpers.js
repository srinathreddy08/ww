﻿'use strict';
angular.module('mercer.services')
    .factory('pcpDomainHelpers',
    function () {
            return {
                forData: function (employeeData) {
                    var accessor = function (employeeFieldName) {
                        var employee = function () {
                            return employeeData.Employee[employeeFieldName];
                        };

                        var lifeEvent = function () {
                            var e = employee();
                            return e && e.LifeEvents[0];
                        };

                        var benefit = function (election) {
                            var le = lifeEvent();
                            return le && le.EligibleBenefitsMap[election.BenefitID];
                        };

                        var plan = function (election) {
                            var b = benefit(election);

                            return b && b.EligiblePlansMap[election.PlanID];
                        };

                        var electedPlan = function (election) {
                            var b = benefit(election);

                            return b && b.ElectedPlan;
                        };

                        return {
                            employee: employee,
                            lifeEvent: lifeEvent,
                            benefit: benefit,
                            plan: plan,
                            electedPlan: electedPlan
                        };
                    };

                    return {
                        current: accessor('CurrentCoveragesEmployee'),
                        pending: accessor('PendingEmployee')
                    };
                }
            };
        });
