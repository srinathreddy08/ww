﻿'use strict';
angular.module('mercer.services').factory('isRepriceableBenefit', [
    'benefitCategoriesService', 'getRepriceableBenefitIds',
    function(benefitCategoriesService, getRepriceableBenefitIds) {
        return {
            forData: forData
        };

        function forData(employeeData) {
            var repriceableBenefitIds = getRepriceableBenefitIds(employeeData);

            return isRepriceableBenefitFilter;

            function isRepriceableBenefitFilter(benefit) {

                return benefitCategoriesService.IsAccountBased(benefit) ||
                    repriceableBenefitIds.indexOf(benefit.BenefitID) > -1;
            }
        }
    }
]);