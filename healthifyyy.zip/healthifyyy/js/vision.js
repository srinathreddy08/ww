angular.module('mercerApp').controller('healthBenefitsVisionController', ['$rootScope', '$scope', 'navigationService', 'healthData', 'coverageDataSource', function ($rootScope, $scope, navigationService, healthData, coverageDataSource) {
  this.$onInit = function () {
    // SET NAVIGATION
    navigationService.setCurrentTabByKeys('healthinsurance', 'vision');
    $scope.healthData = healthData;
    $scope.coverageDataSource = coverageDataSource;
  };
}]);