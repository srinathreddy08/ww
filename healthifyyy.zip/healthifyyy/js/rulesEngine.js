﻿'use strict';
angular.module('mercer.services').service('RulesEngine', ['_', 'timeService', function (_, timeService) {
    var engine = {

        // ************************
        //  Operators
        // ************************

        // Addition
        Addition: function (a, b) { return +a + b; },
        // And
        And: function (a, b) { return a && b; },
        // Division
        Division: function (a, b) { return a / b; },
        // IsEqual
        IsEqual: function (a, b) {
            if ((a instanceof Date) && (b instanceof Date)) {
                return _.isEqual(a, b);
            }
            return a == b;
        },
        // IsGreater
        IsGreater: function (a, b) {
            if ((a instanceof Date) && (b instanceof Date)) {
                return _.gt(a, b);
            }
            return a > b;
        },
        // IsGreaterOrEqual
        IsGreaterOrEqual: function (a, b) {
            if ((a instanceof Date) && (b instanceof Date)) {
                return _.gte(a, b);
            }
            return a >= b;
        },
        // IsLess
        IsLess: function (a, b) {
            if ((a instanceof Date) && (b instanceof Date)) {
                return _.lt(a, b);
            }
            return a < b;
        },
        // IsLessOrEqual
        IsLessOrEqual: function (a, b) {
            if ((a instanceof Date) && (b instanceof Date)) {
                return _.lte(a, b);
            }
            return a <= b;
        },
        // IsNotEqual
        IsNotEqual: function (a, b) { return a != b; },
        // Like
        Like: function (a, b) {
            var regexp = new RegExp(b);
            return regexp.test(a);
        },
        // Multiplication
        Multiplication: function (a, b) { return a * b; },
        // Not
        Not: function (a) { return !a; },
        // Or
        Or: function (a, b) { return a || b; },
        // Power
        Power: function (a, b) { return Math.pow(a, b); },
        // Subtraction
        Subtraction: function (a, b) { return a - b; },
        // Xor
        Xor: function (a, b) { return a ^ b; },

        // ************************
        //  Advanced
        // ************************

        // Between
        Between: function (val, minVal, maxVal) { return minVal <= val && val <= maxVal; },
        // Coalesce
        Coalesce: function (objectArray) {
            for (var i = 0; i < objectArray.length; i++) {
                var val = objectArray[i].value;
                if (val !== null && val !== 'undefined') {
                    return val;
                }
            }
            return null;
        },
        // If
        If: function (condition, trueVal, falseVal) { return condition ? trueVal : falseVal; },
        // In
        In: function (testValue) {
            if (!testValue) {
                return false;
            }
            for (var i = 1; i < arguments.length; i++) {
                if (testValue === arguments[i]) {
                    return true;
                }
            }
            return false;
        },
        // IsNotNull
        IsNotNull: function (value) { return value !== null && value !== undefined; },
        // IsNull
        IsNull: function (value) { return value === null || value === undefined; },
        // NotIn
        NotIn: function (testValue) {
            if (!testValue) {
                return false;
            }
            for (var i = 1; i < arguments.length; i++) {
                if (testValue === arguments[i]) {
                    return false;
                }
            }
            return true;
        },
        // Nvl
        Nvl: function (inputString, replaceWith) { return inputString !== null ? inputString : replaceWith; },

        // ************************
        //  Character
        // ************************

        // InStr
        InStr: function (inputString, substring) {
            if (!inputString) {
                return false;
            }
            return inputString.indexOf(substring) + 1;
        },
        // Left
        Left: function (inputString, symbolsCount) { return inputString.substring(0, symbolsCount); },
        // LeftTrim
        LeftTrim: function (inputString) { return inputString.replace(/^\s+/, ''); },
        // Length
        Length: function (inputString) { return inputString.length; },
        // Mid
        Mid: function (inputString, symbolsCount, startIndex) {
            if (inputString.length < startIndex || startIndex < 0) {
                return '';
            }
            if (symbolsCount < 0 || inputString.length - startIndex + 1 < symbolsCount) {
                return '';
            }

            return inputString.substring(startIndex - 1, symbolsCount);
        },
        // Right
        Right: function (inputString, symbolsCount) { return inputString.substring(inputString.length - symbolsCount, symbolsCount); },
        // RightTrim
        RightTrim: function (inputString) { return inputString.replace(/\s+$/, ''); },
        // ToLower
        ToLower: function (inputString) { return inputString.toLowerCase(); },
        // ToUpper
        ToUpper: function (inputString) { return inputString.toUpperCase(); },
        // Trim
        Trim: function (inputString) {
            if (!String.prototype.trim) {
                return inputString.replace(/^\s+|\s+$/g, '');
            }
            return inputString.trim();
        },

        // ************************
        //  Conversion
        // ************************

        // ToBoolean
        ToBoolean: function (value) {
            switch (typeof (value)) {
                case 'undefined':
                    return undefined;
                case 'object':
                    return value === null ? false : undefined;
                case 'function':
                    return undefined;
                case 'boolean':
                    return value;
                case 'number':
                    return value !== 0;
                case 'string':
                    return value.toLowerCase() === 'true';
            }
            return undefined;
        },
        // ToDate
        ToDate: function (value) { return new Date(value); },
        // ToNumber
        ToNumber: function (value) { return Number(value); },
        // ToString
        ToString: function (value) { return String(value); },

        // ************************
        //  Date
        // ************************

        // Age
        Age: function (birthDate, effectiveDate) {
            if (!effectiveDate) {
                effectiveDate = timeService.now();
            }
            if (typeof effectiveDate === 'string') {
                effectiveDate = new Date(moment(effectiveDate));
            }
            if (effectiveDate < birthDate) {
                return undefined;
            }

            var age = effectiveDate.getFullYear() - birthDate.getFullYear();

            if (effectiveDate.getMonth() < birthDate.getMonth() ||
            (effectiveDate.getMonth() == birthDate.getMonth() && effectiveDate.getDate() < birthDate.getDate())) {
                age--;
            }
            return age;
        },
        // DayAdd
        DayAdd: function (dateTime, days) {
            var timeCopy = dateTime.getTime();
            var daysMsec = days * 24 * 60 * 60 * 1000;
            dateTime.setTime(timeCopy + daysMsec);
            return dateTime;
        },
        // DayDiff
        DayDiff: function (dateTime1, dateTime2) {
            // The number of milliseconds in one day
            var oneDay = 1000 * 60 * 60 * 24;

            // Convert both dates to milliseconds
            var date1Msec = dateTime1.getTime();
            var date2Msec = dateTime2.getTime();

            // Calculate the difference in milliseconds
            var differenceMsec = Math.abs(date1Msec - date2Msec);

            // Convert back to days and return
            return Math.round(differenceMsec / oneDay);
        },
        // Day
        Day: function (dateTime) { return dateTime.getDate(); },
        // FirstOfMonthFollowing
        FirstOfMonthFollowing: function (dateTime) {
            var year = dateTime.getFullYear();
            var month = dateTime.getMonth();
            if (month === 11) {
                month = 0;
                year++;
            } else {
                month++;
            }
            return new Date(year, month, 1, 0, 0, 0, 0);
        },
        AddYear: function (dateTime) {
            var year = dateTime.getFullYear();
            var month = dateTime.getMonth();
            var day = dateTime.getDate();
            return new Date(year + 1, month, day);
        },
        // FirstOfMonthCoinciding
        FirstOfMonthCoinciding: function (dateTime) {
            var year = dateTime.getFullYear();
            var month = dateTime.getMonth();
            var day = dateTime.getDate();
            if (day == 1)
                return new Date(year, month, day);
            else
                return this.FirstOfMonthFollowing(dateTime);
        },

        LastDayOfMonth: function (dateTime) {
            var followingMonthDay = this.FirstOfMonthFollowing(dateTime);
            this.DayAdd(followingMonthDay, -1);
            return followingMonthDay;
        },
        // FirstOfMonth
        FirstOfMonth: function (dateTime) {
            return new Date(dateTime.getFullYear(), dateTime.getMonth(), 1, 0, 0, 0, 0);
        },
        // Month
        Month: function (dateTime) { return dateTime.getMonth(); },
        // Now
        Now: function () { return timeService.now(); },
        // WeekDay
        WeekDay: function (dateTime) {
            var dayOfWeek = [];
            dayOfWeek[0] = "Sunday";
            dayOfWeek[1] = "Monday";
            dayOfWeek[2] = "Tuesday";
            dayOfWeek[3] = "Wednesday";
            dayOfWeek[4] = "Thursday";
            dayOfWeek[5] = "Friday";
            dayOfWeek[6] = "Saturday";
            return dayOfWeek[dateTime.getDay()];
        },
        // Year
        Year: function (dateTime) { return dateTime.getFullYear(); },

        // ************************
        //  Mathematical
        // ************************

        // Abs
        Abs: function (a) { return Math.abs(a); },
        // Max
        Max: function (a, b) { return Math.max(a, b); },
        // Min
        Min: function (a, b) { return Math.min(a, b); },
        // Mod
        Mod: function (a, b) { return a % b; },
        // RoundDown
        RoundDown: function (a) { return Math.floor(a); },
        // Round
        Round: function (a) { return Math.round(a); },
        // RoundUp
        RoundUp: function (a) { return Math.ceil(a); },

        RoundDownToMultiple: function (a, b) {

            // IE 11 have no support for Math.trunc()
            if (!Math.trunc) {
                Math.trunc = function (v) {
                    v = +v;
                    return (v - v % 1) || (!isFinite(v) || v === 0 ? v : v < 0 ? -0 : 0);
                };
            }

            return (Math.trunc(a / b) * b);  
        },

        RoundUpToMultiple: function (a, b) { return (this.RoundDownToMultiple(a, b)) + (Math.ceil((a % b) / b) * b); },

        RoundToNearestMultiple: function (a, b) {
            var u = this.RoundUpToMultiple(a,b);
            var d = this.RoundDownToMultiple(a,b);
            return ((u-a) <= (a-d)) ? u : d;
        },

        // ************************
        //  Custom Helper functions
        // ************************

        GetObjects: function (obj, key, val) {
            var objects = [];
            if (obj != null) {
                for (var i in obj) {
                    if (!obj.hasOwnProperty(i)) continue;
                    if (typeof obj[i] == 'object') {
                        objects = objects.concat(this.GetObjects(obj[i], key, val));
                    } else if (i == key && obj[key] == val) {
                        objects.push(obj);
                    }
                }
            }
            return objects;
        },

        GetShopCartPlanForBenefit: function (dom, benefitId) {
            var planId = '';
            var electedBenefits = this.GetObjects(dom.ElectedBenefits, "BenefitId", benefitId);
            if (electedBenefits) {
                var electedBenefit = electedBenefits[0]
            }
            if (electedBenefit && electedBenefit.hasOwnProperty("PlanId")) {
                planId = electedBenefit.PlanId;
            }
            return planId;
        },

        GetShopCartOptionForBenefit: function (dom, benefitId) {
            var optionId = '';
            var electedBenefits = this.GetObjects(dom.ElectedBenefits, "BenefitId", benefitId);
            if (electedBenefits) {
                var electedBenefit = electedBenefits[0]
            }
            if (electedBenefit && electedBenefit.hasOwnProperty("OptionId")) {
                optionId = electedBenefit.OptionId;
            }
            return optionId;
        },

        GetAmountElected: function (dom, benefitId) {
            var amt = 0;
            var electedBenefits = this.GetObjects(dom.ElectedBenefits, "BenefitId", benefitId);
            if (electedBenefits) {
                var electedBenefit = electedBenefits[0]
            }
            if (electedBenefit && electedBenefit.hasOwnProperty("AmountElected")) {
                amt = electedBenefit.AmountElected;
            }
            return amt;
        },

        GetEmployerAnnualCost: function (dom, benefitId) {
            var cost = 0;
            var electedBenefit;
            var electedBenefits = this.GetObjects(dom.ElectedBenefits, "BenefitId", benefitId);
            if (electedBenefits) {
                electedBenefit = electedBenefits[0]
            }
            if (electedBenefit && electedBenefit.hasOwnProperty("EmployerAnnualCost")) {
                cost = electedBenefit.EmployerAnnualCost;
            }
            return cost;
        },

        GetAmountInforce: function (dom, benefitId) {
            var amt = 0;
            var electedBenefits = this.GetObjects(dom.ElectedBenefits, "BenefitId", benefitId);
            if (electedBenefits) {
                var electedBenefit = electedBenefits[0]
            }
            if (electedBenefit && electedBenefit.hasOwnProperty("AmountInforce")) {
                amt = electedBenefit.AmountInforce;
            }
            return amt;
        },


        GetEOIPendingStatus: function (dom, benefitId) {
            var status = '';
            var electedBenefits = this.GetObjects(dom.ElectedBenefits, "BenefitId", benefitId);
            if (electedBenefits) {
                var electedBenefit = electedBenefits[0]
            }
            if (electedBenefit && electedBenefit.hasOwnProperty("EOIPendingStatus")) {
                status = electedBenefit.EOIPendingStatus;
            }
            return status;
        },

        IsShopCartDepRelTypeCoveredForBenefit: function (dom, relationshipTypes, benefitId) {
            var electedBenefits = dom.ElectedBenefits;
            var dependents = dom.Dependents;
            var relTypes = relationshipTypes.split(',');
            if (electedBenefits && dependents) {
                var electedBenefit = _.find(electedBenefits, function (benefit) {
                    return benefit.BenefitId === benefitId;
                });
                if (electedBenefit) {
                    var dependentAssociationList = electedBenefit.DependentAssociationList;
                    for (var j = 0; j < dependentAssociationList.length; j++) {
                        var matchingDep = _.find(dependents, function (dep) {
                            return dep.Ssn === dependentAssociationList[j];
                        });
                        if (matchingDep && _.includes(relTypes, matchingDep.RelationType)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        },

        IsBenefitElected: function (dom, benefitId) {
            var isElected = false;
            var electedBenefits = this.GetObjects(dom.ElectedBenefits, "BenefitId", benefitId);
            isElected = (electedBenefits && electedBenefits[0]);
            return isElected;
        },
        NotBenefitElected: function (dom, benefitId) {
            return !(this.IsBenefitElected(dom, benefitId));
        },

        IsBenefitPlanElected: function (dom, benefitId, planId) {
            var isElected = false;
            var electedBenefits = this.GetObjects(dom.ElectedBenefits, "BenefitId", benefitId);
            if (electedBenefits && electedBenefits[0]) {
                var electedBenefit = electedBenefits[0];
                isElected = (electedBenefit.PlanId == planId);
            }
            return isElected;
        },
        NotBenefitPlanElected: function (dom, benefitId, planId) {
            return !(this.IsBenefitPlanElected(dom, benefitId, planId));
        },
        IsBenefitPlanOptionElected: function (dom, benefitId, planId, optionId) {
            var isElected = false;
            var electedBenefits = this.GetObjects(dom.ElectedBenefits, "BenefitId", benefitId);
            if (electedBenefits && electedBenefits[0]) {
                var electedBenefit = electedBenefits[0];
                if (planId) {
                    isElected = ((electedBenefit.PlanId == planId) && (electedBenefit.OptionId == optionId));
                }
                else {
                    isElected = (electedBenefit.OptionId == optionId);
                }
            }
            return isElected;
        },
        NotBenefitPlanOptionElected: function (dom, benefitId, planId, optionId) {
            return !(this.IsBenefitPlanOptionElected(dom, benefitId, planId, optionId));
        },
        IsDepCurrentlyCovered: function (dom, benefitId) {
            return (dom.CurrentBenefitCoverage && (_(dom.CurrentBenefitCoverage).includes(benefitId)));
        },
        IsDepCoveredAsEmployee: function (params, benefitId) {
            return !!_.find(params.CoverageAsEmployee, { BenefitId: benefitId }); 
        },
        IsDepCoveredBySpouse: function (dom, benefitId) {
            var benefitsCoveredBySpouse = dom.BenefitsCoveredBySpouse;
            if (benefitsCoveredBySpouse) {
                var benefits = benefitsCoveredBySpouse.split(',');
                for (var j = 0; j < benefitsCoveredBySpouse.length; j++) {
                    if (benefitId === benefits[j]) {
                        return true;
                    }
                }
            }
            return false;
        },
        IsDepRelationTypeACoveredEmployee: function (dom, relationshipTypes) {
            var relType;
            var dependents = dom.Dependents;
            if (dependents) {
                var relTypes = relationshipTypes.split(',');
                for (var j = 0; j < dependents.length; j++) {
                    for (var i = 0; i < relTypes.length; i++) {
                        if (dependents[j].RelationType === relTypes[i] && dependents[j].HasCoverageAsEmployee) {
                            return true;
                        }
                    }
                }
            }
            return false;
        },
        HasDependentRelationshipType: function (dom, relationshipTypes) {
            var hasDependentRelationshipType = false;
            var relType;
            var relTypes = relationshipTypes.split(',');
            var i;
            for (i = 0; i < relTypes.length; i++) {
                var dependents = this.GetObjects(dom, "RelationType", relTypes[i]);
                if (dependents && dependents[0]) {
                    hasDependentRelationshipType = true;
                }
            }
            return hasDependentRelationshipType;
        },
        NotHasDependentRelationshipType: function (dom, relationshipTypes) {
            return !(this.HasDependentRelationshipType(dom, relationshipTypes));
        },
        HasDependentUnderTheAge: function (dom, relationshipTypes, age, effectiveDate) {
            var relType;
            var relTypes = relationshipTypes.split(',');
            var i, j;
            for (i = 0; i < relTypes.length; i++) {
                var dependents = this.GetObjects(dom, "RelationType", relTypes[i]);
                if (dependents) {
                    for (j = 0; j < dependents.length; j++) {
                        var dependentAge = this.Age(new Date(dependents[j].BirthDate), (effectiveDate) ? new Date(effectiveDate) : undefined);
                        if (dependentAge < age) {
                            return true;
                        }
                    }
                }
            }
            return false;
        },
        GetCompanyPlanYearQuestionAnswer: function (dom, benefitId, seq) {
            if (!dom.CompanyPlanYearQuestions) {
                return '';
            }

            var providedAnswer = _.find(dom.CompanyPlanYearQuestions, function (question) {
                return (question.BenefitId === benefitId && question.Seq === seq);
            });

            if (!providedAnswer) {
                return '';
            }

            return providedAnswer.Answer;
        },
        GetAnswerForQuestion: function(dom, questionType) {
            var matchingAs = _.find(_.map(_.keys(dom.Questionnaires), function(val) {
                if (dom.Questionnaires[val].Answers[questionType]) {
                    return dom.Questionnaires[val].Answers[questionType].Value;
                }
            }));

            if (matchingAs) {
                return matchingAs[0];
            }
        },
        HasAnswerForQuestion: function(dom, questionType) {
	        var re = new RegExp('^'+questionType.replace(/\*/g,'.*').replace(/\?/g,'.')+'$');	    
	        var matches = _.find(dom.Questionnaires, function (val, key) {
	            return _.find(val.Answers, function (ansVal, ansKey) {
	                return (re.test(ansKey));
	            });
	        });

	        return _.some(matches);
        },
        FindFrozenPlanYearData: function (dom, frozenElement, benefitCategory, benefitId, planId) {
            var frozenPlanYearData = null;
            if (dom.FrozenPlanYearData) {
                var frozenPlanYearDataList = _.filter(dom.FrozenPlanYearData, { 'FrozenElement' : frozenElement });

                if (frozenPlanYearDataList) {
                    if (benefitId && planId && this.IsBenefitPlanElected(dom, benefitId, planId)) {
                        frozenPlanYearData = _.find(frozenPlanYearDataList, function (frozenData) {
                            return (frozenData.BenefitId === benefitId && frozenData.PlanId === planId);
                        });
                        if (!frozenPlanYearData) {
                            frozenPlanYearData = _.find(frozenPlanYearDataList, function (frozenData) {
                                return (frozenData.BenefitId === benefitId && frozenData.PlanId === '*ALL*');
                            });
                            if (!frozenPlanYearData) {
                                frozenPlanYearData = _.find(frozenPlanYearDataList, function (frozenData) {
                                    return (frozenData.BenefitId === '*ALL*' && frozenData.PlanId === '*ALL*');
                                });
                            }
                        }
                    }
                    else if (benefitId && !planId && this.IsBenefitElected(dom, benefitId)) {
                        frozenPlanYearData = _.find(frozenPlanYearDataList, function (frozenData) {
                            return (frozenData.BenefitId === benefitId);
                        });
                        if (!frozenPlanYearData) {
                            frozenPlanYearData = _.find(frozenPlanYearDataList, function (frozenData) {
                                return (frozenData.BenefitId === '*ALL*');
                            });
                        }
                    }
                    else if (benefitCategory) {
                        var electedBenefits = dom.ElectedBenefits;
                        var electedBenefit = _.find(electedBenefits, function (benefit) {
                            return (benefit.BenefitGroupingID === benefitCategory);
                        });
                        if (electedBenefit) {
                            frozenPlanYearData = _.find(frozenPlanYearDataList, function (frozenData) {
                                return (frozenData.BenefitCategory === benefitCategory);
                            });
                        }
                    }
                }
            }
            return frozenPlanYearData;
        },
        GetFrozenAmt: function (dom, frozenElement, benefitCategory, benefitId, planId) {
            var frozenAmt = 0;
            var frozenPlanYearData = this.FindFrozenPlanYearData(dom, frozenElement, benefitCategory, benefitId, planId);
            if (frozenPlanYearData) {
                frozenAmt = frozenPlanYearData.FrozenAmt;
            }
            return frozenAmt;
        },
        GetFrozenData: function (dom, frozenElement, benefitCategory, benefitId, planId) {
            var frozenData = '';
            var frozenPlanYearData = this.FindFrozenPlanYearData(dom, frozenElement, benefitCategory, benefitId, planId);
            if (frozenPlanYearData) {
                frozenData = frozenPlanYearData.FrozenData;
            }
            return frozenData;
        }
    };

    engine.evaluateFiltered = function (rulesSource, ruleName, data, filter, context) {
        var initial = {
            fn: window.fn,
            obj: window.obj,
            context: window.context,
        };

        var rule = getRule(rulesSource, ruleName);

        try {
            if (context === undefined) {
                context = {};
            }

            // Do not remove as it is used implicitly in eval below
            window.fn = engine;
            window.obj = data;
            window.context = context;

            if (_.isArray(rule)) {
                return _(rule)
                    .compact()
                    .filter(filter)
                    .map(executeRule)
                    .value();
            }

            if (rule && filter(rule)) {
                return executeRule(rule);
            }

            return null;

        } finally {
            // Do not remove as it reverts changes made above
            window.fn = initial.fn;
            window.obj = initial.obj;
            window.context = initial.context;
        }

        function executeRule(rule) {
            // eval uses fn, obj and context fields defined above implicitly
            return eval(rule.definition);
        }
    };

    engine.evaluate = function (rulesSource, ruleName, data, context) {
        return engine.evaluateFiltered(rulesSource, ruleName, data, filter, context);

        function filter() {
            return true;
        }
    };

    engine.ruleExists = function (rulesSource, ruleName) {
        return !!getRule(rulesSource, ruleName);
    };

    return engine;

    function getRule(rulesSource, ruleName) {
        return _(rulesSource.JavascriptRules)
            .find(function (value, key) {
                return key.toUpperCase() === ruleName.toUpperCase();
            });
    }
}
]);
