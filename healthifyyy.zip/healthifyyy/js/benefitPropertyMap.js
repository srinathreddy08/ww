﻿angular.module('mercer.db.shared').constant('benefitPropertyMap', {
    'HUB': {
        icon: 'benefit-hub'
    },
    'PSA': {
        icon: 'benefit-accounts'
    },
    'TSA': {
        icon: 'benefit-accounts'
    },
    'SUPPADD': {
        icon: 'benefit-adandd'
    },
    'ACCIDENT': {
        icon: 'benefit-accident-insurance'
    },
    'CRITILL': {
        icon: 'benefit-critical-illness'
    },
    'HOSPITAL': {
        icon: 'benefit-hospital-indemnity'
    },
    'SPLIFE': {
        icon: 'benefit-spouse-life'
    },
    'CHLIFE': {
        icon: 'benefit-life-child'
    }
});