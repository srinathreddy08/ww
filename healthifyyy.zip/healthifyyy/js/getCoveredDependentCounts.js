﻿'use strict';
angular.module('mercer.services').factory('getCoveredDependentCounts', [
    'dependentVerificationService', 'benefitCategoriesService',
    function(dependentVerificationService, benefitCategoriesService) {
        return function (employee, elections, employeeData, benefitCategory, ignorePendingVerification, leCompleteMode) {
            if (!employee) {
                employee = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
            }

            const relationTypes = {
                spouse: 'SP',
                sameSexSpouse: 'SGSP',
                domesticPartner: 'DP',
                domesticPartnerChild: 'CDP',
                disabledDomesticPartnerChild: 'DCDP',
                child: 'CH',
                disabledChild: 'DISCH',
                fs: 'FS',
                ld: 'LD',
                sameSexChild: 'SGCH'
            };

            const dependents = ignorePendingVerification === 'true' ? getDependentsIgnoreVerification() :  getDependents();
            var unverifiedDependents = getUnverifiedDependents();
            var coveredDependents = getCoveredDependents(leCompleteMode);
            var coveredUnverifiedDependents = getCoveredUnverifiedDependents();

            return {
                AllSpouses: dependentTypeCount([relationTypes.spouse, relationTypes.sameSexSpouse, relationTypes.domesticPartner]),
                Spouses: dependentTypeCount([relationTypes.spouse]),
                DomesticPartners: dependentTypeCount([relationTypes.domesticPartner]),
                SameSexSpouses: dependentTypeCount([relationTypes.sameSexSpouse]),
                AllChildren: dependentTypeCount([relationTypes.domesticPartnerChild, relationTypes.disabledDomesticPartnerChild, relationTypes.child, relationTypes.disabledChild, relationTypes.fs, relationTypes.ld]),
                Children: dependentTypeCount([relationTypes.child, relationTypes.disabledChild, relationTypes.fs, relationTypes.ld]),
                DomesticPartnerChildren: dependentTypeCount([relationTypes.domesticPartnerChild, relationTypes.disabledDomesticPartnerChild]),
                SameSexChildren: dependentTypeCount([relationTypes.sameSexChild]),
                UnverifiedAllSpouses: unverifiedDependentTypeCount([relationTypes.spouse, relationTypes.sameSexSpouse, relationTypes.domesticPartner]),
                UnverifiedSpouses: unverifiedDependentTypeCount([relationTypes.spouse]),
                UnverifiedDomesticPartners: unverifiedDependentTypeCount([relationTypes.domesticPartner]),
                UnverifiedSameSexSpouses: unverifiedDependentTypeCount([relationTypes.sameSexSpouse]),
                UnverifiedAllChildren: unverifiedDependentTypeCount([relationTypes.domesticPartnerChild, relationTypes.disabledDomesticPartnerChild, relationTypes.child, relationTypes.disabledChild, relationTypes.fs, relationTypes.ld]),
                UnverifiedChildren: unverifiedDependentTypeCount([relationTypes.child, relationTypes.disabledChild, relationTypes.fs, relationTypes.ld]),
                UnverifiedDomesticPartnerChildren: unverifiedDependentTypeCount([relationTypes.domesticPartnerChild, relationTypes.disabledDomesticPartnerChild]),
                UnverifiedSameSexChildren: unverifiedDependentTypeCount([relationTypes.sameSexChild]),
                AllDependents: _(coveredDependents).keys().size()
            };

            function getDependents() {
                return _(employee.Dependents)
                    .reject(isVerificationRequiredForDependent)
                    .keyBy('Ssn')
                    .value();
            }

            function getUnverifiedDependents() {
                return _(employee.Dependents)
                    .filter(isVerificationRequiredForDependent)
                    .keyBy('Ssn')
                    .value();
            }

            function isVerificationRequiredForDependent(dependent) {
                if (employee.LifeEvents[0].LifeEventID === '55' && dependentVerificationService.forData(employeeData).isCurrentCoverageHaveNotDevForDependent(dependent)) return false;

                return dependentVerificationService
                    .forData(employeeData)
                    .dependentIsCountedAsUnverified(dependent, elections, benefitCategory);
            }

            function getDependentsIgnoreVerification() {
                return _(employee.Dependents).keyBy('Ssn').value();
            }

            function dependentTypeCount(relationshipCodes) {
                var relationshipCodesMap = _.keyBy(relationshipCodes);

                return _(coveredDependents)
                    .filter(function(dependent) {
                        return relationshipCodesMap[dependent.RelationType];
                    })
                    .size();
            }

            function unverifiedDependentTypeCount(relationshipCodes) {
                var relationshipCodesMap = _.keyBy(relationshipCodes);

                return _(coveredUnverifiedDependents)
                    .filter(function(dependent) {
                        return relationshipCodesMap[dependent.RelationType];
                    })
                    .size();
            }

            function getCoveredDependents(leCompleteMode) {
                var benefitIds = benefitCategoriesService.getBenefitIds(employee, benefitCategory);

                var coveredDependentsSsns = _(elections)
                    .pick(benefitIds)
                    .map('DependentAssociationList')
                    .flattenDeep()
                    .uniq()
                    .value();

                var returnObject;
                if (leCompleteMode === 'true') {
                    var depSsnList = _.map(coveredDependentsSsns, 'DependentSsn');
                    returnObject = _(dependents)
                        .pick(depSsnList)
                        .value();
                } else {
                    returnObject = _(dependents)
                        .pick(coveredDependentsSsns)
                        .value();
                }

                return returnObject;
            }

            function getCoveredUnverifiedDependents() {
                var benefitIds = benefitCategoriesService.getBenefitIds(employee, benefitCategory);

                var coveredDependentsSsns = _(elections)
                    .pick(benefitIds)
                    .map('DependentAssociationList')
                    .flattenDeep()
                    .uniq()
                    .value();

                return _(unverifiedDependents)
                    .pick(coveredDependentsSsns)
                    .value();
            }
        }
    }
]);