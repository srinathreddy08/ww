angular.module('mercerApp').controller('healthBenefitsDentalController', ['$rootScope', '$scope', 'navigationService', 'healthData', 'coverageDataSource', function ($rootScope, $scope, navigationService, healthData, coverageDataSource) {
  this.$onInit = function () {
    // SET NAVIGATION
    navigationService.setCurrentTabByKeys('healthinsurance', 'dental');
    $scope.healthData = healthData;
    $scope.coverageDataSource = coverageDataSource;
  };
}]);