angular.module('mercerApp').controller('healthBenefitsMedicalController', ['$rootScope', '$scope', 'navigationService', 'healthData', 'coverageDataSource', function ($rootScope, $scope, navigationService, healthData, coverageDataSource) {
  this.$onInit = function () {
    // SET NAVIGATION
    navigationService.setCurrentTabByKeys('healthinsurance', 'medical');
    $scope.healthData = healthData;
    $scope.coverageDataSource = coverageDataSource;

  };
}]);