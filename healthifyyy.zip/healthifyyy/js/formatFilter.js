﻿'use strict';
angular.module('mercer.db.shared').filter('format', [
    '$parse', '$filter', '$log',
    function ($parse, $filter, $log) {
        return function (value, dataSources, replaceWhenEmpty) {
            if (!angular.isString(value)) {
                return value;
            }

            return _.reduce(dataSources,
                function (currentValue, dataSource) {
                    var executeFormatter = getFormatter(currentValue, dataSource, replaceWhenEmpty);

                    return executeFormatter();
                },
                value);
        };

        function getFormatter(value, dataSource, replaceWhenEmpty) {
            if (!angular.isArray(dataSource) && !angular.isObject(dataSource)) {
                dataSource = [dataSource];
            }

            return function () {
                if (angular.isArray(dataSource)) {
                    return replaceArrayElementTokens();
                }

                if (replaceWhenEmpty) {
                    try {
                        return replaceObjectElementTokens();
                    } catch (ex) {
                        return null;
                    }
                } else {
                    return replaceObjectElementTokens();
                }
            }

            function replaceArrayElementTokens() {
                return value.replace(/\$([0-9]+)/g, replaceArrayElementToken);
            }

            function replaceArrayElementToken(matchedString, key) {
                var index = parseInt(key, 10);
                return (index >= 0 && index < dataSource.length) ? dataSource[index] : matchedString;
            }

            function replaceObjectElementTokens() {
                return value.replace(/\[\$([^$]+)\$\]/g, replaceObjectElementToken);
            }

            function replaceObjectElementToken(matchedString, key) {
                var segments = key.split(':');
                var format = extractFormat(segments);
                var currentData;
                if (replaceWhenEmpty) {
                    currentData = executeExpression(segments);

                    if (typeof (currentData) === 'undefined' || currentData === null) {
                        var message = '"' + matchedString + '" was evaluated to ' + currentData;

                        $log.error(message);
                        throw new Error(message);
                    }

                    return applyFormat(currentData, format);
                } else {
                    try {
                        currentData = executeExpression(segments);

                        if (!currentData) {
                            return matchedString;
                        }
                        return applyFormat(currentData, format) || matchedString;
                    } catch (e) {
                        return matchedString;
                    }
                }
            }

            function applyFormat(currentData, format) {
                if (!format) {
                    return currentData;
                }

                switch (format) {
                case 'currency':
                    return $filter('currency')(currentData, '$');
                case 'date':
                    return $filter('date')(new Date(Date.parse(currentData)), 'MMMM dd, yyyy');
                default:
                    return $filter(format)(currentData);
                }
            }

            function executeExpression(segments) {
                var result = dataSource;
                var i = 0;

                while (result && i < segments.length) {
                    var currentSegment = segments[i];
                    var fieldValue = result[currentSegment];

                    if (fieldValue === 0 || fieldValue === null) {
                        //Null values should show as 0 per client
                        return '0';
                    }

                    result = fieldValue || $parse(currentSegment)(result);

                    i++;
                }

                return result;
            }

            function extractFormat(segments) {
                var lastSegment = segments[segments.length - 1];
                if (lastSegment.indexOf('format') === -1) {
                    return null;
                }

                var result = lastSegment.split(' ')[1];
                segments.splice(-1, 1);
                return result;
            }
        }
    }
]);