﻿'use strict';
angular.module('mercer.services').factory('getRepriceableBenefitIds', [
    'getRepriceBenefitRelations',
    function (getRepriceBenefitRelations) {
        return getRepriceableBenefitIds;

        function getRepriceableBenefitIds(employeeData) {
            var repriceBenefitRelations = getRepriceBenefitRelations(employeeData);

            var relatedBenefits = _(repriceBenefitRelations)
                .flatMap('RelatedBenefits')
                .value();

            return _(repriceBenefitRelations)
                .keys()
                .concat(relatedBenefits)
                .uniq()
                .value();
        }
    }
]);