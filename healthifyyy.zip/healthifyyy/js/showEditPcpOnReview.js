'use strict';
angular.module('mercer.services')
    .factory('showEditPcpOnReview',
    [
        'showEditPcpOverlayIfNeeded', function(showEditPcpOverlayIfNeeded) {
            return function(newElections, employeeData, shoppingCart, isReviewMode) {

                if (_.every(newElections, { benefit: null })) {
                    return null;
                }

                var additionalConditions = function() {
                    return true;
                };

                var showAllIndividualsRequiringPcp = function(individuals) {
                    return individuals;
                };

                return showEditPcpOverlayIfNeeded(newElections, employeeData, additionalConditions,
                    showAllIndividualsRequiringPcp, shoppingCart.ShoppingCart, isReviewMode);
            };
        }
    ]);