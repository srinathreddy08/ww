'use strict';
angular.module('mercer.db.shared').service('logService', [
    '$log', '$cookies', 'logSources',
    function ($log, $cookies, logSources) {
        var devToolsLoggerName = 'MBCDevTools';

        var currentLogSources = createLogSources();
        var loggedItems = [];

        var loggers = _(currentLogSources)
            .mapValues(function(x, logSourceName) {
                return createLogger(logSourceName);
            })
            .value();

        return {
            clear: clear,
            getLoggedItems: getLoggedItems,
            getLogger: getLogger,
            getLogSources: getLogSources,
            setLogSources: setLogSources
        };

        function clear() {
            loggedItems = [];
        }

        function getLoggedItems() {
            return _(loggedItems)
                .map(function(item) {
                    return JSON.parse(item);
                })
                .value();
        }

        function createLogSources() {
            var changedLogSourceNamesAsObject = _(($cookies.get('debugLog') || '').split(','))
                .map(function (logSourceName) {
                    return logSourceName.trim();
                })
                .without('')
                .uniq()
                .keyBy(function (logSourceName) {
                    return logSourceName;
                })
                .value();

            return _(logSources)
                .mapValues(function (isEnabledByDefault, logSourceName) {
                    return {
                        name: logSourceName,
                        isEnabledByDefault: isEnabledByDefault,
                        isEnabled: (logSourceName in changedLogSourceNamesAsObject) ? !isEnabledByDefault : isEnabledByDefault
                    };
                })
                .value();
        }

        function getLogSources() {
            return currentLogSources;
        }

        function setLogSources(newLogSources) {
            currentLogSources = newLogSources;

            var changedLogSourceNames = _(currentLogSources)
                .pickBy(function (logSource) {
                    return logSource.isEnabledByDefault !== logSource.isEnabled;
                })
                .keys()
                .value();

            $cookies.put('debugLog', changedLogSourceNames.join(','));
        }

        function getLogger(logSourceName) {
            var logger = loggers[logSourceName];

            if (logger) {
                return logger;
            }

            loggers[devToolsLoggerName]
                .warn('Creating logger (enabled by default) for unknown log source ' + logSourceName + '. Known are [' + logSources.join(', ') + ']. Register log source in logSources.js or fix the name.');

            logSources[logSourceName] = true;
            currentLogSources[logSourceName] = {
                name: logSourceName,
                isEnabledByDefault: true,
                isEnabled: true
            };
            loggers[logSourceName] = createLogger(logSourceName);

            return loggers[logSourceName];
        }

        function createLogger(logSourceName) {
            var commonArgs = [logSourceName];

            return {
                log: createLoggerFunction('log'),
                info: createLoggerFunction('info'),
                warn: createLoggerFunction('warn'),
                error: createLoggerFunction('error'),
                debug: createLoggerFunction('debug')
            };

            function createLoggerFunction(level) {
                return loggerFunction;

                function loggerFunction() {
                    if (!isLogEnabled(logSourceName)) {
                        return;
                    }

                    $log[level].apply($log, commonArgs.concat.apply(commonArgs, arguments));

                    loggedItems.push(JSON.stringify({
                        source: logSourceName,
                        level: level,
                        time: new Date(),
                        details: Array.prototype.slice.call(arguments)
                    }));
                }
            }
        }

        function isLogEnabled(logSourceName) {
            return currentLogSources[logSourceName].isEnabled;
        }
    }
]);