﻿'use strict';
angular.module('mercer.services')
    .factory('without',
    ['_', function(_) {
            return function(a, b) {
                return _(a)
                    .reject(function(x) {
                        return _(b).includes(x);
                    })
                    .value();
            };
        }
    ]);