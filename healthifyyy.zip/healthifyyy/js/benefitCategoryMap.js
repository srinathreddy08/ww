﻿angular.module('mercer.db.shared').constant('benefitCategoryMap', {
    // NOTE: don't use 'Name' property in the new functionality, it is deprecated
    MEDICAL: {
        isComparison: true,
        isAdditional: false,
        isPcpCategory: true,
        isAccountContribution: false,
        Alias: 'HB.Common.CommonTerms.MedicalBenefitCategory',
        url: 'medical',
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.MedicalHelp'
        },
        icon: 'benefit-medical'
    },
    O65MED: {
        isComparison: true,
        isAdditional: false,
        isPcpCategory: false,
        isAccountContribution: false,
        Alias: 'HB.Common.CommonTerms.Over65MedicalBenefitCategory',
        url: 'medical-over65',
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.OverMedicalHelp'
        },
        icon: null
    },
    U65MED: {
        isComparison: true,
        isAdditional: false,
        isPcpCategory: false,
        isAccountContribution: false,
        Alias: 'HB.Common.CommonTerms.Under65MedicalBenefitCategory',
        url: 'medical-under65',
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.UnderMedicalHelp'
        },
        icon: null
    },
    DENTAL: {
        isComparison: true,
        isAdditional: false,
        isPcpCategory: true,
        isAccountContribution: false,
        Alias: 'HB.Common.CommonTerms.DentalBenefitCategory',
        url: 'dental',
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.DentalHelp'
        },
        icon: 'benefit-dental'
    },
    VISION: {
        isComparison: true,
        isAdditional: false,
        isPcpCategory: false,
        isAccountContribution: false,
        Alias: 'HB.Common.CommonTerms.VisionBenefitCategory',
        url: 'vision',
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.VisionHelp'
        },
        icon: 'benefit-vision'
    },

    ADDITIONAL: {
        Name: 'ADDITIONAL',
        isComparison: false,
        isAdditional: true,
        isPcpCategory: false,
        isAccountContribution: false,
        isLifeInsuranceCategory: true,
        url: 'additional-benefits',
        Alias: 'HB.Common.CommonTerms.AdditionalBenefitsBenefitCategory',
        IntroductionAlias: 'HB.LifeEvent.AdditionalBenefits.IntroductionText',
        BenefitAliasPrefix: 'HB.LifeEvent.ChooseBenefits.AdditionalBenefits',
        AgreementAliasPrefix: null,
        HasBeneficiaries: true,
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.AdditionalBenefitsHelp'
        },
        Summary: {
            HelpAlias: 'HB.LifeEvent.Summary.AdditionalBenefitsHelp',
            RailPage: 'ADDITIONAL'
        },
        icon: 'benefit-legal'
    },
    'LIFE INSURANCE': {
        Name: 'LIFE INSURANCE',
        isComparison: false,
        isAdditional: true,
        isPcpCategory: false,
        isAccountContribution: false,
        isLifeInsuranceCategory: true,
        url: 'life-insurance',
        Alias: 'HB.Common.CommonTerms.LifeBenefitCategory',
        IntroductionAlias: 'HB.LifeEvent.Life.IntroductionText',
        BenefitAliasPrefix: 'HB.LifeEvent.ChooseBenefits.Life',
        AgreementAliasPrefix: null,
        HasBeneficiaries: true,
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.LifeHelp'
        },
        Summary: {
            HelpAlias: 'HB.LifeEvent.Summary.LifeHelp',
            RailPage: 'LIFE_DIS'
        },
        icon: 'benefit-life'
    },
    SUPPLEMENTAL: {
        Name: 'SUPPLEMENTAL',
        isComparison: false,
        isAdditional: true,
        isPcpCategory: false,
        isAccountContribution: false,
        url: 'supplemental',
        Alias: 'HB.Common.CommonTerms.SupplementalBenefitCategory',
        IntroductionAlias: 'HB.LifeEvent.Supplemental.IntroductionText',
        BenefitAliasPrefix: 'HB.SupplementalBenefits.BenefitDetails',
        AgreementAliasPrefix: 'HB.SupplementalBenefits.Disclaimer',
        HasBeneficiaries: true,
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.SupplementalHelp'
        },
        Summary: {
            HelpAlias: 'HB.LifeEvent.Summary.SupplementalHelp',
            RailPage: 'HEALTH'
        },
        icon: null
    },
    SPENDING: {
        Name: 'SPENDING',
        isComparison: false,
        isAdditional: false,
        isPcpCategory: false,
        isAccountContribution: true,
        Alias: 'HB.Common.CommonTerms.SpendingBenefitCategory',
        url: 'accounts',
        IntroductionAlias: null,
        BenefitAliasPrefix: 'HB.LifeEvent.ChooseBenefits.Accounts',
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.SpendingHelp'
        },
        Summary: {
            HelpAlias: null,
            RailPage: null
        },
        icon: 'benefit-accounts'
    },
    DISABILITY: {
        Name: 'DISABILITY',
        isComparison: false,
        isAdditional: true,
        isPcpCategory: false,
        isAccountContribution: false,
        Alias: 'HB.Common.CommonTerms.DisabilityBenefitCategory',
        url: 'disability-insurance',
        IntroductionAlias: 'HB.LifeEvent.Disability.IntroductionText',
        BenefitAliasPrefix: 'HB.LifeEvent.ChooseBenefits.Disability',
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.DisabilityHelp'
        },
        Summary: {
            HelpAlias: 'HB.LifeEvent.Summary.DisabilityHelp',
            RailPage: 'LIFE_DIS'
        },
        icon: 'benefit-disability'
    },
    PROTECTION: {
        Name: 'PROTECTION',
        isComparison: false,
        isAdditional: true,
        isPcpCategory: false,
        isAccountContribution: false,
        Alias: 'HB.Common.CommonTerms.ProtectionBenefitCategory',
        url: 'protection',
        IntroductionAlias: 'HB.LifeEvent.Protection.IntroductionText',
        BenefitAliasPrefix: 'HB.LifeEvent.ChooseBenefits.Protection',
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: 'HB.LifeEvent.ChooseBenefits.ProtectionHelp'
        },
        Summary: {
            HelpAlias: 'HB.LifeEvent.Summary.ProtectionHelp',
            RailPage: 'PROTECTION'
        },
        icon: 'benefit-identity-theft'
    },
    ACCRUAL: {
        Name: 'ACCRUAL',
        isComparison: false,
        isAdditional: true,
        isPcpCategory: false,
        isAccountContribution: false,
        Alias: 'HB.Common.CommonTerms.AccrualAcct',
        url: '',
        IntroductionAlias: null,
        BenefitAliasPrefix: 'HB.LifeEvent.AccurualAcct.Detail',
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: null
        },
        Summary: {
            HelpAlias: 'HB.LifeEvent.AccrualAcct.AccrualAcctHelp',
            RailPage: 'HEALTH'
        }
    },
    VB_AUTOHOME: {
        Name: 'VB_AUTOHOME',
        isComparison: null,
        isAdditional: null,
        isAccountContribution: null,
        Alias: null,
        url: '',
        IntroductionAlias: null,
        BenefitAliasPrefix: null,
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: null
        },
        Summary: {
            HelpAlias: null,
            RailPage: null
        },
        icon: 'benefit-home-auto',
        VoluntaryCategoryKey: 'AutoHome'
    },
    VB_PET: {
        Name: 'VB_PET',
        isComparison: null,
        isAdditional: null,
        isAccountContribution: null,
        Alias: null,
        url: '',
        IntroductionAlias: null,
        BenefitAliasPrefix: null,
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: null
        },
        Summary: {
            HelpAlias: null,
            RailPage: null
        },
        icon: 'benefit-pet',
        VoluntaryCategoryKey: 'Pet'
    },
    VB_PERSONALPROTECTION: {
        Name: 'VB_PERSONALPROTECTION',
        isComparison: null,
        isAdditional: null,
        isAccountContribution: null,
        Alias: null,
        url: '',
        IntroductionAlias: null,
        BenefitAliasPrefix: null,
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: null
        },
        Summary: {
            HelpAlias: null,
            RailPage: null
        },
        icon: null,
        VoluntaryCategoryKey: 'PersonalProtection'
    },
    VB_AUTO: {
        Name: 'VB_AUTO',
        isComparison: null,
        isAdditional: null,
        isAccountContribution: null,
        Alias: null,
        url: '',
        IntroductionAlias: null,
        BenefitAliasPrefix: null,
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: null
        },
        Summary: {
            HelpAlias: null,
            RailPage: null
        },
        icon: null,
        VoluntaryCategoryKey: 'Auto'
    },
    VB_HOME: {
        Name: 'VB_HOME',
        isComparison: null,
        isAdditional: null,
        isAccountContribution: null,
        Alias: null,
        url: '',
        IntroductionAlias: null,
        BenefitAliasPrefix: null,
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: null
        },
        Summary: {
            HelpAlias: null,
            RailPage: null
        },
        icon: null,
        VoluntaryCategoryKey: 'Home'
    },
    VB_SAVINGS: {
        Name: 'VB_SAVINGS',
        isComparison: null,
        isAdditional: null,
        isAccountContribution: null,
        Alias: null,
        url: '',
        IntroductionAlias: null,
        BenefitAliasPrefix: null,
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: null
        },
        Summary: {
            HelpAlias: null,
            RailPage: null
        },
        icon: null,
        VoluntaryCategoryKey: 'Savings'
    },
    VB_OTHER: {
        Name: 'VB_OTHER',
        isComparison: null,
        isAdditional: null,
        isAccountContribution: null,
        Alias: null,
        url: '',
        IntroductionAlias: null,
        BenefitAliasPrefix: null,
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: null
        },
        Summary: {
            HelpAlias: null,
            RailPage: null
        },
        icon: null,
        VoluntaryCategoryKey: 'Other'
    },
    "default": {
        Name: null,
        isComparison: null,
        isAdditional: null,
        isPcpCategory: null,
        isAccountContribution: null,
        Alias: null,
        url: '',
        IntroductionAlias: null,
        BenefitAliasPrefix: null,
        AgreementAliasPrefix: null,
        HasBeneficiaries: false,
        ChooseBenefits: {
            HelpAlias: null
        },
        Summary: {
            HelpAlias: null,
            RailPage: null
        },
        icon: 'benefit-accounts'
    }
});