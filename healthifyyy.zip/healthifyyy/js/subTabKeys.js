﻿angular.module('mercer.services').constant('subTabKeys', {
    summary: 'summary',
});
