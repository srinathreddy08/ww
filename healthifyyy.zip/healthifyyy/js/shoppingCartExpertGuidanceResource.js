﻿'use strict';
angular.module('mercer.hb').factory('shoppingCartExpertGuidanceResource', [
    '$q', 'logService', 'expertGuidanceResource',
    function ($q, logService, expertGuidanceResource) {
        var logger = logService.getLogger('MissingShoppingCartFunctionInExpertGuidanceFlow');

        return {
            isExpertGuidance: true,
            cacheKeyPrefix: 'EG',
            get: get,
            visit: visit,
            batchAdd: batchAdd,
            submit: submit,
            load: load,
            clear: clear
        };

        function get() {
            return expertGuidanceResource.getSuggestedPackage();
        }

        function visit(options) {
            logger.info('visit', options);
            return { $promise: $q.resolve(null) };
        }

        function batchAdd(options) {
            return expertGuidanceResource.updateSuggestedPackage(options);
        }

        function submit(lifeEvent) {
            logger.info('submit', lifeEvent);
            return { $promise: $q.resolve(null) };
        }

        function load(lifeEvent) {
            logger.info('load/calling getSuggestedPackage', lifeEvent);
            return expertGuidanceResource.getSuggestedPackage();
        }

        function clear() {
            return expertGuidanceResource.clearPackage();
        }
    }
]);
