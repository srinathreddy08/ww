﻿'use strict';
angular.module('mercerApp').factory('pcpService', [
    'showEditPcpOnReview', 'benefitsService', 'pcpOverlayDisplayService', 'mbcContentAndData',
    function(showEditPcpOnReview, benefitsService, pcpOverlayDisplayService, mbcContentAndData) {
        return {
            prepareDataAndShowEditPcpOnReview: prepareDataAndShowEditPcpOnReview,
            isPCPRequired: isPCPRequired,
            showPcp: showPcp
        };

        function showPcp(benefit, suggestedPackage) {
            var employeeData = mbcContentAndData.getEnrollment();

            return employeeData.$promise.then(function(data) {
                var benefitCategories = [benefit.BenefitCategory];
                return prepareDataAndShowEditPcpOnReview(data, suggestedPackage, false, benefitCategories);
            });
        }

        function prepareDataAndShowEditPcpOnReview(employeeData, shoppingCart, isReviewMode, benefitCategories) {
            var newElections = getNewElectionsForBenefitCategories(benefitCategories);

            return showEditPcpOnReview(newElections, employeeData, shoppingCart, isReviewMode);

            function findBenefit(benefitCategory) {
                return _(shoppingCart.ShoppingCart)
                    .find(function(benefit) {
                        return (benefit.BenefitCategory === benefitCategory);
                    });
            }

            function getNewElectionsForBenefitCategories(categories) {
                return _(categories)
                    .values()
                    .reduce(function(resultObject, benefitCategory) {
                        resultObject[benefitCategory] = { benefit: findBenefit(benefitCategory) };
                        return resultObject;
                    }, {});
            }
        }

        function isPCPRequired(election, benefit, employeeData) {
            if (!benefitsService.isPcpBenefit(benefit)) {
                return false;
            }

            return pcpOverlayDisplayService.pcpOverlayShouldBeShown(election, employeeData, additionalConditions);
            
            function additionalConditions() {
                return true;
            }
        }
    }
]);