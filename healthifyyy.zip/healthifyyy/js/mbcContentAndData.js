﻿'use strict';
angular.module('mercer.shared.content').factory('mbcContentAndData', [
    '$q', 'staticContent', 'mbcContentAndDataResourceFactory', 'transformOpenEnrollment', 'processTokensInData', 'globalCache', '$cacheFactory', 'supplementalTabService', 'domainAvailibility', 'contentAliasService',
    function ($q, staticContent, mbcContentAndDataResourceFactory, transformOpenEnrollment, processTokensInData, globalCache, $cacheFactory, supplementalTabService, domainAvailibility, contentAliasService) {
        var contentAndDataResource = mbcContentAndDataResourceFactory(globalCache['mbcContentAndData']);
        var contentAndDataResourceForConfirmationFlow = null;
        var mbcContentAndDataConfirmationFlowCacheKey = 'mbcContentAndDataConfirmationFlowCache';

        return {
            get: getData,
            getProcessedData: getProcessedData,
            getEnrollment: getEnrollment,
            getEnrollmentContentIgnoringRecentlySubmittedLifeEvent: getEnrollmentContentIgnoringRecentlySubmittedLifeEvent,
            getEnrollmentContent: getEnrollmentContent,
            setSubmittedLifeEvent: setSubmittedLifeEvent,
            forgetSubmittedLifeEvent: forgetSubmittedLifeEvent,
            refresh: refresh,
            remove: remove,
            clearWholeCache: clearWholeCache,
            getMegaNavPromise: getMegaNavPromise,
            getHbNavigationPromise: getHbNavigationPromise
        };

        function getEpSupplementalTabTitle(enrollmentContent) {
            var value = enrollmentContent.getEvaluationPointValue('HB.Common.CommonTerms.SupplementalCategory');
            return value && value.Title;
        }

        function getHbNavigationPromise() {
            return getEnrollment()
                .$promise
                .then(function (enrollment) {
                    return getData('nav-hb', transformHbNavigation).$promise;

                    function transformHbNavigation(data) {
                        if (supplementalTabService.forEnrollment(enrollment).showHealthInsuranceSubTab) {
                            data.HBNavigation = _.reject(data.HBNavigation, { Key: "supplemental" })
                            return data;
                        }

                        var healthInsuranceTab = _.find(data.HBNavigation, { Key: "healthinsurance" });
                        if (!healthInsuranceTab) {
                            return data;
                        }

                        healthInsuranceTab.SubNav = _.reject(healthInsuranceTab.SubNav, { Key: "supplemental" });

                        if (!_.some(healthInsuranceTab.SubNav)) {
                            data.HBNavigation = _.reject(data.HBNavigation, { Key: "healthinsurance" });
                        }

                        var enrollmentContent = contentAliasService.forData(enrollment);
                        var epSupplementalTabTitle = getEpSupplementalTabTitle(enrollmentContent);

                        if (!epSupplementalTabTitle) {
                            return data;
                        }

                        var supplementalTab = _.find(data.HBNavigation, { Key: 'supplemental' });

                        if (!supplementalTab) {
                            return data;
                        }

                        supplementalTab.Name = epSupplementalTabTitle;

                        return data;
                    }
                });
        }

        function getMegaNavPromise(hardRefresh) {
            return domainAvailibility.get().$promise
                .then(function (domainAvailabilityResult) {
                    if (domainAvailabilityResult.HbAvailable) {
                        return getEnrollment()
                            .$promise
                            .then(function (enrollment) {
                                return getData('nav',
                                    supplementalTabService.forEnrollment(enrollment).showSeparateTab
                                        ? transformMegaNavSeparateTab
                                        : transformMegaNavSubTab,
                                    hardRefresh).$promise;

                                function transformMegaNavSeparateTab(data) {
                                    var healthAndBenefitsTab = _.find(data.Data.Navigation.MegaNav.Items, { Id: 'HEALTHANDBENEFITS' });

                                    if (!healthAndBenefitsTab) {
                                        return data;
                                    }

                                    var supplementalTab = _.find(healthAndBenefitsTab.Items, { Id: 'SUPPLEMENTAL' });

                                    if (!supplementalTab) {
                                        return data;
                                    }

                                    var enrollmentContent = contentAliasService.forData(enrollment);
                                    var megaNavContent = contentAliasService.forData(data);

                                    var megaNavTabValue = megaNavContent.getContentValue(supplementalTab.ContentAlias);

                                    if (!megaNavTabValue) {
                                        return data;
                                    }

                                    var link = megaNavTabValue.Link;

                                    if (!link) {
                                        return data;
                                    }
                                    var epSupplementalTabTitle = getEpSupplementalTabTitle(enrollmentContent);

                                    if (!epSupplementalTabTitle) {
                                        return data;
                                    }

                                    link.Text = epSupplementalTabTitle;
                                    link.Title = epSupplementalTabTitle;

                                    return data;
                                }

                                function transformMegaNavSubTab(data) {
                                    var healthAndBenefitsTab = _.find(data.Data.Navigation.MegaNav.Items, { Id: 'HEALTHANDBENEFITS' });

                                    if (!healthAndBenefitsTab) {
                                        return data;
                                    }

                                    healthAndBenefitsTab.Items = _.reject(healthAndBenefitsTab.Items, { Id: 'SUPPLEMENTAL' });

                                    if (!_.some(healthAndBenefitsTab.Items)) {
                                        data.Data.Navigation.MegaNav.Items = _.rejext(data.Data.Navigation.MegaNav.Items, { Id: 'HEALTHANDBENEFITS' });
                                    }

                                    return data;
                                }
                            });
                    } else {
                        return getData('nav').$promise;
                    }
                });
        }

        function getData(sectionKey, transform, hardRefresh) {
            return contentAndDataResource.getData(sectionKey, transform, hardRefresh);
        }

        function getProcessedData(sectionKey, options) {
            return contentAndDataResource.getProcessedData(sectionKey, options);
        }

        function getEnrollmentContent() {
            return contentAndDataResource.getEnrollmentContent();
        }

        function getEnrollmentContentIgnoringRecentlySubmittedLifeEvent() {
            var resource = contentAndDataResourceForConfirmationFlow || contentAndDataResource;

            return resource.getEnrollmentContent();
        }

        function getEnrollment() {
            return contentAndDataResource.getEnrollment();
        }

        function setSubmittedLifeEvent(data, currentLifeEventData) {
            //This is used for setting the employee from the confirmation page.
            processTokensInData(data, [staticContent, currentLifeEventData]);
            transformOpenEnrollment(data);
            data.$promise = $q.when(data);
            contentAndDataResource.updateEnrollmentCache(data);

            contentAndDataResourceForConfirmationFlow = initContentAndDataResourceForConfirmationFlow();
        }

        function forgetSubmittedLifeEvent() {
            contentAndDataResource.clearWholeCache();

            clearConfirmationFlowCache();

            if (contentAndDataResourceForConfirmationFlow) {
                moveConfirmationFlowCacheToRegularCache();
                contentAndDataResourceForConfirmationFlow.clearWholeCache();
                contentAndDataResourceForConfirmationFlow = null;
            }
        }

        function moveConfirmationFlowCacheToRegularCache() {
            var enrollmentData = contentAndDataResourceForConfirmationFlow.getCachedEnrollmentData();
            if (enrollmentData) {
                contentAndDataResource.updateEnrollmentCache(enrollmentData);
            }
        }

        function refresh(reload) {
            contentAndDataResource.refresh(reload);
        }

        function clearWholeCache() {
            contentAndDataResource.clearWholeCache();
        }

        function remove(sectionKey) {
            contentAndDataResource.remove(sectionKey);
        }

        function clearConfirmationFlowCache() {
            if ($cacheFactory.info().mbcContentAndDataConfirmationFlowCache) {
                $cacheFactory.get(mbcContentAndDataConfirmationFlowCacheKey).removeAll();
            }
        }

        function initContentAndDataResourceForConfirmationFlow() {

            var mbcContentAndDataConfirmationFlowCache = null;

            if ($cacheFactory.info().mbcContentAndDataConfirmationFlowCache) {
                mbcContentAndDataConfirmationFlowCache = $cacheFactory.get(mbcContentAndDataConfirmationFlowCacheKey);
                mbcContentAndDataConfirmationFlowCache.removeAll();
            }
            else {
                mbcContentAndDataConfirmationFlowCache = $cacheFactory(mbcContentAndDataConfirmationFlowCacheKey);
            }

            return mbcContentAndDataResourceFactory(mbcContentAndDataConfirmationFlowCache);
        }
    }
]);
