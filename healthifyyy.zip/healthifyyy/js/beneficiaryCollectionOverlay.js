﻿'use strict';
angular.module('mercer.services').factory('beneficiaryCollectionOverlay', [
    'mbcContentAndData', 'showHeaderBodyButtonsOverlay', '$q', 'executeWithoutShoppingCartScroll',
    function (mbcContentAndData, showHeaderBodyButtonsOverlay, $q, executeWithoutShoppingCartScroll) {
        return beneficiaryCollectionOverlay;

        function beneficiaryCollectionOverlay(benefitId, newCartObject) {

            if (!benefitId) {
                return;
            }

            var promises = {
                newCart: newCartObject.$promise,
                enrollmentContent: mbcContentAndData.getEnrollmentContent()
            };

            $q.all(promises).then(beneficiaryCollectionOverlayAsync);

            function beneficiaryCollectionOverlayAsync(data) {
                if (!needShowOverlay()) {
                    return;
                }

                var ep = data.enrollmentContent.getEvaluationPointValue('HB.LifeEvent.BeneficiaryRequirementReminderOverlay');


                executeWithoutShoppingCartScroll.execute(function () {
                    return showHeaderBodyButtonsOverlay({
                        header: ep.Title,
                        body: ep.Copy,
                        noButton: {
                            shouldShowCloseButton: true,
                            hideBottomNoButton: true
                        }
                    })
                });

                function needShowOverlay() {

                    var newCart = data.newCart;
                    var enrollmentContent = data.enrollmentContent;

                    var newCartItem = _.find(newCart.ShoppingCart, { BenefitID: benefitId });
                    var enrollmentBenefit = enrollmentContent.data.PendingEmployee.LifeEvents[0].EligibleBenefitsMap[benefitId];

                    if (!newCartItem || !enrollmentBenefit) {
                        return false;
                    }

                    var electedPlan = enrollmentBenefit.EligiblePlansMap[newCartItem.PlanID];

                    if (electedPlan.IsNoCovPlan || electedPlan.PlanYearDefBeneRequirement !== 'R') {
                        return false;
                    }

                    if (newCart.BeneficiaryData.Designations && newCart.BeneficiaryData.Designations[benefitId]) {
                        return false;
                    }

                    return true;
                }
            }
        }
    }
]);