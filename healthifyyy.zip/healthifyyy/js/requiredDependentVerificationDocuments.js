﻿'use strict';
angular.module('mercer.services').factory('requiredDependentVerificationDocuments', [
    'dependentVerificationService', 'stringService','benefitsService', 'EnrollmentRules', 'coverageSourcesService',
    function (dependentVerificationService, stringService, benefitsService, EnrollmentRules, coverageSourcesService) {
        return {
            getRequiredDependentVerificationDocuments: getRequiredDependentVerificationDocuments
        };

        function getRequiredDependentVerificationDocuments(employeeData, cartData) {
            return _(getMappedContentForAliases('HB.CommonElements.DependentVerification.TableData', 'RELATIONSHIPTYPES'))
                .map(function(content, requiredRelTypes) {
                    return {
                        Title: content.Title || '',
                        Description: content.Copy || '',
                        Dependents: getDependentsOfTypes(requiredRelTypes)
                    };

                    function getDependentsOfTypes(requiredRelTypes) {

                        return _(getDependentsFromSourcesByPriority())
                            .filter(isVerificationRequired)
                            .map('dependent')
                            .map(mapDependent)
                            .filter(filterDependentByRelationType)
                            .value();

                        function mapDependent(dependent) {
                            return {
                                FullName: dependent.FirstName + ' ' + dependent.LastName,
                                Status: getDependentStatus(),
                                BirthDate: dependent.BirthDate,
                                RelationType: dependent.RelationType
                            };

                            function getDependentStatus() {
                                var depVerificationStatus = dependent.DepVerificationStatus || 'N';

                                return {
                                    Code: depVerificationStatus,
                                    Title: getDocumentStatus(depVerificationStatus),
                                    Class: getDocumentStatusClass(depVerificationStatus)
                                };

                                function getDocumentStatus(statusCode) {
                                    var statusDictionary = getMappedContentForAliases('HB.CommonElements.DependentVerification.StatusText', 'DEPVERIFICATIONCODE');
                                    if (statusDictionary && statusDictionary[statusCode])
                                        return statusDictionary[statusCode];

                                    return '';
                                }

                                function getDocumentStatusClass(statusCode) {
                                    var statusClasses = {
                                        "I": getStatusClass('status-not-approved', 'fa-warning'),
                                        "D": getStatusClass('status-failed', 'fa-warning'),
                                        "N": getStatusClass('status-required', 'fa-circle')
                                    };

                                    return statusClasses[statusCode] ? statusClasses[statusCode] : '';

                                    function getStatusClass(spanClass, iconClass) {
                                        return {
                                            SpanClass: spanClass,
                                            IconClass: iconClass
                                        };
                                    }
                                }
                            }

                        }

                        function filterDependentByRelationType(dependent) {
                            return _.includes(stringService.convertArrayStringToArray(requiredRelTypes), dependent.RelationType);
                        }

                        function getDependentsFromSourcesByPriority() {
                            var dependentsFromSources = [];

                            _(getSourcesByPriority())
                                .compact()
                                .forEach(function(source) {
                                    _(source.Dependents)
                                        .forEach(function(dependent) {
                                            var duplicatedDependent = getDuplicatedDependent();

                                            if (duplicatedDependent) {
                                                duplicatedDependent.source.push(source);
                                                return;
                                            }

                                            dependentsFromSources.push({
                                                dependent: dependent,
                                                source: [source]
                                            });

                                            function getDuplicatedDependent() {
                                                return _.find(dependentsFromSources, function(item) {
                                                    return item.dependent.Ssn === dependent.Ssn;
                                                });
                                            }
                                        });
                                });
                            
                            return dependentsFromSources;

                            function getSourcesByPriority() {
                                var data = employeeData.Data;
                                var futureCoverages = data.FutureCoverages;

                                return [
                                    data.PendingEmployee,
                                    futureCoverages && futureCoverages[0],
                                    data.CurrentCoveragesEmployee
                                ];
                            }
                        }

                        function isVerificationRequired(dependentWithSource) {
                            var dependent = dependentWithSource.dependent;

                            return _.find(dependentWithSource.source, isVerificationForSourceRequired);

                            function isVerificationForSourceRequired(source) {
                                var dependentVerification = dependentVerificationService.forData(employeeData);

                                if (!dependentVerification.dependentRequiresVerificationByStatus(dependent)) {
                                    return false;
                                }

                                if (dependentVerification.overlayShowsWhen().dependentIsCovered) {
                                    if (source === employeeData.Data.PendingEmployee && cartData && cartData.ShoppingCart) {
                                        return dependentEligibleForMedicalDentalOrVision()
                                            && dependentVerification.dependentRequiresVerificationByCoverage(dependent, cartData.ShoppingCart);
                                    }

                                    return dependentHasMedicalDentalOrVisionCoverage();
                                }

                                return true;

                                function dependentHasMedicalDentalOrVisionCoverage() {
                                    return checkForMdv(function(benefit) {
                                        var electedPlan = benefit.ElectedPlan;

                                        return benefit.IsElected
                                            && !electedPlan.IsNoCovPlan
                                            && _.some(electedPlan.ElectedOption.DependentAssociations, isSameDependent);
                                    });

                                    function isSameDependent(dep) {
                                        return dep.DependentSsn === dependent.Ssn;
                                    }
                                }

                                function dependentEligibleForMedicalDentalOrVision() {
                                    return checkForMdv(function(benefit) {
                                        return coverageSourcesService.isDependentEligibleForRule(dependent, benefit, employeeData);
                                    });
                                }

                                function checkForMdv(functionForCheck) {
                                    if (!source ||
                                        !source.LifeEvents[0] ||
                                        !source.LifeEvents[0].EligibleBenefits) {
                                        return false;
                                    }

                                    var eligibleBenefits = source.LifeEvents[0].EligibleBenefits;

                                    return _(eligibleBenefits)
                                        .some(function(benefit) {
                                            if (!benefitsService.isBenefitMedicalDentalOrVision(benefit)) {
                                                return false;
                                            }

                                            return functionForCheck(benefit);
                                        });
                                }
                            }
                        }
                    }
                })
                .filter(function (docType) {
                    return _.some(docType.Dependents);
                })
                .value();

            function getMappedContentForAliases(evaluationPoint, keyProperty) {
                var alias = employeeData.ContentAliases[evaluationPoint];
                if (!alias) {
                    return {};
                }

                var keys = alias[keyProperty];
                var content = _(alias['CONTENT_ALIAS'])
                    .map(function (path) {
                        return employeeData.Content[path] ? employeeData.Content[path] : '';
                    })
                    .value();

                return _.zipObject(keys, content);
            }
        }
    }
]);
