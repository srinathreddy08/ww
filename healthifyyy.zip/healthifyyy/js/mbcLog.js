﻿'use strict';
angular.module('mercer.db.shared').service('mbcLog', [
    '$http', '$state', '$log', '$q', '$timeout', 'loggedErrors', 'profileService', 'mbcContentAndData', 'flags',
    function ($http, $state, $log, $q, $timeout, loggedErrors, profileService, mbcContentAndData, flags) {
        var errorsLog = [];

        function addErrorMessage(message) {
            var m = message.replace(/\\r\\n/g, '\n').replace(/\\n/g, '\n');
            errorsLog.push('[' + new Date().toLocaleString() + '] ' + m);
        };

        function logMessage(message, logTarget, serverAction) {
            var data = angular.toJson(message);
            $log[logTarget](message);
            $http.post('/api/log/' + serverAction, data);
        };

        this.logMessage = function (message) {
            logMessage(message, 'info', 'message');
        };

        this.logPendoInfo = function (message) {
            $http.post('/api/log/pendoInfo', { 'Message': message });
        }

        this.logWarning = function (message) {
            logMessage(message, 'warn', 'warning');
        };

        this.logError = function (message, obj) {
            if (obj) {
                message = message + ' JSON[' + angular.toJson(obj) + ']';
            }
            $log.error(message);
            addErrorMessage(message);
            var error = { 'message': message, 'stack': null };
            if (!loggedErrors.isLogged(error)) {
                var data = { 'Message': message };
                $http.post('/api/log/error', data)
                    .then(function () {
                        loggedErrors.put(error);
                    });
            }
        };

        var stateChangeCache = [];
        var stateChangeCacheDelay = 200;

        this.logStateChange = function (fromUrl, toUrl, duration) {
            var record = {
                time: new Date(),
                data: {
                    fromUrl: (fromUrl || '').replace('~2F', '/'),
                    toUrl: toUrl.replace('~2F', '/'),
                    duration: duration
                }
            };
            stateChangeCache.push(record);

            $timeout(processCache, stateChangeCacheDelay * 2);

            function processCache() {
                var now = new Date();
                var items = _.filter(stateChangeCache, isRecordOld);
                stateChangeCache = _.reject(stateChangeCache, isRecordOld);
                var compactedRecords = compactRecords(_.map(items, 'data'));

                _.forEach(compactedRecords, putStateChangeRecordToLog);

                function compactRecords(records) {

                    var recordsWithMergedDoubles = mergeDoubles(records);
                    var result = mergeChains(recordsWithMergedDoubles);

                    return result;

                    function mergeDoubles(sourceRecords) {
                        return _(sourceRecords)
                            .map(function (value) {
                                return _.pick(value, ['fromUrl', 'toUrl']);
                            })
                            .uniqWith(_.isEqual)
                            .map(function (value) {
                                var duration = _(sourceRecords)
                                    .filter({ fromUrl: value.fromUrl, toUrl: value.toUrl })
                                    .sumBy('duration');

                                return {
                                    fromUrl: value.fromUrl,
                                    toUrl: value.toUrl,
                                    duration: duration
                                };
                            })
                            .value();
                    }

                    function mergeChains(sourceRecords) {
                        var recordsForIteration = sourceRecords;

                        while (true) {
                            var pair = _(recordsForIteration)
                                .map(function (record) {
                                    var matchedRecord = _.find(recordsForIteration,
                                        function (secondRecord) {
                                            return record.toUrl === secondRecord.fromUrl &&
                                                record !== secondRecord &&
                                                record.fromUrl !== secondRecord.toUrl &&
                                                record.fromUrl !== record.toUrl &&
                                                secondRecord.fromUrl !== secondRecord.toUrl;
                                        });

                                    if (!matchedRecord) {
                                        return null;
                                    }
                                    return {
                                        from: record,
                                        to: matchedRecord
                                    };
                                })
                                .compact()
                                .head();

                            if (!pair) {
                                return recordsForIteration;
                            }

                            var resultRecord = {
                                fromUrl: pair.from.fromUrl,
                                toUrl: pair.to.toUrl,
                                duration: pair.from.duration + pair.to.duration
                            };

                            recordsForIteration = _(recordsForIteration)
                                .reject(function (record) {
                                    return _.isEqual(record, pair.to) || _.isEqual(record, pair.from);
                                })
                                .union([resultRecord])
                                .value();
                        }
                    }
                }

                function putStateChangeRecordToLog(record) {
                    var promises = {
                        profile: profileService.get().$promise,
                        client: flags.isImpersonation || flags.isProxySimulation ? mbcContentAndData.get('client').$promise : $q.resolve(null)
                    };

                    $q.all(promises).then(function (results) {
                        var profile = results.profile;
                        var client = results.client;

                        $http.post('/api/log/stateChange', {
                            PathFrom: record.fromUrl || '',
                            PathTo: record.toUrl,
                            Duration: record.duration || 0,
                            VisitorFakeSsn: profile.Data.Ssn,
                            CompanyId: flags.companyId,
                            ProxyVisitorId: client ? client.Data.GlobalProfileId : ''
                        });
                    });
                }

                function isRecordOld(record) {
                    return now - record.time >= stateChangeCacheDelay;
                }
            }
        };
        this.throwError = function (errorMessage, jsonObj) {
            var message;
            if (jsonObj) {
                message = errorMessage + ' JSON[' + angular.toJson(jsonObj) + ']';
            }

            addErrorMessage(message);
            $state.go('error', {
                message: errorMessage
            });
            throw new Error(message);
        };

        this.addErrorsLog = function (message, obj) {
            if (obj) {
                message = message + ' JSON[' + angular.toJson(obj) + ']';
            }
            addErrorMessage(message);
        };

        this.addInfoLog = function (message, obj) {
            if (obj) {
                message = message + ' JSON[' + angular.toJson(obj) + ']';
            }
            $log.info(message);
            addErrorMessage(message);
        };

        this.getErrorsLog = function () {
            return errorsLog;
        };
    }]);