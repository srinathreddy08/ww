﻿'use strict';
angular.module('mercer.hb')
    .constant('expertGuidanceGlobal', { useSuggestedPackageResource: false, isDoItYourselfFlow: true })
    .run([
        '$transitions', '$rootScope', '$location', 'expertGuidanceGlobal', 'mbcContentAndData', 'executeWithSpinner', 'isDesignV2', 'isBeneficiariesV2', 'egBeneficiariesNavigationService', 'beneficiaryCollectionRequiredService',
        function ($transitions, $rootScope, $location, expertGuidanceGlobal, mbcContentAndData, executeWithSpinner, isDesignV2, isBeneficiariesV2, egBeneficiariesNavigationService, beneficiaryCollectionRequiredService) {
                        
            $transitions.onBefore({}, function ($transitions) {
                var toState = $transitions.$to();
                if (toState.name === 'expert-guidance.get-started'
                    || toState.name === 'expert-guidance.wizard'
                    || toState.name === 'expert-guidance.package-review'
                    || toState.name === 'expert-guidance.beneficiaries-review'
                ) {
                    return mbcContentAndData.getEnrollment().$promise;
                }
            });

            $transitions.onStart({}, async function ($transitions) {
                var toState = $transitions.$to();
                expertGuidanceGlobal.useSuggestedPackageResource = !!toState.useSuggestedPackageResource;
                expertGuidanceGlobal.isDoItYourselfFlow = toState.isDoItYourselfFlow === undefined ? true : toState.isDoItYourselfFlow;
                
                var toStateName = $transitions.$to().name;
                
                var enrollment = await executeWithSpinner(function () {
                    return mbcContentAndData.getEnrollment().$promise;
                });
                
                $rootScope.isDesignV2 = isDesignV2(enrollment, toStateName);
                $rootScope.isBeneficiariesV2 = isBeneficiariesV2(enrollment, $rootScope.isDesignV2);
            });

            $transitions.onSuccess({}, async function ($transitions) {
                var toStateName = $transitions.$to().name;

                if (toStateName === 'expert-guidance.beneficiaries' || toStateName === 'expert-guidance.beneficiaries-review') {
                    var isReviewPage = (toStateName === 'expert-guidance.beneficiaries-review');
                    mbcContentAndData.getEnrollment().$promise.then(function (enrollment) {
                        var lifeEvent = enrollment.Data.PendingEmployee.LifeEvents[0];
                        var benefitIdsToReset = [];
                        if (isReviewPage) {
                           benefitIdsToReset = beneficiaryCollectionRequiredService.getBeneficiaryCollectionRequiredSetToNoCovIds(lifeEvent);
                        }
                        egBeneficiariesNavigationService.initiateBeneficiariesMenu(isReviewPage, benefitIdsToReset);
                    });
                }
            });
            
            $transitions.onBefore({}, function ($transitions) {
                var fromStateName = $transitions.$from().name;
                if (fromStateName === 'expert-guidance.beneficiaries' || fromStateName === 'expert-guidance.beneficiaries-review') {
                    egBeneficiariesNavigationService.setCurrentRoute('not-inside-beneficiaries-eg', null);
                }
            });

            $transitions.onBefore({}, function ($transitions) {
                var fromStateName = $transitions.$from().name;
                var toStateName = $transitions.$to().name;
                if (
                    fromStateName === 'expert-guidance.package-review'
                    && (
                        toStateName === 'expert-guidance.beneficiaries'
                        || toStateName === 'expert-guidance.beneficiaries-review'
                        || toStateName === 'expert-guidance.certifications'
                        || toStateName === 'expert-guidance.client-custom-benefits'
                        || toStateName === 'expert-guidance.suggested-package'
                    )                    
                ) {
                    history.pushState(null, null, $location.absUrl());                
                    return false;
                } else if (fromStateName === 'expert-guidance.beneficiaries-review' && toStateName.startsWith('expert-guidance.review')) {
                    history.pushState(null, null, $location.absUrl());
                    egBeneficiariesNavigationService.initiateBeneficiariesMenu(true);
                    return false;
                }
            });

            $transitions.onError({}, function ($transitions) {
                var fromState = $transitions.$from();
                expertGuidanceGlobal.useSuggestedPackageResource = !!fromState.useSuggestedPackageResource;
                expertGuidanceGlobal.isDoItYourselfFlow = fromState.isDoItYourselfFlow === undefined ? true : fromState.isDoItYourselfFlow;
            });
        }
    ]);