﻿angular.module('mercer.services').constant('tabKeys', {
    getStarted: 'get-started',
    healthBenefits: 'choose-benefits',
    supplementalBenefits: 'supplemental-benefits',
});
