﻿'use strict';
angular.module('mercer.shared.content').factory('reloadCurrentState', [
    '$state', '$stateParams',
    function ($state, $stateParams) {
        return reloadCurrentState;

        function reloadCurrentState() {
            return $state.go($state.$current, angular.copy($stateParams), { reload: true });
        }
    }
]);
