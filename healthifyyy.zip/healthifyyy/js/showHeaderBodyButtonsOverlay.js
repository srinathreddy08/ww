﻿﻿'use strict';
angular.module('mercer.db.shared').factory('showHeaderBodyButtonsOverlay', [
    'overlayService', '$q',
    function (overlayService, $q) {
        return showHeaderBodyButtonsOverlay;
        function showHeaderBodyButtonsOverlay(params) {
            params.deferred = $q.defer();
            overlayService.open(params.template ? params.template : '/shared/views/overlay/headerBodyButtonsOverlay', params);
            return params.deferred.promise;
        }
    }
]);