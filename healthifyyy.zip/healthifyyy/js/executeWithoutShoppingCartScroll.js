﻿angular.module('mercer.hb').factory('executeWithoutShoppingCartScroll', function () {
    var needToShowWidget = true;

    return {
        execute: function (action) {
            needToShowWidget = false;
            return action()
            ['finally'](function () {
                needToShowWidget = true;
            })
        },
        needToShowWidget: function () {
            return needToShowWidget;
        }
    }
});