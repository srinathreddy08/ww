﻿'use strict';
angular.module('mercer.services').factory('getRepriceBenefitRelations', [
    'contentAliasService',
    function (contentAliasService) {
        return getRepriceBenefitRelations;

        function getRepriceBenefitRelations(employeeData) {
            var repriceableBenefitIdsConfiguration = contentAliasService.forData(employeeData)
                .getConfiguration('HB.LifeEvent.RepriceableBenefitIDs');

            return _(allMatches(repriceableBenefitIdsConfiguration.value, /\[ *(.*?) *\]/g))
                .map(function (match) {
                    return parseRelationship(match[1]);
                })
                .keyBy('ElectedBenefitId')
                .value();

            function parseRelationship(config) {
                var parts = config.split(/\ *: */);
                var electedBenefitId = parts[0];

                var hasAdditionalBenefits = parts.length > 1;

                if (!hasAdditionalBenefits) {
                    return benefitWithNoRelatedBenefits(electedBenefitId);
                }

                return {
                    ElectedBenefitId: electedBenefitId,
                    RelatedBenefits: parts[1].split(/\ *, */)
                };

                function benefitWithNoRelatedBenefits(benefitId) {
                    return {
                        ElectedBenefitId: benefitId,
                        RelatedBenefits: []
                    }
                }
            }

            function allMatches(str, regex) {
                var result = [];
                var match;

                while ((match = regex.exec(str)) !== null) {
                    result.push(match);
                }

                return result;
            }
        }

    }
]);