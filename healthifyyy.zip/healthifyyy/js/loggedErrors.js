﻿'use strict';
angular.module('mercer.db.shared')
    .service('loggedErrors',
        function () {
            var loggedErrors = [];

            return {
                isLogged: isLogged,
                put: put
            };

            function put(error) {
                loggedErrors.push(md5(error.message + error.stack));
            }

            function isLogged(error) {
                return _.includes(loggedErrors, md5(error.message + error.stack));
            }
        }
    );