﻿'use strict';
angular.module('mercer.services')
    .factory('individualsThatCanHavePcpByElection',
    ['$q', 'overlayService', 'contentAliasService', 'without', 'pcpDomainHelpers',
        function ($q, overlayService, contentAliasService, without, pcpDomainHelpers) {

            return function (election, employeeData) {
                
                var pcpDomain = pcpDomainHelpers.forData(employeeData);

                var newPlan = function () {
                    return pcpDomain.pending.plan(election);
                };

                var currentCoveragesPlan = function () {
                    return pcpDomain.current.electedPlan(election);
                };

                var pendingEmployee = function () {
                    return pcpDomain.pending.employee();
                };

                var samePlanWasElectedInCurrentCoverages = function () {
                    return currentCoveragesPlan() && currentCoveragesPlan().PlanID === newPlan().PlanID;
                };

                var differentPlanWasElectedInCurrentCoverages = function () {
                    return !samePlanWasElectedInCurrentCoverages();
                };

                var ssnsOfAllCoveredIndividuals = function () {
                    var newCoveredDependents = election.DependentAssociationList;

                    return _([pendingEmployee().Ssn])
                        .concat(newCoveredDependents)
                        .value();
                };

                var ssnsOfIndividualsCoveredInCurrentCoverages = function () {
                    return _(currentCoveragesPlan().ElectedOption.DependentAssociations)
                        .map('DependentSsn')
                        .value();
                };

                var ssnsOfNewlyCoveredIndividuals = function () {
                    var newCoveredDependents = election.DependentAssociationList;
                    var oldCoveredDependents = ssnsOfIndividualsCoveredInCurrentCoverages();

                    return without(newCoveredDependents, oldCoveredDependents);
                };

                var ssnsOfIndividualsThatCanHavePcp = function () {
                    return differentPlanWasElectedInCurrentCoverages()
                        ? ssnsOfAllCoveredIndividuals(election)
                        : ssnsOfNewlyCoveredIndividuals(election);
                };

                var allIndividuals = function () {
                    return _([pendingEmployee()])
                        .concat(pendingEmployee().Dependents)
                        .value();
                };

                var ssns = ssnsOfIndividualsThatCanHavePcp();

                return _(allIndividuals())
                    .filter(function(individual) {
                        return _(ssns).includes(individual.Ssn);
                    })
                    .value();
            };
        }
    ]);
