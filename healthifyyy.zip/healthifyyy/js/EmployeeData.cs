﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HB.Services.RepositoryImpl.RepositoryEntities
{
    public class EmployeeData
    {
        public string ControlID { get; set; }
        public string Ssn { get; set; }
        public DateTime EffDate { get; set; }
        public string CompanyId { get; set; }
        public DateTime? EndDate { get; set; }
        public string ProcessId { get; set; }
        public string UserId { get; set; }
        public DateTime? LogDate { get; set; }
        public string Status_1 { get; set; }
        public string Status_2 { get; set; }
        public string Status_3 { get; set; }
        public string Status_4 { get; set; }
        public string Status_5 { get; set; }
        public string Status_6 { get; set; }
        public string Status_7 { get; set; }
        public string Status_8 { get; set; }
        public string Status_9 { get; set; }
        public string Status_10 { get; set; }
        public string Usercode_1 { get; set; }
        public string Usercode_2 { get; set; }
        public string Usercode_3 { get; set; }
        public string Usercode_4 { get; set; }
        public string Usercode_5 { get; set; }
        public string Usercode_6 { get; set; }
        public string Usercode_7 { get; set; }
        public string Usercode_8 { get; set; }
        public string Usercode_9 { get; set; }
        public string Usercode_10 { get; set; }
        public string Orgcode_1 { get; set; }
        public string Orgcode_2 { get; set; }
        public string Orgcode_3 { get; set; }
        public string Orgcode_4 { get; set; }
        public string Orgcode_5 { get; set; }
        public string Orgcode_6 { get; set; }
        public string Orgcode_7 { get; set; }
        public string Orgcode_8 { get; set; }
        public string Orgcode_9 { get; set; }
        public string Orgcode_10 { get; set; }
        public DateTime? Date_1 { get; set; }
        public DateTime? Date_2 { get; set; }
        public DateTime? Date_3 { get; set; }
        public DateTime? Date_4 { get; set; }
        public DateTime? Date_5 { get; set; }
        public DateTime? Date_6 { get; set; }
        public DateTime? Date_7 { get; set; }
        public DateTime? Date_8 { get; set; }
        public DateTime? Date_9 { get; set; }
        public DateTime? Date_10 { get; set; }
        public decimal? Dollar_1 { get; set; }
        public decimal? Dollar_2 { get; set; }
        public decimal? Dollar_3 { get; set; }
        public decimal? Dollar_4 { get; set; }
        public decimal? Dollar_5 { get; set; }
        public decimal? Dollar_6 { get; set; }
        public decimal? Dollar_7 { get; set; }
        public decimal? Dollar_8 { get; set; }
        public decimal? Dollar_9 { get; set; }
        public decimal? Dollar_10 { get; set; }
        public long? TxnId { get; set; }
    }
}
