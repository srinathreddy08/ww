﻿'use strict';
angular.module('mercer.db.shared').factory('addToCartCounter', [
    function () {
        var actionsCounter = 0;

        return {
            hasPendingActions: hasPendingActions,
            startAddToCartAction: startAddToCartAction,
            finishAddToCartAction: finishAddToCartAction
        };

        function hasPendingActions() {
            return actionsCounter !== 0;
        }

        function startAddToCartAction() {
            actionsCounter++;
        }

        function finishAddToCartAction() {
            actionsCounter--;
        }
    }
]);