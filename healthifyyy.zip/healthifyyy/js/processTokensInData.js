﻿'use strict';
angular.module('mercer.shared.content').factory('processTokensInData',
    ['formatFilter',
        function (formatFilter) {
        	return processTokensInData;

        	function processTokensInData(data, dataSourcesForTokenReplacement) {
        		dataSourcesForTokenReplacement = _.compact(dataSourcesForTokenReplacement);

        		if (data && data.Content && dataSourcesForTokenReplacement.length > 0) {
        			applyFormatFilter(data.Content);
        		}

        		return data;

        		function applyFormatFilter(value) {
        			for (var key in value) {
        				if (!value.hasOwnProperty(key)) {
        					continue;
        				}

        				if (typeof value[key] === 'object') {
        					applyFormatFilter(value[key]);
        				}

        				if (typeof value[key] === 'string') {
        					value[key] = replaceTokens(value[key]);
        				}
        			}
        		}

        		function replaceTokens(value) {
        			return formatFilter(value, dataSourcesForTokenReplacement, false);
        		}
        	}

        }]);