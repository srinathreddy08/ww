﻿angular.module('mercer.services').constant('benefitCategories', {
    SUPPLEMENTAL: 'SUPPLEMENTAL',
});
