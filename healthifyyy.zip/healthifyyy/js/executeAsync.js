﻿'use strict';
angular.module('mercer.db.shared').factory('executeAsync', [
    '$q',
    function ($q) {
        return executeAsync;

        function executeAsync(action) {
            if (!angular.isFunction(action)) {
                return $q.resolve(action);
            }

            return $q.resolve()
                .then(action);
        }
    }
]);