﻿'use strict';
angular.module('mercer.db.shared').factory('featureToggles', [
    'featureTogglesService',
    function (featureTogglesService) {
        return featureTogglesService.getFeatures();
    }
]);
