﻿﻿'use strict';
angular.module('mercer.db.shared')
    .constant('featureDefaults', {

        contentAliasServiceErrorLogging: false, // it looks like useful thing if you turn it on...
        ssnFieldOptional: true, // i've got some doubts...
        
        // below after 13-SEP-2019

        dependentsDisclaimer: true,
        configForRemoveWaiveOptions: false,
        conversionElections: true,
        refactorExpertGuidanceNavigation: false,
        profileBoosterEnabledAlways: false,

        // clientSwat feature http://jira.mercer.com/browse/MCS-165

        displayHsaStopContributionLabelDuringOG: true,
        showConfirmationNumber: true,
        suppressPPPCostSection: true,
        showListOfCoveredDependents: true,
        overrideCoverageWebsite: true,
        isNewErAmountsLogic: true,
        isHttpDecoratorSwitchOn: true,
        showRecalcInformOverlayFaster: false,
        disableScrollingWhenBeneficiaryOverlayShown: true,
        overrideCarrierBenefitOptionPlan: true,
        useHsaFlForHsaReminder: true
    });
