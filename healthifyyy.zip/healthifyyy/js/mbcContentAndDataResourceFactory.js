﻿'use strict';
angular.module('mercer.shared.content').factory('mbcContentAndDataResourceFactory', [
    '_', '$resource', '$q', 'staticContent', 'transformOpenEnrollment', 'pubsub', 'processTokensInData',
    'contentAliasService', 'reloadCurrentState',
    function (_, $resource, $q, staticContent, transformOpenEnrollment, pubsub, processTokensInData,
        contentAliasService, reloadCurrentState) {
        return createResource;

        function createResource(cache) {
            var paramDefaults = {};
            var actions = {
                get:
                {
                    cache: cache,
                    method: 'GET',
                    transformResponse: transformResponse
                }
            };

            var resource = $resource('/api/content/:key', paramDefaults, actions);

            return {
                remove: remove,
                clearWholeCache: clearWholeCache,
                refresh: refresh,
                getData: getData,
                getProcessedData: getProcessedData,
                getEnrollment: getEnrollment,
                getEnrollmentContent: getEnrollmentContent,
                updateEnrollmentCache: updateEnrollmentCache,
                getCachedEnrollmentData: getCachedEnrollmentData
            };

            function getProcessedData(sectionKey, options) {
                options = options || {};
                return getProcessedDataCore(sectionKey,
                    {
                        hardRefresh: options.hardRefresh,
                        getData: function () {
                            return {
                                $promise: $q.all({
                                        additionalData: $q.all(options.additionalDataSources),
                                        sourceData: getContentFromResource(sectionKey, options).$promise
                                    })
                                    .then(function (responses) {
                                        return processTokensInData(responses.sourceData, responses.additionalData);
                                    })
                            };
                        }
                    }).$promise;
            }

            function getData(sectionKey, transform, hardRefresh) {
                return getProcessedDataCore(sectionKey,
                    {
                        hardRefresh: hardRefresh,
                        getData: function () {
                            return getContentFromResource(sectionKey, { transform: transformProxy });
                        }
                    });

                function transformProxy(data) {
                    if (typeof transform !== 'function') {
                        return data;
                    }
                    var perfOperation = window.mbcPerf.start('mcbContentAndData:transform', sectionKey);
                    var result = transform(data);
                    perfOperation.stop();
                    return result;
                }
            }

            function refresh(reload) {
                clearWholeCache();

                if (reload) {
                    return reloadCurrentState();
                }
            }

            function clearWholeCache() {
                cache.removeAll();
            }

            function getProcessedDataCore(sectionKey, options) {
                if (options.hardRefresh) {
                    remove(sectionKey);
                }

                var cachedData = getCachedData(sectionKey);
                if (cachedData) {
                    return cachedData;
                }

                return updateCache(sectionKey, options.getData());
            }

            function getCachedData(sectionKey) {
                return cache.get('transformed.' + sectionKey);
            }

            function remove(sectionKey) {
                //Remove a section from the cache
                cache.remove('transformed.' + sectionKey);
                cache.remove('/api/content/' + sectionKey);
            }

            function updateCache(sectionKey, data) {
                pubsub.publish('mbcContentAndData.cache.updating', { key: sectionKey });

                data.$promise.then(function (newData) {
                    pubsub.publish('mbcContentAndData.cache.updated', { key: sectionKey, newData: newData });
                });

                cache.put('transformed.' + sectionKey, data);

                return data;
            }

            function getContentFromResource(sectionKey, options) {
                return resource.get({
                    'key': sectionKey
                }, processContent);

                function processContent(data) {
                    if (sectionKey === 'dashboard' || sectionKey === 'enrollment') {
                        var clonedData = _.cloneDeep(data);
                        pubsub.publish('mbcContentAndDataReloaded', { key: sectionKey, contentData: clonedData });
                    }

                    var transformAction = options.transform || noTransform;
                    return transformAction(data);
                }

                function noTransform(data) {
                    return data;
                }
            }

            function transformResponse(json) {
                try {
                    // Inject all terms into content
                    var data = angular.fromJson(json);

                    return processTokensInData(data, [staticContent, data]);
                } catch (ex) {
                    console.log(ex);
                    return json;
                }
            }

            function getEnrollmentContent() {
                return getEnrollment().$promise
                    .then(function (data) {
                        return contentAliasService.forData(data);
                    });
            }

            function getEnrollment() {
                return getData('enrollment', transformOpenEnrollment);
            }

            function updateEnrollmentCache(data) {
                return updateCache('enrollment', data);
            }

            function getCachedEnrollmentData() {
                return getCachedData('enrollment');
            }
        }
    }
]);
