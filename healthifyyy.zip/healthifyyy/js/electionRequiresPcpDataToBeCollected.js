'use strict';
angular.module('mercer.services')
    .factory('electionRequiresPcpDataToBeCollected',
    ['individualsThatCanHavePcpByElection', 'pcpDomainHelpers', 'benefitsService', function (individualsThatCanHavePcpByElection, pcpDomainHelpers, benefitsService) {
            return function (election, employeeData) {
                var pcpDomain = pcpDomainHelpers.forData(employeeData),
                    benefit = pcpDomain.pending.benefit(election);

                var hasIndividualsThatCanHavePcp = function () {
                    var individuals = individualsThatCanHavePcpByElection(election, employeeData);

                    return _(individuals).some();
                };

                var planRequiresPcpDataToBeCollected = function () {
                    var newPlan = pcpDomain.pending.plan(election);

                    return newPlan.PlanYearDefPCPRequirement === 'R';
                };

                return ((benefitsService.isBenefitOfMedicalCategory(benefit) && benefitsService.isBenefitOfMedicalId(benefit)) ||
                        (benefitsService.isBenefitOfDentalCategory(benefit) && benefitsService.isBenefitOfDentalId(benefit))) &&
                        planRequiresPcpDataToBeCollected() &&
                        hasIndividualsThatCanHavePcp();
            };
        }
    ]);
