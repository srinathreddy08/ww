﻿'use strict';

angular.module('mercer.services').service('generateCartMap', function () {
    return function (cart) {
        return _(cart.ShoppingCart)
            .reject('IsLostEligibility')
            .keyBy('BenefitID')
            .value();
    };
});