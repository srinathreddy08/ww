﻿'use strict';
angular.module('mercer.hb').factory('shoppingCartResource', [
    '$resource','$q',
    function ($resource, $q) {
        var shoppingCartResource = $resource('/api/shoppingcart/:action', {}, {
            get: { method: 'GET', params: { action: 'get' } },
            visit: { method: 'POST', params: { action: 'visit' } },
            batchAdd: { method: 'POST', params: { action: 'batchAdd' } },
            submit: { method: 'POST', params: { action: 'submit' } },
            load: { method: 'GET', params: { action: 'load' } },
            clear: { method: 'GET', params: { action: 'clear' } },
            selectPackage: { method: 'POST', params: { action: 'selectPackage' } },
            addProvidersForCartItem: { method: 'POST', params: { action: 'addProvidersForCartItem' } },
            getProvidersForCartItem: { method: 'GET', params: { action: 'getProvidersForCartItem' } }
        });
        
        return {
            isExpertGuidance: false,
            cacheKeyPrefix: '',
            get: get,
            visit: visit,
            batchAdd: batchAdd,
            submit: submit,
            load: load,
            clear: clear,
            selectPackage: selectPackage,
            addProvidersForCartItem: addProvidersForCartItem,
            getProvidersForCartItem: getProvidersForCartItem
        };

        function get(lifeEvent) {
            return shoppingCartResource.get(lifeEvent);
        }

        function visit(options) {
            return shoppingCartResource.visit(options);
        }

        function batchAdd(options) {
            return shoppingCartResource.batchAdd(options);
        }

        function selectPackage(){
            return shoppingCartResource.selectPackage().$promise;
        }

        function submit(lifeEvent) {
            return shoppingCartResource.submit(lifeEvent);
        }

        function load(lifeEvent) {
            return shoppingCartResource.load(lifeEvent);
        }

        function clear(lifeEvent) {
            return shoppingCartResource.clear(lifeEvent);
        }

        function addProvidersForCartItem(options) {
            return shoppingCartResource.addProvidersForCartItem(options);
        }

        function getProvidersForCartItem(cartItem) {
            return shoppingCartResource.getProvidersForCartItem(cartItem);
        }
    }
]);
