﻿'use strict';
angular.module('mercer.services')
    .factory('pcpOverlayEnabled',
    ['contentAliasService', function (contentAliasService) {
            return function (employeeData) {
                var contentData = contentAliasService.forData(employeeData);
                return contentData.getConfigurationValue('HB.LifeEvent.PCPDisplay') === 'S';
            };
        }
    ]);