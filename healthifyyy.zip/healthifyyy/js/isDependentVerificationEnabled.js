﻿'use strict';
angular.module('mercer.services').factory('isDependentVerificationEnabled', [
    'dependentVerificationService',
    function(dependentVerificationService) {
        return function(employee) {
            return dependentVerificationService
                .forData(employee)
                .isDependentVerificationEnabled();
        }
    }
]);