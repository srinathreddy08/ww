﻿'use strict';
angular.module('mercer.services').service('aggregateElections', [
    'benefitsService', '_',
    function (benefitsService, _) {
	    return function (electionData, hideNoCovVb) {
	        //Anything with category of CREDIT, SURCHANGE, VB_* should not display in the electionData list but should contribute to the grand totals
	        var employeeCostType = 'Employee';
	        var employerCostType = 'Employer';
	        var payPeriodCostType = 'PayPeriod';
	        var annualCostType = 'Annual';

            var allBenefitsByGroups = getAllBenefitsByGroups();

            return {
                displayed: _(allBenefitsByGroups)
                    .mapValues(filterDisplayedElections)
                    .value(),
                allBenefitsByGroups: allBenefitsByGroups,
	            totals: {
	                perPayPeriod: getTotals(payPeriodCostType),
	                annual: getTotals(annualCostType)
	            }
	        };

            function getAllBenefitsByGroups() {
                return {
                    charges: getCharges(),
                    credits: getCredits(),
                    employerCostElections: getEmployerCostElections(),
                    voluntaryBenefits: getVoluntaryBenefits(),
                    paidExceptVoluntaryElections: getPaidExceptVoluntaryElections()
                };
            }
            
            function getCreditBenefitFilter() {
                return getCategoryFilter('CREDIT');
            }

            function getChargeBenefitFilter() {
                return getCategoryFilter('SURCHARGE');
            }

            function getCredits() {
                return _(getNonzeroElections())
                    .filter(getCreditBenefitFilter())
                    .value();
            }
            
            function getCharges(){
                return _(getNonzeroElections())
                    .filter(getChargeBenefitFilter())
                    .value();
            }

            function getNonzeroElections() {
                return _(electionData)
                    .filter(function(election) {
                        //Per client hide surcharges and credits that have 0 amount
                        return election.ElectedOption &&
                            getCost(election, employeeCostType, annualCostType) &&
                            getCost(election, employeeCostType, payPeriodCostType);
                    })
                    .value();
            }
            
            function getEmployerCostElections() {
                return _(electionData)
                    .reject(getCreditBenefitFilter())
                    .reject(getChargeBenefitFilter())
                    .value();
            }

            function getVoluntaryBenefitsWithElectedPlan() {
                return _(getEmployerCostElections())
                    .filter(isVoluntaryElection)
                    .filter(function(election) {
                        return election.ElectedPlan;
                    })
                    .value();
            }

            function getPaidExceptVoluntaryElections() {
                // If we are showing the noCov VBs, remove all NoCov plans from the main list and add the NoCov plans that have interest to the voluntaryBenefits list to be displayed separately
                return _(getEmployerCostElections())
                    .filter(function (election) {
                        if (!isVoluntaryElection(election)) {
                            return true;
                        }

                        if (hideNoCovVb) {
                            return false;
                        } else {
                            return !(election.ElectedPlan && election.ElectedPlan.IsNoCovPlan);
                        }
                    })
                    .value();
            }

            function getVoluntaryBenefits() {
                return _(getVoluntaryBenefitsWithElectedPlan())
                    .filter(function(election) {
                        return hideNoCovVb ?
                            !election.ElectedPlan.IsNoCovPlan :
                            election.ElectedPlan.IsNoCovPlan && election.IsInterested;
                    })
                    .value();
            }
            
            function getPaidElections() {
                return _(getPaidExceptVoluntaryElections())
                    .union(getVoluntaryBenefits())
                    .value();
            }
            
            function getTaxSavingsElections() {
                return _(getPaidExceptVoluntaryElections())
                    .filter(isTaxSavingAccount)
                    .value();
            }
            

            function isTaxSavingAccount(election) {
                return election.ElectedBenefit.BenefitCategory === 'SPENDING';
            }

            function getBeforeTaxElections() {
                return _(getPaidElections())
                    .filter(getTaxFilter(true))
                    .value();
            }

            function getAfterTaxElections() {
                return _(getPaidElections())
                    .filter(getTaxFilter(false))
                    .value();
            }

            function getMiscTaxElections() {
                return _(getPaidElections())
                    .filter(getTaxFilter(null))
                    .value();
            }

            function getYourCostsElections() {
                // Your costs should be misc totals + after tax totals + before tax totals + surcharges + credits (surcharges and credits are not included in the subtotal but ARE included in the your cost grand total)
                return _(getPaidElections())
                    .union(getCredits(), getCharges())
                    .value();
            }
            
            function getCost(election, personCostType, periodCostType) {
                return election.ElectedOption[personCostType + periodCostType + 'Cost'];
            }
            
            function getCategoryFilter(category) {
                return categoryFilter;

                function categoryFilter(election) {
                    return election.ElectedBenefit.BenefitCategory === category;
                }
            }

            function isVoluntaryElection(election) {
                return election.ElectedBenefit.BenefitCategory.indexOf('VB_') === 0;
            }

            function getTaxFilter(value) {
                return taxFilter;

                function taxFilter(election) {
                    return election.ElectedOption.IsPreTax === value;
                }
            }

            function getTotals(periodCostType) {
                return {
                    beforeTax: getTotal(employeeCostType, getBeforeTaxElections()),
                    afterTax: getTotal(employeeCostType, getAfterTaxElections()),
                    misc: getTotal(employeeCostType, getMiscTaxElections()),
                    paid: getTotal(employeeCostType, getPaidElections()),
                    your: getTotal(employeeCostType, getYourCostsElections()),
                    taxSavings: getTotal(employeeCostType, getTaxSavingsElections()),
                    employer: getTotal(employerCostType, getEmployerCostElections())
                };

                function getTotal(personCostType, elections) {
                    return _(elections)
                        .reduce(function (total, election) {
                            return total + getCost(election, personCostType, periodCostType);
                        }, 0);
                }
            }
            
            function filterDisplayedElections(elections) {
                return _(elections)
                    .reject(function (data) {
                        return benefitsService.isBenefitHiddenFromUser(data.ElectedBenefit);
                    })
                    .value();
            }
	    };
	}]);