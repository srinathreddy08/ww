﻿'use strict';
angular.module('mercer.db.shared').factory('executeAddToCartAction', [
    'addToCartCounter', 'executeWithSpinnerIfDisplaying',
    function (addToCartCounter, executeWithSpinnerIfDisplaying) {
        return executeAddToCartAction;

        function executeAddToCartAction(action) {
            addToCartCounter.startAddToCartAction();

            return executeWithSpinnerIfDisplaying(action)
                ['finally'](addToCartCounter.finishAddToCartAction);
        }
    }
]);