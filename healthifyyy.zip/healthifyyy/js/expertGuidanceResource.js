﻿'use strict';
angular.module('mercer.hb').factory('expertGuidanceResource', [
    '$resource', '$q',
    function ($resource, $q) {
        var stepDataCache = createEmptyCache();

        var resource = $resource('/api/guidedshopping/:action',
            {},
            {
                getStepsStatuses: { method: 'GET', params: { action: 'getStepsStatuses' }, isArray: true },
                getStepData: { method: 'GET', params: { action: 'getStepData' } },
                getAllStepsData: { method: 'GET', params: { action: 'getAllStepsData' } },
                saveAnswers: { method: 'POST', params: { action: 'saveAnswers' }, isArray: true },
                clearAnswers: { method: 'POST', params: { action: 'clearAnswers' } },
                calculatePackage: { method: 'POST', params: { action: 'calculatePackage' } },
                clearPackage: { method: 'POST', params: { action: 'clearPackage' } },
                getExpenses: { method: 'GET', params: { action: 'getExpenses' }, isArray: true },
                saveExpenses: { method: 'POST', params: { action: 'saveExpenses' } },
                clearExpenses: { method: 'POST', params: { action: 'clearExpenses' } },
                getSuggestedPackage: { method: 'GET', params: { action: 'getSuggestedPackage' } },
                updateSuggestedPackage: { method: 'POST', params: { action: 'updateSuggestedPackage' } },
                getHintPageData: { method: 'GET', params: { action: 'getHintPageData' } },
                getCustomizedPlanCostEstimatorData: { method: 'GET', params: { action: 'getCustomizedPlanCostEstimatorData' } }
            });

        return {
            getStepList: getStepList,
            getStep: getStep,
            getStepsAnswers: getStepsAnswers,
            saveAnswers: saveAnswers,
            getExpenses: getExpenses,
            saveExpenses: saveExpenses,
            clearExpenses: clearExpenses,
            clearAnswers: clearAnswers,
            calculatePackage: calculatePackage,
            getSuggestedPackage: getSuggestedPackage,
            updateSuggestedPackage: updateSuggestedPackage,
            clearCache: clearCache,
            clearPackage: clearPackage,
            clearCacheForNextSteps: clearCacheForNextSteps,
            getAllQuestions: getAllQuestions,
            getHintPageData: getHintPageData,
            getCustomizedPlanCostEstimatorData: getCustomizedPlanCostEstimatorData
        };

        function getHintPageData() {
            return resource.getHintPageData().$promise;
        }

        function getCustomizedPlanCostEstimatorData() {
            return resource.getCustomizedPlanCostEstimatorData().$promise;
        }

        function getAllQuestions() {
            return resource.getAllStepsData().$promise
                .then(function (allStepsData) {
                    return _(allStepsData.data)
                        .map('data')
                        .map('Questions')
                        .flattenDeep()
                        .map(mapQuestion)
                        .value();
                });
        }

        function saveExpenses(answerType, expenses) {
            return resource.saveExpenses({
                expenses: _.map(expenses, mapExpense),
                answerType: answerType
            })
                .$promise;

            function mapExpense(expense) {
                return {
                    Id: expense.id,
                    FrequencyOption: expense.frequencyOption,
                    Amount: expense.amount
                };
            }
        }

        function getStepList() {
            if (stepDataCache.stepsStatuses === null) {
                setStepsStatuses(resource.getStepsStatuses());
            }

            return stepDataCache.stepsStatuses;
        }

        function getStepsAnswers() {
            return getStepList()
                .then(function (stepList) {
                    var promisesPerStepId = getPromisesForSteps();

                    return $q.all(promisesPerStepId);

                    function getPromisesForSteps() {
                        return _.map(stepList, function (step) {
                            return getStep(step.url);
                        });
                    }
                });
        }

        function getExpenses(answerType) {
            return resource.getExpenses({
                answerType: answerType
            })
                .$promise
                .then(function (expenses) {
                    return _.map(expenses, mapExpensesData);
                });

            function mapExpensesData(expense) {
                return {
                    id: expense.Id,
                    frequencyOption: expense.FrequencyOption,
                    amount: expense.Amount
                };
            }
        }

        function getStep(stepUrl) {
            if (!stepDataCache.stepsData[stepUrl]) {
                stepDataCache.stepsData[stepUrl] = resource.getStepData({ stepUrl: stepUrl })
                    .$promise;
            }

            return stepDataCache.stepsData[stepUrl].then(mapStepData);

            function mapStepData(step) {
                return {
                    url: step.Url,
                    questions: _.map(step.Questions, mapQuestion)
                };
            }
        }

        function mapQuestion(question) {
            return {
                config: {
                    control: question.Control,
                    title: question.Title,
                    subtitle: question.Subtitle,
                    answerType: question.AnswerType,
                    answers: _.map(question.AnswerOptions,
                        function (answer) {
                            return {
                                id: String(answer.ValueId),
                                title: answer.Title,
                                hint: answer.Hint,
                                icon: answer.Icon,
                                isNoneAnswer: answer.IsNoneAnswer
                            };
                        })
                },
                savedAnswer: getSavedAnswer()
            };

            function getSavedAnswer() {
                var answerSavedLocally = stepDataCache.answersSavedLocally[question.AnswerType];

                if (typeof answerSavedLocally === 'object') {
                    return answerSavedLocally;
                }

                return question.UserProvidedAnswer === null ? null : {
                    Text: question.UserProvidedAnswer.Value,
                    SecondText: question.UserProvidedAnswer.SubAnswer
                };
            }
        }

        function saveAnswers(stepUrl, answers) {
            _.forIn(answers, function (answer) {
                stepDataCache.answersSavedLocally[answer.Type] = answer;
            });

            var mappedAnswers = _.map(answers, mapAnswer);

            return setStepsStatuses(resource.saveAnswers(mappedAnswers));

            function mapAnswer(answer) {
                return {
                    AnswerType: answer.Type,
                    Value: answer.Text,
                    SubAnswer: answer.SecondText
                };
            }
        }

        function setStepsStatuses(query) {
            stepDataCache.stepsStatuses = query.$promise.then(mapStepList);

            return stepDataCache.stepsStatuses;

            function mapStepList(stepList) {
                return _.map(stepList, function (stepInfo) {
                    return {
                        url: stepInfo.Url,
                        isFilled: stepInfo.IsFilled
                    };
                });
            }
        }

        function createEmptyCache() {
            return {
                stepsStatuses: null,
                stepsData: {},
                answersSavedLocally: {}
            };
        }

        function clearExpenses() {
            return resource.clearExpenses().$promise;
        }

        function clearAnswers() {
            return resource.clearAnswers().$promise;
        }

        function clearPackage() {
            return resource.clearPackage();
        }

        function calculatePackage() {
            return resource.calculatePackage().$promise;
        }

        function getSuggestedPackage() {
            return resource.getSuggestedPackage();
        }

        function updateSuggestedPackage(options) {
            return resource.updateSuggestedPackage(options);
        }

        function clearCache() {
            stepDataCache = createEmptyCache();
        }

        function clearCacheForNextSteps(stepUrl) {
            return getStepList()
                .then(function(stepList) {
                    var index = _.findIndex(stepList, { url: stepUrl });
                    var keysToKeep = _(stepList).map('url').take(index + 1).value();
                    stepDataCache.stepsData = _(stepDataCache.stepsData).pick(keysToKeep).value();
                });
        }
    }
]);