﻿describe('transformOpenEnrollment', function () {

    beforeEach(module('mercer.shared.content'));

    var transformOpenEnrollment;
    var enrollment;

    beforeEach(inject(function (_transformOpenEnrollment_) {
        transformOpenEnrollment = _transformOpenEnrollment_;
        jasmine.getJSONFixtures().fixturesPath = 'base/tests/transformOpenEnrollment';
        enrollment = getJSONFixture('enrollment.json');
        transformOpenEnrollment(enrollment);
    }));

    describe('override', function () {

        it('Carrier overrides', function () {
            var currentCoverageMedicalBenefit = enrollment
                .Data
                .CurrentCoveragesEmployee
                .LifeEvents[0]
                .EligibleBenefitsMap['MEDICAL'];

            var aetnaMedicalPlan = currentCoverageMedicalBenefit.EligiblePlansMap['CDHH003E01'];

            expect(aetnaMedicalPlan.CarrierID).toBe(undefined);
            expect(aetnaMedicalPlan.Carrier.CarrierAlias).toBe(undefined);
            expect(aetnaMedicalPlan.Carrier.CarrierContent.LongName).toBe('AETNA_TEST_LONG');
            expect(aetnaMedicalPlan.Carrier.CarrierContent.ShortName).toBe('AETNA_TEST_SHORT');
            expect(aetnaMedicalPlan.Carrier.CarrierContent.CarrierLogo.LogoSrc).toBe('');

            var currentCoverageVisionBenefit = enrollment
                .Data
                .CurrentCoveragesEmployee
                .LifeEvents[0]
                .EligibleBenefitsMap['VISION'];

            var aetnaVisionPlan = currentCoverageVisionBenefit.ElectedPlan;
            expect(aetnaVisionPlan.CarrierID).toBe(undefined);
            expect(aetnaVisionPlan.Carrier.CarrierAlias).toBe(undefined);
            expect(aetnaVisionPlan.Carrier.CarrierContent.LongName).toBe('Aetna');
            expect(aetnaVisionPlan.Carrier.CarrierContent.ShortName).toBe('Aetna');
            expect(aetnaVisionPlan.Carrier.CarrierContent.CarrierLogo.LogoSrc).toBe('');

            var currentCoverageAccidentBenefit = enrollment
                .Data
                .CurrentCoveragesEmployee
                .LifeEvents[0]
                .EligibleBenefitsMap['ACCIDENT'];

            var aetnaAccidentPlan = currentCoverageAccidentBenefit.EligiblePlansMap['COVN035001'];
            expect(aetnaAccidentPlan.CarrierID).toBe(undefined);
            expect(aetnaAccidentPlan.Carrier.CarrierAlias).toBe(undefined);
            expect(aetnaAccidentPlan.Carrier.CarrierContent.LongName).toBe('Voya Financial overrided');
            expect(aetnaAccidentPlan.Carrier.CarrierContent.ShortName).toBe('Voya Financial Short');
            expect(aetnaAccidentPlan.Carrier.CarrierContent.CarrierLogo.LogoSrc).toBe('');
        });

        /* TODO: 

        it('Override benefit logo and names', function () {

        });

        it('Maps For LifeEvent Benefits And Plans', function () {
        });

        it('Plan counts for benefits', function () {
        });

        it('Benefit options override', function () {
        });

        it('Content from ContentAlias for benefits and plans', function () {
        });

        it('Enrollment Functions in Content', function () {
        });

        it('Override DisplayOrder for benefits', function () {
        });

        it('Suppress benefit rounding to integer', function () {
        });

        it('carriers long and short names will be overriden', function () {

        }); 
        */
    });

});
