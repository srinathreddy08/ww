﻿'use strict';

angular.module('mercer.services')
    .value('dependencyTracker', itDepends);