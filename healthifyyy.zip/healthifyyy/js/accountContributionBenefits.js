﻿'use strict';
angular.module('mercer.services').service('accountContributionBenefits', [
    'lifeEventService', '$q',
    function (lifeEventService, $q) {
        var benefitAccessors = {};

        return {
            registerBenefit: registerBenefit,
            recalcSuppressed: recalcSuppressed,
            getItemsToAddToCart: getItemsToAddToCart
        };

        function registerBenefit(scope, benefitId, benefitAccessor) {
            scope.$on('$destroy', function () {
                if (benefitAccessors[benefitId] === benefitAccessor) {
                    delete benefitAccessors[benefitId];
                }
            });

            benefitAccessors[benefitId] = benefitAccessor;
        }

        function recalcSuppressed(benefitId, shoppingCart) {
            var behavior = getAccountContributionBenefitBehavior(benefitId, shoppingCart);

            return behavior.recalcSuppressed;
        }

        function getAccountContributionBenefitBehavior(benefitId, shoppingCart) {
            return {
                recalcSuppressed: false,
                getBenefits: getBenefits,
                recalculateOptionCosts: recalculateOptionCosts
            };

            function getBenefits() {
                return getBenefitAccessors(function (itemBenefitId) {
                    return itemBenefitId === benefitId;
                });
            }

            function recalculateOptionCosts(lifeEvent, items, opt, frontLoadAmountForHsa) {
                return lifeEventService
                    .recalculateOptionCostFromCartItem(lifeEvent, items[0], null, opt, frontLoadAmountForHsa)
                    .then(function (recalculatedOption) {
                        return [recalculatedOption];
                    });
            }

            function getBenefitAccessors(filter) {
                return _(shoppingCart)
                    .keyBy('BenefitID')
                    .mapValues(function (cartItem, benefitId) {
                        return benefitAccessors[benefitId] ||
                            defaultCartItemAccessor(cartItem);
                    })
                    .pickBy(function (accessor, benefitId) {
                        return filter(benefitId);
                    })
                    .value();

                function defaultCartItemAccessor(cartItem) {
                    return {
                        cartItem: getItem,
                        applyChanges: getItem
                    };

                    function getItem() {
                        return cartItem;
                    }
                }
            }

        }

        function getItemsToAddToCart(cartItem, getAdditionalItemsToAddToCart, lifeEvent, content, shoppingCart, doReprice, opt, frontLoadAmountForHsa) {
            var currentBenefitId = cartItem.BenefitID;
            var behavior = getAccountContributionBenefitBehavior(currentBenefitId, shoppingCart);

            var benefits = behavior.getBenefits();

            var items = _(benefits)
                .map(function (accessor, benefitId) {
                    var sourceCartItem = benefitId === currentBenefitId
                        ? cartItem
                        : accessor.cartItem();

                    return {
                        accessor: accessor,
                        cartItem: _.clone(sourceCartItem)
                    };
                })
                .value();

            var cartItems = _.map(items, 'cartItem');

            var repriceCall = doReprice ?
                behavior.recalculateOptionCosts(lifeEvent, cartItems, opt, frontLoadAmountForHsa) :
                $q.resolve(_(cartItems).map(lifeEventService.convertCartItemToOption).value());

            return repriceCall
                .then(function (calculatedItems) {
                    _(cartItems)
                        .forEach(function (item, index) {
                            var calculatedOption = calculatedItems[index];

                            item.OptionID = calculatedOption.OptionID;
                            item.Amount = calculatedOption.AmountElected;
                            item.EmployeePayPeriodCost = calculatedOption.EmployeePayPeriodCost;
                            item.EmployeeAnnualCost = calculatedOption.EmployeeAnnualCost;
                            item.EmployerPayPeriodCost = calculatedOption.EmployerPayPeriodCost;
                            item.EmployerAnnualCost = calculatedOption.EmployerAnnualCost;
                            item.EOIPendingStatus = calculatedOption.EOIPendingStatus;
                            item.PremiumMonthly = calculatedOption.PremiumMonthly;
                            item.PremiumAnnual = calculatedOption.PremiumAnnual;
                            item.AdministrativeCostMonthly = calculatedOption.AdministrativeCostMonthly;
                            item.AdministrativeCostAnnual = calculatedOption.AdministrativeCostAnnual;
                            item.AmountPended = calculatedOption.AmountPended;
                            item.AmountInforce = calculatedOption.AmountInforce;
                            item.PendedEmployeePayPeriodCost = calculatedOption.PendedEmployeePayPeriodCost;
                            item.PendedEmployeeAnnualCost = calculatedOption.PendedEmployeeAnnualCost;
                            item.Amount5 = calculatedOption.Amount5;
                        });

                    var itemsToAddToCart = _(items)
                        .map(function (item) {
                            return item.accessor.applyChanges(item.cartItem);
                        })
                        .value();

                    var activeItem = _.find(itemsToAddToCart, {
                        BenefitID: currentBenefitId
                    });

                    return _.flattenDeep([itemsToAddToCart, getAdditionalItemsToAddToCart(activeItem)]);
                });
        }
    }
]);