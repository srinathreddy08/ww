'use strict';
angular.module('mercerApp').service('crossBenefitDependentMatchingFactory', [
    'contentAliasService',
    function (contentAliasService) {
        return {
            forEmployee: forEmployee
        };

        function forEmployee(employeeData) {
            var benefitTierDepMatch = contentAliasService.forData(employeeData)
                    .getConfigurationValue('HB.LifeEvent.BenefitTierDepMatch');

            var benefitsIds = benefitTierDepMatch && getBenefitsIds(benefitTierDepMatch.VALUE);

            var primaryBenefitId = benefitsIds && benefitsIds[0];
            var childBenefitId = benefitsIds && benefitsIds[1];

            return {
                getBenefitsShouldBeMatched: getBenefitsShouldBeMatched,
                restrictPlanSelectionAccordingToDependentMatching: restrictPlanSelectionAccordingToDependentMatching,
                isValidCart: isValidCart,
                getMatchingConfiguration: getMatchingConfiguration
            }

            function getBenefitsIds(matchingBenefits) {
                if (!matchingBenefits || !_.isArray(matchingBenefits) || !matchingBenefits.length) {
                    return null;
                }

                var filteredArr = _(matchingBenefits).filter().map(function(x) {
                    return x.replace('[', '').replace(']', '');
                }).value();
                return filteredArr.length ?
                    filteredArr[0]
                    .trim()
                    .split(':') :
                    null;
            }

            function restrictPlanSelectionAccordingToDependentMatching(benefitId, shoppingCart) {
                if (!getBenefitsShouldBeMatched()) {
                    return false;
                }

                if (benefitId !== childBenefitId) {
                    return false;
                }

                var primaryBenefit = getPrimaryBenefit(shoppingCart);
                if (!primaryBenefit) {
                    return false;
                }

                return primaryBenefit.IsNoCov;
            }

            function getMatchingConfiguration() {
                return {
                    benefitsShouldBeMatched: getBenefitsShouldBeMatched(),
                    primaryBenefitId: primaryBenefitId,
                    childBenefitId: childBenefitId
                }
            }

            function getBenefitsShouldBeMatched() {
                return primaryBenefitId && childBenefitId;
            }

            function isValidCart(shoppingCart) {
                var primaryBenefit = getPrimaryBenefit(shoppingCart);
                var childBenefit = getChildBenefit(shoppingCart);

                if (!primaryBenefit || !childBenefit) {
                    return true;
                }

                if (childBenefit.IsNoCov) {
                    return true;
                }

                return !primaryBenefit.IsNoCov && hasSameDependents(primaryBenefit, childBenefit);
            }

            function getPrimaryBenefit(shoppingCart) {
                return getBenefit(shoppingCart, primaryBenefitId);
            }

            function getChildBenefit(shoppingCart) {
                return getBenefit(shoppingCart, childBenefitId);
            }

            function getBenefit(shoppingCart, id) {
                return _(shoppingCart).find({ 'BenefitID': id });
            }

            function hasSameDependents(primaryBenefit, childBenefit) {
                var primaryDependents = primaryBenefit.DependentAssociationList;
                var childDependents = childBenefit.DependentAssociationList;

                return !_(primaryDependents).difference(childDependents).some()
                    && !_(childDependents).difference(primaryDependents).some();
            }
        }
    }
]);