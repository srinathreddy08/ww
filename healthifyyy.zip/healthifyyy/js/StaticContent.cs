﻿namespace Mercer.MBC.UI.Models.Sitecore
{
    using System.Collections.Generic;

    public class StaticContent
    {
        public Dictionary<string, string> Terms { get; set; }

        public Dictionary<string, string> AuthTerms { get; set; }

        public Dictionary<string, string> Gender { get; set; }

        public Dictionary<string, string> MaritalStatus { get; set; }

        public Dictionary<string, string> ComparisonSortBy { get; set; }

        public Dictionary<string, string> MessageCenterCategories { get; set; }

        public Dictionary<string, string> MessageCenterContactUs { get; set; }

        public Dictionary<string, string> Proxy { get; set; }

        public Dictionary<string, string> SortBy { get; set; }

        public List<Country> Countries { get; set; }

        public Dictionary<string, Image> Images { get; set; }

        public Dictionary<string, string> DcPlanTypes { get; set; }

        public Dictionary<string, string> MonthsNames { get; set; }
    }
}