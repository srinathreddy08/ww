﻿'use strict';
angular.module('mercer.hb').factory('expertGuidanceState', [
    'expertGuidanceGlobal',
    function (expertGuidanceGlobal) {
        return {
            isDoItYourselfFlow: isDoItYourselfFlow,
            useSuggestedPackageResource: useSuggestedPackageResource,
            parseUseSuggestedPackageResourceParameter: parseUseSuggestedPackageResourceParameter
        };

        function parseUseSuggestedPackageResourceParameter(useSuggestedPackageResourceParameter) {
            return useSuggestedPackageResourceParameter === undefined ||
                useSuggestedPackageResourceParameter === null ? useSuggestedPackageResource() : useSuggestedPackageResourceParameter;
        }

        function useSuggestedPackageResource() {
            return !!expertGuidanceGlobal.useSuggestedPackageResource;
        }

        function isDoItYourselfFlow(){
            return expertGuidanceGlobal.isDoItYourselfFlow;
        }
    }
]);