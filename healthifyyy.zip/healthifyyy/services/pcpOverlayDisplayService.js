﻿'use strict';
angular.module('mercerApp').factory('pcpOverlayDisplayService', [
    'pcpOverlayEnabled', 'electionRequiresPcpDataToBeCollected',
    function (pcpOverlayEnabled, electionRequiresPcpDataToBeCollected) {
        return {
            pcpOverlayShouldBeShown: pcpOverlayShouldBeShown
        };

        function pcpOverlayShouldBeShown(election, employeeData, additionalConditions) {
            return election && pcpOverlayEnabled(employeeData) &&
                electionRequiresPcpDataToBeCollected(election, employeeData) &&
                additionalConditions();
        };
    }
]);