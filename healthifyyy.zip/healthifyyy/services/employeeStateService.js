﻿'use strict';
angular.module('mercer.shared.content').factory('employeeStateService', [
    'benefitsService', 'stringService',
    function (benefitsService, stringService) {
        return {
            forEmployee: forEmployee,
            forAllEmployees: forAllEmployees
        };

        function forEmployee(employee) {
            var lifeEvent = employee.LifeEvents[0];
            var employeeState = {
                forCart: forCart,

                getElectedOptionForBenefit: getElectedOptionForBenefit,
                getEligiblePlansForBenefit: getEligiblePlansForBenefit,
                getElectedPlanForBenefitId: getElectedPlanForBenefitId,
                getElectedPlanForBenefitCategory: getElectedPlanForBenefitCategory,
                getElectedBenefitPlanOption: getElectedBenefitPlanOption,
                getFirstEligibleCoveragePlanForBenefit: getFirstEligibleCoveragePlanForBenefit,
                getBenefitByCategory: getBenefitByCategory,
                getHsaBenefit: getHsaBenefit,
                getLifeEvent: getLifeEvent
            };

            return employeeState;

            function getHsaBenefit() {
                return _(lifeEvent.EligibleBenefits)
                    .find(function (b) {
                        return benefitsService.isHSABenefit(b);
                    });
            }

            function getBenefitByCategory(benefitCategory) {
                return _(lifeEvent.EligibleBenefits)
                    .find({ BenefitCategory: benefitCategory });
            }

            function getElectedPlanForBenefitId(benefitId) {
                var benefit = _(lifeEvent.EligibleBenefits)
                    .find({ BenefitID: benefitId });

                if (!benefit) {
                    return null;
                }

                return benefit.ElectedPlan;
            }

            function getElectedPlanForBenefitCategory(benefitCategory) {
                var benefit = _(lifeEvent.EligibleBenefits)
                    .find({ BenefitCategory: benefitCategory });

                if (!benefit) {
                    return null;
                }

                return benefit.ElectedPlan;
            }

            function getEligiblePlansForBenefit(benefitId) {
                var benefit = _(lifeEvent.EligibleBenefits)
                    .find({ BenefitID: benefitId });

                if (!benefit) {
                    return null;
                }

                return benefit.EligiblePlans;
            }

            function getElectedOptionForBenefit(benefitId) {
                var electedPlan = getElectedPlanForBenefitId(benefitId);

                if (!electedPlan) {
                    return null;
                }

                return electedPlan.ElectedOption;
            }

            function getElectedBenefitPlanOption(benefitId, planId, optionId) {
                var eligiblePlans = getEligiblePlansForBenefit(benefitId);

                if (!eligiblePlans) {
                    return null;
                }

                var plan = _(eligiblePlans)
                    .find({ PlanID: planId });

                var electedOption = _(plan.EligibleOptions)
                    .find({ OptionID: optionId });

                return electedOption;
            }

            function getFirstEligibleCoveragePlanForBenefit(benefitId) {
                var eligiblePlans = getEligiblePlansForBenefit(benefitId);

                if (!eligiblePlans) {
                    return null;
                }

                return _(eligiblePlans)
                    .find({ IsNoCovPlan: false });
            }

            function getLifeEvent() {
                return lifeEvent;
            }

            function forCart(shoppingCart) {
                var electionData = getElections();

                return {
                    isNoCovElectionByBenefitId: isNoCovElectionByBenefitId,
                    isNoCovElectionForDependent: isNoCovElectionForDependent,
                    isCovElection: isCovElection,
                    getElectedBenefitIds: getElectedBenefitIds,
                    isElectedAmountInCartChanged: isElectedAmountInCartChanged,
                    getSpendingElection: getSpendingElection,
                    isCovSpendingElection: isCovSpendingElection,
                    areUnumBenefitsCovered: areUnumBenefitsCovered,
                    getElectedPlanForBenefit: getElectedPlanForBenefit,
                    getElectedOptionForBenefit: getElectedOptionForBenefit,
                    isNoCovElectionByBenefitCategory: isNoCovElectionByBenefitCategory
                };

                function getElectedBenefit(benefitId) {
                    return _(electionData).find(function (e) {
                        return e.ElectedBenefit.BenefitID === benefitId;
                    });
                }

                function getElectedPlanForBenefit(benefitId) {
                    return getElectedBenefit(benefitId).ElectedPlan;
                }

                function getElectedOptionForBenefit(benefitId) {
                    return getElectedBenefit(benefitId).ElectedOption;
                }

                function isNoCovElectionByBenefitId(benefitId) {
                    return _(shoppingCart)
                        .find({ BenefitID: benefitId })
                        .IsNoCov;
                }

                function isNoCovElectionByBenefitCategory(benefitCategory) {
                    return _(shoppingCart)
                        .find({ BenefitCategory: benefitCategory })
                        .IsNoCov;
                }

                function isNoCovElectionForDependent(benefitId, dependentSsn) {

                    var benefit = _(shoppingCart)
                        .find({
                            BenefitID: benefitId
                        });

                    return benefit.IsNoCov || !(_(benefit.DependentAssociationList).includes(dependentSsn));
                }

                function isCovElection(benefitId) {
                    return !isNoCovElectionByBenefitId(benefitId);
                }

                function getElectedBenefitIds() {
                    return _(shoppingCart)
                        .filter(function (benefit) {
                            return !benefit.IsNoCov;
                        }).map(function (benefit) {
                            return benefit.BenefitID;
                        });
                }

                function areUnumBenefitsCovered(configuration) {
                    var qualBenefitsConfigValue = configuration.getConfigurationValue('HB.LifeEvent.Unum.QualBenefits');

                    if (!qualBenefitsConfigValue) {
                        return false;
                    }

                    var qualBenefits = stringService.convertArrayStringToArray(qualBenefitsConfigValue);

                    return _(shoppingCart)
                        .filter(function (item) {
                            return _(qualBenefits).some(function (benefit) {
                                return benefit === item.BenefitID;
                            });
                        }).filter(function (item) {
                            return !item.IsNoCov;
                        }).some(function (item) {
                            return item.EOIPendingStatus === "A" || item.EOIPendingStatus === "P";
                        });
                }

                function isElectedAmountInCartChanged(benefitId) {
                    var domOption = employeeState.getElectedOptionForBenefit(benefitId);
                    var cartOption = getCartItem(benefitId);

                    return domOption.AmountElected !== cartOption.Amount;
                }

                function getCartItem(benefitId) {
                    return _(shoppingCart).find({
                        BenefitID: benefitId
                    });
                }

                function getElections() {
                    return _(shoppingCart)
                        .mapValues(function (cartItem) {
                            var benefit = lifeEvent.EligibleBenefitsMap[cartItem.BenefitID];
                            var plan = benefit.EligiblePlansMap[cartItem.PlanID];
                            var option = plan.EligibleOptionsMap[cartItem.OptionID];
                            var electedPlan = benefit.ElectedPlan;

                            return {
                                ElectedBenefit: benefit,
                                ElectedPlan: plan,
                                ElectedOption: option,
                                Carrier: plan && plan.Carrier,
                                cartItem: cartItem
                            };
                        })
                        .value();
                }

                function getSpendingElection(type) {
                    var isRequeredBenefit = benefitsService['is' + type + 'Benefit'];

                    return _(electionData)
                        .find(function (election) {
                            return isRequeredBenefit(election.ElectedBenefit);
                        });
                }

                function isCovSpendingElection(type) {
                    var election = getSpendingElection(type);
                    return election && !election.ElectedPlan.IsNoCovPlan;
                }
            }
        }

        function forAllEmployees(data) {
            var employeeState = {
                getAllLifeEvents: getAllLifeEvents,
                getAllBenefitsInLifeEvents: getAllBenefitsInLifeEvents,
                getAllBenefits: getAllBenefits,
                getAllPlans: getAllPlans,
                getAllOptions: getAllOptions,
                getAllCarriers: getAllCarriers
            };

            return employeeState;

            function getAllLifeEvents() {
                return _(data.Employee)
                    .pick(['PendingEmployee', 'PendingLEVEmployee', 'CurrentCoveragesEmployee', 'HistoricalCoverages', 'FutureCoverages'])
                    .values()
                    .flattenDeep()
                    .compact()
                    .map('LifeEvents')
                    .flattenDeep()
                    .value();
            }

            function getAllBenefitsInLifeEvents() {
                var lifeEvents = getAllLifeEvents();

                return _(lifeEvents)
                    .map(function (lifeEvent) {
                        return _(lifeEvent.EligibleBenefits)
                            .map(function (benefit) {
                                return {
                                    lifeEvent: lifeEvent,
                                    benefit: benefit
                                };
                            })
                            .value();
                    })
                    .flattenDeep()
                    .value();
            }

            function getAllBenefits() {
                var lifeEvents = getAllLifeEvents();

                return _(lifeEvents)
                    .map('EligibleBenefits')
                    .flattenDeep()
                    .value();
            }

            function getAllPlans() {
                var benefits = getAllBenefits();

                return _(benefits)
                    .map('EligiblePlans')
                    .flattenDeep()
                    .value();
            }

            function getAllOptions() {
                var plans = getAllPlans();

                return _(plans)
                    .map('EligibleOptions')
                    .flattenDeep()
                    .value();
            }

            function getAllCarriers() {
                return _(getAllLifeEvents())
                    .map('Carriers')
                    .map(_.values)
                    .flatten()
                    .value();
            }
        }
    }
]);