﻿angular.module('mercer.shared.content').factory('supplementalTabService', [
    'contentAliasService',
    function (contentAliasService) {
        return { forEnrollment: forEnrollment };

        function forEnrollment(enrollment) {
            var enrollmentContent = contentAliasService.forData(enrollment);

            var supplementalBenefitsPresented = enrollment.Data.CurrentCoveragesEmployee &&
                _.some(enrollment.Data.CurrentCoveragesEmployee.LifeEvents[0].EligibleBenefits, { BenefitCategory: 'SUPPLEMENTAL' });

            var showSeparateTab = enrollmentContent.getConfigurationValue('HB.LifeEvent.Summary.SupplementalCoverages') === 'Y';

            return {
                showSeparateTab: showSeparateTab && supplementalBenefitsPresented,
                showHealthInsuranceSubTab: !showSeparateTab && supplementalBenefitsPresented
            };

        }
    }
]
);
