﻿'use strict';
angular
    .module('mercer.db.shared')
    .factory('benefitsService', [
        'benefitCategoryMap', 'stringService',
        function (benefitCategoryMap, stringService) {
            var result = {
                isBenefitHiddenFromUser: isBenefitHiddenFromUser,
                isOptionDerivedBenefit: isBenefitOfType('OPTDRV'),
                isHSABenefit: isBenefitOfType('HSA'),
                isHSAFLBenefit: isBenefitOfType('HSAFL'),
                isAdditionalBenefitCategory: isAdditionalBenefitCategory('ADDITIONAL'),
                isHCFSABenefit: isHCFSABenefit(),
                isDCFSABenefit: isBenefitPlanTypeEqualsTo(31),
                isLPFSABenefit: isBenefitPlanTypeEqualsTo(32),
                isAmountBasedBenefit: isBenefitOfType('AMT'),
                isAmountDirectedBenefit: isBenefitOfType('AMTDRC'),
                isOptionDirectedBenefit: isBenefitOfType('OPTDRC'),
                isBenefitOfMedicalCategory: isBenefitOfCategory('MEDICAL'),
                isBenefitOfVoluntaryCategory: isBenefitOfVoluntaryCategory,
                isBenefitOfCreditCategory: isBenefitOfCategory('CREDIT'),
                isBenefitOfSurchargeCategory: isBenefitOfCategory('SURCHARGE'),
                isRXBenefitCategory: isBenefitOfCategory('PHARMACY'),
                isBenefitOfDentalCategory: isBenefitOfCategory('DENTAL'),
                isBenefitOfVisionCategory: isBenefitOfCategory('VISION'),
                isBenefitOfMedicalId: isBenefitOfId('MEDICAL'),
                isBenefitOfDentalId: isBenefitOfId('DENTAL'),
                isBenefitMedicalDentalOrVision: isBenefitMedicalDentalOrVision,
                isComparisonBenefit: isComparisonBenefit,
                isPcpBenefit: isPcpBenefit,
                pcpCategories: getPcpBenefitCategories()
            };

            return result;
            
            function isBenefitHiddenFromUser(benefit) {
                return benefit.BenefitType === 'HSAFL';
            }

            function isComparisonBenefit(benefit) {
                return (benefitCategoryMap[benefit.BenefitCategory] || benefitCategoryMap['default']).isComparison;
            }

            function getPcpBenefitCategories() {
                return ["MEDICAL", "DENTAL"];
            }

            function isBenefitOfVoluntaryCategory(benefit) {
                return stringService.startsWith(benefit.BenefitCategory, "VB_");
            }

            function isPcpBenefit(benefit) {
                return (benefitCategoryMap[benefit.BenefitCategory] || benefitCategoryMap['default']).isPcpCategory;
            }

            function isBenefitMedicalDentalOrVision(benefit) {
                return result.isBenefitOfMedicalCategory(benefit)
                    || result.isBenefitOfDentalCategory(benefit)
                    || result.isBenefitOfVisionCategory(benefit);
            }

            function isHCFSABenefit() {
                return function(benefit) {
                    var isSpendingBenefitCategory = benefit.BenefitCategory === 'SPENDING';
                    var isHCFSABenefitPlanType = isBenefitPlanTypeEqualsTo(30)(benefit);
                    var isHSAFLBenefit = isBenefitOfType('HSAFL')(benefit);

                    return !result.isHSABenefit(benefit)
                        && !isHSAFLBenefit
                        && isSpendingBenefitCategory
                        && isHCFSABenefitPlanType;
                };
            }

            function isBenefitOfType(benefitType) {
                return function(benefit) {
                    return benefit.BeneFlexYearBenefitTypeInd === benefitType;
                };
            }

            function isAdditionalBenefitCategory(benefitCategory) {
                return function(benefit) {
                    return benefit.BenefitCategory === benefitCategory;
                };
            }

            function isBenefitPlanTypeEqualsTo(planType) {
                return function(benefit) {
                    var covPlan = _(benefit.EligiblePlans)
                        .find({ IsNoCovPlan: false });

                    return covPlan && covPlan.Type === planType;
                };
            }

            function isBenefitOfCategory(category) {
                return function(benefit) {
                    return benefit.BenefitCategory === category;
                };
            }

            function isBenefitOfId(benefitId) {
                return function(benefit) {
                    return benefit.BenefitID === benefitId;
                };
            }
        }
    ]);