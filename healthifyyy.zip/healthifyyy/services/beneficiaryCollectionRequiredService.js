﻿'use strict';
angular.module('mercer.services').factory('beneficiaryCollectionRequiredService', [
    'mbcContentAndData', 'cacheService', '$q',
    function (mbcContentAndData, cacheService, $q) {
        return {
            setBeneficiaryCollectionRequiredCacheItems: setBeneficiaryCollectionRequiredCacheItems,
            getCacheKey: getCacheKey,
            getSetToNocovCacheKey: getSetToNocovCacheKey,
            clearCache: clearCache,
            isBeneficiaryCollectionRequired: isBeneficiaryCollectionRequired,
            getBeneficiaryCollectionRequiredSetToNoCovIds: getBeneficiaryCollectionRequiredSetToNoCovIds
        };

        function getCacheKey(lifeEvent) {
            return 'plansRequiringBeneficiariesAdded.' + lifeEvent.LifeEventID + '.'
                + lifeEvent.LifeEventDate + '.'
                + lifeEvent.LifeEventSequenceNumber;
        }

        function getSetToNocovCacheKey(lifeEvent) {
            return 'plansRequiringBeneficiariesSetToNocov.' + lifeEvent.LifeEventID + '.'
                + lifeEvent.LifeEventDate + '.'
                + lifeEvent.LifeEventSequenceNumber;
        }

        function clearCache(lifeEvent) {
            cacheService.cache.remove(getCacheKey(lifeEvent));
            cacheService.cache.remove(getSetToNocovCacheKey(lifeEvent));
        }

        function isBeneficiaryCollectionRequired(lifeEvent) {
            var cacheKey = getCacheKey(lifeEvent);
            var plans = cacheService.cache.get(cacheKey);
            return (plans && Object.keys(plans).length > 0);
        }

        function getBeneficiaryCollectionRequiredSetToNoCovIds(lifeEvent) {
            var cacheKey = getSetToNocovCacheKey(lifeEvent);
            var plans = cacheService.cache.get(cacheKey);
            plans = plans ? plans : {};
            return Object.keys(plans);
        }

        function setBeneficiaryCollectionRequiredCacheItems(benefitId, newCartObject) {

            if (!benefitId) {
                return;
            }

            var promises = {
                newCart: newCartObject.$promise,
                enrollmentContent: mbcContentAndData.getEnrollmentContent()
            };

            $q.all(promises).then(beneficiaryCollectionRequiredServiceAsync);

            function beneficiaryCollectionRequiredServiceAsync(data) {                
                var newCart = data.newCart;
                var enrollmentContent = data.enrollmentContent;
                var newCartItem = _.find(newCart.ShoppingCart, { BenefitID: benefitId });
                var enrollmentBenefit = enrollmentContent.data.PendingEmployee.LifeEvents[0].EligibleBenefitsMap[benefitId];
                var electedPlan;
                var cacheKey = getCacheKey(enrollmentContent.data.PendingEmployee.LifeEvents[0]);
                var setToNoCovCacheKey = getSetToNocovCacheKey(enrollmentContent.data.PendingEmployee.LifeEvents[0]);

                if (!needToCollect()) {
                    if (hasBeneficiaryRequiredPlanButNoCov()) {
                        var plansRequiringBeneficiariesSetToNoCov = {};
                        if (!cacheService.cache.get(setToNoCovCacheKey)) {
                            cacheService.cache.put(setToNoCovCacheKey, plansRequiringBeneficiariesSetToNoCov);
                        }
                        plansRequiringBeneficiariesSetToNoCov = cacheService.cache.get(setToNoCovCacheKey);
                        if (!plansRequiringBeneficiariesSetToNoCov[benefitId]) {
                            plansRequiringBeneficiariesSetToNoCov[benefitId] = enrollmentBenefit;
                            cacheService.cache.put(setToNoCovCacheKey, plansRequiringBeneficiariesSetToNoCov);
                        }
                    }
                    if (cacheService.cache.get(cacheKey) && (cacheService.cache.get(cacheKey))[benefitId]) {
                        delete cacheService.cache.get(cacheKey)[enrollmentBenefit.BenefitID];                        
                    }
                    return;
                } else {
                    
                        var plansRequiringBeneficiariesAdded = {};
                        if (!cacheService.cache.get(cacheKey)) {
                            cacheService.cache.put(cacheKey, plansRequiringBeneficiariesAdded);
                            
                        }
                        plansRequiringBeneficiariesAdded = cacheService.cache.get(cacheKey);
                        if (!plansRequiringBeneficiariesAdded[benefitId]) {
                            plansRequiringBeneficiariesAdded[benefitId] = enrollmentBenefit;
                            cacheService.cache.put(cacheKey, plansRequiringBeneficiariesAdded);
                        }
                    
                    return;
                }

                function hasBeneficiaryRequiredPlanButNoCov() {
                    if (!newCartItem || !enrollmentBenefit) {
                        return true;
                    }

                    electedPlan = enrollmentBenefit.EligiblePlansMap[newCartItem.PlanID];

                    if (electedPlan?.IsNoCovPlan) {
                        return enrollmentBenefit.EligiblePlans.some(function (plan) {
                            return plan.PlanYearDefBeneRequirement === 'R';
                        });                        
                    }

                    return false;
                }

                function needToCollect() {
                    if (!hasBeneficiaryRequiredPlanButNoCov()) {

                        electedPlan = enrollmentBenefit.EligiblePlansMap[newCartItem.PlanID];

                        if (electedPlan?.IsNoCovPlan || electedPlan?.PlanYearDefBeneRequirement !== 'R') {
                            return false;
                        }

                        /*if (newCart.BeneficiaryData.Designations && newCart.BeneficiaryData.Designations[benefitId]) {
                            return false;
                        }*/

                        return true;
                    }
                }
            }
        }
    }
]);