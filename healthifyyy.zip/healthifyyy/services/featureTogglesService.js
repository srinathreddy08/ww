﻿'use strict';
angular.module('mercer.db.shared').factory('featureTogglesService', [
    '$cookies', 'featureDefaults',
    function ($cookies, featureDefaults) {
        var featureOverridesCookieName = 'features';

        return {
            getFeatures: getFeatures,
            setFeatureOverrides: setFeatureOverrides,
            clearFeatureOverrides: clearFeatureOverrides,
            getOverridenFeatures: getOverridenFeatures,
            featureOverridesCookieName: featureOverridesCookieName
        };

        function getFeatures() {
            return _.defaults({}, getFeatureOverrides(), featureDefaults);
        }

        function getFeatureOverrides() {
            var featureOverridesString = $cookies.get(featureOverridesCookieName);

            if (angular.isNullOrUndefined(featureOverridesString)) {
                return {};
            }

            return _(featureOverridesString.split(' ').join('').split(','))
                .map(function (featureOverrideString) {
                    return featureOverrideString.split(':');
                })
                .fromPairs()
                .mapValues(function (overrideValue) {
                    return overrideValue === 'true';
                })
                .value();
        }

        function setFeatureOverrides(desiredState) {
            var overrides = _(getFeaturesThatDifferFromDefaults(desiredState))
                .map(function (featureName) {
                    var desiredFeatureState = desiredState[featureName];

                    return featureName + ':' + desiredFeatureState;
                })
                .value();

            if (overrides.length > 0) {
                $cookies.put(featureOverridesCookieName, overrides.join(','), {
                    path: '/'
                });
            } else {
                $cookies.remove(featureOverridesCookieName, {
                    path: '/'
                });
            }
        }

        function clearFeatureOverrides() {
            $cookies.remove(featureOverridesCookieName, {
                path: '/'
            });
        }

        function getOverridenFeatures() {
            return getFeaturesThatDifferFromDefaults(getFeatureOverrides());
        }

        function getFeaturesThatDifferFromDefaults(state) {
            return _(featureDefaults)
                .pickBy(function (featureDefault, featureName) {
                    var desiredFeatureState = state[featureName];
                    return desiredFeatureState !== undefined && desiredFeatureState !== featureDefault;
                })
                .keys()
                .value();
        }
    }
]);
