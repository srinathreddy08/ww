﻿'use strict';
angular.module('mercer.services').service('mbcUtilService', ['staticContent', '_', 'contentAliasService', function (staticContent, _, contentAliasService) {
    var service = {
        capitalizeFirstLetter: function(str) {
            if (!str) {
                return "";
            }

            return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
        },
        capitalizeWord: function(str) {
            if (!str) {
                return "";
            }

            return str.toUpperCase();
        },

        getCoverageImage: getCoverageImage,
        getElectionCoverageImage: getElectionCoverageImage,
        mapGenericVBImage: function(category, planType, benefitType, isNoCov) {
            var key, categoryNoSpaces = category.replace(/ /g, '');
            if (!staticContent.Images) {
                return '';
            }

            //First category then look at category_planType_On then look at category_benefitType_On
            return staticContent.Images[categoryNoSpaces + '_Off'] || staticContent.Images[categoryNoSpaces + '_' + planType + '_Off'] ||
                staticContent.Images[categoryNoSpaces + '_' + benefitType + '_Off'] || '';
        },
        getVBAliasMap: function() {
            //VB Aliases do not follow the same pattern as other benefits, need a category to alias mapping for them
            return {
                'VB_AUTO': 'HB.LifeEvent.VoluntaryBenefits.AutoHome',
                'VB_HOME': 'HB.LifeEvent.VoluntaryBenefits.AutoHome',
                'VB_PET': 'HB.LifeEvent.VoluntaryBenefits.Pet',
                'VB_PERSONALPROTECTION': 'HB.LifeEvent.VoluntaryBenefits.PersonalProtection',
                'VB_SUPPLEMENTAL': 'HB.LifeEvent.VoluntaryBenefits.Supplemental'
            };
        }
    };
    return service;
    
    function getCoverageImage(benefit, plan, employeeData, isVb) {
        var electionDetails = {
            BenefitContentAlias: benefit.ContentAlias,
            BenefitType: benefit.BenefitType,
            BenefitCategory: benefit.BenefitCategory,
            PlanType: plan && plan.Type,
            CarrierContent: plan && plan.Carrier && plan.Carrier.CarrierContent
        };

        return getElectionCoverageImage(electionDetails, employeeData, isVb);
    }

    function getElectionCoverageImage(electionDetails, employeeData, isVb) {
        return getCarrierLogo() ||
            getBenefitLogo() ||
            getNoCovLogo() ||
            getEmptyImg();

        function getLogo(content, logoField) {
            if (!content) {
                return null;
            }

            var logo = content[logoField];
            if (!logo || isEmptyBase64Logo()) {
                return null;
            }

            return {
                Alt: logo.Alt || content.ShortName,
                LogoSrc: logo.IsBase64 && logo.LogoSrc
                    ? 'data:image/jpeg;base64,' + logo.LogoSrc
                    : '/media/' + logo.MediaId
            };

            function isEmptyBase64Logo() {
                return logo.IsBase64 && !logo.LogoSrc;
            }
        }

        function getCarrierLogo() {
            return getLogo(electionDetails.CarrierContent, 'CarrierLogo');
        }

        function getBenefitLogo() {
            var dataContent = contentAliasService.forData(employeeData);
            var benefitData = dataContent.getContentObject(electionDetails.BenefitContentAlias);
            return getLogo(benefitData, 'BenefitLogo');
        }

        function getNoCovLogo() {
            if (!staticContent.Images) {
                return null;
            }

            var category = electionDetails.BenefitCategory;
            var categoryNoSpaces = category.replace(/ /g, '');
            
            var benefitType = electionDetails.BenefitType;

            //First category then look at category_planType_On then look at category_benefitType_On
            var keyEnding = isVb ? '_Off' : '_On';
            var staticImg = staticContent.Images[categoryNoSpaces + keyEnding] ||
                staticContent.Images[categoryNoSpaces + '_' + electionDetails.PlanType + keyEnding] ||
                staticContent.Images[categoryNoSpaces + '_' + benefitType + keyEnding];

            return staticImg ? {
                LogoSrc: '/media/' + staticImg.MediaId,
                Alt: staticImg.Alt
            } : null;

        }

        function getEmptyImg() {
            return {
                LogoSrc: null,
                Alt: null
            };
        }
    }
}]);