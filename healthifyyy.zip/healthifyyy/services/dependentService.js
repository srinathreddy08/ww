﻿'use strict';
angular.module('mercer.services').factory('dependentService', [
    'dependentResourceService', '_', 'contentAliasService', 'logService', 'staticContent',
    function (dependentResourceService, _, contentAliasService, logService, staticContent) {
        var spouseCodes = ['S', 'SSNT', 'DPT', 'SST', 'DPNT'];
        var spouseRelationTypes = ['SP', 'DP', 'SGSP'];
        var logger = logService.getLogger('DependentUser.Coverage');

        return {
            addDependent: addDependent,
            updateDependent: updateDependent,
            getRestrictions: dependentResourceService.getRestrictions,
            getDependentRestrictions: getDependentRestrictions,
            getDependentRestrictionsByCode: getDependentRestrictionsByCode,
            canEditCoverage: canEditCoverage,
            getSpouseCodes: getSpouseCodes,
            getSpouseRelationTypes: getSpouseRelationTypes,
            getAvailableRelationships: getAvailableRelationships
        };

        function addDependent(dependentsArray) {
            return dependentResourceService.addDependent(_.map(dependentsArray, cloneAndChangeDependentBeforeSave));
        }

        function updateDependent(originalDependentSsn, dependentFormData, isDomainPage) {
            logger.debug('saveDependent()');

            var dependentToSave = cloneAndChangeDependentBeforeSave(dependentFormData);

            dependentToSave.Ssn = dependentFormData.IsDummySSN && !dependentFormData.Ssn ?
                originalDependentSsn :
                dependentFormData.Ssn;
            dependentToSave.SuppressRecalc = isDomainPage;

            logger.debug('isDomainPage', isDomainPage);

            return dependentResourceService.updateDependent(originalDependentSsn, dependentToSave, isDomainPage);
        }

        function cloneAndChangeDependentBeforeSave(dependentFormData) {
            var resultDependent = _.cloneDeep(dependentFormData);

            setNullAddressIfSame();
            removeStateIfCountryHasNoStates();
            formatBirthDate();

            return resultDependent;

            function removeStateIfCountryHasNoStates() {
                if (resultDependent.Address) {
                    var countryRecord = staticContent.Countries[resultDependent.Address.Country || 'USA'];
                    if (!countryRecord) {
                        resultDependent.Address.State = null;
                    } else {
                        var states = countryRecord.States;
                        if (!states || states.length === 0 || !_.find(states, { StateProvinceCode: resultDependent.Address.State })) {
                            resultDependent.Address.State = null;
                        }
                    }
                }
            }

            function setNullAddressIfSame() {
                if (resultDependent.SameAddress) {
                    resultDependent.Address = null;
                }
                delete resultDependent.SameAddress;
            }

            function formatBirthDate() {
                resultDependent.BirthDate = moment(resultDependent.BirthDate).format("MM/DD/YYYY");
            }
        }

        function getDependentRestrictions(dep, restrictions) {
            return getDependentRestrictionsByCode(dep.RelationshipCode, restrictions);
        }

        function getDependentRestrictionsByCode(code, restrictions) {
            return restrictions.DependentRestrictions && restrictions.DependentRestrictions[code];
        }

        function canEditCoverage(hasCoverage, coverageRule) {
            var coverageRules = {
                addOnly: 'A',
                dropOnly: 'D',
                addAndDrop: 'B',
                notEditable: 'N'
            };

            var canAddCoverage = coverageRule === coverageRules.addAndDrop || coverageRule === coverageRules.addOnly;
            var canDropCoverage = coverageRule === coverageRules.addAndDrop || coverageRule === coverageRules.dropOnly;

            return hasCoverage ? canDropCoverage : canAddCoverage;
        }

        function getSpouseCodes() {
            return spouseCodes;
        }

        function getSpouseRelationTypes() {
            return spouseRelationTypes;
        }

        function getAvailableRelationships(employeeData, dependentRestrictions) {
            if (!dependentRestrictions) {
                return {};
            }

            var content = contentAliasService.forData(employeeData);
            var dependentRelationshipsContent =
                content.getObjectOrDefault('HB.Common.CommonTerms.RelationshipDependent');

            return _(dependentRelationshipsContent)
                .pickBy(function (v, relationshipCode) {
                    return _.includes(dependentRestrictions.AvailableRelationshipCodes, relationshipCode);
                })
                .value();
        }
    }
]);