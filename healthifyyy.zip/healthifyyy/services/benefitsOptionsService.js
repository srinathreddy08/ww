﻿'use strict';
angular.module('mercer.services').factory('benefitsOptionsService', [
    'contentAliasService', 'stringService', 'employeeStateService',
    function (contentAliasService, stringService, employeeStateService) {

        return {
            overrideOptions: overrideOptions,
            getOverrideOptionsConfiguration: getOverrideOptionsConfiguration
        };

        function overrideOptions(data) {
            var allBenefits = employeeStateService.forAllEmployees(data).getAllBenefits();

            var benefitsOverrideOptionValues = getOverrideOptionsConfiguration(data);

            _(allBenefits).forEach(function (benefit) {
                var benefitOptionValue = benefitsOverrideOptionValues[benefit.BenefitID];
                if (benefitOptionValue) {
                    overrideOptionNameForEmployees(benefit, benefitOptionValue, data);
                }
            });
        }

        function getOverrideOptionsConfiguration(data) {
            var overrideBenefitsOptionConfiguration = contentAliasService.forData(data)
                .getAliasObjectOrDefault('HB.LifeEvent.OptionNameOverride');

            var result = {};

            _.forEach(overrideBenefitsOptionConfiguration, function (val, key) {
                if (!key) {
                    return;
                }

                var overridenValue = contentAliasService.forData(data).getContentValue(val.ContentPath);
                if (!overridenValue) {
                    return;
                }

                var parts = overridenValue.split(/\ *: */);
                var optionId = parts[0];
                var overrideOptionValue = parts[1];

                var benefitIDs = _(stringService.convertArrayStringToArray(key)).keyBy().value();
                _(benefitIDs).forEach(function (benefitID) {
                    var newOption = {};
                    newOption[optionId] = overrideOptionValue;
                    result[benefitID] = _.assign({}, result[benefitID], newOption);
                });
            });

            return result;
        }

        function overrideOptionForBenefitPlans(employee, benefit, newContentId, optionId) {
            var forEmployee = employeeStateService.forEmployee(employee);
            var electedOption = forEmployee.getElectedOptionForBenefit(benefit.BenefitID);

            if (electedOption && electedOption.OptionID === optionId) {
                electedOption.ContentAlias = newContentId;
            }

            var eligiblePlans = forEmployee.getEligiblePlansForBenefit(benefit.BenefitID);
            _.filter(eligiblePlans, function (plan) {
                var option = _(plan.EligibleOptions).find({ OptionID: optionId });
                if (option) {
                    return option.ContentAlias = newContentId;
                }
            });
        }

        function overrideBenefitOptionsAndContent(employee, benefit, overrideOptions, data) {
            _.forEach(overrideOptions, function (overrideOptionValue, optionId) {
                var newContentId = "/overridenPlanOptionValue/" + benefit.BenefitID + "_" + optionId;
                data.Content[newContentId] = overrideOptionValue;

                overrideOptionForBenefitPlans(employee, benefit, newContentId, optionId);
            });
        }

        function overrideOptionNameForEmployees(benefit, overrideOptionsValue, data) {
            var allEmployees = _(data.Employee)
                .pick(['PendingEmployee', 'PendingLEVEmployee', 'CurrentCoveragesEmployee', 'HistoricalCoverages', 'FutureCoverages'])
                .values()
                .flattenDeep()
                .value();

                _.filter(allEmployees, function (employee) {
                    if (!_(employee).isEmpty()) {
                        overrideBenefitOptionsAndContent(employee, benefit, overrideOptionsValue, data);
                    }
                });
        }
    }
]);
