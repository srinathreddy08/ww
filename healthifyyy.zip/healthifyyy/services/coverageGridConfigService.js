'use strict';
angular.module('mercer.hb').factory('coverageGridConfigService', [
    'contentAliasService', '$cookies',
    function (contentAliasService, $cookies) {
        return {
            forData: forData
        };

        function forData(employeeData) {
            var data = contentAliasService.forData(employeeData);
            
            var coverageGridConfig = data.getConfiguration('HB.LifeEvent.WhosCovered.CoverageGridConfig').asNumber();
            var expandCoverageGridConfig = data.getConfiguration('HB.LifeEvent.WhosCoveredGridOverride').asStringArray();

            return {
                shouldShowCoverage: shouldShowCoverage(),
                shouldDefaultToBestMatchPlan: shouldDefaultToBestMatchPlan(),
                shouldBeExpandedInLifeEventPage: shouldBeExpandedInLifeEventPage(),
                shouldBeExpandedInDomainPage: shouldBeExpandedInDomainPage(), 
                isDeferredCoverageModeEnabled: getIsDeferredCoverageModeEnabled()
            };

            function shouldShowCoverage() {
                return coverageGridConfig !== 0;
            }

            function shouldDefaultToBestMatchPlan() {
                return coverageGridConfig === 2;
            }

            function shouldBeExpandedInLifeEventPage() {
                var config = _(expandCoverageGridConfig);
                return config.includes('0') || getIsDeferredCoverageModeEnabled();
            }

            function shouldBeExpandedInDomainPage() {
                return _(expandCoverageGridConfig).includes('1');
            }

            function getIsDeferredCoverageModeEnabled() {
                return coverageGridConfig ===3 ;
            }
        }
    }
]);