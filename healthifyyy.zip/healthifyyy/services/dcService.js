﻿'use strict';
angular.module('mercer.services').factory('dcService', function () {
    return {
        isBenefitDc: isBenefitDc,
        getPayPeriodPlanCost: getPayPeriodPlanCost,
        getPlanCost: getPlanCost
    };

    function isBenefitDc(benefit, employee) {
        var contributionTypes = employee.ContributionTypes;
        return contributionTypes && contributionTypes.indexOf(benefit.BenefitID) > -1;
    }

    function getPlanCost(option, periodName) {
        var employerCost = option['Employer' + periodName + 'Cost'] || 0;
        var employeeCost = option['Employee' + periodName + 'Cost'] || 0;

        return employerCost + employeeCost;
    }

    function getPayPeriodPlanCost(option) {
        return getPlanCost(option, 'PayPeriod');
    }
});