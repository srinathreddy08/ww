﻿'use strict';
angular.module('mercer.hb').service('dependentVerificationService', [
  'timeService', 'contentAliasService', 'overlayService', '$q', 'comparisonBenefitCategories', 'displayedComparisonCategories', 'lifeEventVerificationService',
  function(timeService, contentAliasService, overlayService, $q, comparisonBenefitCategories, displayedComparisonCategories, lifeEventVerificationService) {
    return {
      forData: forData,
    };

    function forData(employeeData) {

      var content = contentAliasService.forData(employeeData);
      var isVerificationDocumentsToggle = content.getConfigurationValue('HB.VerificationDocuments.Toggle') === 'Yes';

      return {
        dependentIsCountedAsUnverified: dependentIsCountedAsUnverified,
        isDependentPending: isDependentPending,
        // dependentRequiresVerificationByCoverage  should be removed when old Required Documents page will be removed
        dependentRequiresVerificationByCoverage: dependentRequiresVerificationByCoverage,
        dependentRequiresVerificationByStatus: dependentRequiresVerificationByStatus,
        isDependentVerificationEnabled: isDependentVerificationEnabled,
        showDependentVerificationOverlayForNewlyAddedDependents: showDependentVerificationOverlayForNewlyAddedDependents,
        showDependentVerificationOverlayForNewlyCoveredDependents: showDependentVerificationOverlayForNewlyCoveredDependents,
        overlayShowsWhen: overlayShowsWhen,
        getVerificationDocumentsToggle: getVerificationDocumentsToggle,
        showOverlayOnPlanChange: showOverlayOnPlanChange,
        isCurrentCoverageHaveNotDevForDependent: isCurrentCoverageHaveNotDevForDependent,
      };

      function showOverlay() {
        return overlayService.open('/life-event/views/dependent-verification-overlay',
          {
            employeeData: employeeData,
            isVerificationDocumentsToggle: isVerificationDocumentsToggle,
          });
      }

      function overlayShowsWhen() {
        return content
          .getConfiguration('HB.LifeEvent.LEDepVerificationTrigger')
          .asSwitch({
            dependentIsAdded: '0',
            dependentIsCovered: '1',
          });
      }

      function dependentIsExemptedFromVerification(dependent) {
        var relationTypesExemptFromDependentVerification = content
          .getConfiguration('HB.LifeEvent.RelationTypesExemptFromDependentVerification')
          .asStringArray();

        return relationTypesExemptFromDependentVerification.indexOf(dependent.RelationType) !== -1;
      }

      function dependentIsCountedAsUnverified(dependent, elections, benefitCategory) {
        if (isVerificationDocumentsToggle) {
          return isDependentVerificationEnabledPerBenefit(dependent, elections, benefitCategory);
        }

        return false;
      }

      function isDependentVerificationEnabledPerBenefit(dependent, elections, benefitCategory) {
        const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
        const smallMarketData = empData.SmallMarketData;
        let listOfBenefitsEnabledForVerification = [];
        if (smallMarketData.BenefitsWithVerificationEnabled !== null) {
          listOfBenefitsEnabledForVerification = smallMarketData.BenefitsWithVerificationEnabled.split(',');
        }
        const currentElectionByBenefitCategory = Object.values(elections).find(election => election.BenefitCategory === benefitCategory);
        if (listOfBenefitsEnabledForVerification.length === 0) return false;

        return smallMarketData.DepEligVerificationType === 'PEND'
          && listOfBenefitsEnabledForVerification.includes(currentElectionByBenefitCategory.BenefitCategory)
            && (currentElectionByBenefitCategory && currentElectionByBenefitCategory.DependentAssociationList
                && currentElectionByBenefitCategory.DependentAssociationList.includes(dependent.Ssn))
            && dependentRequiresVerificationByStatus(dependent);
      }

      function dependentRequiresVerificationByStatus(dependent) {
        if (dependentIsExemptedFromVerification(dependent)) {
          return false;
        }

        return dependent.DepVerificationStatus !== 'Y';
      }

      function dependentRequiresVerificationByCoverage(dependent, elections) {
        return dependentIsCovered(dependent, elections);
      }

      function dependentIsCovered(dependent, elections) {
        var dependentIsCoveredInCart = dependentIsCoveredIn(elections);

        return dependentIsCoveredInCart(dependent);
      }

      function isDependentPending(dependent) {
        if (!isDependentVerificationEnabled()) return false;

        return dependentRequiresVerificationByStatus(dependent);
      }

      function getVerificationDocumentsToggle() {
        return isVerificationDocumentsToggle;
      }

      function isDependentVerificationEnabled() {
        if (isVerificationDocumentsToggle) {
            const empData = employeeData.Data.PendingEmployee || employeeData.Data.FutureCoverages[0] || employeeData.Data.CurrentCoveragesEmployee;
          const smallMarketData = empData.SmallMarketData;
          return smallMarketData.DepEligVerificationType === 'PEND';
        }

        return false;
      }

      function showOverlayOnPlanChange(benefitId, shoppingCart) {
        let shouldShowOverlay = false;
        if (isVerificationDocumentsToggle) {
          const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
          const smallMarketData = empData.SmallMarketData;
          let listOfBenefitsEnabledForVerification;

          if (smallMarketData && empData.LifeEvents[0].LifeEventVerificationStatus !== 'Y') {
            listOfBenefitsEnabledForVerification = smallMarketData.BenefitsWithVerificationEnabled !== null ? smallMarketData.BenefitsWithVerificationEnabled.split(',') : [];
            const currentPlanId = empData.LifeEvents[0].EligibleBenefits.find(benefit => benefit.BenefitID === benefitId).ElectedPlan.PlanID;
            const newPlanId = shoppingCart.find(election => election.BenefitID === benefitId).PlanID;

            if (smallMarketData.LifeEventVerificationType === 'ADD') {
              shouldShowOverlay = listOfBenefitsEnabledForVerification && listOfBenefitsEnabledForVerification.includes(benefitId)
                && lifeEventVerificationService.isLeHasLeIdForLev(smallMarketData, empData.LifeEvents[0]) && currentPlanId === 'NOCOV' && newPlanId !== 'NOCOV';
            } else {
              shouldShowOverlay = listOfBenefitsEnabledForVerification && listOfBenefitsEnabledForVerification.includes(benefitId)
                && lifeEventVerificationService.isLeHasLevType(smallMarketData) && lifeEventVerificationService.isLeHasLeIdForLev(smallMarketData, empData.LifeEvents[0])
                && currentPlanId !== newPlanId;
            }
          }
        }

        if (shouldShowOverlay) {
          return showOverlay();
        }

        return $q.resolve();
      }

      function showDependentVerificationOverlayForNewlyAddedDependents(initialElections, newElections) {
        let shouldShowOverlay = false;
        if (isVerificationDocumentsToggle) {
          const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
          const smallMarketData = empData.SmallMarketData;

          const isDepEligibleVerificationType = smallMarketData && smallMarketData.DepEligVerificationType === 'PEND' || smallMarketData.DepEligVerificationType === 'NOPEND';
          shouldShowOverlay = isDepEligibleVerificationType
            && overlayShowsWhen().dependentIsAdded
            && newUnverifiedDependentsWereAdded(initialElections, newElections);

        }

        if (shouldShowOverlay) {
          return showOverlay();
        }

        return $q.resolve();
      }

      function showDependentVerificationOverlayForNewlyCoveredDependents(initialElections, newElections, shoppingCart) {
        let shouldShowOverlay = false;
        if (isVerificationDocumentsToggle) {
          const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
          const smallMarketData = empData.SmallMarketData;
          let listOfBenefitsEnabledForVerification;
          let isDepEligibleVerificationType;
          let lifeEventVerificationType;

          if (smallMarketData) {
            isDepEligibleVerificationType = smallMarketData.DepEligVerificationType === 'PEND' || smallMarketData.DepEligVerificationType === 'NOPEND';
            lifeEventVerificationType = smallMarketData.LifeEventVerificationType;
            listOfBenefitsEnabledForVerification = smallMarketData.BenefitsWithVerificationEnabled !== null ? smallMarketData.BenefitsWithVerificationEnabled.split(',') : [];

            //conditions for DEV
            shouldShowOverlay = overlayShowsWhen().dependentIsCovered
              && isDepEligibleVerificationType
              && _(shoppingCart).some(election => election.IsChanged === true && listOfBenefitsEnabledForVerification && listOfBenefitsEnabledForVerification.includes(election.BenefitID))
              && newElectionsThatNeedVerificationPerBenefit(initialElections, newElections, listOfBenefitsEnabledForVerification);

            //conditions for LEV
            if (!shouldShowOverlay && lifeEventVerificationType !== 'NOLEV' && empData.LifeEvents[0].LifeEventVerificationStatus !== 'Y') {
              shouldShowOverlay = lifeEventVerificationService.isLeHasLeIdForLev(smallMarketData, empData.LifeEvents[0])
                && (_(shoppingCart).some(election => election.IsChanged === true && listOfBenefitsEnabledForVerification && listOfBenefitsEnabledForVerification.includes(election.BenefitID))
                  && (isThereNewElectionsForEmployee(initialElections, newElections, listOfBenefitsEnabledForVerification, lifeEventVerificationType)
                    || isCoverageAddedOrDroppedForDependentWhileLEVEnabled(newElections, listOfBenefitsEnabledForVerification, lifeEventVerificationType)));
            }
          }
        }

        if (shouldShowOverlay) {
          return showOverlay();
        }

        return $q.resolve();
      }

      function newUnverifiedDependentsWereAdded(updatedDependents) {
        var dependentsBeforeSave = employeeData.Data.PendingEmployee.Dependents;

        var newDependents = _(updatedDependents)
          .filter(function(a) {
            return !_(dependentsBeforeSave)
              .some(function(d) {
                return d.Ssn === a.Ssn;
              });
          })
          .value();

        return _(newDependents)
          .some(dependentRequiresVerificationByStatus);
      }

      function isCoverageAddedOrDroppedForDependentWhileLEVEnabled(newElections, listOfBenefitsEnabledForVerification, lifeEventVerificationType) {
        const currentEligibleBenefits = employeeData.Data.PendingEmployee.LifeEvents[0].EligibleBenefits.filter(benefit => listOfBenefitsEnabledForVerification && listOfBenefitsEnabledForVerification.includes(benefit.BenefitID));

        return newElections.some(election => {
          const electionFromDom = currentEligibleBenefits.find(benefit => benefit.BenefitID === election.BenefitID);
          if (!electionFromDom) return false;
          const dependentAssociationListFromDom = electionFromDom.ElectedPlan.ElectedOption.DependentAssociations.map(dep => dep.DependentSsn);
          const isAddedBen = _(election.DependentAssociationList).filter(d => !dependentAssociationListFromDom.includes(d)).some();
          const isDroppedBen = _(dependentAssociationListFromDom).filter(d => !election.DependentAssociationList.includes(d)).some();

          return lifeEventVerificationType !== 'ADD' ? isAddedBen || isDroppedBen : isAddedBen;
        });
      }

      function isThereNewElectionsForEmployee(initialElections, newElections, listOfBenefitsEnabledForVerification, lifeEventVerificationType) {
        const noCoveragePlanId = 'NOCOV';
        const filteredInitialElections = Array.isArray(initialElections) ? initialElections.filter(election => election.PlanID !== noCoveragePlanId) : Object.values(initialElections).filter(election => election.PlanID !== noCoveragePlanId);
        const newAddedElections = newElections.filter(election => election.PlanID !== noCoveragePlanId);
        const droppedElections = newElections.filter(election => election.PlanID === noCoveragePlanId);

        if (lifeEventVerificationType === 'ADD') {
          return newAddedElections.some(newAddedElection => !filteredInitialElections.some(filteredInitialElection => filteredInitialElection.BenefitID === newAddedElection.BenefitID) && listOfBenefitsEnabledForVerification.includes(newAddedElection.BenefitID));
        } else if (lifeEventVerificationType === 'BOTH' || lifeEventVerificationType === 'ANY') {
          return newAddedElections.some(newAddedElection => !filteredInitialElections.some(filteredInitialElection => filteredInitialElection.BenefitID === newAddedElection.BenefitID) && listOfBenefitsEnabledForVerification.includes(newAddedElection.BenefitID))
            || filteredInitialElections.some(filteredInitialElection => droppedElections.some(droppedElection => droppedElection.BenefitID === filteredInitialElection.BenefitID) && listOfBenefitsEnabledForVerification.includes(filteredInitialElection.BenefitID));
        } else {
          return false;
        }
      }

      function newElectionsThatNeedVerificationPerBenefit(initialElections, newElections, listOfBenefitsEnabledForVerification) {
        const empData = employeeData.Data.PendingEmployee || employeeData.Data.CurrentCoveragesEmployee || employeeData.Data.FutureCoverages[0];
        const filteredNewElectionByBenefitsWithVerificationEnabled = newElections.filter(election => listOfBenefitsEnabledForVerification.includes(election.BenefitCategory) && election.PlanID !== 'NOCOV');
        let filteredInitialElectionByBenefitsWithVerificationEnabled = [];

        for (let i = 0, n = filteredNewElectionByBenefitsWithVerificationEnabled.length; i < n; i++) {
          const initialElectionThatWasChanged = Object.values(initialElections).filter(election => election.BenefitCategory === filteredNewElectionByBenefitsWithVerificationEnabled[i].BenefitCategory);
          if (initialElectionThatWasChanged.length > 0) {
            filteredInitialElectionByBenefitsWithVerificationEnabled.push(initialElectionThatWasChanged[0]);
          }
        }
        if (filteredInitialElectionByBenefitsWithVerificationEnabled.length === 0) return false;

        return filteredNewElectionByBenefitsWithVerificationEnabled.some(election => {
          const currentInitialElection = filteredInitialElectionByBenefitsWithVerificationEnabled.find(el => el.BenefitCategory === election.BenefitCategory);
          if (!currentInitialElection) return false;
          return _(empData.Dependents)
            .filter(dependentRequiresVerificationByStatus)
            .reject(dep => empData.LifeEvents[0].LifeEventID === '55' && isCurrentCoverageHaveNotDevForDependent(dep))
            .reject(dep => currentInitialElection.DependentAssociationList.includes(dep.Ssn))
            .filter(dep => election.DependentAssociationList.includes(dep.Ssn))
            .some();
        });
      }

      function isCurrentCoverageHaveNotDevForDependent(dep) {
        const currentCoveragesEmployee = employeeData.Data.CurrentCoveragesEmployee;
        const futureCoveragesEmployee = employeeData.Data.FutureCoverages[0];
      
        return (
          currentCoveragesEmployee &&
          currentCoveragesEmployee.SmallMarketData.DepEligVerificationType === 'NODEV' &&
          (
            currentCoveragesEmployee.LifeEvents[0].EligibleBenefits
              .filter(benefit => displayedComparisonCategories.includes(benefit.BenefitCategory))
              .some(benefit =>
                benefit.ElectedPlan.ElectedOption.DependentAssociations.find(dependent => dependent.DependentSsn === dep.Ssn)
              ) ||
            (
              futureCoveragesEmployee &&
              futureCoveragesEmployee.LifeEvents[0].PlanYear !== futureCoveragesEmployee.PlanYearInfo.NextPlanYear &&
              futureCoveragesEmployee.LifeEvents[0].EligibleBenefits
                .filter(benefit => displayedComparisonCategories.includes(benefit.BenefitCategory))
                .some(benefit =>
                  benefit.ElectedPlan.ElectedOption.DependentAssociations.find(dependent => dependent.DependentSsn === dep.Ssn)
                )
            )
          )
        );
      }

      function dependentIsCoveredIn(elections) {
        return checkCoverage;

        function checkCoverage(dependent) {
          return _(elections)
            .filter(benefitSupportsDocumentVerification)
            .map('DependentAssociationList')
            .flattenDeep()
            .includes(dependent.Ssn);
        }
      }

      function benefitSupportsDocumentVerification(election) {
        return _(comparisonBenefitCategories)
          .includes(election.BenefitCategory);
      }
    }
  },
]);