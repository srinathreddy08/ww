'use strict';
angular.module('mercer.db.shared').factory('stringService', ['$log',
    function ($log) {
        return {
            convertArrayStringToArray: convertArrayStringToArray,
            convertSeveralArraysOfStringToArray: convertSeveralArraysOfStringToArray,
            endsWith: endsWith,
            startsWith: startsWith,
            containsHtmlTags: containsHtmlTags,
            wildCardMatch: wildCardMatch,
            wildCardMatchArray: wildCardMatchArray
        };

        function convertSeveralArraysOfStringToArray(arrayOfStrings) {
            return _(arrayOfStrings).map(convertArrayStringToArray).flattenDeep().value();
        }

        function convertArrayStringToArray(arrayString) {
            var arrayItems = arrayString
                .replace('[', '')
                .replace(']', '')
                .split(',');

            return _(arrayItems)
                .map(function (item) {
                    return item.trim().replace(/"/g, '');
                })
                .reject(function (item) {
                    return item === '';
                })
                .value();
        }

        function endsWith(subjectString, subString) {
            if (!subjectString || !subString) {
                return false;
            }

            var position = subjectString.length - subString.length;

            if (position < 0) {
                return false;
            }

            return subjectString.indexOf(subString, position) !== -1;
        }

        function startsWith(subjectString, subString) {
            if (!subjectString || !subString) {
                return false;
            }

            return subjectString.indexOf(subString) === 0;
        }

        function containsHtmlTags(string) {
            return string.indexOf('</') > -1
                || string.indexOf('/>') > -1
                || string.indexOf('&lt;') > -1;
        }

        function wildCardMatch(pattern, source) {

            if (!pattern) {
                return false;
            }

            try {
                var regexpPattern = pattern
                    .replace('.', '\\.')
                    .replace('*', '.*');
                return new RegExp('^' + regexpPattern + '$').test(source);
            }
            catch (exception) {
                $log.debug("stringService.wildCardMatch: invalid pattern: " + pattern);
                $log.debug(exception);
                return false;
            }
        }

        function wildCardMatchArray(patternArray, source) {
            return _.some(patternArray, function (pattern) {
                return wildCardMatch(pattern, source);
            });
        }

    }
]);