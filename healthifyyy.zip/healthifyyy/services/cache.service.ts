import { Inject, Injectable } from '@angular/core';

import { Ng1CacheService } from '../common-hybrid/ng1-cache.service';

export interface ING1Cache {
  info: () => any;
  put: (key: string, value: any) => void;
  get: (key: string) => any;
  remove: (key: string) => void;
  removeAll: () => void;
  destroy: () => void;
}

/**
 * Wrapped implementation of "cacheService"
 * TODO: Replace with actual implementation
 */
@Injectable({
  providedIn: 'root'
})
export class CacheService {
  cache: ING1Cache;

  constructor(@Inject(Ng1CacheService) ng1Service: any) {
    Object.assign(this, ng1Service);
  }
}
