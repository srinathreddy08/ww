import { inject, InjectionToken } from '@angular/core';

import { SpinnerService } from './spinner.service';
import { executeAsync } from '../utils/execute-async';

export type ExecuteWithSpinnerIfDisplayingFn = (spinWhileFn: () => Promise<unknown>) => void;

const executeWithSpinnerIfDisplayingFactory = (spinnerService: SpinnerService): ExecuteWithSpinnerIfDisplayingFn =>
  (spinWhileFn) => {
    const spinnerAction = spinnerService.keepDisplayingSpinnerIfItStarts();
    return executeAsync(spinWhileFn)
      .finally(spinnerAction.complete);
  };

export const ExecuteWithSpinnerIfDisplaying = new InjectionToken<ExecuteWithSpinnerIfDisplayingFn>(
  'executeWithSpinnerIfDisplaying',
  {
    providedIn: 'root',
    factory: () => executeWithSpinnerIfDisplayingFactory(inject(SpinnerService))
  }
);
