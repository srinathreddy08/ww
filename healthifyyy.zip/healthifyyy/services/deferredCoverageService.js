'use strict';
angular.module('mercer.hb').service('deferredCoverageService', ['dependencyTracker', 'coverageGridConfigService', 'logService',
    function (dependencyTracker, coverageGridConfigService, logService) {
        var logger = logService.getLogger('WhosCovered.Deferred');
        var isDeferredCoverageModeEnabled;

        var availableBenefitCategories = _(['MEDICAL', 'DENTAL', 'VISION', 'U65MED', 'O65MED']);

        var savedDeferredCoveragesList = {};
        var tempDeferredCoveragesList = {};

        var coverageEligibility = {};

        var initialElections;

        var stateVersion = dependencyTracker.value(0);

        return {
            config: config,

            setInitialElections: versionIncrementation(setInitialElections),
            setCoverageEligibility: versionIncrementation(setCoverageEligibility),

            setParticipantCoverage: versionIncrementation(setParticipantCoverage),
            setDependentCoverage: versionIncrementation(setDependentCoverage),
            doesParticipantHaveDeferredCoverage: versionChecker(doesParticipantHaveDeferredCoverage),
            doesDependentHaveDeferredCoverage: versionChecker(doesDependentHaveDeferredCoverage),
            shouldWorkWithDeferredElection: versionChecker(shouldWorkWithDeferredElection),
            
            getSavedDeferredCoverages: versionChecker(getSavedDeferredCoverages),
            getTempDeferredCoverages: versionChecker(getTempDeferredCoveragesList),
            doesParticipantHaveSavedDeferredCoverage: versionChecker(doesParticipantHaveSavedDeferredCoverage),

            save: versionIncrementation(save),
            clear: versionIncrementation(clear)
        };

        function config(employeeData) {
            isDeferredCoverageModeEnabled = coverageGridConfigService.forData(employeeData).isDeferredCoverageModeEnabled;
        }

        function setCoverageEligibility(benefitId, participantEligibility, dependentsEligibility) {
            coverageEligibility[benefitId] = {
                participantEligibility: participantEligibility,
                dependentsEligibility: dependentsEligibility
            };

            logger.debug('setCoverageEligibility', coverageEligibility);
        }

        function save() {
            logger.debug('savedDeferredCoveragesList', savedDeferredCoveragesList);

            savedDeferredCoveragesList = _.cloneDeep(tempDeferredCoveragesList);
            logger.debug('save', savedDeferredCoveragesList);
        }

        function shouldWorkWithDeferredElection(electionItem) {
            if (!isDeferredCoverageModeEnabled || !initialElections) {
                return false;
            }

            if (Array.isArray(electionItem)) {
                return _(electionItem).every(function (election) {
                    var benefitId = election.BenefitId;
                    return initialElections[benefitId] && availableBenefitCategories.includes(election.BenefitCategory) && initialElections[benefitId].IsNoCov;
                });
            }

            var initialElection = initialElections[electionItem];
            return initialElection && availableBenefitCategories.includes(initialElection.BenefitCategory) && initialElection.IsNoCov;
        }

       
        function setInitialElections(elections) {
            removeDeferredCoveragesWhichIsAlreadyCovered();

            tempDeferredCoveragesList = _.cloneDeep(savedDeferredCoveragesList);
            logger.debug('setInitialElections, elections', tempDeferredCoveragesList, elections);
            initialElections = elections;

            function removeDeferredCoveragesWhichIsAlreadyCovered() {
                var coveredElections = _(elections)
                    .keys()
                    .filter(function (key) {
                    return !elections[key].IsNoCov;
                    })
                    .value();

                savedDeferredCoveragesList = _(savedDeferredCoveragesList)
                    .omit(coveredElections)
                    .value();
            }

        }

        function doesParticipantHaveDeferredCoverage(benefitId) {
            if (!isDeferredCoverageModeEnabled) {
                return false;
            }

            var result = doesCoverageContainBenefit(tempDeferredCoveragesList, benefitId);

            logger.debug('doesParticipantHaveDeferredCoverage', benefitId, result);
            return result;
        }

        function doesParticipantHaveSavedDeferredCoverage(benefitId) {
            if (!isDeferredCoverageModeEnabled) {
                return false;
            }

            var result = doesCoverageContainBenefit(savedDeferredCoveragesList, benefitId);

            logger.debug('doesParticipantHaveDeferredCoverage', benefitId, result);
            return result;
        }

        function doesCoverageContainBenefit(coverageList, benefitId) {           
            if(!benefitId){
              return _(coverageList).keys().value().length > 0;      
            }


            if (typeof(benefitId) === 'string') {
                return coverageList.hasOwnProperty(benefitId);
            }

            if (Array.isArray(benefitId)) {
                return _(benefitId).some(function( id ){ return coverageList.hasOwnProperty(id);});
            }            
        }

        function doesDependentHaveDeferredCoverage(benefitId, dependentId) {
            if (!isDeferredCoverageModeEnabled) {
                return false;
            }

            var result = doesParticipantHaveDeferredCoverage(benefitId) && tempDeferredCoveragesList[benefitId].DependentAssociationList[dependentId];
            logger.debug('doesDependentHaveDeferredCoverage', benefitId, dependentId, result);
            return result;
        }

        function setParticipantCoverage(value, benefitId) {
            if (!value) {
                delete tempDeferredCoveragesList[benefitId];
                logger.debug('setParticipantCoverage', value, benefitId, tempDeferredCoveragesList);
                return;
            }

            if (!tempDeferredCoveragesList[benefitId]) {
                tempDeferredCoveragesList[benefitId] = { DependentAssociationList: {} };
            }

            logger.debug('setParticipantCoverage', value, benefitId, tempDeferredCoveragesList);
        }

        function setDependentCoverage(value, benefitId, dependentId) {
            if (!isDependentEligible(benefitId, dependentId)) {
                return;
            }

            if (value) {
                setParticipantCoverage(true, benefitId);
                tempDeferredCoveragesList[benefitId].DependentAssociationList[dependentId] = true;
                return;
            }

            if (tempDeferredCoveragesList[benefitId]) {
                delete tempDeferredCoveragesList[benefitId].DependentAssociationList[dependentId];

                if (participantIsNotEligibleAndNoDependents(benefitId)) {
                    setParticipantCoverage(false, benefitId);
                }
            }

            logger.debug('setDependentCoverage', value, benefitId, dependentId, tempDeferredCoveragesList);
        }

        function isDependentEligible(benefitId, dependentId) {
            return coverageEligibility[benefitId] &&
                coverageEligibility[benefitId].dependentsEligibility[dependentId];
        }

        function participantIsNotEligibleAndNoDependents(benefitId) {
            var coverageEligibilityItem = coverageEligibility[benefitId];
            var coverage = tempDeferredCoveragesList[benefitId];

            if (coverageEligibilityItem && coverageEligibilityItem.participantEligibility) {
                return false;
            }

            return coverage && _(coverage.DependentAssociationList).keys().value().length === 0;
        }

        function getSavedDeferredCoverages() {
            return savedDeferredCoveragesList;
        }

        function getTempDeferredCoveragesList() {
            return _(tempDeferredCoveragesList).mapValues(function(v) {
                return {
                    DependentAssociationList: _(v.DependentAssociationList)
                        .pickBy(function(val) {
                            return val;
                        })
                        .keys()
                        .value()
                }
            }).value();
        }

        function versionIncrementation(action) {
            return function () {
                stateVersion.write(stateVersion() + 1);
                logger.debug('callWithDependencyTrackerCounterIncrementation', stateVersion());
                return action.apply(this, arguments);
            }
        }

        function versionChecker(action) {
            return function () {
                logger.debug('callWithDependencyTrackerTriggering', stateVersion());
                stateVersion();
                return action.apply(this, arguments);
            }
        }

        function clear() {
            savedDeferredCoveragesList = {};
            tempDeferredCoveragesList = {};
            coverageEligibility = {};
            initialElections = {};
        }
    }
]);