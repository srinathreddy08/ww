﻿'use strict';
angular.module('mercerApp').service('leBenefitsService', [
    'EnrollmentRules', 'contentAliasService', 'depsPendingVerificationService',
    'dependentVerificationService', 'amountBasedBenefitService', 'optionStatusService',
    'benefitCategoriesService', 'dcService', 'mbcUtilService', 'aggregateElections', 'generateCartMap',
    'isRepriceableBenefit', 'pcpService', 'benefitsService', 'benefitIconService', 'spendingAccountsService',
    'suppressedBenefitsPlansOptionsService', 'flags',
    function (EnrollmentRules, contentAliasService, depsPendingVerificationService,
        dependentVerificationService, amountBasedBenefitService, optionStatusService,
        benefitCategoriesService, dcService, mbcUtilService, aggregateElections, generateCartMap,
        isRepriceableBenefit, pcpService, benefitsService, benefitIconService, spendingAccountsService,
        suppressedBenefitsPlansOptionsService, flags) {
        return {
            createBenefitList: createBenefitList,
            getBenefitListData: getBenefitListData
        };

        function createBenefitList(parameters) {
            var aggregated = aggregateElections(createElectionData(), parameters.hideNoCovVb);

            if (!parameters.hideNoCovVb) {
                setCovImages(aggregated.displayed.voluntaryBenefits);
            }

            if (!parameters.isCart) {
                setFootnotes(aggregated.displayed.paidExceptVoluntaryElections);
            }

            var paidExceptVoluntaryElections = aggregated.displayed.paidExceptVoluntaryElections;

            populateElectionsWithDepsVerifiedOptionCosts(paidExceptVoluntaryElections);

            return {
                byStatus: separateBenefitsByStatus(paidExceptVoluntaryElections),
                beneficiaryData: getBeneficiaryData(),
                showSubtotals: getShowSubtotals(),
                aggregated: aggregated,
                dcSubTotalTooltipEnabled: calculateDcSubTotalTooltipEnabled(paidExceptVoluntaryElections)
            };

            function getElectedDomBenefits() {
                return _(getLifeEvent().EligibleBenefits)
                    .filter({ IsElected: true })
                    .filter(function (benefit) {
                        return suppressedBenefitsPlansOptionsService.filterByBenefits(benefit, parameters.enrollmentContent);
                    })
                    .value();
            }

            function getDomBeneficiaryData() {
                var employee = parameters.employee;

                return {
                    beneficiaries: employee.Beneficiaries,
                    designations: employee.BeneficiaryDesignations
                };
            }

            function getCartBeneficiaryData() {
                if (!parameters.isCart) {
                    return {};
                }

                var cartBeneficiaryData = parameters.cart.BeneficiaryData;

                if (!cartBeneficiaryData) {
                    return {};
                }

                //Add the cart beneficiary data to the beneficiary structure
                return {
                    beneficiaries: cartBeneficiaryData.Beneficiaries,
                    designations: cartBeneficiaryData.Designations
                };
            }

            function getLifeEvent() {
                return parameters.employee.LifeEvents[0];
            }

            function createElectionData() {
                var electionData = parameters.isCart
                    ? createElectionDataForCart()
                    : createElectionDataForDom();
                var modifiedElections = _.map(electionData, modifyElection);
                return modifiedElections;

                function modifyElection(election) {
                    var frontLoadBenefit = amountBasedBenefitService.getFrontLoadingBenefit(election.benefit, parameters.employeeData, parameters.employeeType);
                    var frontLoadAmount = 0;
                    if (frontLoadBenefit) {
                        var frontLoadElection = _.find(electionData,
                            function (benefit) {
                                return benefit.benefit.BenefitID === frontLoadBenefit.BenefitID;
                            });

                        frontLoadAmount = frontLoadElection ? frontLoadElection.employeeAnnualCost : 0;
                    }

                    election.employeeAnnualCostWithFrontload = election.employeeAnnualCost + frontLoadAmount;
                    return election;
                }

                function createElectionDataForCart() {
                    //Get both the cart DOM footnote rules before calculating the electionData
                    var employeeData = parameters.employeeData;
                    var bestMatchData = parameters.bestMatchData;
                    var cartData = parameters.cart;

                    var pendingEmployee = employeeData.Data.PendingEmployee;
                    var footNoteRules = EnrollmentRules.summaryFootNotes(cartData.ShoppingCart, employeeData, bestMatchData, pendingEmployee, "true");

                    var electedBenefitsInCartFormat = _(getLifeEvent().EligibleBenefits)
                        .filter({ IsElected: true })
                        .filter(function (benefit) {
                            return suppressedBenefitsPlansOptionsService.filterByBenefits(benefit, parameters.enrollmentContent);
                        })
                        .map(function (benefit) {
                            return transformDOMToCartFormat(benefit);
                        })
                        .value();

                    var domFootnoteRules = EnrollmentRules.summaryFootNotes(
                        electedBenefitsInCartFormat,
                        employeeData,
                        bestMatchData,
                        pendingEmployee,
                        "false");

                    //Create map of benefitID to cart item
                    var cartMap = generateCartMap(cartData);

                    //Loop through eligible benefits (needed since views that are separated by status need to pull status= "Z" or "N" from the DOM)
                    var electionDataSource = getElectionDataSource();

                    var isRepriceableBenefitFilter = isRepriceableBenefit.forData(employeeData);

                    var electionData = _(electionDataSource)
                        .map(function (benefit) {
                            var cartItem = cartMap[benefit.BenefitID];

                            //If the benefit exists in the cart create the cart election, otherwise transform the DOM item for display
                            var election = cartItem ? createElectionFromCart(benefit, cartItem, cartMap) : createElectionFromDom(benefit);

                            if (cartItem && benefitCategoriesService.IsAmountBased(benefit)) {
                                election.ElectedOption.EOIPendingStatus = cartItem.EOIPendingStatus;
                            }

                            //Add footnote rule onto an election
                            if (footNoteRules[benefit.BenefitID]) {
                                var currentFootNoteRules = cartItem ? footNoteRules : domFootnoteRules;

                                election.Footnote = currentFootNoteRules[benefit.BenefitID].Footnote || '';
                                election.Notice = currentFootNoteRules[benefit.BenefitID].Notice || '';
                                election.ShowNotice = true;
                            }

                            //Can update the benefit if the elected option has status of A or E and the benefits are editable on a page level
                            election.IsAvailableToUpdate = optionStatusService.isAvailableForUpdate(election.ElectedOption) && parameters.isEditable;

                            return election;
                        })
                        .value();

                    return electionData;

                    function getElectionDataSource() {
                        if (parameters.separateByStatus) {
                            return getElectedDomBenefits();
                        }

                        return _(getElectedDomBenefits())
                            .filter(function (benefit) {
                                return cartMap[benefit.BenefitID];
                            })
                            .value();
                    }

                    function createElectionFromCart(benefit, cartItem, shoppingCart) {
                        //Create election item for the view from the cart
                        var plan = benefit.EligiblePlansMap[cartItem.PlanID] || benefit.ElectedPlan;
                        var electedDomOption = plan.EligibleOptionsMap[cartItem.OptionID] || plan.ElectedOption;

                        var option = isRepriceableBenefitFilter(benefit) ? getOptionWithCostsCopiedFroMCart() : electedDomOption;
                        var election = createElection(
                            'cart',
                            benefit,
                            plan,
                            option,
                            cartItem.DependentAssociationList,
                            cartItem.IsInterested,
                            'PendingEmployee',
                            amountBasedBenefitService.shoppingCartProvider(shoppingCart),
                            cartItem);

                        election.isPCPRequired = pcpService.isPCPRequired(cartItem, benefit, employeeData);

                        return election;

                        function getOptionWithCostsCopiedFroMCart() {
                            return _.assign({}, electedDomOption, {
                                AmountElected: cartItem.Amount,
                                AmountInforce: cartItem.AmountInforce,
                                AmountPended: cartItem.AmountPended,
                                EmployeeAnnualCost: cartItem.EmployeeAnnualCost,
                                EmployeePayPeriodCost: cartItem.EmployeePayPeriodCost,
                                EmployerAnnualCost: cartItem.EmployerAnnualCost,
                                EmployerPayPeriodCost: cartItem.EmployerPayPeriodCost,
                                PendedEmployeeAnnualCost: cartItem.PendedEmployeeAnnualCost,
                                PendedEmployeePayPeriodCost: cartItem.PendedEmployeePayPeriodCost,
                                EEPayPeriodCostInforce: (electedDomOption.EmployeePayPeriodCost || 0) - (electedDomOption.PendedEmployeePayPeriodCost || 0)
                            });
                        }
                    }
                }

                function createElectionDataForDom() {
                    return _(getElectedDomBenefits())
                        .map(createElectionFromDom)
                        .value();
                }

            }

            function setCovImages(voluntaryBenefits) {
                _(voluntaryBenefits)
                    .forEach(function (election) {
                        var electedBenefit = election.ElectedBenefit;
                        var electedPlan = election.ElectedPlan;
                        election.CovImage = mbcUtilService.getCoverageImage(electedBenefit, electedPlan, parameters.employeeData, true);
                    });
            }

            function calculateDcSubTotalTooltipEnabled(paidExceptVoluntaryElections) {
                return _(paidExceptVoluntaryElections)
                    .reject(function (election) {
                        return election.ElectedPlan.IsNoCovPlan;
                    })
                    .map('ElectedBenefit')
                    .some(function (b) {
                        return dcService.isBenefitDc(b, parameters.employee);
                    });
            }

            function setFootnotes(paidExceptVoluntaryElections) {
                var electedBenefitsTransformed = _(getElectedDomBenefits())
                    .map(transformDOMToCartFormat)
                    .value();

                var footNoteRules = EnrollmentRules.summaryFootNotes(electedBenefitsTransformed, parameters.employeeData, null, parameters.employee, "true", "true");

                //Set the footnotes on the model
                _(paidExceptVoluntaryElections)
                    .filter(function (election) {
                        return footNoteRules[election.ElectedBenefit.BenefitID];
                    })
                    .forEach(function (election) {
                        election.Footnote = footNoteRules[election.ElectedBenefit.BenefitID].Footnote;
                        election.ShowNotice = true;
                    });
            }

            function getElection(benefitId) {
                var electionDataMap = _(createElectionData())
                    .keyBy(function (election) {
                        return election.ElectedBenefit.BenefitID;
                    })
                    .value();

                return electionDataMap[benefitId];
            }

            function createElectionFromDom(benefit) {
                //Create election item for the view from a DOM benefit
                var plan = benefit.ElectedPlan;
                var option = plan && plan.ElectedOption;

                return createElection('dom',
                    benefit,
                    plan,
                    option,
                    _.map(option.DependentAssociations, 'DependentSsn'),
                    benefit.IsInterested,
                    parameters.employeeType,
                    amountBasedBenefitService.domProvider()
                );
            }

            function createElection(type, benefit, plan, option, coveredDependentsSsns, isInterested, employeeType, electionDataProvider, source) {
                var election = {
                    ElectedBenefit: benefit,
                    ElectedPlan: plan,
                    ElectedOption: option,
                    CoveredDependents: getCoveredDependents(coveredDependentsSsns),
                    CovImage: mbcUtilService.getCoverageImage(benefit, plan, parameters.employeeData),
                    IsInterested: isInterested,
                    IsNoCovPlan: plan.IsNoCovPlan,
                    type: type,
                    FootnoteContext: createFootnoteContext(option),
                    AmountElected: option.AmountElected,

                    benefit: benefit,
                    plan: plan,
                    option: option,
                    isNoCov: plan.IsNoCovPlan,
                    isInterested: isInterested,
                    icon: benefitIconService.getIcon(benefit),
                    isIconGrayed: isIconGrayed(),
                    isVoluntary: isVoluntary(),
                    carrierPlan: isVoluntary() ? 'Offered' : plan.Content,

                    categoryKey: getCategoryKey(),
                    employeePayPeriodCost: option.EmployeePayPeriodCost,
                    employeeAnnualCost: option.EmployeeAnnualCost,
                    employerPayPeriodCost: option.EmployerPayPeriodCost,
                    employerAnnualCost: option.EmployerAnnualCost,

                    isComparisonBenefit: benefitsService.isComparisonBenefit(benefit),

                    source: source,
                    employee: parameters.employee
                };

                if (benefitCategoriesService.IsAccountBased(benefit)) {
                    election.AccountsData = amountBasedBenefitService
                        .forData(parameters.employeeData, employeeType)
                        .getElectionData(benefit, electionDataProvider);
                }

                return election;

                function isIconGrayed() {
                    return isVoluntary() ? !isInterested : plan.IsNoCovPlan;
                }

                function isVoluntary() {
                    return benefit.BenefitCategory &&
                        (benefit.BenefitCategory.substr(0, 3) === "VB_");
                }

                function getCategoryKey() {
                    return benefitCategoriesService.GetCategoryByName(benefit.BenefitCategory).VoluntaryCategoryKey;
                }
            }

            function createFootnoteContext(option) {
                var footNoteContextProperties = {
                    GetElection: getElection
                };

                return _.create(option, footNoteContextProperties);
            }

            function getCoveredDependents(ssns) {
                return _(parameters.employee.Dependents)
                    .filter(function (dependent) {
                        return ssns.indexOf(dependent.Ssn) >= 0;
                    })
                    .map(function (dependent) {
                        return {
                            Source: dependent,
                            IsPending: dependentVerificationService
                                .forData(parameters.employeeData)
                                .isDependentPending(dependent)
                        };
                    })
                    .value();
            }

            function transformDOMToCartFormat(benefit) {
                //Manipulate the DOM data (benefit parameter) so it matches the cart structure
                return {
                    BenefitID: benefit.BenefitID,
                    BenefitCategory: benefit.BenefitCategory,
                    DependentAssociationList: benefit.ElectedPlan && benefit.ElectedPlan.ElectedOption.DependentAssociations,
                    PlanID: benefit.ElectedPlan && benefit.ElectedPlan.PlanID,
                    OptionID: benefit.ElectedPlan && benefit.ElectedPlan.ElectedOption.OptionID,
                    Amount: benefit.ElectedPlan && benefit.ElectedPlan.ElectedOption.AmountElected,
                    LifeEventDate: parameters.employee.LifeEvents[0].LifeEventDate
                };
            }

            function separateBenefitsByStatus(paidExceptVoluntaryElections) {
                var benefitsAvailableToUpdate = _(paidExceptVoluntaryElections)
                    .filter('IsAvailableToUpdate')
                    .value();
                var benefitsNotAvailableToUpdate = _(paidExceptVoluntaryElections)
                    .reject('IsAvailableToUpdate')
                    .value();

                return {
                    benefitsAvailableToUpdate: benefitsAvailableToUpdate,
                    benefitsNotAvailableToUpdate: benefitsNotAvailableToUpdate
                };
            }

            function getBeneficiaryData() {
                return {
                    dom: getDomBeneficiaryData(),
                    cart: getCartBeneficiaryData()
                };
            }

            function getShowSubtotals() {
                var configName = parameters.isLifeEventPage || parameters.isCart
                    ? "HB.LifeEvent.ChooseBenefits.CostSummarySubTotals"
                    : "HB.LifeEvent.Summary.CostSummarySubTotals";

                return contentAliasService
                    .forData(parameters.employeeData)
                    .getConfigurationValue(configName) === "S";
            }

            function populateElectionsWithDepsVerifiedOptionCosts(paidExceptVoluntaryElections) {
                _.forEach(paidExceptVoluntaryElections, overrideElectionVerifiedValues);

                function overrideElectionVerifiedValues(election) {
                    var employee = _.cloneDeep(parameters.employee);
                    var benefit = election.ElectedBenefit;
                    var benefitId = benefit.BenefitID;
                    var plan = benefit.EligiblePlansMap[election.ElectedPlan.PlanID];
                    var option = plan.EligibleOptionsMap[election.ElectedOption.OptionID];

                    if (parameters.isCart) {
                        var domBenefit = employee.LifeEvents[0].EligibleBenefitsMap[benefitId];
                        var cartBenefit = _.find(parameters.cart.ShoppingCart, { BenefitID: benefitId });
                        domBenefit.DependentAssociationList = cartBenefit && cartBenefit.DependentAssociationList || [];
                    }

                    var derivedOptionDetails = depsPendingVerificationService.getVerifiedOptionDetails(
                        contentAliasService.forData(parameters.employeeData),
                        employee,
                        benefitId,
                        plan.PlanID,
                        option.OptionID);

                    _.merge(election, derivedOptionDetails);
                }
            }
        }

        function getBenefitListData(enrollmentContent, employeeType, newSuggestedPackage, clientCustomBenefitItems, isSuggestedPackage, isBenefitListEditable) {
            var benefitList = getBenefitList();
            var emp = _(enrollmentContent.data).get(employeeType);

            var displayedElections = benefitList.aggregated.displayed.employerCostElections;
            var coveredVoluntaryBenefits = _(benefitList.aggregated.displayed.paidExceptVoluntaryElections)
                .filter(isVoluntaryBenefit)
                .value();
            var costElections = _(displayedElections)
                .reject(isVoluntaryBenefit)
                .value();

            return {
                includedItems: getIncludedItems(),
                recommendedItems: getRecommendedItems(),
                offeredItems: getOfferedItems(),
                taxSavingAccountsItems: getIncludedTaxSavingAccountsItems(),
                taxSavingAccountsItemsForTile: getIncludedTaxSavingAccountsItemsWithFl(),
                availableTaxSavingAccountsItems: getAvailableTaxSavingAccountsItems(),
                availableNonTaxSavingAccountsItems: getAvailableNonTaxSavingAccountsItems(),
                clientCustomBenefitsItems: getClientCustomBenefitItems(),
                hasAvailableTaxSavingAccountsItems: hasAvailableTaxSavingAccountsItems(),
                hasIncludedTaxSavingAccountsItems: hasIncludedTaxSavingAccountsItems(),
                totals: benefitList.aggregated.totals,
                aggregated: benefitList.aggregated,
                beneficiaryData: benefitList.beneficiaryData.dom,
                dcSubTotalTooltipEnabled: benefitList.dcSubTotalTooltipEnabled,
                showSubtotals: benefitList.showSubtotals,
                suggestedPackage: newSuggestedPackage,
                enrollmentContent: enrollmentContent,
                isEditable: isBenefitListEditable,
                coveredVoluntaryBenefits: coveredVoluntaryBenefits,
                displayCosts: emp.SmallMarketData.DisplayCosts
            };

            function hasAvailableTaxSavingAccountsItems() {
                if (!isBenefitListEditable) {
                    return true;
                }

                return _(costElections)
                    .filter(isTaxSavingAccount)
                    .filter(isEditable)
                    .some();

                function isEditable(item) {
                    var service = spendingAccountsService.forCommonData({
                        benefit: item.benefit,
                        shoppingCart: _.keyBy(newSuggestedPackage.ShoppingCart, 'BenefitID'),
                        employeeData: enrollmentContent.contentSource
                    });
                    return service.isEditable();
                }
            }

            function hasIncludedTaxSavingAccountsItems() {
                return _(costElections)
                    .filter(filterIncluded)
                    .some(function (item) {
                        if (benefitsService.isHSABenefit(item.benefit)) {
                            return item.employeeAnnualCost !== 0 && item.employeePayPeriodCost !== 0;
                        }

                        return true;
                    });
            }

            function employerCostElections() {
                if (isSuggestedPackage) {
                    return _(costElections)
                        .reject(isClientCustomBenefit)
                        .value();
                }

                return costElections;
            }

            function getIncludedItems() {
                return _(employerCostElections())
                    .filter(filterIncluded)
                    .value();
            }

            function getClientCustomBenefitItems() {
                return _(costElections)
                    .filter(isClientCustomBenefit)
                    .value();
            }

            function getAvailableTaxSavingAccountsItems() {
                return _(employerCostElections())
                    .filter(isTaxSavingAccount)
                    .value();
            }

            function getRecommendedItems() {
                return _(displayedElections)
                    .filter(isVoluntaryBenefit)
                    .filter(isRecommended)
                    .reject(isTaxSavingAccount)
                    .value();
            }

            function getOfferedItems() {
                return _(employerCostElections())
                    .filter(isOffered)
                    .reject(isTaxSavingAccount)
                    .value();
            }

            function getAvailableNonTaxSavingAccountsItems() {
                return _(getIncludedItems())
                    .reject(isTaxSavingAccount)
                    .filter(isAvailableToChange)
                    .value();
            }

            function getIncludedTaxSavingAccountsItems() {
                return _(getIncludedItems())
                    .filter(isTaxSavingAccount)
                    .value();
            }

            function getIncludedTaxSavingAccountsItemsWithFl() {
                return _(benefitList.aggregated.allBenefitsByGroups.employerCostElections)
                    .filter(filterIncluded)
                    .filter(isTaxSavingAccount)
                    .value();
            }

            function filterIncluded(item) {
                if (item.isVoluntary) {
                    return false;
                }

                return !item.IsNoCovPlan;
            }

            function isTaxSavingAccount(item) {
                return item.benefit.BenefitCategory === 'SPENDING';
            }

            function isAvailableToChange(item) {
                return !item.benefit.IsNZ;
            }

            function isVoluntaryBenefit(item) {
                return benefitsService.isBenefitOfVoluntaryCategory(item.benefit);
            }

            function isOffered(item) {
                return item.isNoCov;
            }

            function isRecommended(item) {
                return item.isInterested;
            }

            function isClientCustomBenefit(item) {
                return _(clientCustomBenefitItems).find({ BenefitID: item.benefit.BenefitID });
            }

            function getBenefitList() {
                return createBenefitList({
                    cart: newSuggestedPackage,
                    employee: _(enrollmentContent.data).get(employeeType),
                    employeeData: enrollmentContent.contentSource,
                    bestMatchData: null,
                    isCart: isBenefitListEditable,
                    isLifeEventPage: true,
                    isEditable: isBenefitListEditable,
                    hideNoCovVb: false,
                    separateByStatus: false,
                    employeeType: employeeType,
                    enrollmentContent: enrollmentContent
                });
            }
        }
    }
]);