import { Injectable } from '@angular/core';
import { from } from 'rxjs';
import { switchMap, take } from 'rxjs/operators';
import { RawParams, UIRouter } from '@uirouter/angular';
import { BaseNavigationService } from '@common-navigation/services/base-navigation.service';
import { NavRouteNames } from '@common-navigation/models/nav-route';
import { EnrollmentNavHelper } from './common/enrollment-nav-helper';
import { EnrollmentNavigationBuilderService } from './services/enrollment-navigation-builder.service';
import { EnrollmentNavigationGuardService } from './services/enrollment-navigation-guard.service';
import { EnrollmentNavigationProgressService } from './services/enrollment-navigation-progress.service';
import { LifeEventNavigationStatusService } from '@common-navigation/services/life-event-navigation-status.service';
import { ICanActivateRouteResult } from './models/can-activate-route-result';
import { EnrollmentService } from '@services/enrollment.service';
import { IEnrollment } from 'src/app/common-dto/enrollment.model';
import { LifeEventNavigationsState } from 'src/app/common-dto/life-event-navigations-state.constants';
import { CommonNavHelper } from '@common-navigation/common/common-nav-helper';
import { EnrollmentCacheHelper } from './common/enrollment-cache-helper';
import { EnrollmentNavTabId } from './common/enrollment-nav-ids';
import { BeneficiariesMenuBuilderService } from '@beneficiaries/services/beneficiaries-menu-builder.service';
import { BeneficiariesNavItemId } from '@beneficiaries/common/beneficiaries-nav-ids';
import { EnrollmentBeneficiariesPageComponent } from '@open-enrollment/enrollment-beneficiaries-page/enrollment-beneficiaries-page.component';
import { BeneficiariesInsideLeService } from '@beneficiaries/services/beneficiaries-inside-le.service';
import { ShoppingCartService } from '@services/shopping-cart.service';
import { IBeneficiariesPlanModel } from "../../../common-dto/beneficiaries.model";
import * as _ from "lodash";

@Injectable({
  providedIn: 'root',
})
export class EnrollmentNavigationService extends BaseNavigationService {
  private currentBeneficiariesComponent: EnrollmentBeneficiariesPageComponent = null;

  constructor(
    router: UIRouter,
    enrollmentService: EnrollmentService,
    private builderService: EnrollmentNavigationBuilderService,
    private progressService: EnrollmentNavigationProgressService,
    private guardService: EnrollmentNavigationGuardService,
    private statusService: LifeEventNavigationStatusService,
    private beneficiariesBuilderService: BeneficiariesMenuBuilderService,
    private beneficiariesInsideLeService: BeneficiariesInsideLeService,
    private shoppingCartService: ShoppingCartService,
  ) {
    super(router, enrollmentService, builderService, progressService);
  }

  setCurrentBeneficiariesComponent(component: EnrollmentBeneficiariesPageComponent): void {
    this.currentBeneficiariesComponent = component;
  }

  async applyChangesForBeneficiariesPageOnNavigateOut(toStateName: string): Promise<void> {
    if (this.currentBeneficiariesComponent && this.currentBeneficiariesComponent.beneficiariesAllocationEnable && this.currentBeneficiariesComponent.navigationButtonsAreEnabled && !this.currentBeneficiariesComponent.applyToAllBenefitsButtonPressed) {
      if (toStateName.startsWith('life-event.')) {
        await this.beneficiariesInsideLeService.saveChangesToShoppingCartWhenNavigateOut(this.currentBeneficiariesComponent.beneficiariesPlan, this.currentBeneficiariesComponent.isExpertGuidance);
      } else {
        const currentOriginalBeneficiariesPlan = _.cloneDeep(this.beneficiariesInsideLeService.beneficiariesPlans.find((bPlanL: IBeneficiariesPlanModel) => bPlanL.benefitId === this.currentBeneficiariesComponent.beneficiariesPlan.benefitId));
        if (_.isEqual(this.currentBeneficiariesComponent.beneficiariesPlan.designations, currentOriginalBeneficiariesPlan.designations)) return;

        const shouldSave = await this.currentBeneficiariesComponent.showBeneficiariesSaveModal();
        if (shouldSave) {
          await this.beneficiariesInsideLeService.saveChangesToShoppingCartWhenNavigateOut(this.currentBeneficiariesComponent.beneficiariesPlan, this.currentBeneficiariesComponent.isExpertGuidance);
        }
      }
    }

    if (toStateName.startsWith('life-event.') && toStateName !== 'life-event.beneficiaries') {
      const lifeEvent = this.beneficiariesInsideLeService.enrollment.Data.PendingEmployee.LifeEvents[0];
      this.shoppingCartService.clearCartCache(lifeEvent.LifeEventID, lifeEvent.LifeEventSequenceNumber, lifeEvent.LifeEventDate, this.currentBeneficiariesComponent.isExpertGuidance);
    }
  }

  // Route guard
  canActivateRoute(stateName: string, params?: Record<string, any>): Promise<ICanActivateRouteResult> {
    const navRoute = CommonNavHelper.parseIncomingRoute(stateName, params);
    const canActivate$ = this.enrollmentService.enrollment$.pipe(
      switchMap((enrollment) => {
        return from(this.builderService.buildNavigation(enrollment, navRoute.Name)).pipe(
          switchMap((navItems) => this.guardService.canActivateRoute$(navRoute, navItems))
        );
      })
    );
    return new Promise((resolve, reject) => canActivate$.pipe(take(1)).subscribe(resolve, reject));
  }

  async canSkipToCheckOut(): Promise<boolean> {
    const navMenu = await this.navMenu$.pipe(take(1)).toPromise();
    return await this.progressService.canSkipToCheckOut(navMenu);
  }

  skipToCheckout() {
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe((enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      const pendingLifeEvent = enrollment.Data.PendingEmployee?.LifeEvents[0];
      if (enrollmentFlowV2Enabled && typeof(pendingLifeEvent) !== 'undefined' && pendingLifeEvent !== null) {
        this.navMenu$.pipe(take(1)).subscribe(async (navMenu) => {
          const visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);
          const itemToCheckout = this.progressService.getReviewAndSaveItemToCheckout(navMenu, visitedPages);
          this.router.stateService.go(itemToCheckout.NavRoute.Name, itemToCheckout.NavRoute.Params);
        });
      }
    });
  }

  benefitsEligibilityIsChanged(): void {
    if (!this.router.globals.current.name.startsWith('life-event.')) {
      return;
    }
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe((enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      const pendingLifeEvent = enrollment.Data.PendingEmployee?.LifeEvents[0];
      if (enrollmentFlowV2Enabled && typeof(pendingLifeEvent) !== 'undefined' && pendingLifeEvent !== null) {
        this.navMenu$.pipe(take(1)).subscribe(async (navMenu) => {
          const visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);
          this.progressService.resetPageHistoryToMyInformation(navMenu, visitedPages, pendingLifeEvent);
          this.refreshEnrollmentNav();
        });
      }
    });
  }

  shoppingCartIsUpdated(): void {
    if (!this.router.globals.current.name.startsWith('life-event.')) {
      return;
    }
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe((enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      const pendingLifeEvent = enrollment.Data.PendingEmployee?.LifeEvents[0];
      if (enrollmentFlowV2Enabled && typeof(pendingLifeEvent) !== 'undefined' && pendingLifeEvent !== null) {
        this.beneficiariesInsideLeService.destroyBeneficiaryData();
        from(this.builderService.buildNavigation(enrollment, LifeEventNavigationsState.GetStarted)).pipe(take(1)).subscribe(async (navMenu) => {
          const visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);
          this.progressService.checkUnvisitedPagesInMiddleOfBeneficiaries(navMenu, enrollment, visitedPages, pendingLifeEvent);
          this.refreshEnrollmentNav();
        });
      }
    });
  }

  lifeEventIsInitialized(lifeEventIdsToExcept: string[]): void {
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe((enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      if (enrollmentFlowV2Enabled) {
        this.beneficiariesInsideLeService.destroyBeneficiaryData();
        this.statusService.clearVisitedPagesHistoryExept(lifeEventIdsToExcept);
      }
    });
  }

  lifeEventIsReinitialized(): void {
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe((enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      if (enrollmentFlowV2Enabled) {
        this.beneficiariesInsideLeService.destroyBeneficiaryData();
      }
    });
  }

  lifeEventIsResumed(): void {
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe((enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      if (enrollmentFlowV2Enabled) {
        this.beneficiariesInsideLeService.destroyBeneficiaryData();
      }
    });
  }

  lifeEventIsCanceled(lifeEventID: string, lifeEventDate: string): void {
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe((enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      if (enrollmentFlowV2Enabled) {
        this.setCurrentRoute(NavRouteNames.leNotActive, null);
        this.statusService.clearVisitedPagesHistory(lifeEventID, lifeEventDate);
        this.beneficiariesInsideLeService.destroyBeneficiaryData();
        EnrollmentCacheHelper.clearAllCachedData();
      }
    });
  }

  lifeEventIsCompleted(): void {
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe((enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      if (enrollmentFlowV2Enabled) {
        this.setCurrentRoute(NavRouteNames.leNotActive, null);
        const pendingLifeEvent = EnrollmentCacheHelper.getCachedPendingLifeEvent();
        this.statusService.clearVisitedPagesHistory(pendingLifeEvent?.LifeEventID, pendingLifeEvent?.LifeEventDate);
        this.beneficiariesInsideLeService.destroyBeneficiaryData();
        EnrollmentCacheHelper.clearAllCachedData();
      }
    });
  }

  clearLifeEventCacheAndHistory(lifeEventID: string, lifeEventDate: string): void {
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe((enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      if (enrollmentFlowV2Enabled) {
        this.statusService.clearVisitedPagesHistory(lifeEventID, lifeEventDate, true);
        EnrollmentCacheHelper.clearAllCachedData();
      }
    });
  }

  enableAllBeneficiariesMenuItemsAndNavigateToBeneficiariesConfirmation(currentRouteName: string): void {
    this.enrollmentService.enrollment$.pipe(take(1)).subscribe(async (enrollment: IEnrollment) => {
      const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
      const isBeneficiariesManagementEnabled = this.beneficiariesBuilderService.isBeneficiariesManagementEnabled(enrollment);
      if (enrollmentFlowV2Enabled && isBeneficiariesManagementEnabled) {
        // enable all Beneficiaries menu items
        const pendingLifeEvent = EnrollmentCacheHelper.getCachedPendingLifeEvent();
        const navItems = await this.builderService.buildNavigation(enrollment, currentRouteName);
        const visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);
        this.progressService.enableAllBeneficiariesMenuItems(navItems, visitedPages, pendingLifeEvent);

        // navigate to the Beneficiaries Confirmation page
        const flattenedReviewAndSaveNavItems = CommonNavHelper.getFlatTabNavItems(navItems.NavMenuTabs[EnrollmentNavTabId.ReviewAndSave]);
        const beneficiariesConfirmationMenuItem = flattenedReviewAndSaveNavItems.find(item => item.Id === BeneficiariesNavItemId.BeneficiariesConfirmation);
        this.goTo(beneficiariesConfirmationMenuItem);
      }
    });
  }

  async tryToResolveUrlForLifeEventResume(originalUrl: string): Promise<string> {
    if (typeof(originalUrl) === 'undefined' || originalUrl === null) {
      return originalUrl;
    }
    if (!originalUrl.startsWith('/life-event/')) {
      return originalUrl;
    }
    if (originalUrl.startsWith('/life-event/reinitiate')) {
      return originalUrl;
    }

    const enrollment = await this.enrollmentService.enrollment$.pipe(take(1)).toPromise();
    const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
    if (!enrollmentFlowV2Enabled) {
      return originalUrl;
    }

    const [originalStateName, originalStateParams] = EnrollmentNavHelper.convertLifeEventUrlToState(originalUrl);

    const [newStateName, newStateParams] = await this.tryToResolveStateForLifeEventResume(originalStateName, originalStateParams);

    const newUrl = CommonNavHelper.convertStateToUrl(newStateName, newStateParams);
    return newUrl;
  }

  async tryToResolveStateForLifeEventResume(originalStateName: string, originalStateParams: RawParams): Promise<[string, RawParams]> {
    if (typeof(originalStateName) === 'undefined' || originalStateName === null) {
      return [originalStateName, originalStateParams];
    }
    if (!originalStateName.startsWith('life-event.')) {
      return [originalStateName, originalStateParams];
    }
    if (originalStateName === 'life-event.reinitiate') {
      return [originalStateName, originalStateParams];
    }

    const enrollment = await this.enrollmentService.enrollment$.pipe(take(1)).toPromise();
    const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
    if (!enrollmentFlowV2Enabled) {
      return [originalStateName, originalStateParams];
    }

    const pendingLifeEvent = enrollment.Data.PendingEmployee?.LifeEvents[0];
    if (typeof(pendingLifeEvent) === 'undefined' || pendingLifeEvent === null) {
      return [originalStateName, originalStateParams];
    }

    const navItems = await this.builderService.buildNavigation(enrollment, originalStateName);

    let visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);
    this.progressService.checkUnvisitedPagesInMiddleOfChooseBenefits(navItems, enrollment, visitedPages, pendingLifeEvent);
    visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);
    this.progressService.checkUnvisitedPagesInMiddleOfBeneficiaries(navItems, enrollment, visitedPages, pendingLifeEvent);
    visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);

    const newState = this.progressService.getLastVisitedStateForEnrollmentFlow(navItems, visitedPages);
    if (typeof(newState) === 'undefined' || newState === null) {
      return [originalStateName, originalStateParams];
    }

    return newState;
  }

  async tryToResolveStateForLifeEventReinitialize(originalStateName: string, originalStateParams: RawParams): Promise<[string, RawParams]> {
    if (typeof(originalStateName) === 'undefined' || originalStateName === null) {
      return [originalStateName, originalStateParams];
    }
    if (!originalStateName.startsWith('life-event.')) {
      return [originalStateName, originalStateParams];
    }
    if (originalStateName === 'life-event.reinitiate') {
      return [originalStateName, originalStateParams];
    }

    const enrollment = await this.enrollmentService.enrollment$.pipe(take(1)).toPromise();
    const enrollmentFlowV2Enabled = EnrollmentNavHelper.isEnrollmentFlowV2Enabled(enrollment);
    if (!enrollmentFlowV2Enabled) {
      return [originalStateName, originalStateParams];
    }

    const pendingLifeEvent = enrollment.Data.PendingEmployee?.LifeEvents[0];
    if (typeof(pendingLifeEvent) === 'undefined' || pendingLifeEvent === null) {
      return [originalStateName, originalStateParams];
    }

    const navItems = await this.builderService.buildNavigation(enrollment, originalStateName);

    let visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);
    const pageHistoryIsResetForChooseBenefits = this.progressService.checkUnvisitedPagesInMiddleOfChooseBenefits(navItems, enrollment, visitedPages, pendingLifeEvent);
    visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);
    const pageHistoryIsResetForBeneficiaries = this.progressService.checkUnvisitedPagesInMiddleOfBeneficiaries(navItems, enrollment, visitedPages, pendingLifeEvent);
    visitedPages = await this.statusService.getAllVisitedPages(pendingLifeEvent.LifeEventID, pendingLifeEvent.LifeEventDate);

    if (pageHistoryIsResetForChooseBenefits || pageHistoryIsResetForBeneficiaries) {
      if (typeof(visitedPages) === 'undefined' || visitedPages === null || visitedPages.length === 0) {
        return [LifeEventNavigationsState.GetStarted, undefined];
      }
      else {
        const newState = this.progressService.getLastVisitedStateForEnrollmentFlow(navItems, visitedPages);
        if (typeof(newState) !== 'undefined' && newState !== null) {
          return newState;
        }
        else {
          return [LifeEventNavigationsState.GetStarted, undefined];
        }
      }
    }

    return [originalStateName, originalStateParams];
  }
}
