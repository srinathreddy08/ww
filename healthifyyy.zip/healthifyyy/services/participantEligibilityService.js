﻿'use strict';
angular.module('mercer.db.shared').service('participantEligibilityService', [
    'contentAliasService',
    function (contentAliasService) {
        var retireeSplitOptionIdentifiers =
        {
            'U65MED': 'HB.Common.CommonTerms.Under65RetireeOptionIdentifier',
            'O65MED': 'HB.Common.CommonTerms.Over65RetireeOptionIdentifier',
            'DENTAL': 'HB.Common.CommonTerms.RetireeDentalOptionIdentifier',
            'VISION': 'HB.Common.CommonTerms.RetireeVisionOptionIdentifier'
        };

        return {
            forData: function (employeeData) {
                var data = contentAliasService.forData(employeeData);

                return {
                    isParticipantEligibleForOption: isParticipantEligibleForOption
                };

                function isParticipantEligibleForOption(benefit, optionId) {
                    var retireeOptionIdentifierEp = retireeSplitOptionIdentifiers[benefit.BenefitCategory];

                    if (!retireeOptionIdentifierEp) {
                        return true;
                    }

                    var optionIdPart = retireeOptionIdPart();

                    if (!optionIdPart) {
                        return true;
                    }

                    return optionId.indexOf(optionIdPart.value) > -1;

                    function retireeOptionIdPart() {
                        var retireeOptionConfig = data.getAlias(retireeOptionIdentifierEp);
                        
                        if (!retireeOptionConfig.value) {
                            return null;
                        }

                        if (typeof retireeOptionConfig.value === 'string') {
                            return retireeOptionConfig.getContent();
                        }

                        var applicableBenefitIds = retireeOptionConfig.getField(retireeOptionIdentifierEp.toUpperCase()).asStringArray();

                        if (applicableBenefitIds.indexOf(benefit.BenefitID) === -1)
                        {
                            return null;
                        }

                        return retireeOptionConfig.getLinkedContent();
                    }
                }
            }
        };
    }
]);