﻿'use strict';

angular.module('mercer.services')
    .factory('amountBasedBenefitService',
        ['$parse', 'employeeCoverageService', 'benefitsService',
            function ($parse, employeeCoverageService, benefitsService) {
                return {
                    shoppingCartProvider: shoppingCartProvider,
                    domProvider: domProvider,
                    forData: forData,
                    getFrontLoadingBenefit: getFrontLoadingBenefit,
                };

                function shoppingCartProvider(shoppingCart) {
                    return {
                        getElectedOption: getElectedOption
                    };

                    function getElectedOption(benefit) {
                        var cartItem = shoppingCart[benefit.BenefitID];
                        return {
                            EmployeePayPeriodCost: cartItem.EmployeePayPeriodCost,
                            EmployerAnnualCost: cartItem.EmployerAnnualCost,
                            EmployeeAnnualCost: cartItem.EmployeeAnnualCost,
                            AmountElected: cartItem.Amount,
                            EmployerPayPeriodCost: cartItem.EmployerPayPeriodCost
                        };
                    }
                }

                function domProvider() {
                    return {
                        getElectedOption: getElectedOption
                    };

                    function getElectedOption(benefit) {
                        if (!benefit.ElectedPlan) {
                            return null;
                        }

                        return benefit.ElectedPlan.ElectedOption;
                    }
                }

                function forData(employeeData, employeeType) {
                    var service = {
                        getHsaBenefit: getHsaBenefit,
                        getElectionData: getElectionData
                    };
                    return service;

                    function getHsaBenefit() {
                        var benefits = getBenefits(employeeData, employeeType);
                        return _(benefits).filter(benefitsService.isHSABenefit).head();
                    }

                    function getElectionData(benefit, optionDataProvider) {
                        if (!benefit) {
                            return null;
                        }

                        var electedOption = optionDataProvider.getElectedOption(benefit);

                        if (!electedOption) {
                            return null;
                        }

                        var hsaBenefit = service.getHsaBenefit();

                        if (hsaBenefit && hsaBenefit.BenefitID === benefit.BenefitID) {
                            var hsaFrontLoadingBenefit = getFrontLoadingBenefit(benefit, employeeData, employeeType);

                            if (hsaFrontLoadingBenefit) {
                                var electedHsaFrontLoadingOption = optionDataProvider.getElectedOption(hsaFrontLoadingBenefit);
                                return {
                                    EmployeePayPeriodCost: electedOption.EmployeePayPeriodCost,
                                    YearToDateContributions: electedOption.YearToDateContributions + electedHsaFrontLoadingOption.YearToDateContributions,
                                    YearToDateReconciledContributions: electedOption.YearToDateReconciledContributions + electedHsaFrontLoadingOption.YearToDateReconciledContributions,
                                    EmployerAnnualCost: electedOption.EmployerAnnualCost + electedHsaFrontLoadingOption.EmployerAnnualCost,
                                    EmployeeAnnualCost: electedOption.EmployeeAnnualCost + electedHsaFrontLoadingOption.AmountElected,
                                    AmountElected: electedOption.AmountElected + electedHsaFrontLoadingOption.AmountElected,
                                    FrontLoading: electedHsaFrontLoadingOption,
                                    FrontLoadingBenefit: hsaFrontLoadingBenefit,
                                    EmployerPayPeriodCost: electedOption.EmployerPayPeriodCost
                                };
                            }
                        }

                        return electedOption;
                    }
                }

                function getFrontLoadingBenefit(benefit, enrollment, employeeType) {
                    var frontLoadingPairsSetting =
                        enrollment.Configuration['HB.ConnectHSAAndHSAFrontLoadBenefit'];

                    if (!frontLoadingPairsSetting) {
                        return null;
                    }

                    var frontLoadingMapping = _(frontLoadingPairsSetting.split(';'))
                        .map(function (pairText) {
                            return pairText.split(',');
                        })
                        .fromPairs()
                        .value();

                    var frontLoadingBenefitId = frontLoadingMapping[benefit.BenefitID];
                    var benefits = getBenefits(enrollment, employeeType);
                    return benefits[frontLoadingBenefitId];
                }

                function getBenefits(enrollment, employeeType) {
                    var employee;

                    if (employeeType === 'ResolveEmployeeCoverage') {
                        employee = employeeCoverageService.getEmployeeCoverage(enrollment.Employee);
                    } else {
                        var getEmployee = $parse(employeeType);
                        employee = getEmployee(enrollment.Employee);
                    }

                    return employee.LifeEvents[0].EligibleBenefitsMap;
                }

            }]);