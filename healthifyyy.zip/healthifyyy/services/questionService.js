'use strict';
angular.module('mercer.services').factory('questionService', [
    '$resource', 'mbcContentAndData', 'dependentService', 'contentAliasService',
    function ($resource, mbcContentAndData, dependentService, contentAliasService) {
        var questionResource = $resource('/api/questionnaire/:action', {}, {
            save: { method: 'POST', params: { action: 'save' } }
        });
        return {
            save: save,
            answersChanged: answersChanged,
            getAnswers: getAnswers,
            getQuestionsForDisplay: getQuestionsForDisplay,
            createSingleQuestion: createSingleQuestion,
            createEditableQuestions: createEditableQuestions,
            getConfigureHealthQuestionsByEventLogic: getConfigureHealthQuestionsByEventLogic,
            getDataForMyInformation: getDataForMyInformation,
            resetHiddenQuestions: resetHiddenQuestions,
            filterAndSortQuestions: filterAndSortQuestions
        };

        function filterAndSortQuestions(questionsData) {
            var questions = questionsData.questions;
            if (questionsData.useQuestionDependency) {
                return questions
                    .filter(function (question) {
                        return questionsData.dynamicConfig[question.Question.Key].IsDisplayed();
                    })
                    .sortBy(function (question) {
                        var config = question.Config;
                        return config && config.DisplayOrder;
                    });
            }
            return questions;
        }

        function getDataForMyInformation(employeeData, employeeType) {
            var resultQuestions = getQuestions();
            return {
                questions: resultQuestions,
                dynamicConfig: getDynamicQuestionConfig(resultQuestions),
                useQuestionDependency: useQuestionDependency()
            };

            function getQuestions() {
                var data = employeeData.Data;
                var source = employeeType ? _.get(data, employeeType)
                    : data.PendingEmployee || data.CurrentCoveragesEmployee || data.FutureCoverages && data.FutureCoverages[0];

                if (!source) {
                    return null;
                }

                return getQuestionsForDisplay(source.Questionnaires, get(), employeeData, true);

                function get() {
                    var configureHealthQuestionsByEventLogic = getConfigureHealthQuestionsByEventLogic(employeeData);

                    var questions = _.compact(configureHealthQuestionsByEventLogic ?
                        [
                            createSingleQuestion('HB.Common.CommonTerms.EETobaccoQuestion', 'HB.HealthQuestions.EETobaccoQuestionControl', employeeData),
                            createSingleQuestion('HB.Common.CommonTerms.EECessationQuestion', 'HB.HealthQuestions.EECessationQuestionControl', employeeData),
                            createSingleQuestion('HB.Common.CommonTerms.SPTobaccoQuestion', 'HB.HealthQuestions.SPTobaccoQuestionControl', employeeData),
                            createSingleQuestion('HB.Common.CommonTerms.SPCessationQuestion', 'HB.HealthQuestions.SPCessationQuestionControl', employeeData),
                            createSingleQuestion('HB.Common.CommonTerms.SPSurchargeQuestion', 'HB.HealthQuestions.SPSurchargeQuestionControl', employeeData),
                            createSingleQuestion('HB.HealthQuestions.WellnessQuestion1Content', 'HB.HealthQuestions.WellnessQuestion1Control', employeeData),
                            createSingleQuestion('HB.HealthQuestions.WellnessQuestion2Content', 'HB.HealthQuestions.WellnessQuestion2Control', employeeData),
                            createSingleQuestion('HB.HealthQuestions.WellnessQuestion3Content', 'HB.HealthQuestions.WellnessQuestion3Control', employeeData),
                            createSingleQuestion('HB.HealthQuestions.WellnessQuestion4Content', 'HB.HealthQuestions.WellnessQuestion4Control', employeeData),
                            createSingleQuestion('HB.HealthQuestions.WellnessQuestion5Content', 'HB.HealthQuestions.WellnessQuestion5Control', employeeData)
                        ] :
                        [
                            createSingleQuestion('HB.Common.CommonTerms.EETobaccoQuestion', null, employeeData),
                            createSingleQuestion('HB.Common.CommonTerms.EECessationQuestion', null, employeeData),
                            createSingleQuestion('HB.Common.CommonTerms.SPTobaccoQuestion', null, employeeData),
                            createSingleQuestion('HB.Common.CommonTerms.SPCessationQuestion', null, employeeData),
                            createSingleQuestion('HB.Common.CommonTerms.SPSurchargeQuestion', null, employeeData)
                        ].concat(createMultiQuestion('HB.Common.CommonTerms.WellnessQuestions', employeeData)));

                    return useQuestionDependency() ? getDynamicQuestions() : questions;

                    function getDynamicQuestions() {
                        var dynamicConfig = getDynamicDisplayConfiguration(questions);
                        return _.map(questions,
                            function (question) {
                                var config = dynamicConfig[question.Question.Key];

                                if (!config) {
                                    return _.assign({}, question, {
                                        DisplayEnabled: false
                                    });
                                }

                                return _.assign({}, question, {
                                    DisplayEnabled: true,
                                    IsEditable: config.EditAllowed,
                                    Config: config
                                });

                            });

                        function getDynamicDisplayConfiguration(questions) {
                            var content = contentAliasService.forData(employeeData);
                            var config = content.getConfigurationValue('HB.Common.CommonTerms.QuestionDependency');

                            return _(questions)
                                .map(function (question) {
                                    var questionId = question.Question.Key;
                                    var displayOrder = config && config[questionId + '_DISPLAY_ORDER'];

                                    if (!displayOrder) {
                                        return null;
                                    }

                                    return {
                                        Id: questionId,
                                        Action: config[questionId + '_ACTION'] && config[questionId + '_ACTION'].toUpperCase(),
                                        DependentOn: config[questionId + '_DEPENDENT_ON'],
                                        DisplayOrder: + displayOrder,
                                        EditAllowed: config[questionId + '_EDIT_ALLOWED'] === 'Yes'
                                    };
                                })
                                .filter()
                                .keyBy('Id')
                                .value();
                        }
                    }

                    function createMultiQuestion(contentName) {
                        var result = [];

                        var configuration = employeeData.Configuration;
                        var questionData = contentAliasService.forData(employeeData).getEvaluationPointValue(contentName);

                        _(questionData)
                            .forEach(function (q) {
                                var displayEnabled = isQuestionDisplayEnabled(configuration, contentName);

                                result.push({
                                    ContentEP: contentName,
                                    Question: q,
                                    DisplayEnabled: displayEnabled,
                                    IsEditable: true
                                });
                            });

                        return result;
                    }
                }
            }

            function getDynamicQuestionConfig(questions) {
                var config = _(questions)
                    .reduce(function (acc, q) {
                        acc[q.Question.Key] = {
                            Question: q,
                            IsDisplayed: isDisplayed
                        };
                        return acc;

                        function isDisplayed() {
                            var dependentQuestionId = q.Config.DependentOn;

                            if (!dependentQuestionId) {
                                return true;
                            }

                            var dependentQuestion = config[dependentQuestionId],
                                expectedValue = "";

                            expectedValue = this.Question.Config.Action === 'DISPLAY' ? 'Y' : 'N';

                            return (dependentQuestion.Question.Answer.Value === expectedValue)
                                && dependentQuestion.IsDisplayed();
                        }
                    }, {});

                return config;
            }

            function useQuestionDependency() {
                var contentService = contentAliasService.forData(employeeData);
                return contentService.getConfigurationValue('HB.Common.CommonTerms.UseQuestionDependency') === 'Yes';
            }

        }

        function save(answers, effectiveDate) {
            var data = {
                answers: answers,
                effectiveDate: effectiveDate
            };

            return questionResource.save(data, function () {
                var newAnswers = _.cloneDeep(answers);
                //Update the pending employee cached object
                mbcContentAndData.getEnrollment().$promise.then(
                    function (enrollmentData) {
                        var questionnaires = enrollmentData.Data.PendingEmployee.Questionnaires;
                        _.forEach(questionnaires,
                            function (questionnaire) {
                                _.forEach(questionnaire.Answers,
                                    function (answer, key) {
                                        if (answers[key]) {
                                            answer.Value = newAnswers[key].Value;
                                            answer.SubValue = newAnswers[key].SubValue;
                                            delete newAnswers[key];
                                        }
                                    });
                            });

                        var newAnswersQuestionnaireName = 'newAnswers';
                        questionnaires[newAnswersQuestionnaireName] = questionnaires[newAnswersQuestionnaireName] ||
                            { Answers: {}, Type: newAnswersQuestionnaireName };
                        var newAnswersQuestionnaire = questionnaires[newAnswersQuestionnaireName].Answers;

                        _.forEach(newAnswers, function (answer, key) {
                            newAnswersQuestionnaire[key] = {
                                Value: answer.Value,
                                SubValue: answer.SubValue,
                                IsReadOnly: false
                            };
                        });
                    });
            });
        }

        function resetHiddenQuestions(questions, dynamicQuestionConfig) {
            _(questions).filter(function (q) {
                return !dynamicQuestionConfig[q.Question.Key].IsDisplayed();
            }).forEach(function (q) {
                q.Answer = q.InitiallyAnswerIsExisting ? _.assign({}, q.InitiallyAnswerIsExisting) : undefined;
            });
        }

        function answersChanged(oldQuestions, questions) {
            var oldAnswers = getAnswers(oldQuestions);
            var answers = getAnswers(questions);

            return _(answers)
                .some(function (answer, key) {
                    var oldAnswer = oldAnswers[key];
                    var isSame = oldAnswer.Value == answer.Value &&
                        oldAnswer.SubValue == answer.SubValue;

                    return !isSame;
                });
        }

        function getAnswers(questions) {
            return _(questions)
                .keyBy(function (q) {
                    return q.Question.Key;
                })
                .mapValues('Answer')
                .value();
        }

        function getQuestionsForDisplay(questionnaires, allQuestions, data, checkSpouseDependents) {
            var questionsToBeShown = getKeysToBeShown();

            setAnswersFromQuestionnaires(questionsToBeShown);
            return questionsToBeShown;

            function setAnswersFromQuestionnaires(questions) {
                var allQuestionnaires = getAllQuestionnaires();

                _.forEach(questions, function (question) {
                    var initialAnswer = allQuestionnaires[question.Question.Key];

                    question.InitiallyAnswerIsExisting = initialAnswer && _.assign({}, initialAnswer);
                    question.Answer = initialAnswer ?
                        _.assign({}, initialAnswer)
                        : { Value: null };
                });

                function getAllQuestionnaires() {
                    var result = {};

                    _.forEach(questionnaires, function (questionnaire) {
                        _.forEach(questionnaire.Answers, function (answer, key) {
                            result[key] = _.clone(answer);
                        });
                    });

                    return result;
                }
            }

            function getKeysToBeShown() {
                var result = _.compact(allQuestions);

                if (checkSpouseDependents) {
                    if (!participantHasAnySpouseDependents()) {
                        result = removeTheSpouseQuestionKeys(result);
                    }
                }

                return getKeysThatAreConfiguredToBeShown(result);

                function getKeysThatAreConfiguredToBeShown(questions) {
                    return _(questions)
                        .filter('DisplayEnabled')
                        .value();
                }


                function removeTheSpouseQuestionKeys(questions) {
                    var spouseQuestions = [
                        'HB.Common.CommonTerms.SPTobaccoQuestion',
                        'HB.Common.CommonTerms.SPCessationQuestion',
                        'HB.Common.CommonTerms.SPSurchargeQuestion'
                    ];

                    return _(questions)
                        .reject(isSpouseQuestion)
                        .value();

                    function isSpouseQuestion(question) {
                        return _.includes(spouseQuestions, question.ContentEP);
                    }
                }

                function participantHasAnySpouseDependents() {
                    var participant = data.Data.PendingEmployee || data.Data.CurrentCoveragesEmployee || data.Data.FutureCoverages && data.Data.FutureCoverages[0];

                    if (!participant || !participant.Dependents) {
                        return false;
                    }

                    return _(participant.Dependents)
                        .some(isSpouseDependent);

                    function isSpouseDependent(dep) {
                        return _.includes(dependentService.getSpouseRelationTypes(), dep.RelationType);
                    }
                }
            }
        }

        function isQuestionDisplayEnabled(configuration, contentName) {
            var clientConfiguration = configuration['HB.ClientConfiguration'];
            return clientConfiguration && clientConfiguration[contentName.toUpperCase() + 'FLAG'] === 'S';
        }

        function createSingleQuestion(contentName, contentControlName, employeeData) {
            var configuration = employeeData.Configuration;
            var dataContent = contentAliasService.forData(employeeData);

            var questionData = dataContent.getEvaluationPointValue(contentName);
            if (!questionData) {
                return null;
            }

            var displayEnabled, isEditable;
            if (contentControlName) {
                var contentControl = dataContent.getConfigurationValue(contentControlName);

                displayEnabled = contentControl.DISPLAY_ENABLED === 'True';
                isEditable = contentControl.ISEDITABLE === 'True';
            } else {
                displayEnabled = isQuestionDisplayEnabled(configuration, contentName);
                isEditable = true;
            }

            return {
                ContentEP: contentName,
                Question: questionData,
                DisplayEnabled: displayEnabled,
                IsEditable: isEditable
            };
        }

        function createEditableQuestions(questions, answers) {
            return _(questions)
                .map(function (val) {
                    return {
                        Question: val,
                        Answer: answers ? _.clone(answers[val.Key]) : createEmptyAnswer(),
                        DisplayEnabled: true,
                        IsEditable: true,
                        MultipleOptionLogic: getMultipleLogic(val)
                    };
                })
                .value();

            function createEmptyAnswer() {
                return {
                    IsReadOnly: false,
                    Value: '',
                    SubValue: ''
                };
            }

            function getMultipleLogic(question) {
                if (question.Key === 'COVERED_EXPENSES') {
                    var singleOptionId = '4';

                    return {
                        SingleOptionId: singleOptionId,
                        MapSubValuesToValue: function (selectedValues) {
                            if (selectedValues.length === 1 && selectedValues[0] === singleOptionId) {
                                return singleOptionId;
                            }

                            return (4 - selectedValues.length).toString();
                        },
                        MapValueToSubValues: function (value) {
                            if (value === singleOptionId) {
                                return singleOptionId;
                            }

                            var subValues = [];
                            for (var i = 1; i <= 4 - value; i++) {
                                subValues.push(i);
                            }

                            return subValues.join(',');
                        }
                    };
                }

                return null;
            }
        }

        function getConfigureHealthQuestionsByEventLogic(employeeData) {
            var dataContent = contentAliasService.forData(employeeData);
            var configuration = dataContent.getConfigurationValue('HB.HealthQuestions.ConfigureHealthQuestionsByEventLogic');

            if (!configuration) {
                return false;
            }

            var settings = configuration['HB.HEALTHQUESTIONS.CONFIGUREHEALTHQUESTIONSBYEVENTLOGIC'];
            if (!settings) {
                return false;
            }

            return settings[0] === 'T';
        }
    }]);