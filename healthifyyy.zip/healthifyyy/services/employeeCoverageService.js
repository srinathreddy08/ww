﻿'use strict';
angular
    .module('mercer.db.shared')
    .factory('employeeCoverageService', function () {

        var isFilledEmployee = function (employee) {
            return employee && employee.LifeEvents && employee.LifeEvents[0];
        };

        var isCurrentCoverageExists = function(employee) {
            return isFilledEmployee(employee.CurrentCoveragesEmployee);
        }

        var isFutureCoverageExists = function(employee) {
            return employee.FutureCoverages && employee.FutureCoverages[0] && isFilledEmployee(employee.FutureCoverages[0]);
        }

        var getEmployeeCoverage = function (employee) {

            if (isCurrentCoverageExists(employee)) return employee.CurrentCoveragesEmployee;

            return isFutureCoverageExists(employee) ? employee.FutureCoverages[0] : null;
        }
        return {
            getEmployeeCoverage: getEmployeeCoverage,
            isCurrentCoverageExists: isCurrentCoverageExists,
            isFutureCoverageExists: isFutureCoverageExists
        }
    });