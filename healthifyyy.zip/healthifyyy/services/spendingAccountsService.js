﻿'use strict';
angular.module('mercer.hb').factory('spendingAccountsService', [
    '_', 'employeeStateService', 'EnrollmentRules', 'hsaService', 'benefitsService', 'contentAliasService',
    'shoppingCartAmountItemService', 'amountBasedBenefitService', 'accountContributionBenefits', 'charitableBenefitsService',
    'executeAddToCartAction', 'shoppingCartService', 'pubsub', 'executeWithSpinner', 
    function (_, employeeStateService, EnrollmentRules, hsaService, benefitsService, contentAliasService,
        shoppingCartAmountItemService, amountBasedBenefitService, accountContributionBenefits, charitableBenefitsService,
        executeAddToCartAction, shoppingCartService, pubsub, executeWithSpinner) {
        return {
            forCommonData: forCommonData,
            isEmployeeMatch: isEmployeeMatch, 
            getRecalcActionsKey: getRecalcActionsKey
        };

        function getRecalcActionsKey(hsaAmount, frontLoadAmountForHsa) {
            return String(hsaAmount) + '+' + String(frontLoadAmountForHsa);
        }

        function forCommonData(commonData) {
            var employeeType = commonData.employeeType ? commonData.employeeType : 'PendingEmployee';
            var benefit = commonData.benefit;
            var sourceBenefit = commonData.sourceBenefit;
            var shoppingCart = commonData.shoppingCart;
            var employeeData = commonData.employeeData;
            var isFlyoutMode = !!commonData.isFlyoutMode;
            var recalcActions = commonData.recalcActions;

            var benefitId = benefit && benefit.BenefitID;
            var content = contentAliasService.forData(employeeData);
            var shoppingCartItem = shoppingCart && shoppingCart[benefitId];
            var isHsaBenefit = benefit && benefitsService.isHSABenefit(benefit);
            var isHsaOrHsaflBenefit = isHsaBenefit ||
                benefit && benefitsService.isHSAFLBenefit(benefit);
            var electedMedicalHsaEligibleCartItem = internalGetElectedMedicalHsaEligibleCartItem();

            var isElectedMedicalPlanHsaEligible = electedMedicalHsaEligibleCartItem &&
                hsaService.forData(employeeData).isPlanHsaEligible(electedMedicalHsaEligibleCartItem.PlanID);
            var pendingEmployee = _(employeeData.Employee).get(employeeType);
            var lifeEvent = pendingEmployee &&
                pendingEmployee.LifeEvents ?
                pendingEmployee.LifeEvents[0] : null;
            var accountsData = commonData.accountsData ? commonData.accountsData : getAccountData();
            var previousMaximumCorrectionValue = null;

            return {
                getElectedMedicalHsaEligibleCartItem: getElectedMedicalHsaEligibleCartItem,
                isEligible: isEligible,
                isFormDisabled: isFormDisabled,
                getCoverageOption: getCoverageOption,
                getCovPlanFromDom: getCovPlanFromDom,
                getNoCovPlanFromDom: getNoCovPlanFromDom,
                IsNoCovPlanElectedInCart: noCovPlanIsElectedInCart,
                createShoppingCartItemForBenefit: createShoppingCartItemForBenefit,
                isEditable: isEditable,
                setAccountData: setAccountData,
                getAccountData: getAccountData,

                addToCart: addToCart,
                getItemsThatWillBeAddedToCart: getItemsThatWillBeAddedToCart,
                removeFromCart: removeFromCart,
                stopContribution: stopContribution,
                recalcSuppressed: recalcSuppressed,
                getMaximumCorrection: getMaximumCorrection,
                getMaximumAmount: getMaximumAmount
            };

            function isEditable() {
                var benefitIsEligible = isEligible();
                var formIsDisabled = isFormDisabled();
                return benefitIsEligible && !formIsDisabled;
            }

            function setAccountData(data) {
                accountsData = data;
            }

            function addToCart(amountEntered, frontLoadingAmountEntered) {
                return executeAddToCartAction(addToCartAsync);

                function addToCartAsync() {
                    var item = createShoppingCartItemForBenefit(amountEntered, frontLoadingAmountEntered);
                    var result = modifyShoppingCart(item, amountEntered, true, frontLoadingAmountEntered);
                    return result;
                }
            }

            function getItemsThatWillBeAddedToCart(amountEntered, frontLoadingAmountEntered, opt) {
                var item = createShoppingCartItemForBenefit(amountEntered, frontLoadingAmountEntered);

                return getItemsToAddToCart(item, amountEntered, true, frontLoadingAmountEntered, opt);
            }

            function getFrontLoadingAmountEntered(frontLoadingAmountEntered) {
                return accountsData.FrontLoading
                    ? (frontLoadingAmountEntered === undefined
                        ? parseFloat(String(accountsData.FrontLoading.AmountElected), 10)
                        : parseFloat(String(frontLoadingAmountEntered), 10))
                    : 0;
            }

            function getItemsToAddToCart(itemChanges, maximumAmount, doReprice, frontLoadingAmountEntered, opt) {
                return accountContributionBenefits
                    .getItemsToAddToCart(itemChanges,
                        getAdditionalItemsForAmount,
                        lifeEvent,
                        content, shoppingCart,
                        doReprice, opt, frontLoadingAmountEntered);

                function getAdditionalItemsForAmount(cartItem) {
                    if (accountsData.FrontLoading) {
                        return [createFrontLoadingCartItem()];
                    }

                    return [];

                    function createFrontLoadingCartItem() {
                        var amount = Math.min(maximumAmount, getFrontLoadingAmountEntered(frontLoadingAmountEntered));

                        return {
                            BenefitID: accountsData.FrontLoadingBenefit.BenefitID,
                            PlanID: cartItem.PlanID,
                            OptionID: cartItem.OptionID,
                            Amount: amount,
                            AmountInforce: 0,
                            EmployeeAnnualCost: amount,
                            EmployeePayPeriodCost: 0,
                            EmployerAnnualCost: 0,
                            EmployerPayPeriodCost: 0,
                            AmountElected: 0,
                            AmountPended: 0,
                            PremiumMonthly: 0,
                            PremiumAnnual: 0,
                            AdministrativeCostMonthly: 0,
                            AdministrativeCostAnnual: 0,
                            PendedEmployeePayPeriodCost: 0,
                            PendedEmployeeAnnualCost: 0,
                            DependentAssociationList: [],
                            ControlID: lifeEvent.ControlID,
                            LifeEventDate: lifeEvent.LifeEventDate,
                            LifeEventID: lifeEvent.LifeEventID
                        };
                    }
                }
            }

            function modifyShoppingCart(itemChanges, maximumAmount, doReprice, frontLoadingAmountEntered) {
                return executeWithSpinner(getItemsToAddToCart(itemChanges, maximumAmount, doReprice, frontLoadingAmountEntered)
                    .then(addItemsToCart));

                function addItemsToCart(items) {
                    var changedItems = _(items)
                        .reject(function (item) {
                            return angular.toJson(item) === angular.toJson(shoppingCart[item.BenefitID]);
                        })
                        .sortBy(function (item) {
                            var itemWasChangedFromUi = item.BenefitID === benefitId;

                            // the item that was edited from UI needs to come first,
                            // so that it will have the lowest DisplayOrder in batchAdd call response and
                            // thus will be displayed in the shoppingCartWidget as recently changed
                            return itemWasChangedFromUi ? 1 : 2;
                        })
                        .value();

                    var firstChangedBenefit = _(changedItems).head();
                    var firstChangedBenefitId = firstChangedBenefit ? firstChangedBenefit.BenefitID : benefitId;

                    var options = {
                        items: changedItems,
                        lifeEvent: lifeEvent,
                        keepCosts: true,
                        visitedBenefitId: isFlyoutMode ? null : firstChangedBenefitId,
                        editedBenefitId: firstChangedBenefitId
                    };

                    return shoppingCartService.batchAdd(options)
                        .then(function (cartData) {
                            pubsub.publish('cartUpdated', { data: cartData });
                        });
                }
            }

            function itemToBeAddedToCartAfterStopContribution(amountEntered) {
                if (isHsaOrHsaflBenefit) {
                    var item = createShoppingCartItemForBenefit(amountEntered, 0);
                    item.Amount = 0;
                    item.EmployeePayPeriodCost = 0;
                    return item;
                } else {
                    return shoppingCartAmountItemService.createNoCovItem(benefit, lifeEvent);
                }
            }

            function stopContribution() {
                executeAddToCartAction(stopContributionAsync);

                function stopContributionAsync() {
                    if (isHsaOrHsaflBenefit) {
                        var item = itemToBeAddedToCartAfterStopContribution();
                        return modifyShoppingCart(item, 0, false);
                    } else {
                        return removeFromCartAsync();
                    }
                }
            }

            function removeFromCart() {
                return executeAddToCartAction(removeFromCartAsync);
            }

            function removeFromCartAsync() {
                var item = shoppingCartAmountItemService.createNoCovItem(benefit, lifeEvent);

                return modifyShoppingCart(item, 0, true);
            }

            function recalcSuppressed() {
                return accountContributionBenefits.recalcSuppressed(benefitId, shoppingCart) ||
                    !charitableBenefitsService.forBenefit(benefit, employeeData).showCalcButton();
            }

            function getElectedMedicalHsaEligibleCartItem() {
                return electedMedicalHsaEligibleCartItem;
            }

            function getAmtElectedFrequency() {
                var clientConfiguration = content.getConfigurationValue('HB.ClientConfiguration');

                return clientConfiguration['HB.LIFEEVENT.AMTELECTEDFREQUENCY'];
            }

            function isAnnual() {
                return getAmtElectedFrequency() === 'A';
            }

            function createShoppingCartItemForBenefit(amountEntered, frontLoadingAmountEntered) {
                var plan = getCovPlanFromDom();

                var pureAmount = amountEntered - frontLoadingAmountEntered;
                var calculatedAmount = (isAnnual() && recalcSuppressed()) ? 0 : calculateOtherContribution();

                return {
                    BenefitID: benefitId,
                    PlanID: plan.PlanID,
                    OptionID: isHsaOrHsaflBenefit ? electedMedicalHsaEligibleCartItem.OptionID : plan.EligibleOptions[0].OptionID,
                    Amount: isAnnual() ? pureAmount : calculatedAmount,
                    EmployeePayPeriodCost: isAnnual() ? calculatedAmount : pureAmount,
                    DependentAssociationList: [],
                    ControlID: lifeEvent.ControlID,
                    LifeEventDate: lifeEvent.LifeEventDate,
                    LifeEventID: lifeEvent.LifeEventID
                };

                function calculateOtherContribution() {
                    return EnrollmentRules.spendingAcctCalculation(
                        getAmtElectedFrequency(),
                        pendingEmployee,
                        lifeEvent.EligibleBenefitsMap[benefitId],
                        pureAmount,
                        employeeData);
                }
            }

            function getAccountData() {
                return accountsData
                    ? accountsData
                    : amountBasedBenefitService
                        .forData(employeeData, employeeType)
                        .getElectionData(benefit, amountBasedBenefitService.shoppingCartProvider(shoppingCart));
            }

            function getCovPlanFromDom() {
                if (noCovPlanIsElectedInCart()) {
                    return sholudReturnHsaCoverage() ? getDefaultHsaCoveragePlan() : getDefaultCovPlanFromDom();
                } else {
                    return getPlanElectedInCart();
                }
            }

            function sholudReturnHsaCoverage() {
                return isHsaOrHsaflBenefit && isElectedMedicalPlanHsaEligible && electedMedicalHsaEligibleCartItem;
            }

            function getNoCovPlanFromDom() {
                return getDefaultPlanFromDomForCoverage(true);
            }

            function getDefaultCovPlanFromDom() {
                return getDefaultPlanFromDomForCoverage(false);
            }

            function getDefaultPlanFromDomForCoverage(isNoCov) {
                return _.find(benefit.EligiblePlans, { IsNoCovPlan: isNoCov });
            }

            function getOriginalMaximum() {
                var maxElectAmountFromRule = EnrollmentRules.getAMTBenefitMaxContribution(shoppingCart, benefitId, employeeData);

                return maxElectAmountFromRule === null ?
                    getCoverageOptionWithNoOverrides().MaximumElectAmount :
                    maxElectAmountFromRule;
            }

            function getMaximumCorrection() {
                if (sourceBenefit) {
                    return getMaximumCorrectionFromSourceBenefit();
                }

                if (isEmployeeMatch(pendingEmployee)) {
                    if (!isHsaOrHsaflBenefit) {
                        return getCoverageOptionWithNoOverrides().Amount5;
                    }

                    var newMaximumCorrectionValue;

                    if (recalcActions) {
                        var recalcActionKey = _(recalcActions).keys().head();

                        if (recalcActionKey) {
                            var recalcAction = recalcActions[recalcActionKey];
                            newMaximumCorrectionValue = recalcAction &&
                                recalcAction.costsForThisItem &&
                                recalcAction.costsForThisItem.Amount5;
                        }
                    }

                    newMaximumCorrectionValue = newMaximumCorrectionValue || previousMaximumCorrectionValue;
                    previousMaximumCorrectionValue = newMaximumCorrectionValue;

                    return newMaximumCorrectionValue;
                }

                var sourceItem = noCovPlanIsElectedInCart()
                    ? accountsData
                    : shoppingCartItem;

                if (sourceItem.EmployerAnnualCost === null) {
                    sourceItem.EmployerAnnualCost = accountsData.EmployerAnnualCost;
                }

                return isAnnual() ?
                    sourceItem.EmployerAnnualCost :
                    sourceItem.EmployerPayPeriodCost;

                function getMaximumCorrectionFromSourceBenefit() {
                    var sourceBenefitData = forCommonData(_.assign({}, commonData, {
                        benefit: sourceBenefit,
                        sourceBenefit: null
                    }));

                    return sourceBenefitData.getMaximumCorrection();
                }
            }

            function getMaximumAmount() {
                return getOriginalMaximum() - getMaximumCorrection();
            }

            function getCoverageOption() {
                return _.defaults({
                    MaximumElectAmount: getMaximumAmount(),
                    EmployerAnnualCost: shoppingCartItem.EmployerAnnualCost,
                    EmployerPayPeriodCost: shoppingCartItem.EmployerPayPeriodCost
                }, getCoverageOptionWithNoOverrides());
            }

            function getCoverageOptionWithNoOverrides() {

                return noCovPlanIsElectedInCart()
                    ? getDefaultCoverageOption()
                    : getOptionElectedInCart();
            }

            function getDefaultCoverageOption() {
                if (sholudReturnHsaCoverage()) {
                    return getDefaultHsaCoverageOption();
                }

                return getDefaultCoverageOptionFromDom();
            }

            function getOptionElectedInCart() {
                var plan = getPlanElectedInCart();
                return plan.EligibleOptionsMap[shoppingCartItem.OptionID];
            }

            function noCovPlanIsElectedInCart() {
                var electedPlan = getPlanElectedInCart();

                return electedPlan.IsNoCovPlan;
            }

            function getPlanElectedInCart() {
                return benefit.EligiblePlansMap[shoppingCartItem.PlanID];
            }

            function getDefaultHsaCoverageOption() {

                var plan = getDefaultHsaCoveragePlan();

                return plan.EligibleOptionsMap[electedMedicalHsaEligibleCartItem.OptionID];
            }

            function getDefaultHsaCoveragePlan() {
                return getMatchingMedicalPlan() || getDefaultCovPlanFromDom();
            }

            function getMatchingMedicalPlan() {
                return benefit.EligiblePlansMap[electedMedicalHsaEligibleCartItem.PlanID];
            }

            function getDefaultCoverageOptionFromDom() {
                var eligibleOptions = getCovPlanFromDom().EligibleOptions;
                var electedOption = eligibleOptions.filter(function (item) { return item.IsElected === true });
                return electedOption.length > 0 ? electedOption[0] : eligibleOptions[0];
            }

            function internalGetElectedMedicalHsaEligibleCartItem() {
                var medicalBenefitCategoryList = ["MEDICAL", "O65MED", "U65MED"];
                var b = _.find(shoppingCart,
                    function (item) {
                        var result = _(medicalBenefitCategoryList).includes(item.BenefitCategory)
                            && hsaService.forData(employeeData).isPlanHsaEligible(item.PlanID);
                        return result;
                    });
                return b;
            }

            function isFormDisabled() {
                var crossBenefitCheck = EnrollmentRules.crossBenefitCheck(shoppingCart, employeeData, employeeType);
                return _.some(crossBenefitCheck.Disable[benefitId]);
            }

            function isEligible() {
                var unbundleHsaFromHdhp = content.getConfigurationValue('HB.LifeEvent.UnbundleHSAFromHDHP') === '1';
                var unbundleLpfsaFromHsa = content.getConfigurationValue('HB.LifeEvent.UnbundleLPFSAFromHSA') === '1';

                var cartStateService = employeeStateService
                    .forEmployee(pendingEmployee)
                    .forCart(shoppingCart);

                if (!unbundleHsaFromHdhp || unbundleLpfsaFromHsa) {
                    if (isElectedMedicalPlanHsaEligible) {
                        if (benefitsService.isHCFSABenefit(benefit)) {
                            return false;
                        } else if (benefitsService.isLPFSABenefit(benefit)) {
                            return unbundleLpfsaFromHsa || cartStateService.isCovSpendingElection('HSA');
                        }
                    } else if (benefitsService.isHSABenefit(benefit) || benefitsService.isLPFSABenefit(benefit)) {
                        return false;
                    }

                    return true;
                }

                if (benefitsService.isHSABenefit(benefit)) {
                    return isElectedMedicalPlanHsaEligible && !cartStateService.isCovSpendingElection('HCFSA');
                }

                if (benefitsService.isHCFSABenefit(benefit)) {
                    if (!isElectedMedicalPlanHsaEligible) {
                        return true;
                    }

                    return !cartStateService.isCovSpendingElection('HSA');
                }

                if (benefitsService.isLPFSABenefit(benefit)) {
                    return isElectedMedicalPlanHsaEligible && cartStateService.isCovSpendingElection('HSA');
                }

                return true;
            }

        }

        function isEmployeeMatch(pendingEmployee) {
            return pendingEmployee.SmallMarketData.HsaEmployerContribStrategy === 'EEMATCH';
        }
    }
]);