import { Inject, Injectable } from '@angular/core';

import { Ng1FlagsService } from '../common-hybrid/ng1-flags.service';

@Injectable({ providedIn: 'root' })
export class FlagsService {

  initiatedLEThisSession: boolean;
  isImpersonation: boolean;
  isProxySimulation: boolean;
  isMobile: boolean;
  isAuth2Login: boolean;
  isMasAuthentication: boolean;
  hsaSignUpComplete: boolean;
  isBigText: boolean;
  fsaAutoPayAgreementAnswers: boolean[];
  isAdaContrastTheme: boolean;
  isInternalProxy: boolean;
  sessionToken: string;
  companyId: string;
  displayCosts: boolean;

  constructor(@Inject(Ng1FlagsService) ng1Service: any) {
    Object.assign(this, ng1Service);
  }
}
