﻿'use strict';
angular.module('mercer.services')
    .factory('depsPendingVerificationService', [
        '$resource', '$q', 'isDependentVerificationEnabled', '$transitions', 'comparisonBenefitCategories',
        'EnrollmentRules', 'benefitsOptionsService',
        function ($resource, $q, isDependentVerificationEnabled, $transitions, comparisonBenefitCategories,
            EnrollmentRules, benefitsOptionsService) {
            var cachedOptions = {};

            $transitions.onStart({}, function () {
                cachedOptions = {};
            });

            var depsPendingVerificationResource = $resource('/api/depsPendingVerification/GetVerifiedOptionCosts', {},
                { getVerifiedOptionCosts: { method: 'GET' } });

            var emptyVerifiedDetails = {
                VerifiedAnnualCost: 0,
                VerifiedPPCost: 0,
                VerifiedOptionID: '',
                ElectedOption: {
                    VerifiedAnnualCost: 0,
                    VerifiedPPCost: 0,
                    VerifiedOptionID: ''
                }
            };

            return {
                createCache: createCache,
                getVerifiedOptionDetails: getVerifiedOptionDetails,
                getDerivedOptionId: getDerivedOptionId

            };

            function createCache(enrollmentContent) {
                var promises = [];
                var enrollment = enrollmentContent.contentSource;

                if (!isDependentVerificationEnabled(enrollment)) {
                    return $q.resolve();
                }
                var data = enrollment.Data;

                addVerifiedOptionsDetailsToCacheForEmployee(data.PendingEmployee);
                addVerifiedOptionsDetailsToCacheForEmployee(data.CurrentCoveragesEmployee);
                addVerifiedOptionsDetailsToCacheForEmployee(data.FutureCoverages && data.FutureCoverages[0]);

                return $q.all(promises)
                    .then(function () {
                        return cachedOptions;
                    });

                function addVerifiedOptionsDetailsToCacheForEmployee(employee) {
                    if (!employee) {
                        return;
                    }
                    var lifeEvent = employee.LifeEvents[0];
                    var eligibleBenefitsMap = lifeEvent.EligibleBenefitsMap;

                    _(eligibleBenefitsMap)
                        .filter(function (benefit) {
                            return isBenefitCoveredAndComparison(benefit, benefit.ElectedPlan);
                        })

                        .forEach(addBenefitToCache);

                    function addBenefitToCache(benefit) {
                        var benefitId = benefit.BenefitID;
                        var lifeEventId = lifeEvent.LifeEventID;
                        var lifeEventDate = lifeEvent.LifeEventDate;
                        var electedPlan = benefit.ElectedPlan;
                        var electedPlanId = electedPlan.PlanID;
                        var electedOption = electedPlan.ElectedOption;
                        var electedOptionId = electedOption.OptionID;

                        var derivedOptionId = getDerivedOptionId(enrollment, employee, benefit);

                        if (derivedOptionId === electedOptionId) {
                            return;
                        }

                        var derivedOption = eligibleBenefitsMap[benefitId].EligiblePlansMap[electedPlanId].EligibleOptionsMap[derivedOptionId];

                        if (!derivedOption) {
                            promises.push(requestDerivedOption());
                        }

                        function requestDerivedOption() {
                            return depsPendingVerificationResource.getVerifiedOptionCosts(
                                {
                                    ControlId: employee.CompanyID || lifeEvent.ControlID,
                                    Ssn: employee.Ssn,
                                    LifeEventId: lifeEventId,
                                    LifeEventDate: lifeEventDate,
                                    BenefitId: benefitId,
                                    PlanId: electedPlanId,
                                    OptionId: derivedOptionId
                                })
                                .$promise
                                .then(processCosts);

                            function processCosts(costs) {
                                if (!costs) {
                                    return $q.resolve();
                                }
                                
                                var optionDescription = getOptionDescriptionOverride(enrollment, benefitId, derivedOptionId) ||
                                                        enrollmentContent.getContentString(costs.OptionAlias) ||
                                                        costs.OptionDescription;
                                
                                if (optionDescription) {
                                    setDerivedOptionCache(costs, optionDescription);
                                    return $q.resolve();
                                }

                                function setDerivedOptionCache(costs, description) {
                                    var derivedOptionDetails = {
                                        VerifiedAnnualCost: costs.AnnualCost,
                                        VerifiedPPCost: costs.PayPeriodCost,
                                        VerifiedOptionID: description,
                                        ElectedOption: {
                                            VerifiedAnnualCost: costs.AnnualCost,
                                            VerifiedPPCost: costs.PayPeriodCost,
                                            VerifiedOptionID: description
                                        }
                                    };

                                    var cacheKey = getOptionKey(lifeEventId, lifeEventDate, benefitId, electedPlanId, derivedOptionId);

                                    cachedOptions[cacheKey] = derivedOptionDetails;
                                }
                            }
                        }

                    }
                }
            }

            function getVerifiedOptionDetails(enrollmentContent, employee, benefitId, planId, optionId) {
                var enrollment = enrollmentContent.contentSource;
                if (!isDependentVerificationEnabled(enrollment)) {
                    return null;
                }

                var lifeEvent = employee.LifeEvents[0];
                var eligibleBenefitsMap = lifeEvent.EligibleBenefitsMap;
                var benefit = lifeEvent.EligibleBenefitsMap[benefitId];
                var plan = benefit.EligiblePlansMap[planId];
                if (!isBenefitCoveredAndComparison(benefit, plan)) {
                    return null;
                }

                var option = plan.EligibleOptionsMap[optionId];

                var derivedOptionId = getDerivedOptionId(enrollment, employee, benefit);
                if (derivedOptionId === optionId) {
                    return null;
                }

                var derivedOption = eligibleBenefitsMap[benefitId].EligiblePlansMap[plan.PlanID].EligibleOptionsMap[derivedOptionId];
                if (derivedOption) {
                    return createDetailsFromOption(derivedOption, enrollmentContent);
                }

                var cacheKey = getOptionKey(lifeEvent.LifeEventID, lifeEvent.LifeEventDate, benefitId, planId, derivedOptionId);
                return cachedOptions[cacheKey] || emptyVerifiedDetails;

                function createDetailsFromOption(option, enrollmentContent) {
                    var description = getOptionDescriptionOverride(enrollment, benefitId, option.OptionID) ||
                                      enrollmentContent.getContentString(option.ContentAlias) ||
                                      option.OptionYearDefDescr1;
                    
                    return {
                        VerifiedAnnualCost: option.EmployeeAnnualCost,
                        VerifiedPPCost: option.EmployeePayPeriodCost,
                        VerifiedOptionID: description,
                        ElectedOption: {
                            VerifiedAnnualCost: option.EmployeeAnnualCost,
                            VerifiedPPCost: option.EmployeePayPeriodCost,
                            VerifiedOptionID: description
                        }
                    };
                }
            }

            function getOptionDescriptionOverride(enrollment, benefitId, optionId) {
                var benefitsOverrideOptionValues = benefitsOptionsService.getOverrideOptionsConfiguration(enrollment);
                if (!benefitsOverrideOptionValues) {
                    return null;
                }

                var benefitOverrideOptionValues = benefitsOverrideOptionValues[benefitId];
                if (!benefitOverrideOptionValues) {
                    return null;
                }

                return benefitOverrideOptionValues[optionId];
            }

            function getDerivedOptionId(enrollment, employee, benefit) {

                if ((!benefit.DependentAssociationList || !benefit.DependentAssociationList.length)
                    && benefit.ElectedPlan.ElectedOption.DependentAssociations) {
                    benefit.DependentAssociationList = _.map(benefit.ElectedPlan.ElectedOption.DependentAssociations, 'DependentSsn');
                }

                var eligibleBenefitsMap = employee.LifeEvents[0].EligibleBenefitsMap;
                var derivedOptionId = EnrollmentRules.deriveOption(eligibleBenefitsMap,
                    benefit.BenefitID, enrollment, 'true', 'false', employee);
                return derivedOptionId;
            }

            function getOptionKey(lifeEventId, lifeEventDate, benefitId, planId, optionId) {
                return lifeEventId + '|' +
                    lifeEventDate + '|' +
                    benefitId + '|' +
                    planId + '|' +
                    optionId;
            }

            function isBenefitCoveredAndComparison(benefit, electedPlan) {
                var isComparisonBenefit = _(comparisonBenefitCategories).includes(benefit.BenefitCategory);
                var isCovered = !electedPlan.IsNoCovPlan;
                return isComparisonBenefit && isCovered;
            }
        }
    ]);