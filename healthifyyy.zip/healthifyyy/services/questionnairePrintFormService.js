﻿'use strict';
angular.module('mercerApp').factory('questionnairePrintFormService', [
    'questionService', 'contentAliasService',
    function (questionService, contentAliasService) {
        var submitCache = null;

        return {
            fillSubmitCache: fillSubmitCache,
            getSubmitCache: getSubmitCache,
            getQuestions: getQuestions
        };

        function fillSubmitCache(enrollment) {
            submitCache = getQuestions(enrollment, 'PendingEmployee');
        }

        function getQuestions(enrollment, employeeType) {
            var questionsData = questionService.getDataForMyInformation(enrollment, employeeType);
            var questions = _.mapValues(questionService.filterAndSortQuestions(questionsData), mapQuestion);
            var enrollmentContent = contentAliasService.forData(enrollment);
            var title = enrollmentContent.getEvaluationPointValue('HB.LifeEvent.GetStarted.WhosCovered.MyBenefitsHeader');
            return {
                questions: questions,
                title: title
            };

            function mapQuestion(question) {
                return {
                    title: question.Question.Text,
                    answers: question.Question.Options[question.Answer.Value]
                }
                
            }
        }

        function getSubmitCache() {
            return submitCache;
        }
    }
]);

