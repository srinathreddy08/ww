﻿'use strict';
angular.module('mercer.db.shared').service('coverageSourcesService', [
    'dependentService', 'participantEligibilityService', 'dependencyTracker', 'EnrollmentRules',
    function (dependentService, participantEligibilityService, dependencyTracker, EnrollmentRules) {
        return {
            fromCartElections: fromCartElections,
            fromDomElections: fromDomElections,
            fromDomElectionsForConfirmation: fromDomElectionsForConfirmation,
            isDependentEligibleForRule: isDependentEligibleForRule
        };

        function fromCartElections(data, employee, cart) {
            var lifeEvent = employee.LifeEvents[0];
            var eligibleBenefits = lifeEvent.EligibleBenefitsMap;
            var participantEligibility = participantEligibilityService.forData(data.employeeData);

            return {
                employeeData: data.employeeData,
                employee: employee,
                elections: getElections(),
                editable: true,
                isParticipantEditable: isParticipantEditable,
                isDependentEditable: isDependentEditable,
                isDependentEligible: function (dependent, benefit) {
                    return isDependentEligibleForRule(dependent, benefit, data.employeeData)
                },
                bestMatch: {
                    MEDICAL: data.bestMatchData && data.bestMatchData.AllMedicalMatches
                }
            };

            function getElections() {
                return _(cart.ShoppingCart)
                    .keyBy('BenefitID')
                    .mapValues(function(cartItem) {
                        var benefit = eligibleBenefits[cartItem.BenefitID];
                        var election = _.clone(cartItem);

                        election.DependentAssociationList = _(cartItem.DependentAssociationList)
                            .filter(function(ssn) {
                                var dependent = _(employee.Dependents).find({ Ssn: ssn });
                                return dependent && isDependentEligible(dependent, benefit, data.employeeData);
                            })
                            .value();

                        return election;
                    })
                    .value();
            }

            function isParticipantEditable(benefitId) {
                var benefit = eligibleBenefits[benefitId];

                return _(benefit.EligiblePlans)
                    .flattenDeep()
                    .map('EligibleOptions')
                    .flattenDeep()
                    .some(function(option) {
                        return participantEligibility
                            .isParticipantEligibleForOption(benefit, option.OptionID);
                    });
            }

            function isDependentEditable(dependent, benefitId) {
                var benefit = eligibleBenefits[benefitId];

                if (!isDependentEligible(dependent, benefit, data.employeeData)) {
                    return false;
                }

                if (!data.restrictionsData) {
                    return true;
                }

                var dependentRestrictions = dependentService.getDependentRestrictions(dependent, data.restrictionsData);

                if (!dependentRestrictions) {
                    return true;
                }

                var hasCoverage = _(benefit.ElectedPlan.ElectedOption.DependentAssociations)
                    .some({ DependentSsn: dependent.Ssn });

                return dependentService.canEditCoverage(hasCoverage, dependentRestrictions.CoverageRule);
            }
        }

        function fromDomElections(employeeData, employee) {
            return {
                employeeData: employeeData,
                employee: employee,
                elections: getElections(),
                editable: false,
                isParticipantEditable: function() {
                    return false;
                },
                isDependentEditable: function() {
                    return false;
                },
                isDependentEligible: function() {
                    return true;
                }
            };

            function getElections() {
                return _(employee.LifeEvents[0].EligibleBenefits)
                    .filter('ElectedPlan')
                    .keyBy('BenefitID')
                    .mapValues(function(benefit) {
                        var electedPlan = benefit.ElectedPlan;
                        var electedOption = electedPlan.ElectedOption;

                        return {
                            BenefitID: benefit.BenefitID,
                            BenefitCategory: benefit.BenefitCategory,
                            PlanID: electedPlan.PlanID,
                            OptionID: electedOption.OptionID,
                            DependentAssociationList: _.map(electedOption.DependentAssociations, 'DependentSsn')
                        };
                    })
                    .value();
            }
        }

        function fromDomElectionsForConfirmation(employeeData, employee) {
            var domElections = fromDomElections(employeeData, employee);
            domElections.isDependentEligible = function (dependent, benefit) {
                return isDependentEligibleForRule(dependent, benefit, employeeData)
            };

            return domElections;
        }

        function isDependentEligible(dependent, benefit, employeeData) {
            if (benefit.CovPlanCount === 0) {
                return false;
            }

            return isDependentEligibleForRule(dependent, benefit, employeeData);
        }

        function isDependentEligibleForRule(dependent, benefit, employeeData) {
            var eligibility = EnrollmentRules.dependentBenefitCategoryEligibility(dependent, employeeData, benefit.BenefitCategory);

            return eligibility && eligibility.indexOf(benefit.BenefitID) >= 0;
        }
    }
]);