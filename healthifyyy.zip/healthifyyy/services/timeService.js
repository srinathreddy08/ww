﻿'use strict';
angular
    .module('mercer.db.shared')
    .factory('timeService', ['timeOffset', 'flags', function (timeOffset, flags) {

            var isOffsetEnabled = function () {
                return timeOffset.IsOffsetEnabled;
            }

            return {
                now: function() {
                    var result = new Date();

                    if (!isOffsetEnabled()) {
                        return result;
                    }

                    result.setDate(result.getDate() + timeOffset.Days);
                    result.setTime(result.getTime() + timeOffset.Minutes * 60 * 1000);
                    return result;
                },

                isOffsetEnabled: isOffsetEnabled
            }
        }
    ]);