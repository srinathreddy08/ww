﻿'use strict';

angular.module('mercerApp').service('optionStatusService', function() {
        return {
            isAvailableForUpdate: function(option) {
                return _.includes(['A', 'E'], option.Status);
            }
        };
    });