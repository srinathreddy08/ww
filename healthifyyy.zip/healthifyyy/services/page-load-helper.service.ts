import { Injectable } from '@angular/core';
import { PubsubService } from './pubsub.service';
import { SpinnerService } from './spinner.service';

@Injectable({
  providedIn: 'root'
})
export class PageLoadHelperService {
  private static pageUrls: string[] = [];
  private static spinnerService: SpinnerService = null;

  constructor(private pubsubService: PubsubService, private spinnerService: SpinnerService) { 
    PageLoadHelperService.spinnerService = this.spinnerService;
    this.pubsubService.subscribe('stateChanged', this.onStateChanged);
  }

  loadPageWithSpinner(pageUrl: string): void {
    if (pageUrl && !PageLoadHelperService.pageUrls.includes(pageUrl)) {
      PageLoadHelperService.spinnerService.showGlobalSpinner();
      PageLoadHelperService.pageUrls.push(pageUrl);
    }
  }

  private onStateChanged(e, data): void {
    if (data && PageLoadHelperService.pageUrls.includes(data.toUrl)) {
      const idx = PageLoadHelperService.pageUrls.indexOf(data.toUrl);
      PageLoadHelperService.pageUrls.splice(idx, 1);
      PageLoadHelperService.spinnerService.hideGlobalSpinner();
    }
  }
}
