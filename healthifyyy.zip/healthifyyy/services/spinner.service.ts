import { Injectable } from '@angular/core';

import { BehaviorSubject } from 'rxjs';

import { PubsubService } from './pubsub.service';

export interface SpinnerStateLayer {
  isDisplayed: boolean;
  onBeforeLayerAboveRemoved: (prevStateIsDisplayed: boolean) => boolean;
}

@Injectable({
  providedIn: 'root'
})
export class SpinnerService {
  private static readonly globalLoader: HTMLDivElement = document.querySelector('#firstTimeBlockingOverlay');
  private spinnerStateLayers: SpinnerStateLayer[] = [];

  readonly isSpinnerDisplayed$ = new BehaviorSubject<boolean>(false);

  constructor(private pubsubService: PubsubService) {
    this.pauseDisplayingSpinner();
  }

  get isSpinnerDisplayed(): boolean {
    return this.isSpinnerDisplayed$.getValue();
  }

  get isGlobalSpinnerVisible(): boolean {
    return SpinnerService.globalLoader.style.display !== 'none';
  }

  showGlobalSpinner(): void {
    if (this.isGlobalSpinnerVisible) return;
    SpinnerService.globalLoader.style.display = 'block';
  }

  hideGlobalSpinner(): void {
    if (!this.isGlobalSpinnerVisible) return;
    SpinnerService.globalLoader.style.display = 'none';
  }

  startDisplayingSpinner() {
    this.pubsubService.publish('stopIdleTimer');
    return this.addSpinnerStateLayer(true, layerIsDisplaying => layerIsDisplaying);
  }

  pauseDisplayingSpinner() {
    return this.addSpinnerStateLayer(false, layerIsDisplaying => layerIsDisplaying);
  }

  keepDisplayingSpinnerIfItStarts() {
    return this.addSpinnerStateLayer(
      this.isSpinnerDisplayed,
      layerIsDisplaying => layerIsDisplaying || this.isSpinnerDisplayed
    );
  }

  get activeLayer(): SpinnerStateLayer {
    return this.spinnerStateLayers[this.spinnerStateLayers.length - 1];
  }

  private addSpinnerStateLayer(
    isDisplayed: SpinnerStateLayer['isDisplayed'],
    onBeforeLayerAboveRemoved: SpinnerStateLayer['onBeforeLayerAboveRemoved']
  ): { complete: () => void } {
    const stateLayer: SpinnerStateLayer = {
      isDisplayed,
      onBeforeLayerAboveRemoved
    };

    this.spinnerStateLayers.push(stateLayer);
    this.isSpinnerDisplayed$.next(this.activeLayer?.isDisplayed);

    return {
      complete: this.spinnerStateCompleteFactory(stateLayer)
    };
  }

  private spinnerStateCompleteFactory(stateLayer: SpinnerStateLayer): () => void {
    return () => {
      const indexOfActiveLayer = this.spinnerStateLayers.indexOf(stateLayer);
      const previousStateLayer = this.spinnerStateLayers[indexOfActiveLayer - 1];

      previousStateLayer.isDisplayed = previousStateLayer.onBeforeLayerAboveRemoved(previousStateLayer.isDisplayed);
      this.spinnerStateLayers.splice(indexOfActiveLayer, 1);

      this.isSpinnerDisplayed$.next(this.activeLayer?.isDisplayed);

      this.pubsubService.publish('startIdleTimer');
    };
  }
}
