﻿describe('employeeLifeEventActionService', function () {

    var employeeLifeEventActionServiceConstants, $state;

    beforeEach(module('mercerApp'));

    beforeEach(inject(function (_employeeLifeEventActionServiceConstants_, _$state_) {
        employeeLifeEventActionServiceConstants = _employeeLifeEventActionServiceConstants_;
        $state = _$state_;
    }));

    it('Maximum length of constants',
        function () {
            var constants = _(employeeLifeEventActionServiceConstants.types)
                .map()
                .union(getPageVisitIds())
                .value();

            _.forEach(constants, function (constant) {
                expect(constant.length).toBeLessThan(41,
                    'Constant "' + constant + '" is too long, maximum length is 40');
            });

            function getPageVisitIds() {
                var allStates = $state.get();

                return _(allStates)
                    .filter(function (state) {
                        return state.name.indexOf('expert-guidance.') === 0;
                    })
                    .map('pageVisitId')
                    .compact()
                    .value();
            }
        });
});