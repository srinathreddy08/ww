﻿'use strict';
angular.module('mercer.services').factory('dependentResourceService', [
    '$resource', '_', 'contentAliasService', 'flags', 'cacheService',
    function($resource, _, contentAliasService, flags, cacheService) {
        var dependentsResource = $resource('/api/dependents/:action',
            {},
            {
                add: { method: 'POST', params: { action: 'add' }, isArray: true },
                update: { method: 'POST', params: { action: 'update' } },
                getRestrictions: { method: 'GET', params: { action: 'getRestrictions' } }
            });
            
        return {
            addDependent: addDependent,
            updateDependent: updateDependent,
            getRestrictions: getRestrictions
        };

        function addDependent(deps) {
            return dependentsResource.add({
                Dependents: deps
            }).$promise;
        }

        function updateDependent(ssn, dep, isDomainPageUpdate) {
            return dependentsResource.update({
                OriginalDependentSsn: ssn,
                UpdatedDependent: dep,
                IsDomainPageUpdate: isDomainPageUpdate
            }).$promise;
        }

        function getRestrictions(lifeEventId, lifeEventDate) {
            var cacheKey = constructGetRestrictionsKey(lifeEventId, lifeEventDate);
            if (cacheService.cache.get(cacheKey) == undefined) {
                var restrictionsRequest = dependentsResource.getRestrictions({
                    LifeEventId: lifeEventId,
                    LifeEventDate: lifeEventDate
                }).$promise;

                cacheService.cache.put(cacheKey, restrictionsRequest);
            }

            return cacheService.cache.get(cacheKey);
        }

        function constructGetRestrictionsKey(lifeEventId, lifeEventSeqNo, lifeEventDate) {
            return 'dependentResourceService.getRestrictions.' + lifeEventDate + '.' + lifeEventSeqNo;
        }
    }
]);