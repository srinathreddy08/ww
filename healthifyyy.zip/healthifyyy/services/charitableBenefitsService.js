﻿'use strict';
angular.module('mercer.services').service('charitableBenefitsService', ['_', 'contentAliasService', 'mbcContentAndData',
    'stringService',
    function (_, contentAliasService, mbcContentAndData, stringService) {
        return {
            forBenefit: forBenefit
        };

        function forBenefit(benefit, employeeData) {
            var content = contentAliasService.forData(employeeData);

            return {
                showPerPayPeriod: showPerPayPeriod,
                showMaxAmount: showMaxAmount,
                showCalcButton: showCalcButton
            };

            function showPerPayPeriod() {
                return isNoOptionForBenefit('HB.LifeEvent.LumpsumBenefits');
            }

            function showMaxAmount() {
                return isNoOptionForBenefit('HB.LifeEvent.SuppressMaxAmount');
            }

            function showCalcButton() {
                return isNoOptionForBenefit('HB.LifeEvent.SuppressCalcButton');
            }

            function isNoOptionForBenefit(configName) {
                if (!content.getConfigurationValue(configName)) {
                    return true;
                }

                var configurationOption = stringService.convertArrayStringToArray(content.getConfigurationValue(configName));
                if (!configurationOption) {
                    return true;
                }

                return !stringService.wildCardMatchArray(configurationOption, benefit.BenefitID);
            }
        }
    }
]);