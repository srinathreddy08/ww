import { TestBed } from '@angular/core/testing';
import { BehaviorSubject, of } from 'rxjs';
import { take } from 'rxjs/operators';
import { IEnrollment } from 'src/app/common-dto/enrollment.model';
import { EnrollmentNavigationBuilderService } from './services/enrollment-navigation-builder.service';
import { EnrollmentNavigationService } from './enrollment-navigation.service';
import { INavMenuItem } from "@common-navigation/models/nav-menu-item";
import { UIRouter } from '@uirouter/angular';
import { EnrollmentMenuMockBuilder } from './mocks/enrollment-menu-mock-builder';
import { EnrollmentNavigationProgressService } from './services/enrollment-navigation-progress.service';
import { DeepPartial } from '@mocks/deep-partial';
import { NavStatus } from '@common-navigation/models/nav-status';
import { EnrollmentNavigationGuardService } from './services/enrollment-navigation-guard.service';
import { EnrollmentService } from '@services/enrollment.service';
import { LifeEventNavigationStatusService } from '@common-navigation/services/life-event-navigation-status.service';
import { LifeEventIdentifier } from 'src/app/common-dto/life-event-identifier.constants';
import { EnrollmentMockBuilderForMenu } from './mocks/enrollment-mock-builder-for-menu';
import { ILifeEventNavigationStatus } from '@common-navigation/models/life-event-navigation-status';
import { EnrollmentNavTestHelper } from './mocks/enrollment-nav-test-helper';
import { EnrollmentNavTabId } from './common/enrollment-nav-ids';
import { DataHelperFromOldAngular } from '@services/data-helper-from-old-angular.service';
import { BeneficiariesInsideLeService } from "@beneficiaries/services/beneficiaries-inside-le.service";
import { ShoppingCartService } from "@services/shopping-cart.service";

describe('EnrollmentNavigationService', () => {
  let navigationService: EnrollmentNavigationService;
  let mockUIRouter;
  let mockEnrollmentService;
  let mockDataHelperFromOldAngular;
  let mockBuilderService;
  let mockProgressService;
  let mockGuardService;
  let mockStatusService;
  let mockBeneficiariesInsideLeService;
  let mockShoppingCartService;

  beforeEach(() => {
    mockUIRouter = {
      stateService: {
        go: jest.fn(),
      },
    };

    mockEnrollmentService = {
      enrollment$: new BehaviorSubject<IEnrollment>(null),
      reloadEnrollment: jest.fn().mockReturnValue(of(null)),
    };

    mockDataHelperFromOldAngular = {
      getShoppingCart: jest.fn().mockReturnValue(of(null)),
    };

    mockBuilderService = {
      buildNavigation: jest.fn(),
    };

    mockProgressService = {
      activateRoute$: jest.fn((activeRouteName, navItems, enrollment) => of(navItems)),
      getNextMenuItem: jest.fn(),
      getPreviousMenuItem: jest.fn(),
      checkUnvisitedPagesInMiddleOfChooseBenefits: jest.fn().mockReturnValue(false),
      checkUnvisitedPagesInMiddleOfBeneficiaries: jest.fn().mockReturnValue(false),
      getLastVisitedStateForEnrollmentFlow: jest.fn(),
    };

    mockGuardService = {
      canActivateRoute$: jest.fn().mockReturnValue(of(true)),
    };

    mockStatusService = {
      getAllVisitedPages: jest.fn(),
      clearVisitedPagesHistory: jest.fn(),
      clearVisitedPagesHistoryExept: jest.fn(),
    }

    mockBeneficiariesInsideLeService = {};
    mockShoppingCartService = {};

    TestBed.configureTestingModule({
      providers: [
        EnrollmentNavigationService,
        { provide: UIRouter, useValue: mockUIRouter },
        { provide: EnrollmentService, useValue: mockEnrollmentService },
        { provide: DataHelperFromOldAngular, useValue: mockDataHelperFromOldAngular },
        { provide: EnrollmentNavigationBuilderService, useValue: mockBuilderService },
        { provide: EnrollmentNavigationProgressService, useValue: mockProgressService },
        { provide: EnrollmentNavigationGuardService, useValue: mockGuardService },
        { provide: LifeEventNavigationStatusService, useValue: mockStatusService },
        { provide: BeneficiariesInsideLeService, useValue: mockBeneficiariesInsideLeService},
        { provide: ShoppingCartService, useValue: mockShoppingCartService },
      ],
    });

    navigationService = TestBed.inject(EnrollmentNavigationService);
  });

  describe('navMenu$', () => {
    it('should build navigation menu', async () => {
      //arrange
      const lifeEventID = LifeEventIdentifier.OPEN_ENROLMENT;
      const lifeEventDate = new Date().toString();

      const enrollmentMockData = new EnrollmentMockBuilderForMenu()
        .withPendingEmployee((f) => f.lifeEventID(lifeEventID).lifeEventDate(lifeEventDate))
        .build();
      mockEnrollmentService.enrollment$.next(enrollmentMockData);

      const menuMock = new EnrollmentMenuMockBuilder().build();
      mockBuilderService.buildNavigation.mockReturnValue(of(menuMock));
      navigationService.setCurrentRoute('');

      //act
      const navMenu = await navigationService.navMenu$.pipe(take(1)).toPromise();

      //assert
      expect(navMenu.NavMenuTabs[EnrollmentNavTabId.GetStarted]).toBeTruthy();
      expect(navMenu.NavMenuTabs[EnrollmentNavTabId.ChooseBenefits]).toBeTruthy();
      expect(navMenu.NavMenuTabs[EnrollmentNavTabId.ReviewAndSave]).toBeTruthy();
    });
  });

  describe('setCurrentRoute', () => {
    test.each([
      { requestedNavRoute: { Name: 'test.test', Params: { test: 'test', nullParam: null } }, validatedNavRoute: { Name: 'test.test', Params: { test: 'test' } } },
      { requestedNavRoute: { Name: 'test.test', Params: { nullParam: null } }, validatedNavRoute: { Name: 'test.test' } },
    ])('should initiate route only with valid parameters and drop invalid ones', async ({requestedNavRoute, validatedNavRoute}) => {
      //arrange
      const lifeEventID = LifeEventIdentifier.OPEN_ENROLMENT;
      const lifeEventDate = new Date().toString();

      const enrollmentMockData = new EnrollmentMockBuilderForMenu()
        .withPendingEmployee((f) => f.lifeEventID(lifeEventID).lifeEventDate(lifeEventDate))
        .build();
      mockEnrollmentService.enrollment$.next(enrollmentMockData);
      const enrollment: IEnrollment = await mockEnrollmentService.enrollment$.pipe(take(1)).toPromise();

      const menuMock = new EnrollmentMenuMockBuilder().build();
      mockBuilderService.buildNavigation.mockReturnValue(of(menuMock));

      //act
      navigationService.setCurrentRoute(requestedNavRoute.Name, requestedNavRoute.Params);
      const navMenu = await navigationService.navMenu$.pipe(take(1)).toPromise();

      //assert
      expect(mockProgressService.activateRoute$).toHaveBeenCalledWith(validatedNavRoute, menuMock, enrollment);
    });
  });

  describe('goTo', () => {
    test.each([
      { isNavItemEnabled: 'enabled', expected: 'navigate' },
      { isNavItemEnabled: 'disabled', expected: 'not navigate' },
    ])('should $expected to url when nav item is $isNavItemEnabled', ({ isNavItemEnabled, expected }) => {
      //arrange
      let navMenuItem: DeepPartial<INavMenuItem> = {
        NavRoute: { Name: 'test.test' },
        Status: isNavItemEnabled === 'enabled' ? NavStatus.Enabled : NavStatus.Disabled,
      };

      //act
      navigationService.goTo(navMenuItem as INavMenuItem);

      //assert
      const expectedCallTimes = expected === 'navigate' ? 1 : 0;
      expect(mockUIRouter.stateService.go).toHaveBeenCalledTimes(expectedCallTimes);
    });
  });

  describe('tryToResolveUrlForLifeEventResume', () => {
    test.each([
      {
        originalUrl: undefined,
        testState: null,
        expectedUrl: undefined
      },
      {
        originalUrl: '/account/profile',
        testState: null,
        expectedUrl: '/account/profile'
      },
      {
        originalUrl: '/life-event/reinitiate',
        testState: null,
        expectedUrl: '/life-event/reinitiate'
      },
      {
        originalUrl: '/life-event/review',
        testState: null,
        expectedUrl: '/life-event/review'
      },
      {
        originalUrl: '/life-event/review',
        testState: ['life-event.my-information', undefined],
        expectedUrl: '/life-event/my-information'
      },
      {
        originalUrl: '/life-event/review',
        testState: ['life-event.supplemental-benefits', {benefitId: 'hospital'}],
        expectedUrl: '/life-event/supplemental-benefits/hospital'
      },
    ])(
      'For originalUrl=\'$originalUrl\' and testState=$testState should return \'$expectedUrl\'',
      async ({originalUrl, testState, expectedUrl}) => {
        //arrange
        const lifeEventID = LifeEventIdentifier.OPEN_ENROLMENT;
        const lifeEventDate = new Date().toString();

        const enrollmentMockData = new EnrollmentMockBuilderForMenu()
          .withPendingEmployee((f) => f.lifeEventID(lifeEventID).lifeEventDate(lifeEventDate))
          .build();
        mockEnrollmentService.enrollment$.next(enrollmentMockData);

        const menuMock = new EnrollmentMenuMockBuilder().build();
        mockBuilderService.buildNavigation.mockReturnValue(of(menuMock));

        const visitedPages: ILifeEventNavigationStatus[] = EnrollmentNavTestHelper.convertToVisitedPages(menuMock, lifeEventID, lifeEventDate);
        mockStatusService.getAllVisitedPages.mockReturnValue(of(visitedPages).toPromise());

        mockProgressService.getLastVisitedStateForEnrollmentFlow.mockReturnValue(testState);

        //act
        const resultUrl = await navigationService.tryToResolveUrlForLifeEventResume(originalUrl);

        //assert
          expect(resultUrl).toEqual(expectedUrl);
      });
  });

  describe('tryToResolveStateForLifeEventResume', () => {
    test.each([
      {
        originalStateName: undefined,
        originalStateParams: undefined,
        testState: null,
        expectedState: [undefined, undefined]
      },
      {
        originalStateName: 'account.profile',
        originalStateParams: undefined,
        testState: null,
        expectedState: ['account.profile', undefined]
      },
      {
        originalStateName: 'life-event.reinitiate',
        originalStateParams: {lifeEventId: 55},
        testState: null,
        expectedState: ['life-event.reinitiate', {lifeEventId: 55}]
      },
      {
        originalStateName: 'life-event.review',
        originalStateParams: undefined,
        testState: null,
        expectedState: ['life-event.review', undefined]
      },
      {
        originalStateName: 'life-event.review',
        originalStateParams: undefined,
        testState: ['life-event.my-information', undefined],
        expectedState: ['life-event.my-information', undefined]
      },
      {
        originalStateName: 'life-event.review',
        originalStateParams: undefined,
        testState: ['life-event.supplemental-benefits', {benefitId: 'hospital'}],
        expectedState: ['life-event.supplemental-benefits', {benefitId: 'hospital'}]
      },
    ])(
      'For originalState=[$originalStateName, $originalStateParams] and testState=$testState should return $expectedState',
      async ({originalStateName, originalStateParams, testState, expectedState}) => {
        //arrange
        const lifeEventID = LifeEventIdentifier.OPEN_ENROLMENT;
        const lifeEventDate = new Date().toString();

        const enrollmentMockData = new EnrollmentMockBuilderForMenu()
          .withPendingEmployee((f) => f.lifeEventID(lifeEventID).lifeEventDate(lifeEventDate))
          .build();
        mockEnrollmentService.enrollment$.next(enrollmentMockData);

        const menuMock = new EnrollmentMenuMockBuilder().build();
        mockBuilderService.buildNavigation.mockReturnValue(of(menuMock));

        const visitedPages: ILifeEventNavigationStatus[] = EnrollmentNavTestHelper.convertToVisitedPages(menuMock, lifeEventID, lifeEventDate);
        mockStatusService.getAllVisitedPages.mockReturnValue(of(visitedPages).toPromise());

        mockProgressService.getLastVisitedStateForEnrollmentFlow.mockReturnValue(testState);

        //act
        const resultState = await navigationService.tryToResolveStateForLifeEventResume(originalStateName, originalStateParams);

        //assert
        const [resultStateName, resultStateParams] = resultState;
        const [expectedStateName, expectedStateParams] = expectedState;
        expect(resultStateName).toEqual(expectedStateName);
        expect(resultStateParams).toEqual(expectedStateParams);
      });
  });
});
