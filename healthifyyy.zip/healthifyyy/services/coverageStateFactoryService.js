'use strict';
angular.module('mercerApp').service('coverageStateFactoryService', [
    'participantEligibilityService', 'dependencyTracker', 'EnrollmentRules', 'mbcLog', 'dependentVerificationService', 'optionStatusService', 'coverageGridConfigService', 'deferredCoverageService', 'logService', 'benefitCategoryMappingService', 'crossBenefitDependentMatchingFactory', 'contentAliasService',
    function (participantEligibilityService, dependencyTracker, EnrollmentRules, mbcLog, dependentVerificationService, optionStatusService, coverageGridConfigService, deferredCoverageService, logService, benefitCategoryMappingService, crossBenefitDependentMatchingFactory, contentAliasService) {
        var logger = logService.getLogger('WhosCovered.CoverageState');
        var combineCategoriesRules = benefitCategoryMappingService.getCombineCategoriesRules();

        return {
            getCoverageByCategories: getCoverageByCategories,
            getCoverageByBenefits: getCoverageByBenefits
        };

        function getCoverageByCategories(coverageSource) {
            var coverageSourceByBenefit = getCoverageByBenefits(coverageSource);
            var coveragesByBenefits = getRawCoveragesByBenefits(coverageSourceByBenefit);

            var rawCoveragesByCategories = getRawCoveragesByCategories(coverageSourceByBenefit);
            var coveragesByCategories = combineCategories(coverageSourceByBenefit, rawCoveragesByCategories);

            var dataContent = contentAliasService.forData(coverageSource.employeeData);
            var shouldSupressIneligibleDependents = dataContent.getConfigurationValue('HB.LifeEvent.IneligibleDependents') !== 'Y';

            return {
                Participant: createParticipantCoverages(coverageSourceByBenefit, coveragesByBenefits, coveragesByCategories),
                Dependents: createDependentsCoverages(coverageSourceByBenefit, coveragesByBenefits, coveragesByCategories),
                Categories: coveragesByCategories,
                GetChangedElections: coverageSourceByBenefit.GetChangedElections,
                GetCurrentElections: coverageSourceByBenefit.GetCurrentElections,
                InitialElections: coverageSourceByBenefit.InitialElections,
                ByBenefits: coverageSourceByBenefit,
                employee: coverageSource.employee,
                employeeData: coverageSource.employeeData,
                isShoppingCart: coverageSource.editable
            };

            function combineCategories(coverageSourceByBenefit, categories) {
                var combined = _(combineCategoriesRules)
                    .mapValues(function (combinedCategories) {
                        return _(categories).pick(combinedCategories).value();
                    })
                    .pickBy(function (combinedCategories) {
                        return _(combinedCategories).keys().some();
                    })
                    .mapValues(function (categoriesToCombine, category) {
                        return combineCoveragesIntoCategory(coverageSourceByBenefit, categoriesToCombine, category);
                    })
                    .value();

                return _.defaults({}, combined, categories);
            }

            function combineCoveragesIntoCategory(coverageSourceByBenefit, categoriesToCombine, category, singleBenefitId) {
                var shouldWorkWithDeferredElection = coverageSource.editable && deferredCoverageService.shouldWorkWithDeferredElection(categoriesToCombine);

                var participantCoverage = combineCoverages(getParticipantCoverages(categoriesToCombine));
                if (typeof (singleBenefitId) !== 'undefined' && singleBenefitId !== null) { participantCoverage.BenefitId = singleBenefitId };

                var dependentsCoverages = _(coverageSourceByBenefit.Dependents)
                    .mapValues(function (dependent) {
                        var dependentCoverage = combineCoverages(getDependentCoverages(categoriesToCombine, dependent));
                        if (typeof (singleBenefitId) !== 'undefined' && singleBenefitId !== null) { dependentCoverage.BenefitId = singleBenefitId };
                        return dependentCoverage;
                    })
                    .value();

                var combinedCategory = combineCoverages(categoriesToCombine);
                if (typeof (singleBenefitId) !== 'undefined' && singleBenefitId !== null) { combinedCategory.BenefitId = singleBenefitId };

                return _.defaults({}, combinedCategory, {
                    Participant: participantCoverage,
                    Dependents: dependentsCoverages
                });

                function combineCoverages(coverages) {
                    var self = {
                        BenefitCategory: category,
                        Editable: dependencyTracker.computed(function () {
                            return _(coverages)
                                .some(function (coverage) {
                                    return coverage.Editable();
                                });
                        }),
                        Eligible: dependencyTracker.computed(function () {
                            return _(coverages)
                                .some(function (coverage) {
                                    return coverage.Eligible();
                                });
                        }),
                        Covered:
                            shouldWorkWithDeferredElection ?
                                function () {
                                    return _(coverages)
                                        .some(function (coverage) {
                                            return coverage.Covered();
                                        });
                                } :
                                dependencyTracker.computed(function () {
                                    return _(coverages)
                                        .some(function (coverage) {
                                            return coverage.Covered();
                                        });
                                }),
                        Displayed: function () {
                            if (shouldSupressIneligibleDependents) {
                                return self.Covered() || self.Editable();
                            }
                            return true;
                        },
                        SetCovered:
                            shouldWorkWithDeferredElection ?
                                function (newValue) {
                                    _(coverages)
                                        .forEach(function (coverage) {
                                            return coverage.SetCovered(newValue);
                                        });
                                } :

                                function (newValue) {

                                    logger.debug('combine Coverages');
                                    if (!canSetCoverage(self, newValue)) {
                                        return;
                                    }

                                    _(coverages)
                                        .forEach(function (coverage) {
                                            logger.debug('SetCovered - combineCoverages');
                                            return coverage.SetCovered(newValue);
                                        });
                                }
                    };

                    return self;
                }
            }

            function getRawCoveragesByBenefits(coverageSourceByBenefit) {
                var benefits = coverageSourceByBenefit.Benefits;

                return _(benefits)
                    .mapValues(function (benefit) {
                        return combineCoveragesIntoCategory(coverageSourceByBenefit, [benefit], benefit.BenefitCategory, benefit.BenefitId);
                    })
                    .value();
            }

            function getRawCoveragesByCategories(coverageSourceByBenefit) {
                var benefits = coverageSourceByBenefit.Benefits;

                return _(benefits)
                    .groupBy('BenefitCategory')
                    .mapValues(function (categoriesToCombine, category) {
                        return combineCoveragesIntoCategory(coverageSourceByBenefit, categoriesToCombine, category);
                    })
                    .value();
            }

            function createPersonCoverages(personBenefitCoverage, byBenefitCoverages, byCategoryCoverages) {
                return _.defaults({}, personBenefitCoverage, {
                    Benefits: byBenefitCoverages,
                    Categories: byCategoryCoverages
                });
            }

            function createParticipantCoverages(coverageSourceByBenefit, coveragesByBenefits, coveragesByCategories) {
                return createPersonCoverages(coverageSourceByBenefit.Participant,
                    getParticipantCoverages(coveragesByBenefits),
                    getParticipantCoverages(coveragesByCategories));
            }

            function createDependentCoverages(coveragesByBenefits, coveragesByCategories, dependentCoverageByBenefit) {
                return createPersonCoverages(dependentCoverageByBenefit,
                    getDependentCoverages(coveragesByBenefits, dependentCoverageByBenefit),
                    getDependentCoverages(coveragesByCategories, dependentCoverageByBenefit));
            }

            function createDependentsCoverages(coverageSourceByBenefit, coveragesByBenefits, coveragesByCategories) {
                return _(coverageSource.employee.Dependents)
                    .map(function (dependent) {
                        var dependentCoverageByBenefit = coverageSourceByBenefit.Dependents[dependent.Ssn];
                        return createDependentCoverages(coveragesByBenefits, coveragesByCategories, dependentCoverageByBenefit);
                    })
                    .value();
            }
        }

        function getCoverageByBenefits(coverageSource) {
            if (coverageSource.editable) {
                deferredCoverageService.setInitialElections(coverageSource.elections);
            }

            var employee = coverageSource.employee;
            var employeeData = coverageSource.employeeData;
            var benefitsById = employee.LifeEvents[0].EligibleBenefitsMap;

            var crossBenefitDependentMatchingService = crossBenefitDependentMatchingFactory.forEmployee(coverageSource.employeeData);
            var crossBenefitDependentMatchingConfig = crossBenefitDependentMatchingService.getMatchingConfiguration();

            var noCovPlans = _(benefitsById)
                .mapValues(function (benefit) {
                    return _.find(benefit.EligiblePlans, 'IsNoCovPlan');
                })
                .value();

            var electionListState = _(coverageSource.elections)
                .mapValues(function (election) {
                    return {
                        PlanID: dependencyTracker.value(election.PlanID),
                        OptionID: dependencyTracker.value(election.OptionID),
                        DependentAssociationList: dependencyTracker.value(election.DependentAssociationList)
                    };
                })
                .value();

            var getCurrentElections = dependencyTracker.computed(function () {
                return _(coverageSource.elections)
                    .mapValues(function (election, benefitId) {
                        var electionState = electionListState[benefitId];

                        return getElectionWithAppliedChange(election, {
                            PlanID: electionState.PlanID(),
                            OptionID: electionState.OptionID(),
                            DependentAssociationList: electionState.DependentAssociationList()
                        });
                    })
                    .value();
            });

            var getChangedElections = dependencyTracker.computed(function () {
                var currentElections = getCurrentElections();

                return _(currentElections)
                    .omitBy(function (changedElection, benefitId) {
                        var election = coverageSource.elections[benefitId];

                        return election.PlanID === changedElection.PlanID &&
                            election.OptionID === changedElection.OptionID &&
                            _.isEqual(
                                _.sortBy(election.DependentAssociationList),
                                _.sortBy(changedElection.DependentAssociationList));
                    })
                    .value();
            });

            if (coverageSource.editable) {
                validateElections(getCurrentElections());
            }

            return {
                Participant: createParticipant(),
                Dependents: createDependents(),
                Benefits: getCoveragesByBenefits(),
                GetChangedElections: getChangedElections,
                GetCurrentElections: getCurrentElections,
                InitialElections: coverageSource.elections,
                employee: coverageSource.employee,
                employeeData: coverageSource.employeeData
            };

            function getCoveragesByBenefits() {
                var participantEligibility = participantEligibilityService.forData(employeeData);

                return _(electionListState)
                    .mapValues(function (electionState, benefitId) {
                        var isChildBenefitInCrossBenefitMatching = crossBenefitDependentMatchingConfig.childBenefitId === benefitId && crossBenefitDependentMatchingConfig.benefitsShouldBeMatched;
                        var isParentBenefitInCrossBenefitMatching = crossBenefitDependentMatchingConfig.primaryBenefitId === benefitId && crossBenefitDependentMatchingConfig.benefitsShouldBeMatched;

                        var option = getOption(coverageSource.elections[benefitId]);
                        var availableToUpdate = optionStatusService.isAvailableForUpdate(option);
                        var isParticipantEditable = coverageSource.isParticipantEditable(benefitId);

                        var isDependentEditable = _(employee.Dependents)
                            .keyBy('Ssn')
                            .mapValues(function (dependent) {
                                return coverageSource.isDependentEditable(dependent, benefitId);
                            })
                            .value();

                        var isDependentEligible = _(employee.Dependents)
                            .keyBy('Ssn')
                            .mapValues(function (dependent) {
                                return coverageSource.isDependentEligible(dependent, benefitsById[benefitId]);
                            })
                            .value();

                        if (coverageSource.editable) {
                            deferredCoverageService.setCoverageEligibility(benefitId, isParticipantEditable, isDependentEditable);
                        }

                        var getCurrentElection = dependencyTracker.computed(function () {
                            var currentElections = getCurrentElections();

                            return currentElections[benefitId];
                        });

                        var noCovChange = dependencyTracker.computed(function () {
                            return getNoCovElectionChange(getCurrentElection());
                        });

                        var noCovChangeAsArray = dependencyTracker.computed(function () {
                            return hasNoCovPlan() ? [noCovChange()] : [];
                        });

                        var participantCoverage = createParticipantCoverage();

                        var dependentsCoverages = _(employee.Dependents)
                            .keyBy('Ssn')
                            .mapValues(createDependentCoverage)
                            .value();



                        var allPeople = _.values(dependentsCoverages).concat([participantCoverage]);

                        var selectAllEditable = dependencyTracker.computed(function () {
                            return _(allPeople)
                                .some(function (coverageInBenefit) {
                                    return coverageInBenefit.Editable();
                                });
                        });

                        var selectAllEligible = dependencyTracker.computed(function () {
                            return _(allPeople)
                                .some(function (coverageInBenefit) {
                                    return coverageInBenefit.Eligible();
                                });
                        });

                        var editablePeople = dependencyTracker.computed(function () {
                            return _(allPeople)
                                .filter(function (coverage) {
                                    return coverage.Editable();
                                })
                                .value();
                        });

                        var allEditableCoveredChanges = dependencyTracker.computed(function () {
                            return getElectionChangesThatChangePlan(function (election) {
                                return _.defaults({
                                    DependentAssociationList: _(dependentsCoverages)
                                        .pickBy(function (coverage) {
                                            return coverage.Editable() || coverage.Covered();
                                        })
                                        .keys()
                                        .value()
                                }, election);
                            });
                        });

                        var noEditableCoveredChanges = dependencyTracker.computed(function () {
                            return getElectionChangesThatChangePlan(function (election) {
                                return _.defaults({
                                    DependentAssociationList: _(dependentsCoverages)
                                        .pickBy(function (coverage) {
                                            return !coverage.Editable() && coverage.Covered();
                                        })
                                        .keys()
                                        .value()
                                }, election);
                            });
                        });

                        var noCovPlanIsElected = dependencyTracker.computed(function () {
                            return isNoCovPlan(benefitId, electionState.PlanID());
                        });

                        var selectAllCovered = dependencyTracker.computed(function () {
                            var applicablePeople = selectAllEditable() ? editablePeople() : allPeople;

                            return hasCoveredPeople(applicablePeople);
                        });

                        var validSelectAllToggleChanges = getValidElectionsAfterChangeToCoverage(function () {
                            if (selectAllCovered()) {
                                if (participantCoverage.Editable()) {
                                    return noCovChangeAsArray();
                                } else {
                                    return noEditableCoveredChanges();
                                }
                            } else {
                                return allEditableCoveredChanges();
                            }
                        });

                        var self = {
                            BenefitId: benefitId,
                            BenefitCategory: getBenefitCategory(benefitId),
                            Participant: participantCoverage,
                            Dependents: dependentsCoverages,
                            Editable: selectAllEditable,
                            Eligible: selectAllEligible,
                            Covered: selectAllCovered,
                            SetCovered:
                                coverageSource.editable && deferredCoverageService.shouldWorkWithDeferredElection(benefitId) ?
                                    function (newValue) {
                                        _(editablePeople()).forEach(function (p) {
                                            p.SetCovered(newValue);
                                        });
                                    } :
                                    function (newValue) {
                                        if (!canSetCoverage(self, newValue)) {
                                            return;
                                        }

                                        applyBestChange(validSelectAllToggleChanges, benefitId);

                                        if (!newValue && isParentBenefitInCrossBenefitMatching) {
                                            setDeferredCoverageForAllAvailablePersonsInChildBenefit(false, crossBenefitDependentMatchingConfig.childBenefitId);
                                        }
                                    }
                        };

                        return self;

                        function hasCoveredPeople(people) {
                            return _(people)
                                .some(function (coverage) {
                                    return coverage.Covered();
                                });
                        }

                        function createParticipantCoverage() {
                            var covChanges;

                            if (isChildBenefitInCrossBenefitMatching) {
                                var electionChange = function (election) {
                                    var mainElection = getCurrentElections()[crossBenefitDependentMatchingConfig.primaryBenefitId];
                                    return _.defaults({ DependentAssociationList: _.clone(mainElection.DependentAssociationList) }, election);
                                }

                                covChanges = dependencyTracker.computed(function () {
                                    return getElectionChangesThatChangePlan(electionChange);
                                });

                            } else {
                                covChanges = dependencyTracker.computed(getElectionChangesThatChangePlan);
                            }

                            var covChangesWithDeferredChanges = dependencyTracker.computed(
                                function () {
                                    var change = function (election) {

                                        if (deferredCoverageService.doesParticipantHaveSavedDeferredCoverage(election.BenefitID)) {
                                            var deferredCoverage = deferredCoverageService.getSavedDeferredCoverages()[election.BenefitID];
                                            var dependents = _(deferredCoverage.DependentAssociationList).keys().value();
                                            if (dependents.length) {
                                                return _.defaults({ DependentAssociationList: dependents }, election);
                                            }
                                        }

                                        if (isChildBenefitInCrossBenefitMatching) {
                                            var mainElection = getCurrentElections()[crossBenefitDependentMatchingConfig.primaryBenefitId];
                                            return _.defaults({ DependentAssociationList: _.clone(mainElection.DependentAssociationList) }, election);
                                        }

                                        return election;
                                    }
                                    return getElectionChangesThatChangePlan(change);
                                }
                            );

                            var validParticipantToggleChanges = getValidElectionsAfterChangeToCoverage(function () {
                                if (noCovPlanIsElected()) {
                                    return covChanges();
                                }

                                return noCovChangeAsArray();
                            });

                            var hasReadonlyCoveredDependent = dependencyTracker.computed(function () {
                                return _(dependentsCoverages)
                                    .some(function (dependentCoverage, ssn) {
                                        return !isDependentEditable[ssn] && dependentCoverage.Covered();
                                    });
                            });

                            var validCovChangesWithDeferredChanges = getValidElectionsAfterChangeToCoverage(covChangesWithDeferredChanges);
                            var validNoCovChanges = getValidElectionsAfterChangeToCoverage(noCovChangeAsArray);

                            var benefitCategory = getBenefitCategory(benefitId);

                            //participant coverage
                            var self = {
                                IsParticipant: true,
                                BenefitId: benefitId,
                                BenefitCategory: benefitCategory,
                                Editable: dependencyTracker.computed(function () {
                                    logger.debug('Editable participant coverage.');
                                    if (!availableToUpdate) {
                                        return false;
                                    }

                                    if (!isParticipantEditable) {
                                        return false;
                                    }

                                    if (isChildBenefitInCrossBenefitMatching && deferredCoverageService.shouldWorkWithDeferredElection(crossBenefitDependentMatchingConfig.primaryBenefitId)) {
                                        return deferredCoverageService.doesParticipantHaveDeferredCoverage(crossBenefitDependentMatchingConfig.primaryBenefitId);
                                    }

                                    if (hasReadonlyCoveredDependent()) {
                                        return _(validParticipantToggleChanges())
                                            .some(function (changes) {
                                                return !isNoCovPlan(benefitId, changes[benefitId].PlanID);
                                            });
                                    }

                                    return _(validParticipantToggleChanges()).some();
                                }),
                                Eligible: dependencyTracker.computed(function () {
                                    return true;
                                }),
                                Covered: getParticipantCoveredHandler(),
                                SetCovered: getParticipantSetCoveredHandler(),
                                SetCoveredInPlan: function (planId) {
                                    if (electionState.PlanID() === planId) {
                                        return;
                                    }

                                    var changes = isNoCovPlan(benefitId, planId) ? validNoCovChanges : changesThatSetBenefitIntoPlan(validCovChangesWithDeferredChanges, planId);

                                    applyBestChange(changes, benefitId);
                                }
                            };

                            return self;

                            function getParticipantCoveredHandler() {
                                return coverageSource.editable && deferredCoverageService.shouldWorkWithDeferredElection(benefitId) ?
                                    deferredBasedHandler : shoppingCartBasedHandler();


                                function deferredBasedHandler() {
                                    return isParticipantEditable && deferredCoverageService.doesParticipantHaveDeferredCoverage(benefitId);
                                }

                                function shoppingCartBasedHandler() {
                                    return dependencyTracker.computed(function () {
                                        return !noCovPlanIsElected() &&
                                            participantEligibility.isParticipantEligibleForOption(benefitsById[benefitId], electionState.OptionID());
                                    });
                                }
                            }

                            function getParticipantSetCoveredHandler() {
                                if (!coverageSource.editable || !deferredCoverageService.shouldWorkWithDeferredElection(benefitId)) {
                                    return shoppingCartBasedHandler;
                                }

                                if (isChildBenefitInCrossBenefitMatching) {
                                    return deferredBasedHandlerForChildBenefitInCrossBenefitMatching;
                                }

                                if (isParentBenefitInCrossBenefitMatching) {
                                    return deferredBasedHandlerForPrimaryBenefitInCrossBenefitMatching;
                                }

                                return deferredBasedHandler;

                                function deferredBasedHandlerForChildBenefitInCrossBenefitMatching(newValue) {
                                    if (!canSetCoverage(self, newValue)) {
                                        return;
                                    }
                                    setDeferredCoverageForAllAvailablePersonsInChildBenefit(newValue, benefitId);
                                }

                                function deferredBasedHandlerForPrimaryBenefitInCrossBenefitMatching(newValue) {
                                    if (!canSetCoverage(self, newValue)) {
                                        return;
                                    }

                                    if (!newValue) {
                                        setDeferredCoverageForAllAvailablePersonsInChildBenefit(false, crossBenefitDependentMatchingConfig.childBenefitId);
                                    }

                                    deferredCoverageService.setParticipantCoverage(newValue, benefitId);
                                }

                                function deferredBasedHandler(newValue) {
                                    if (!canSetCoverage(self, newValue)) {
                                        return;
                                    }

                                    deferredCoverageService.setParticipantCoverage(newValue, benefitId);
                                }

                                function shoppingCartBasedHandler(newValue) {
                                    logger.debug('SetCovered participant coverage.');
                                    if (!canSetCoverage(self, newValue)) {
                                        logger.debug('SetCovered participant !canSetCoverage.');
                                        return;
                                    }

                                    applyBestChange(validParticipantToggleChanges, benefitId);

                                    if (!newValue && isParentBenefitInCrossBenefitMatching) {
                                        setDeferredCoverageForAllAvailablePersonsInChildBenefit(false, crossBenefitDependentMatchingConfig.childBenefitId);
                                    }
                                }
                            }
                        }

                        function createDependentCoverage(dependent) {
                            var covered = getDependentCoveredHandler();

                            var validToggleChanges = getValidElectionsAfterChangeToCoverage(function () {
                                if (isChildBenefitInCrossBenefitMatching) {
                                    if (covered()) {
                                        return noCovChangeAsArray();
                                    }

                                    return getElectionChangesThatChangePlan(function (election) {
                                        var mainElection = getCurrentElections()[crossBenefitDependentMatchingConfig.primaryBenefitId];

                                        return _.defaults(
                                            { DependentAssociationList: coverDependent(mainElection.DependentAssociationList, dependent.Ssn) }
                                            , election);
                                    });

                                }

                                var e = getElectionChangesThatChangePlan(function (election) {
                                    return _.defaults({
                                        DependentAssociationList: toggleDependent(election.DependentAssociationList, dependent.Ssn)
                                    }, election);
                                });
                                return e;
                            });

                            var self = {
                                BenefitId: benefitId,
                                BenefitCategory: getBenefitCategory(benefitId),
                                Editable: dependencyTracker.computed(function () {
                                    if (!availableToUpdate) {
                                        return false;
                                    }

                                    if (!isDependentEditable[dependent.Ssn]) {
                                        return false;
                                    }

                                    if (isChildBenefitInCrossBenefitMatching && deferredCoverageService.shouldWorkWithDeferredElection(crossBenefitDependentMatchingConfig.primaryBenefitId)) {
                                        return deferredCoverageService.doesDependentHaveDeferredCoverage(crossBenefitDependentMatchingConfig.primaryBenefitId, dependent.Ssn);
                                    }

                                    var vtc = validToggleChanges();
                                    return _(vtc).some();
                                }),
                                Eligible: dependencyTracker.computed(function () {
                                    return isDependentEligible[dependent.Ssn];
                                }),
                                Covered: covered,
                                SetCovered: getDependentSetCoveredHandler()
                            };

                            return self;

                            function getDependentCoveredHandler() {
                                return coverageSource.editable && deferredCoverageService.shouldWorkWithDeferredElection(benefitId) ?
                                    deferredBasedHandler : getShoppingCartBasedHandler();

                                function deferredBasedHandler() {
                                    return deferredCoverageService.doesDependentHaveDeferredCoverage(benefitId, dependent.Ssn);
                                }

                                function getShoppingCartBasedHandler() {
                                    return dependencyTracker.computed(function () {
                                        return electionState.DependentAssociationList().indexOf(dependent.Ssn) >= 0;
                                    });
                                }
                            }

                            function getDependentSetCoveredHandler() {
                                if (!coverageSource.editable || !deferredCoverageService.shouldWorkWithDeferredElection(benefitId)) {
                                    return shoppingCartBasedHandler;
                                }

                                if (isChildBenefitInCrossBenefitMatching) {
                                    return deferredBasedHandlerForChildBenefitInCrossBenefitMatching;
                                }

                                if (isParentBenefitInCrossBenefitMatching) {
                                    return deferredBasedHandlerForPrimaryBenefitInCrossBenefitMatching;
                                }

                                return deferredBasedHandler;

                                function deferredBasedHandlerForChildBenefitInCrossBenefitMatching(newValue) {
                                    if (!isDependentEditable[dependent.Ssn]) {
                                        return;
                                    }

                                    setDeferredCoverageForAllAvailablePersonsInChildBenefit(newValue);
                                }
                                function deferredBasedHandlerForPrimaryBenefitInCrossBenefitMatching(newValue) {
                                    if (!isDependentEditable[dependent.Ssn]) {
                                        return;
                                    }

                                    deferredCoverageService.setDependentCoverage(newValue, benefitId, dependent.Ssn);

                                    if (!newValue) {
                                        deferredCoverageService.setDependentCoverage(false, crossBenefitDependentMatchingConfig.childBenefitId, dependent.Ssn);
                                    }
                                    else {
                                        setDeferredCoverageForAllAvailablePersonsInChildBenefitIfItIsCovered();
                                    }

                                }

                                function deferredBasedHandler(newValue) {
                                    if (!isDependentEditable[dependent.Ssn]) {
                                        return;
                                    }

                                    deferredCoverageService.setDependentCoverage(newValue, benefitId, dependent.Ssn);
                                }

                                function shoppingCartBasedHandler(newValue) {
                                    logger.debug('SetCovered dependent coverage. Original');
                                    if (!canSetCoverage(self, newValue)) {
                                        return;
                                    }

                                    applyBestChange(validToggleChanges, benefitId);

                                    if (isParentBenefitInCrossBenefitMatching) {
                                        if (!newValue) {
                                            deferredCoverageService.setDependentCoverage(false, crossBenefitDependentMatchingConfig.childBenefitId, dependent.Ssn);
                                        }
                                        else {
                                            setDeferredCoverageForAllAvailablePersonsInChildBenefitIfItIsCovered();
                                        }
                                    }
                                }
                            }

                            function toggleDependent(ssnList, ssn) {
                                return covered() ? _.without(ssnList, ssn) : _.union(ssnList, [ssn]);
                            }

                            function coverDependent(ssnList, ssn) {
                                return covered() ? _.clone(ssnList) : _.union(ssnList, [ssn]);
                            }
                        }

                        function changesThatSetBenefitIntoPlan(validChanges, planId) {
                            return dependencyTracker.computed(function () {
                                return _(validChanges())
                                    .filter(function (elections) {
                                        return elections[benefitId].PlanID === planId;
                                    })
                                    .value();
                            });
                        }

                        function hasNoCovPlan() {
                            var noCovPlan = noCovPlans[benefitId];

                            return !!noCovPlan;
                        }

                        function getElectionChangesThatChangePlan(change) {

                            var clonedElection = _.clone(getCurrentElection());
                            var changedElection = change ? change(clonedElection) : clonedElection;

                            var newElections = _(getBenefit(getCurrentElection()).EligiblePlans)
                                .reject('IsNoCovPlan')
                                .map(function (plan) {
                                    var newElection = _.defaults({
                                        PlanID: plan.PlanID
                                    }, changedElection);

                                    var allElections = {};
                                    allElections[benefitId] = newElection;
                                    _.defaults(allElections, getCurrentElections());

                                    return _.defaults({
                                        OptionID: EnrollmentRules.deriveOption(allElections, benefitId, employeeData)
                                    }, newElection);
                                })
                                .value();

                            var noCovPlan = noCovPlans[benefitId];

                            if (noCovPlan) {
                                var noCovOptionId = noCovPlan.EligibleOptions[0].OptionID;

                                var newElectionsWithoutNoCov = _(newElections)
                                    .reject({
                                        OptionID: noCovOptionId
                                    })
                                    .value();

                                var hasDerivedNoCovOption = newElectionsWithoutNoCov.length < newElections.length;

                                if (hasDerivedNoCovOption) {
                                    var noDependentsAreCovered = changedElection.DependentAssociationList.length === 0;

                                    if (noDependentsAreCovered) {
                                        return _(newElectionsWithoutNoCov)
                                            .union([getNoCovElectionChange(getCurrentElection())])
                                            .value();
                                    }
                                }

                                return newElectionsWithoutNoCov;
                            }

                            return newElections;
                        }

                        function setDeferredCoverageForAllAvailablePersonsInChildBenefit(newValue) {
                            var primaryBenefitDependents = shouldPrimaryBenefitWorkWithDeferredCoverages() ?
                                deferredCoverageService.getTempDeferredCoverages()[crossBenefitDependentMatchingConfig.primaryBenefitId].DependentAssociationList :
                                getCurrentElections()[crossBenefitDependentMatchingConfig.primaryBenefitId].DependentAssociationList;


                            deferredCoverageService.setParticipantCoverage(newValue, crossBenefitDependentMatchingConfig.childBenefitId);

                            if (newValue) {
                                _(primaryBenefitDependents).forEach(function (dSsn) {
                                    deferredCoverageService.setDependentCoverage(newValue, crossBenefitDependentMatchingConfig.childBenefitId, dSsn);
                                });
                            }
                        }

                        function setDeferredCoverageForAllAvailablePersonsInChildBenefitIfItIsCovered() {
                            if (deferredCoverageService.doesParticipantHaveDeferredCoverage(crossBenefitDependentMatchingConfig.childBenefitId)) {
                                setDeferredCoverageForAllAvailablePersonsInChildBenefit(true);
                            }
                        }

                        function shouldPrimaryBenefitWorkWithDeferredCoverages() {
                            return deferredCoverageService.shouldWorkWithDeferredElection(crossBenefitDependentMatchingConfig.primaryBenefitId);
                        }
                    })
                    .value();
            }

            function isNoCovPlan(benefitId, planId) {
                var noCovPlan = noCovPlans[benefitId];

                return noCovPlan && noCovPlan.PlanID === planId;
            }

            function getElectionWithAppliedChange(baseElection, changes) {
                var costFieldNames = [
                    'Amount',
                    'AmountInforce',
                    'AmountPended',
                    'AdministrativeCostAnnual',
                    'AdministrativeCostMonthly',
                    'EmployeeAnnualCost',
                    'EmployeePayPeriodCost',
                    'EmployerAnnualCost',
                    'EmployerPayPeriodCost',
                    'PendedEmployeeAnnualCost',
                    'PendedEmployeePayPeriodCost',
                    'PremiumAnnual',
                    'PremiumMonthly'
                ];

                var newElection = _.defaults({}, changes, baseElection);
                var costFields = _(getOption(newElection)).pick(costFieldNames).value();

                return _.defaults({}, costFields, newElection);
            }

            function getBenefit(election) {
                return benefitsById[election.BenefitID];
            }

            function getBenefitCategory(benefitId) {
                return benefitsById[benefitId].BenefitCategory;
            }

            function getPlan(election) {
                return getBenefit(election).EligiblePlansMap[election.PlanID];
            }

            function getOption(election) {
                return getPlan(election).EligibleOptionsMap[election.OptionID];
            }

            function hasPlanAndOptionOnFile(election) {
                return getPlan(election) && getOption(election);
            }

            function getElectionsAugmentedByAutoelections(changedElection) {
                var currentElections = getCurrentElections();

                var customAutoElections = EnrollmentRules.customAutoElections(changedElection, currentElections, employee, employeeData);
                var option = getOption(changedElection);

                var changedElections = _(option.AutoElections)
                    .union(customAutoElections)
                    .filter(getElection)
                    .map(function (autoElection) {
                        var newElection = _.clone(getElection(autoElection));

                        newElection.PlanID = autoElection.AutoPlanID;
                        newElection.OptionID = autoElection.AutoOptionID;
                        var noCovPlanIsAutoelected = isNoCovPlan(newElection.BenefitID, autoElection.AutoPlanID);

                        if (noCovPlanIsAutoelected) {
                            newElection.DependentAssociationList = [];
                        } else if (autoElection.IncludeDepsInd === 'Y') {
                            newElection.DependentAssociationList = changedElection.DependentAssociationList;
                        }

                        return newElection;
                    })
                    .filter(hasPlanAndOptionOnFile)
                    .keyBy('BenefitID')
                    .value();

                var result = {};
                result[changedElection.BenefitID] = changedElection;

                _.defaults(result, changedElections, currentElections);

                return result;

                function getElection(autoElection) {
                    return currentElections[autoElection.AutoBenefitID];
                }
            }

            function getElectionsWithNoPlanOrOption(elections) {
                return _(elections)
                    .omitBy(hasPlanAndOptionOnFile)
                    .value();
            }

            function getElectionsWithRestrictedByCrossDependents(elections) {
                if (!crossBenefitDependentMatchingConfig.benefitsShouldBeMatched) {
                    return {};
                }

                var isRestricted = calcIsRestrictedByShoppingCart();

                var result = {};
                if (isRestricted) {
                    result[crossBenefitDependentMatchingConfig.childBenefitId] = elections[crossBenefitDependentMatchingConfig.childBenefitId];
                }

                function calcIsRestrictedByShoppingCart() {
                    var primaryElection = elections[crossBenefitDependentMatchingConfig.primaryBenefitId];
                    var childElection = elections[crossBenefitDependentMatchingConfig.childBenefitId];

                    if (!primaryElection || !childElection) {
                        return false;
                    }

                    return (isNoCovPlan(primaryElection.BenefitID, primaryElection.PlanID) && !isNoCovPlan(childElection.BenefitID, childElection.PlanID)) ||

                        _(childElection.DependentAssociationList)
                            .difference(primaryElection.DependentAssociationList)
                            .some();
                }

                return result;
            }

            function getElectionsWithDisabledElectedPlan(elections) {
                var crossBenefitIsPlanDisabled = EnrollmentRules.crossBenefitPlanDisable(elections, employee, employeeData);

                return _(elections)
                    .pickBy(function (election) {
                        return crossBenefitIsPlanDisabled(getBenefit(election), getPlan(election));
                    })
                    .value();
            }

            function getElectionsThatBecameWorse(elections, validation) {
                var currentElections = getCurrentElections();
                var currentBadElections = validation(currentElections);
                var newBadElections = validation(elections);

                return _(currentElections)
                    .pickBy(function (election, benefitId) {
                        return !currentBadElections[benefitId] &&
                            newBadElections[benefitId];
                    })
                    .value();
            }

            function areElectionsInvalid(elections) {

                return _.some(getElectionsThatBecameWorse(elections, getElectionsWithNoPlanOrOption)) ||
                    _.some(getElectionsThatBecameWorse(elections, getElectionsWithDisabledElectedPlan)) ||
                    _.some(getElectionsThatBecameWorse(elections, getElectionsWithRestrictedByCrossDependents));
            }

            function getNoCovElectionChange(currentElection) {
                var benefitId = currentElection.BenefitID;
                var noCovPlan = noCovPlans[benefitId];

                return getElectionWithAppliedChange(currentElection, {
                    PlanID: noCovPlan.PlanID,
                    OptionID: noCovPlan.EligibleOptions[0].OptionID,
                    DependentAssociationList: []
                });
            }

            function applyBestChange(validChanges, benefitId) {
                var validChangesByPriority = _(validChanges())
                    .sortBy(displayOrderOfChangedPlan(benefitId))
                    .sortBy(bestMatchOrder())
                    .sortBy(descendingNumberOfCoveragePlansMatchingInitialElections)
                    .sortBy(orderWhereBenefitWithNoChangeToPlanComesFirst(benefitId))
                    .value();

                var bestChange = _(validChangesByPriority).head();

                _(bestChange)
                    .forEach(function (changedElection, benefitId) {
                        var electionState = electionListState[benefitId];

                        electionState.PlanID.write(changedElection.PlanID);
                        electionState.OptionID.write(changedElection.OptionID);
                        electionState.DependentAssociationList.write(changedElection.DependentAssociationList);
                    });
            }

            function getValidElectionsAfterChangeToCoverage(availableBenefitCoverageChanges) {
                return dependencyTracker.computed(function () {
                    return _(availableBenefitCoverageChanges())
                        .filter(hasPlanAndOptionOnFile)
                        .map(getElectionsAugmentedByAutoelections)
                        .reject(areElectionsInvalid)
                        .value();
                });
            }

            function createDependents() {
                return _(employee.Dependents)
                    .keyBy('Ssn')
                    .mapValues(createDependent)
                    .value();
            }

            function createParticipant() {
                return createPerson('employee', employee);
            }

            function createDependent(dependent) {
                return createPerson('dependent', dependent);
            }

            function createPerson(type, source) {
                return {
                    Type: type,
                    Source: source,
                    IsPending: isPending(type, source),
                    empData: employee,
                    isVerificationDocumentsToggle: isVerificationDocumentsToggle(),
                    currentCoverage: employeeData.Data.CurrentCoveragesEmployee,
                    futureCoverage: employeeData.Data.FutureCoverages[0],
                };
            }

            function isPending(type, dependent) {
                if (type === 'employee') {
                    return false;
                }

                return dependentVerificationService.forData(employeeData).isDependentPending(dependent);
            }

            function isVerificationDocumentsToggle() {
                return dependentVerificationService.forData(employeeData).getVerificationDocumentsToggle();
            }

            function electionsToString(elections) {
                var tuples = _(elections)
                    .map(function (election) {
                        return '(' + election.BenefitID + ';' + election.PlanID + ';' + election.OptionID + ')';
                    })
                    .value()
                    .join(', ');

                return '[' + tuples + ']';
            }

            function validateElections(elections) {
                try {
                    var electionsWithNoPlanOrOption = getElectionsWithNoPlanOrOption(elections);

                    if (_.some(electionsWithNoPlanOrOption)) {
                        mbcLog.logError('HB: the following elections are not valid because either plan or option does not exist in the benefit: ' + electionsToString(electionsWithNoPlanOrOption));
                    }

                    var electionsWithDisabledElectedPlan = getElectionsWithDisabledElectedPlan(elections);

                    if (_.some(electionsWithDisabledElectedPlan)) {
                        mbcLog.logError('HB: the following elections are not valid because the elected plan is disabled (revise HB.LifeEvent.CrossBenefit.SuppressPlans and HB.LifeEvent.CrossBenefit.RestrictToPlans javascript rules): ' + electionsToString(electionsWithDisabledElectedPlan));
                    }
                }
                catch (e) {
                    mbcLog.logError('HB: failed to validate elections. Error: ' + e);
                }
            }

            function bestMatchOrder() {
                var shouldDefaultToBestMatchPlan = coverageGridConfigService.forData(coverageSource.employeeData).shouldDefaultToBestMatchPlan;

                return shouldDefaultToBestMatchPlan
                    ? descendingNumberOfBestMatchPlans
                    : anyOrder;
            }

            function displayOrderOfChangedPlan(benefitId) {
                return function (elections) {
                    var changedElection = elections[benefitId];
                    var plan = getPlan(changedElection);

                    return plan.DisplayOrder;
                };
            }

            function anyOrder() {
                return 0;
            }

            function descendingNumberOfBestMatchPlans(elections) {
                var numberOfBestMatchPlans = _(elections)
                    .filter(function (election, benefitId) {
                        return getBestMatchPlanIds(benefitId).indexOf(election.PlanID) > -1;
                    })
                    .size();

                // sort descending:
                return -numberOfBestMatchPlans;
            }

            function getBestMatchPlanIds(benefitId) {
                var benefitCategory = getBenefitCategory(benefitId);

                return coverageSource.bestMatch[benefitCategory] || [];
            }

            function descendingNumberOfCoveragePlansMatchingInitialElections(elections) {
                var numberOfPlansMatchingInitialElections = _(elections)
                    .filter(function (election, benefitId) {
                        var planId = coverageSource.elections[benefitId].PlanID;

                        return !isNoCovPlan(benefitId, planId) && election.PlanID === planId;
                    })
                    .size();

                // sort descending:
                return -numberOfPlansMatchingInitialElections;
            }

            function orderWhereBenefitWithNoChangeToPlanComesFirst(benefitId) {
                return function (elections) {
                    return elections[benefitId].PlanID === coverageSource.elections[benefitId].PlanID ? 0 : 1;
                };
            }
        }

        function canSetCoverage(coverage, newValue) {
            return coverage.Editable() && coverage.Covered() !== newValue;
        }

        function getParticipantCoverages(coverages) {
            return _(coverages)
                .mapValues('Participant')
                .value();
        }

        function getDependentCoverages(coverages, dependent) {
            return _(coverages)
                .mapValues('Dependents')
                .mapValues(dependent.Source.Ssn)
                .value();
        }
    }
]);