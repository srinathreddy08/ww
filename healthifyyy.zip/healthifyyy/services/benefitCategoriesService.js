﻿'use strict';
angular.module('mercer.services').factory('benefitCategoriesService', [
    'benefitsService', 'benefitCategoryMap',
    function (benefitsService, benefitCategoryMap) {

        return {
            LifeInsurance: getCategoryByName('LIFE INSURANCE'),
            IsLifeInsuranceCategory: isLifeInsuranceCategory,
            GetCategoryByName: getCategoryByName,
            GetDefaultCategory: getDefaultCategory,
            IsAmountBased: isAmountBased,
            IsAccountBased: isAccountBased,
            getBenefitIds: getBenefitIds
        };

        function isLifeInsuranceCategory(categoryName){
            var categoryData = benefitCategoryMap[categoryName];
            if (!categoryData) {
                return false;
            }
            return !!categoryData.isLifeInsuranceCategory;
        }

        function getDefaultCategory() {
            return benefitCategoryMap['default'];
        }

        function getCategoryByName(categoryName) {
            return benefitCategoryMap[categoryName] || getDefaultCategory();
        }

        function isAmountBased(benefit) {
            return isLifeInsuranceCategory(benefit.BenefitCategory) && benefitsService.isAmountBasedBenefit(benefit);
        }

        function isAccountBased(benefit) {
            return isAmountBased(benefit) || benefit.BenefitCategory === 'SPENDING';
        }

        function getBenefitIds(employee, categories) {
            var lifeEvent = employee.LifeEvents[0];
            return _(lifeEvent.EligibleBenefitsMap)
                .pickBy(function (benefit) {
                    return categories.indexOf(benefit.BenefitCategory) >= 0;
                })
                .keys()
                .value();
        }
    }
]);