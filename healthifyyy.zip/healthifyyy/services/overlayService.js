﻿'use strict';
angular.module('mercer.db.shared').factory('overlayService', [
    'eventService', '$q', 'spinnerService', '$templateRequest', 'executeAsync', 'pubsub',
    function (eventService, $q, spinnerService, $templateRequest, executeAsync, pubsub) {
        var overlay = null;
        var overlayClosedDeferred = null;

        return {
            open: open,
            close: close,
            closeRejected: closeRejected,
            getContext: getContext,
            isOverlayOpened: isOverlayOpened
        };

        function open(viewUrl, overlayViewModel, options) {
            var spinnerAction;
            overlayClosedDeferred = $q.defer();

            return $templateRequest(viewUrl)
                .then(function () {
                    var isAllowedPromise = options && options.isAllowedToShowAfterTemplateIsLoaded
                        ? executeAsync(options.isAllowedToShowAfterTemplateIsLoaded)
                        : $q.resolve(true);

                    return isAllowedPromise
                        .then(function (allowedToShow) {
                            if (allowedToShow) {
                                overlay = {
                                    viewUrl: viewUrl,
                                    model: overlayViewModel,
                                    onLoad: onLoad
                                };

                                eventService.publish('overlayService.contextUpdated');
                            }
                            else {
                                closeRejected();
                            }

                            return overlayClosedDeferred.promise;
                        });
                })
            ['finally'](onClosed);

            function onLoad() {
                spinnerAction = spinnerService.pauseDisplayingSpinner();
                $('body').addClass('is-popup-open');
            }

            function onClosed() {
                $('body').removeClass('is-popup-open');
                spinnerAction.complete();
            }
        }

        function close(result) {
            if (overlayClosedDeferred) {
                overlayClosedDeferred.resolve(result);
                closeOverlay();
            }
        }

        function closeRejected(reason) {
            if (overlayClosedDeferred) {
                overlayClosedDeferred.reject(reason);
                closeOverlay();
            }
        }

        function closeOverlay() {
            overlay = null;
            overlayClosedDeferred = null;
            eventService.publish('overlayService.contextUpdated');
            pubsub.publish('onOverlayClose');
        }

        function getContext() {
            return overlay;
        }

        function isOverlayOpened() {
            return !!overlay;
        }
    }
]);