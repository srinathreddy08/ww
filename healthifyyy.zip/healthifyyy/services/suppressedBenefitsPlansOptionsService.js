angular.module('mercer.db.shared').service('suppressedBenefitsPlansOptionsService',
    function () {
        return {
            filterByBenefits: filterByBenefits
        };

        function getSuppressedBenefits(enrollmentContent) {
            var suppressedBPO = enrollmentContent.getConfigurationValue('HB.Common.SuppressBPOfromUI');
            return _.map(suppressedBPO, function (bpo) { return bpo.BENEFITID; });
        }

        function filterByBenefits(benefit, enrollmentContent) {
            var suppressedBenefitsPlansOptions = getSuppressedBenefits(enrollmentContent);
            return !_.some(suppressedBenefitsPlansOptions, function (suppressedBenefit) {
                return suppressedBenefit === benefit.BenefitID;
            });
        }
    }
);
