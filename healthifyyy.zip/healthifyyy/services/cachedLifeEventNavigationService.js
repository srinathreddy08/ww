﻿'use strict';
angular.module('mercer.db.shared').service('cachedLifeEventNavigationService',
    ['employeeLifeEventActionService', '$cacheFactory', '$http', '$transitions', '$q',
        function (employeeLifeEventActionService, $cacheFactory, $http, $transitions, $q) {
        var useCacheForNextNavLifeEventRequest = false;
        var navLifeEventCache = $cacheFactory('navLifeEventCache');
        $transitions.onStart({}, clearLifeEventNavigationCache);
        var lifeEventNavigationCache;

        return {
            getLifeEventNavigation: getLifeEventNavigation
        };

        function getLifeEventNavigation(useCacheForNextRequest) {
            var promise;
            
            if (useCacheForNextRequest && lifeEventNavigationCache) {
                promise = lifeEventNavigationCache;
            } else {
                promise = $http.get('/api/content/nav-lifeevent', {
                    params: {},
                    cache: navLifeEventCache
                });
                lifeEventNavigationCache = promise;
            }

            if (!useCacheForNextNavLifeEventRequest) {
                navLifeEventCache.removeAll();
            }

            return $q.all({
                navLifeEvent: promise,
                reinitializationModel: employeeLifeEventActionService.getReinitializationModel()
            }).then(function (response) {
                var navLifeEvent = response.navLifeEvent;
                useCacheForNextNavLifeEventRequest = useCacheForNextRequest;
                if (response.reinitializationModel.isReinitialized()) {
                    navLifeEvent.data.NavigationStatus = _.mapValues(navLifeEvent.data.NavigationStatus,
                        function(value, tab) {
                            value.IsEnabled = true;
                            if (tab !== 'cart') {
                                value.SubNav = _.mapValues(value.SubNav,
                                    function(subNavItem) {
                                        subNavItem.IsEnabled = true;
                                        return subNavItem;
                                    });
                            } else {
                                var reviewState = value.SubNav.review;
                                if (reviewState) {
                                    reviewState.IsEnabled = true;
                                }
                            }

                            return value;
                        });
                }
                return navLifeEvent.data;
            });
        }

        function clearLifeEventNavigationCache() {
            lifeEventNavigationCache = null;
        }
    }]);