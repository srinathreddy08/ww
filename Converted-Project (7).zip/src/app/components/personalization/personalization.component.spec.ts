import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PersonalizationComponent } from './personalization.component';
import { PersonalizationService } from '../../services/personalization.service';
import { of } from 'rxjs';

class MockPersonalizationService {
  transformDataToSave(data: any) { return data; }
  save(data: any) { return of({}); }
}

describe('PersonalizationComponent', () => {
  let component: PersonalizationComponent;
  let fixture: ComponentFixture<PersonalizationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalizationComponent ],
      providers: [ { provide: PersonalizationService, useClass: MockPersonalizationService } ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
