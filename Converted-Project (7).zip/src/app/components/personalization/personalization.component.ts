import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PersonalizationService } from '../../services/personalization.service';
import { cloneDeep, some, find, remove } from 'lodash';

@Component({
  selector: 'app-personalization',
  templateUrl: './personalization.component.html',
  styleUrls: ['./personalization.component.css']
})
export class PersonalizationComponent implements OnInit {
  @Input() personalization: any;
  @Input() saveFunctionContainer: any;
  @Output() personalizationEditModeChanged = new EventEmitter<boolean>();

  savedData: any;

  constructor(private personalizationService: PersonalizationService) {}

  ngOnInit(): void {
    this.savedData = cloneDeep(this.personalization.Data);
    if (this.saveFunctionContainer) {
      this.saveFunctionContainer.do = this.saveAll.bind(this);
    }
  }

  getPersonalizationData() {
    return this.personalization.Data.forEach((section: any) => {
      remove(section.Personalizations, (personalization: any) => personalization.ContentAlias === null);
    });
  }

  isSelectionChanged() {
    return some(this.personalization.Data, (section: any) => {
      const savedSection = find(this.savedData, { ContentAlias: section.ContentAlias });
      return some(section.Personalizations, (item: any) => {
        const savedItem = find(savedSection.Personalizations, { ContentAlias: item.ContentAlias });
        return savedItem && savedItem.Value !== item.Value;
      });
    });
  }

  saveAll() {
    const saveData = this.personalizationService.transformDataToSave(this.personalization.Data);
    return this.personalizationService.save(saveData).toPromise().then(() => {
      this.savedData = cloneDeep(this.personalization.Data);
    });
  }

  onSelectionChanged(newEditMode: boolean) {
    this.personalizationEditModeChanged.emit(newEditMode);
  }
}
