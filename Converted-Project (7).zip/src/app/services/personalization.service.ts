import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { MbcContentAndDataService } from './mbc-content-and-data.service';

@Injectable({
  providedIn: 'root'
})
export class PersonalizationService {
  private apiUrl = '/api/profile';

  constructor(private http: HttpClient, private mbcContentAndData: MbcContentAndDataService) {}

  get(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getPersonalization`);
  }

  save(code: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/savePersonalization`, code).pipe(
      map(response => {
        this.mbcContentAndData.refresh(false);
        return response;
      })
    );
  }

  getJustForYou(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getJustForYou`);
  }

  transformDataToSave(data: any): any {
    return data
      .map((item: any) => item.Personalizations)
      .flat()
      .reduce((set: any, personalization: any) => {
        const code = personalization.Code;
        if (code) {
          set[code] = personalization.Value;
        }
        return set;
      }, {});
  }
}
