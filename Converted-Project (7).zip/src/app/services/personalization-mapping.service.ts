import { Injectable } from '@angular/core';
import { PersonalizationService } from './personalization.service';
import { PERSONALIZATION_MAPPING_FOR_LIFE_CHANGES_QUESTION, LIFE_CHANGES_QUESTION_ID, LIFE_CHANGES_NONE_SELECTED_ANSWER_ID } from '../constants/personalization-mapping.constants';
import { cloneDeep, compact, uniq, forEach, find, includes } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class PersonalizationMappingService {
  constructor(private personalizationService: PersonalizationService) {}

  savePersonalizationData(lifeStyleAnswers: any, questions: any): void {
    this.personalizationService.get().subscribe(personalization => {
      const personalizationData = this.personalizationService.transformDataToSave(personalization.Data);
      const mappedPersonalization = this.getMappedPersonalizationData(personalizationData, lifeStyleAnswers, questions);
      this.personalizationService.save(mappedPersonalization).subscribe();
    });
  }

  private getMappedPersonalizationData(personalization: any, lifeStyleAnswers: any, questions: any): any {
    const answerIds = this.getAnswerOptionIds(questions);
    const chosenAnswers = lifeStyleAnswers.SecondText.split(',');
    return this.getMappedPersonalizationBasedOnLifeStyleAnswers(personalization, answerIds, chosenAnswers);
  }

  private getMappedPersonalizationBasedOnLifeStyleAnswers(personalization: any, answerIds: string[], chosenAnswers: string[]): any {
    const isNoneOptionSelected = includes(chosenAnswers, LIFE_CHANGES_NONE_SELECTED_ANSWER_ID);

    forEach(compact(uniq(answerIds)), id => {
      const keys = this.getMappedKeyForAnswerId(id);
      forEach(keys, key => {
        personalization[key] = this.isAnswerSelected(key, chosenAnswers, isNoneOptionSelected);
      });
    });

    return personalization;
  }

  private isAnswerSelected(key: string, chosenAnswers: string[], isNoneOptionSelected: boolean): boolean {
    if (isNoneOptionSelected) {
      return false;
    }

    const mappedAnswersByKey = PERSONALIZATION_MAPPING_FOR_LIFE_CHANGES_QUESTION[key];
    return chosenAnswers.some(item => includes(mappedAnswersByKey, item));
  }

  private getAnswerOptionIds(questions: any): string[] {
    const lifeStyleQuestion = find(questions, question => question.config.answerType === LIFE_CHANGES_QUESTION_ID);
    const optionIds: string[] = [];
    forEach(lifeStyleQuestion.normalAnswers, option => {
      optionIds.push(option.id);
    });
    return optionIds;
  }

  private getMappedKeyForAnswerId(id: string): string[] {
    return Object.keys(PERSONALIZATION_MAPPING_FOR_LIFE_CHANGES_QUESTION).filter(key => includes(PERSONALIZATION_MAPPING_FOR_LIFE_CHANGES_QUESTION[key], id));
  }

  getLifeStyleQuestionOptions(questions: any): any {
    return find(questions, { Type: LIFE_CHANGES_QUESTION_ID });
  }
}
