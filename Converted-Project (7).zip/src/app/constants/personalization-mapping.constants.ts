export const PERSONALIZATION_MAPPING_FOR_LIFE_CHANGES_QUESTION = {
    CHILDREN: ['14'],
    BUYHOME: ['16'],
    SAVINGS: ['9', '10'],
    FINANCIAL: ['13'],
    HOMEINS: ['4'],
    IDTHEFT: ['12'],
    RENTERINS: ['4'],
    AUTOINS: ['4'],
    VETCARE: ['1']
};

export const LIFE_CHANGES_QUESTION_ID = 'EG_LIFE_CHANGES';

export const LIFE_CHANGES_NONE_SELECTED_ANSWER_ID = '0';
