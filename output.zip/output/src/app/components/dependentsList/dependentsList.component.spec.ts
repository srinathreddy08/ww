import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DependentListComponent } from './dependent-list.component';

describe('DependentListComponent', () => {
  let component: DependentListComponent;
  let fixture: ComponentFixture<DependentListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DependentListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DependentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the correct number of dependents', () => {
    component.dependents = [
      { FirstName: 'John', LastName: 'Doe', BirthDate: new Date('1990-01-01') },
      { FirstName: 'Jane', LastName: 'Doe', BirthDate: new Date('1992-02-02') }
    ];
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelectorAll('.list-item').length).toBe(2);
  });
});