import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-dependent-list',
  templateUrl: './dependent-list.component.html',
  styleUrls: ['./dependent-list.component.css']
})
export class DependentListComponent {
  @Input() dependentCoveredTitle: string = '';
  @Input() dependents: { FirstName: string; LastName: string; BirthDate: Date; }[] = [];

  constructor() {}
}