import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HealthBenefitsSummaryComponent } from './health-benefits-summary.component';

describe('HealthBenefitsSummaryComponent', () => {
  let component: HealthBenefitsSummaryComponent;
  let fixture: ComponentFixture<HealthBenefitsSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HealthBenefitsSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthBenefitsSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Additional tests can be added here
});