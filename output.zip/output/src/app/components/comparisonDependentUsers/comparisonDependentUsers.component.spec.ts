import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CoverageGridWrapperComponent } from './coverage-grid-wrapper.component';

describe('CoverageGridWrapperComponent', () => {
  let component: CoverageGridWrapperComponent;
  let fixture: ComponentFixture<CoverageGridWrapperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoverageGridWrapperComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoverageGridWrapperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Add more tests as needed
});