import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-coverage-grid-wrapper',
  templateUrl: './coverage-grid-wrapper.component.html',
  styleUrls: ['./coverage-grid-wrapper.component.css']
})
export class CoverageGridWrapperComponent {
  @Input() data: any;
  @Input() displayedComparisonCategories: any;
  @Input() showPrimaryCareProviders: boolean = false;
  @Input() widgetTitle: string = '';
  @Input() hideTitle: boolean = false;
  @Input() detailsLink: string = '';
  @Input() coverage: any;

  constructor() {}
}