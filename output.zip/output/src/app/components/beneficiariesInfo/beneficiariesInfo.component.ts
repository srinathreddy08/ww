import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beneficiaries',
  templateUrl: './beneficiaries.component.html',
  styleUrls: ['./beneficiaries.component.css']
})
export class BeneficiariesComponent implements OnInit {
  terms = { Beneficiaries: 'Beneficiaries' }; // Example static data
  enrollmentContent = {
    Common: {
      Beneficiary: {
        PrimaryLabel: 'Primary Beneficiaries',
        SecondaryLabel: 'Secondary Beneficiaries'
      }
    }
  };
  beneficiariesDesignations = [];
  beneficiaries = {};
  primary = [];
  secondary = [];

  ngOnInit() {
    this.primary = this.beneficiariesDesignations.filter(d => !d.IsSecondary);
    this.secondary = this.beneficiariesDesignations.filter(d => d.IsSecondary);
  }

  getDesignationBirthDate(id: number): Date | null {
    // Implement logic to get birth date
    return null;
  }
}