import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EoiLinkComponent } from './eoi-link.component';

describe('EoiLinkComponent', () => {
  let component: EoiLinkComponent;
  let fixture: ComponentFixture<EoiLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EoiLinkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EoiLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display content when eoiPendingStatus is A or P', () => {
    component.eoiPendingStatus = 'A';
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.fa-file-text')).toBeTruthy();
  });

  // Add more tests as needed
});