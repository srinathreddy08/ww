import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-eoi-link',
  templateUrl: './eoi-link.component.html',
  styleUrls: ['./eoi-link.component.css']
})
export class EoiLinkComponent {
  @Input() alignBottom: boolean = false;
  @Input() eoiPendingStatus: string = '';
  @Input() externalEoi: boolean = false;
  @Input() electedBenefit: { BenefitID: string } = { BenefitID: '' };
  @Input() content: { Value?: string, Link?: string } = {};

  constructor() {}
}