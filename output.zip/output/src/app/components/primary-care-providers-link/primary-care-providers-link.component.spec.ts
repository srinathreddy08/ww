import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewPrimaryCareProvidersComponent } from './view-primary-care-providers.component';

describe('ViewPrimaryCareProvidersComponent', () => {
  let component: ViewPrimaryCareProvidersComponent;
  let fixture: ComponentFixture<ViewPrimaryCareProvidersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewPrimaryCareProvidersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPrimaryCareProvidersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call viewPrimaryCareProviders on click', () => {
    spyOn(component, 'viewPrimaryCareProviders');
    const link = fixture.nativeElement.querySelector('a');
    link.click();
    expect(component.viewPrimaryCareProviders).toHaveBeenCalled();
  });
});