import { Component } from '@angular/core';

@Component({
  selector: 'app-view-primary-care-providers',
  templateUrl: './view-primary-care-providers.component.html',
  styleUrls: ['./view-primary-care-providers.component.css']
})
export class ViewPrimaryCareProvidersComponent {
  content: string = 'View Primary Care Providers';

  showPrimaryCareProviders(): boolean {
    // Implement logic to determine if primary care providers should be shown
    return true;
  }

  viewPrimaryCareProviders(): void {
    // Implement logic to view primary care providers
    console.log('Viewing primary care providers');
  }
}