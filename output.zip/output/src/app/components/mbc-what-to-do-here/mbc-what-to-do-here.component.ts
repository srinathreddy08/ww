import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-what-to-do-here',
  templateUrl: './what-to-do-here.component.html',
  styleUrls: ['./what-to-do-here.component.css']
})
export class WhatToDoHereComponent {
  @Input() contentKey: string;
  @Input() datasource: any;
  @Input() content: any;
  @Input() static: any;
  expanded: boolean = false;
  expandable: boolean = true;
  contentLoaded: boolean = true;

  toggle(): void {
    this.expanded = !this.expanded;
  }

  hasLinks(content: any): boolean {
    return content.Link1 && (content.Link1.Id || content.Link1.Text || content.Link1.Title || content.Link1.Url) ||
           content.Link2 && (content.Link2.Id || content.Link2.Text || content.Link2.Title || content.Link2.Url);
  }
}