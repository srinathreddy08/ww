import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WhatToDoHereComponent } from './what-to-do-here.component';

describe('WhatToDoHereComponent', () => {
  let component: WhatToDoHereComponent;
  let fixture: ComponentFixture<WhatToDoHereComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WhatToDoHereComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WhatToDoHereComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle expanded state', () => {
    component.toggle();
    expect(component.expanded).toBeTrue();
    component.toggle();
    expect(component.expanded).toBeFalse();
  });

  it('should detect links correctly', () => {
    const contentWithLinks = {
      Link1: { Id: 1, Text: 'Link1' },
      Link2: { Id: 2, Text: 'Link2' }
    };
    expect(component.hasLinks(contentWithLinks)).toBeTrue();

    const contentWithoutLinks = {};
    expect(component.hasLinks(contentWithoutLinks)).toBeFalse();
  });
});