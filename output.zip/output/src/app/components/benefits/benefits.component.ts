import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-benefits',
  templateUrl: './benefits.component.html',
  styleUrls: ['./benefits.component.css']
})
export class BenefitsComponent {
  @Input() data: any;
  @Input() separateByStatus: boolean;
  @Input() hasEditableBenefits: boolean;
  @Input() coverageEffectiveDateInfo: any;
  @Input() displayCosts: boolean;
  @Input() showAnnualAmounts: boolean;
  @Input() electionData: any;
  @Input() benefitsAvailableToUpdate: any;
  @Input() hasNonEditableBenefits: boolean;
  @Input() benefitsNotAvailableToUpdate: any;
  @Input() totals: any;
  @Input() showSubtotals: boolean;
  @Input() dcSubTotalTooltipEnabled: boolean;
  @Input() credits: any[];
  @Input() charges: any[];
  @Input() companyCont: boolean;
  @Input() isQuaterlyOrSemiAnnual: boolean;
  @Input() columnClasses: any;
  @Input() static: any;
  @Input() HB: any;
  @Input() content: any;
}