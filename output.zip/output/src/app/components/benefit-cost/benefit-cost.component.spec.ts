import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CostDisplayComponent } from './cost-display.component';

describe('CostDisplayComponent', () => {
  let component: CostDisplayComponent;
  let fixture: ComponentFixture<CostDisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CostDisplayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CostDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Additional tests can be added here
});