﻿'use strict';
angular.module('mercerApp')
    .constant('displayedComparisonCategories', ['MEDICAL', 'DENTAL', 'VISION']);