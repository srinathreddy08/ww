// NAVIGATION SERVICE
angular.module('mercer.db.shared').service('navigationService', [
    '$rootScope', '$location', '$timeout', '_', '$q', 'shoppingCartService', 'mbcContentAndData', '$state',
    '$stateParams', '$urlMatcherFactory', 'flags', 'mbcLog', 'employeeCoverageService', 'domainAvailibility', 'pensionPayments',
    'dbTaxViewValue', 'contentAliasService', 'logService', 'executeWithSpinnerIfDisplaying', 'dbContextService',
    'onlineCommencementService', 'requiredDependentVerificationDocuments',
    'cachedLifeEventNavigationService', 'benefitCategories', 'tabKeys', 'subTabKeys', 'enrollmentNavigationService',
    function ($rootScope, $location, $timeout, _, $q, shoppingCartService, mbcContentAndData, $state, $stateParams,
        $urlMatcherFactory, flags, mbcLog, employeeCoverageService, domainAvailibility, pensionPayments, dbTaxViewValue,
        contentAliasService, logService, executeWithSpinnerIfDisplaying, dbContextService,
        onlineCommencementService, requiredDependentVerificationDocuments,
        cachedLifeEventNavigationService, benefitCategories, tabKeys, subTabKeys, enrollmentNavigationService) {
        var logger = logService.getLogger('NavigationService');

        var allPortalSections = getInitialAllPortalSections();
        var dynamicNavMap = getInitialDynamicNavMap();

        var hasLifeEventNavigationData = false;
        var lifeEventNavigationData = null;
        var megaNav = {};
        var isLinear = true;
        var navKeys = {
            tabKey: undefined,
            subtabKey: undefined
        };

        var currentPortalSectionKey = undefined;
        var currentPortalSectionSource = undefined;
        var currentPortalSection = null;

        var currentTab = {};
        var currentSubtab = {};
        var currentPageTitle = undefined;

        var mobileHeader = {
            title: '',
            subtitle: '',
            exitText: '',
            search: true,
            alertText: ''
        };

        var pendingUpdateMobileHeaderAction;

        return {
            getMegaNav: getMegaNav,
            getCurrentlySelectedTab: getCurrentlySelectedTab,
            getCurrentlySelectedSubtab: getCurrentlySelectedSubtab,
            getCurrentlySelectedPageTitle: getCurrentlySelectedPageTitle,
            getMobileHeader: getMobileHeader,
            setIsLinear: setIsLinear,
            getCurrentPortalSection: getCurrentPortalSection,
            resetHasLifeEventData: resetHasLifeEventData,
            setCurrentPortalSection: setCurrentPortalSection,
            updateNavStateWithFreshLifeEventData: updateNavStateWithFreshLifeEventData,
            getUrl: getUrl,
            mapNames: mapNames,
            setCurrentTabByKeys: setCurrentTabByKeys,
            activateSubtab: activateSubtab,
            setCurrentTabByCurrentUrl: setCurrentTabByCurrentUrl,
            notifyNavUpdated: notifyNavUpdated,
            updatePreviousStatesLinkable: updatePreviousStatesLinkable,
            updateLifeEventNavigationData: updateLifeEventNavigationData,
            getDynamicNavMap: getDynamicNavMap,
            checkPageAccess: checkPageAccess,
            adminAccessAllowed: adminAccessAllowed,
            getGlobalNavigationUpdates: getGlobalNavigationUpdates,
            updateGlobalNavigation: updateGlobalNavigation,
            getChooseBenefitsIsEnabled: getChooseBenefitsIsEnabled,
            getEnrollmentFlowV2IsEnabled: getEnrollmentFlowV2IsEnabled,
            getNextNavigationItemStateOrName: getNextNavigationItemStateOrName,
            goNext: goNext,
            goPrev: goPrev,
            skipToCheckout: skipToCheckout,
            updateMobileHeader: updateMobileHeader,
            mobileHome: mobileHome,
            updateMobileHeaderByNavigationItem: updateMobileHeaderByNavigationItem,
            getLENavEnabledMapping: getLeNavEnabledMapping,
            getHBNavEnabledMapping: getHbNavEnabledMapping,
            getNavMapping: getNavMapping,
            updateTabContent: updateTabContent,
            updateAllTabsContent: updateAllTabsContent,
            removeSectionTab: removeSectionTab,
            disableNavForConfirmation: disableNavForConfirmation,
            getLifeEventPortalSectionWithNextRequestCaching: getLifeEventPortalSectionWithNextRequestCaching
        };

        function getGlobalNavigationUpdates(skipHardRefresh) {
            var navPromise = mbcContentAndData.getMegaNavPromise(!skipHardRefresh);

            return $q
                .all({
                    navData: navPromise,
                    enrollmentData: getEnrollmentIfAvailable(),
                    healthBenefitsNavigationUpdated: updateHealthBenefitsNavigationIfAvailable(),
                    pensionPaymentsData: calculatePensionPaymentsDataIfAvailable(),
                    pensionRequiredFiles: getdbDocumentPlanList(),
                    healthDocumentList: getHealthDocumentList()
                })
                .then(function (results) {
                    return navUpdates;

                    function navUpdates() {
                        logger.debug('navUpdates', megaNav, results.navData);
                        megaNav = results.navData;

                        updateDocUpload();
                        updateHeaderFooter();
                        copyExtraPortalSections();
                        updateDbMenuItems();
                        updateCurrentPortalSection();
                    }

                    function updateDocUpload() {
                        var navigation = megaNav.Data.Navigation;
                        var docUploadListItem = deepSearch(navigation.MegaNav,
                            'DOCUPLOAD', 'Id', 'Items');
                        if (docUploadListItem == null || docUploadListItem
                            .Items == null || docUploadListItem.Items.length ===
                            0) {
                            return;
                        }

                        updateRolDocUploadLink(docUploadListItem);
                        updateHealthDocUploadLink(docUploadListItem);
                    }

                    function updateRolDocUploadLink(docUploadListItem) {
                        var linkId = 'ROL_UPLOAD';
                        var pensionRequiredFiles = results.pensionRequiredFiles;

                        var hideRol = true;

                        if (pensionRequiredFiles != null && pensionRequiredFiles.Data != null && pensionRequiredFiles.Data.Plans != null) {
                            var dbDocumentsForUploadExist = _.some(pensionRequiredFiles.Data.Plans,
                                function (plan) {
                                    var isWetFlow = onlineCommencementService.getWetFLowStatus(plan.WetFlowConfiguration, flags.isImpersonation);

                                    return !isWetFlow && _.some(plan.RequiredDocuments, function (item) {
                                        return item.Status === 0 || item.Status === 4;
                                    });
                                });

                            hideRol = !dbDocumentsForUploadExist;
                        }

                        if (hideRol) {
                            var rolUpload = _.find(docUploadListItem.Items,
                                function (item) {
                                    return item.Id === linkId;
                                });

                            if (rolUpload != null) {
                                rolUpload.Ignore = true;
                            }

                            var tab = _.find(megaNav.Data.DocuploadNavigation,
                                function (item) {
                                    return item.Key.toUpperCase() === linkId;
                                });

                            if (tab != null) {
                                tab.Hidden = true;
                            }
                        }
                    }

                    function updateHealthDocUploadLink(docUploadListItem) {
                        var linkId = 'DEP_VERIFY';

                        var requiredFiles = results.healthDocumentList;

                        var hide = true;

                        if (requiredFiles != null) {
                            var hbDocumentsForUploadExist = _.some(requiredFiles, function (documents) {
                                return documents.Dependents && documents.Dependents.length > 0;
                            });

                            hide = !hbDocumentsForUploadExist;
                        }

                        if (hide) {
                            var rolUpload = _.find(docUploadListItem.Items,
                                function (item) {
                                    return item.Id === linkId;
                                });

                            if (rolUpload != null) {
                                rolUpload.Ignore = true;
                            }

                            var tab = _.find(megaNav.Data.DocuploadNavigation,
                                function (item) {
                                    return item.Key.toUpperCase() === linkId;
                                });

                            if (tab != null) {
                                tab.Hidden = true;
                            }
                        }
                    }

                    function updateHeaderFooter() {
                        logger.debug('updateHeaderFooter', 'before', megaNav
                            .Header, megaNav.Footer);
                        var navigation = megaNav.Data.Navigation;

                        //Sorted
                        megaNav.Header = _.groupBy(navigation.MegaNav.Items,
                            'ColumnOrder');
                        megaNav.Footer = _.groupBy(navigation.Footer.Items,
                            'ColumnOrder');

                        logger.debug('updateHeaderFooter', 'after', megaNav
                            .Header, megaNav.Footer);

                        notifyMeganavUpdated();
                    }

                    function copyExtraPortalSections() {
                        logger.debug('copyExtraPortalSections', 'before',
                            allPortalSections['my-account'],
                            allPortalSections['voluntary-benefits']);
                        allPortalSections['my-account'] = megaNav.Data
                            .AccountNavigation;
                        allPortalSections['voluntary-benefits'] = megaNav.Data
                            .VbNavigation;
                        allPortalSections['documents-upload'] = megaNav.Data
                            .DocuploadNavigation;
                        logger.debug('copyExtraPortalSections', 'after',
                            allPortalSections['my-account'],
                            allPortalSections['voluntary-benefits']);
                    }

                    function updateDbMenuItems() {
                        var navigation = megaNav.Data.Navigation;

                        var dbPlanLinkListItem = deepSearch(navigation.MegaNav,
                            'DBPLANLINKLIST', 'Id', 'Items');
                        var dbPaymentsLinkListItem =
                            deepSearch(navigation.MegaNav, 'DBPAYLINKLIST',
                                'Id', 'Items');

                        if (dbPlanLinkListItem != null) {
                            var dbPlanLinkList = megaNav
                                .Content[dbPlanLinkListItem.ContentAlias];

                            var dbPlanOverviewItem = _
                                .find(allPortalSections['db-plan'],
                                    {
                                        Key: 'overview'
                                    });
                            dbPlanOverviewItem.Name = dbPlanLinkList[0].Text;

                            var estimateItem = _
                                .find(allPortalSections['db-plan'],
                                    {
                                        Key: 'estimates'
                                    });
                            estimateItem.Name = dbPlanLinkList[1].Text;

                            var myDataItem = _
                                .find(allPortalSections['db-plan'],
                                    {
                                        Key: 'my-data'
                                    });
                            myDataItem.Name = dbPlanLinkList[2].Text;

                            if (dbPlanLinkList.length > 3) {
                                var myElection = _
                                    .find(allPortalSections['db-plan'],
                                        {
                                            Key: 'my-election'
                                        });
                                myElection.Name = dbPlanLinkList[3].Text;
                            }
                        }

                        if (dbPaymentsLinkListItem != null) {
                            var dbPaymentsLinkList = megaNav
                                .Content[dbPaymentsLinkListItem.ContentAlias];

                            var paymentsOverviewItem = _
                                .find(allPortalSections['pension-payments'],
                                    {
                                        Key: 'overview'
                                    });
                            paymentsOverviewItem.Name = dbPaymentsLinkList[0]
                                .Text;

                            var paymentTaxesSuppressed = results
                                .pensionPaymentsData.paymentTaxesSuppressed;
                            if (!paymentTaxesSuppressed) {
                                var taxWithholding = _
                                    .find(allPortalSections['pension-payments'],
                                        {
                                            Key: 'tax-withholding'
                                        });
                                taxWithholding.Name = dbPaymentsLinkList[1]
                                    .Text;
                            }

                            var paymentMethodSuppressed = results
                                .pensionPaymentsData.paymentMethodSuppressed;
                            if (!paymentMethodSuppressed) {
                                var paymentMethodItem = _
                                    .find(allPortalSections['pension-payments'],
                                        {
                                            Key: 'payment-method'
                                        });
                                paymentMethodItem.Name = paymentTaxesSuppressed
                                    ? dbPaymentsLinkList[1].Text
                                    : dbPaymentsLinkList[2].Text;
                            }
                        }
                    }

                    function updateCurrentPortalSection() {
                        logger.debug('updateCurrentPortalSection',
                            currentPortalSectionKey);

                        // Update Data if we've been passed any keys at some point
                        if (!currentPortalSectionKey) {
                            logger.debug('updateCurrentPortalSection',
                                'skipping');
                            return;
                        }

                        // Set Data
                        logger.debug('updateCurrentPortalSection', 'before',
                            currentPortalSectionSource, currentPortalSection);
                        currentPortalSectionSource = allPortalSections[
                            currentPortalSectionKey];
                        currentPortalSection = _.cloneDeep(currentPortalSectionSource);
                        logger.debug('updateCurrentPortalSection', 'after',
                            currentPortalSectionSource, currentPortalSection);

                        if (currentPortalSectionKey === 'life-event' &&
                            lifeEventNavigationData) {
                            disableNavForConfirmation(results.enrollmentData);
                        }

                        // Set Tabs
                        if (navKeys.tabKey) {
                            setCurrentTabByKeys(navKeys.tabKey, navKeys
                                .subtabKey);
                        } else {
                            notifyNavUpdated();
                        }
                    }
                });

            function getEnrollmentIfAvailable() {
                return domainAvailibility.get().$promise
                    .then(function (availability) {
                        if (!availability.HbAvailable) {
                            return $q.resolve();
                        }

                        return mbcContentAndData.getEnrollment().$promise;
                    });
            }

            function updateHealthBenefitsNavigationIfAvailable() {
                logger.debug('updateHealthBenefitsNavigationIfAvailable');

                return $q.all({
                    enrollmentData: getEnrollmentIfAvailable(),
                    navData: navPromise
                })
                    .then(function (results) {
                        var enrollment = results.enrollmentData;
                        var navData = results.navData;

                        if (!enrollment) {
                            return;
                        }

                        if (!employeeCoverageService
                            .isCurrentCoverageExists(enrollment.Employee) &&
                            employeeCoverageService
                                .isFutureCoverageExists(enrollment.Employee)) {

                            logger
                                .debug('updateHealthBenefitsNavigationIfAvailable', 'HEALTHANDBENEFITS', 'before', navData.Data.Navigation.MegaNav.Items);
                            //Filter HEALTHANDBENEFITS items
                            _(navData.Data.Navigation.MegaNav.Items)
                                .filter({ Id: 'HEALTHANDBENEFITS' })
                                .forEach(function (item) {
                                    item.Items = _(item.Items)
                                        .filter({ Id: 'HEALTHSUMMARY' })
                                        .value();
                                });
                            logger
                                .debug('updateHealthBenefitsNavigationIfAvailable', 'HEALTHANDBENEFITS', 'after', navData.Data.Navigation.MegaNav.Items);
                        }
                    });
            }

            function calculatePensionPaymentsDataIfAvailable() {
                return domainAvailibility.get().$promise
                    .then(function (availability) {
                        if (!availability.DbAvailable) {
                            return $q.resolve({
                                paymentTaxesSuppressed: false,
                                paymentMethodSuppressed: false
                            });
                        }

                        return pensionPayments.getPensionPayments()
                            .then(function (pensionPaymentsResponse) {
                                return {
                                    paymentTaxesSuppressed:
                                        paymentTaxesSuppressed(),
                                    paymentMethodSuppressed:
                                        paymentMethodSuppressed()
                                };

                                function paymentTaxesSuppressed() {
                                    var taxSuppressConfig =
                                        pensionPaymentsResponse
                                            .Configuration[
                                        'DB.Tax.StateTaxSuppressConfiguration'];

                                    if (!taxSuppressConfig) {
                                        return false;
                                    }

                                    return taxSuppressConfig.TAXES_CONFIG ===
                                        dbTaxViewValue.Suppress;
                                }

                                function paymentMethodSuppressed() {
                                    return pensionPaymentsResponse.commonConfig
                                        .paymentMethod.suppressed;
                                }
                            });
                    });
            }

            function getdbDocumentPlanList() {
                return domainAvailibility.get().$promise
                    .then(function (availability) {
                        if (!availability.DbAvailable) {
                            return null;
                        }

                        return dbContextService.getPromise()
                            .then(function () {
                                if (!dbContextService.IsOnlineCommencement() ||
                                    dbContextService.IsInROLProxy()) {
                                    return null;
                                }

                                return onlineCommencementService.getRequiredDocumentsData(true);
                            });
                    });
            }

            function getHealthDocumentList() {
                function getCartDataIfAvailable(employeeData) {
                    var pendingEmployee = employeeData.Data.PendingEmployee;

                    if (!pendingEmployee) {
                        return $q.resolve(null);
                    }

                    var lifeEvent = pendingEmployee.LifeEvents[0];

                    return shoppingCartService
                        .get(lifeEvent.LifeEventID, lifeEvent
                            .LifeEventSequenceNumber, lifeEvent.LifeEventDate)
                        .$promise;
                }

                return domainAvailibility.get().$promise
                    .then(function (response) {

                        if (!response.HbAvailable) {
                            return null;
                        }

                        return mbcContentAndData.getEnrollment().$promise
                            .then(function (employeeData) {
                                return getCartDataIfAvailable(employeeData)
                                    .then(function (cartData) {
                                        return requiredDependentVerificationDocuments.getRequiredDependentVerificationDocuments(employeeData, cartData);
                                    });
                            });
                    });
            }
        }

        function updateGlobalNavigation(skipHardRefresh) {
            logger.debug('updateGlobalNavigation');

            // Get data for Non Linear mode
            return getGlobalNavigationUpdates(skipHardRefresh)
                .then(function (navUpdates) {
                    logger.debug('updateGlobalNavigation', 'applying navUpdates');
                    navUpdates();
                    logger.debug('updateGlobalNavigation', 'applied navUpdates');

                    if (pendingUpdateMobileHeaderAction) {
                        logger.debug('updateGlobalNavigation', 'has pendingUpdateMobileHeaderAction, calling it');
                        pendingUpdateMobileHeaderAction(megaNav);
                    }

                    return $q.when();
                });
        }

        function getChooseBenefitsIsEnabled() {
            return updateLifeEventNavigationDataIfNeeded()
                .then(function () {
                    var cb = lifeEventNavigationData.NavigationStatus['choose-benefits'];

                    return cb.IsEnabled && cb.IsAvailable;
                });
        }

        function getEnrollmentFlowV2IsEnabled() {
          return $rootScope.isEnrollmentFlowV2;
        }

        function getNextNavigationItemStateOrName() {
          var stateOrName;
          if ($rootScope.isEnrollmentFlowV2) {
            var nextMenuItem = enrollmentNavigationService.getNextMenuItem();
            stateOrName = nextMenuItem.NavRoute.Name;
          } else {
            var nextNavigationItem = getNavigationItemByOffsetFromCurrent(null, 1);
            stateOrName = 'life-event.' + nextNavigationItem.subtabKey;
          }
          return stateOrName;
        }

        function goNext(settings) {
            logger.debug('goNext', settings);
            
            if ($rootScope.isEnrollmentFlowV2) {
                enrollmentNavigationService.goNext();
            }      
            
            // GO TO NEXT LINK IN NAV
            var nextNavigationItem = getNavigationItemByOffsetFromCurrent(settings, 1);

            // Check Keys to see if its one that needs a refresh
            activateSubtab(nextNavigationItem.subtabKey, settings);           

            // Back to page top
            $('html, body').animate({ scrollTop: 0 }, 'slow');
        }

        function goPrev(settings) {
            logger.debug('goPrev', settings);  
            
            if ($rootScope.isEnrollmentFlowV2) {
                enrollmentNavigationService.goPrev();
            }
            
            // GO TO PREVIOUS LINK IN NAV
            var previousNavigationItem = getNavigationItemByOffsetFromCurrent(settings, -1);

            // Get prev link url and move there
            setUrl(previousNavigationItem.subtab);
            
            // Back to page top
            $('html, body').animate({ scrollTop: 0 }, 'slow');
        }

        function getNavigationItemByOffsetFromCurrent(settings, offset) {
            var allNavigationItems = flattenedCurrentPortalSection();

            var currentIndex = _(allNavigationItems)
                .findIndex({
                    subtabKey: currentSubtab.Key
                });

            var remainingItems = offset > 0 ?
                _(allNavigationItems).slice(currentIndex + 1).value() :
                _(allNavigationItems).take(currentIndex).reverse().value();

            var availableRemainingItems = getAvailableNavigationItems(remainingItems, settings);

            return availableRemainingItems[offset - (offset > 0 ? 1 : -1)];
        }

        function getAvailableNavigationItems(navigationItems, settings) {
            var ignoreHidden = !!settings && settings.ignoreHidden;
            navigationItems = _(navigationItems)
                .reject(function (navigationItem) {
                    return navigationItem.subtab.autocomplete === true;
                })
                .value();

            if (!ignoreHidden) {
                return navigationItems;
            }

            return _(navigationItems)
                .reject(function (navigationItem) {
                    return navigationItem.subtab.Hidden === true;
                })
                .value();
        }


        function skipToCheckout() {
            logger.debug('skipToCheckout');

            if ($rootScope.isEnrollmentFlowV2) {
                enrollmentNavigationService.skipToCheckout();
            } 
            
            activateSubtab('review');

            // Back to page top
            $('html, body').animate({ scrollTop: 0 }, 'slow');
        }

        function updateMobileHeader(title, subtitle, viewSearch, exitText, alertText) {
            logger.debug('updateMobileHeader', 'before', mobileHeader);
            mobileHeader = {
                title: title,
                subtitle: subtitle,
                exitText: exitText,
                search: viewSearch,
                alertText: alertText
            };
            logger.debug('updateMobileHeader', 'after', mobileHeader);

            // Broadcast
            $timeout(function () { $rootScope.$broadcast('mobileHeader.update') }, 0);
        }

        function mobileHome() {

            // Broadcast
            $timeout(function () { $rootScope.$broadcast('mobileHeader.home') }, 0);
        }

        function updateMobileHeaderByNavigationItem(megaNavItemId) {
            logger.debug('updateMobileHeaderByNavigationItem', megaNavItemId);

            pendingUpdateMobileHeaderAction = function (meganavData) {
                logger.debug('pendingUpdateMobileHeaderAction', megaNavItemId, meganavData);
                var megaNavItems = _(meganavData.Data.Navigation.MegaNav.Items)
                    .keyBy('Id')
                    .value();
                var megaNavItem = megaNavItems[megaNavItemId];
                var title = contentAliasService.forData(meganavData).getContentValue(megaNavItem.ContentAlias);

                updateMobileHeader(false, title, false, undefined);
                pendingUpdateMobileHeaderAction = null;
            };

            if (!_.isEmpty(megaNav)) {
                logger.debug('updateMobileHeaderByNavigationItem', 'immediate execution');
                pendingUpdateMobileHeaderAction(megaNav);
            }
        }

        function getLeNavEnabledMapping(benefits) {
            //Determine whether or not tabs should be enabled
            var response = {};
            var nav;
            var tabIndex;
            var tab;
            var subtabIndex;
            var benefitCategory;

            _.forEach(benefits, function (benefit) {
                benefitCategory = benefit.BenefitCategory;
                nav = getNavMapping(benefitCategory, getSectionTabNameByCategory(benefitCategory));
                tabIndex = getTabIndexByKey(nav.tab);
                tab = currentPortalSection[tabIndex];
                if (tab) {
                    subtabIndex = getSubtabIndexByKey(getNavMapping(benefitCategory, getSectionTabNameByCategory(benefitCategory)).subtab, tab);
                    var benefitId = benefit.BenefitID;
                    if (benefitCategory === benefitCategories.SUPPLEMENTAL){

                        subtabIndex = getSubtabIndexByKey(benefitId.toLowerCase(), tab);
                    };
                    response[benefitId] = tab.IsEnabled && tab.SubNav[subtabIndex] && tab.SubNav[subtabIndex].IsEnabled;
                }
            });

            return response;
        }

        function getSectionTabNameByCategory(benefitCategory) {
            return benefitCategory === benefitCategories.SUPPLEMENTAL ? tabKeys.supplementalBenefits : tabKeys.healthBenefits;
        }

        function getHbNavEnabledMapping(benefits) {
            var response = {};
            var enabledNavUrls = [];

            _.forEach(currentPortalSection, function (d) {
                if (d.IsEnabled) {
                    enabledNavUrls.push(d.Url);
                }
                _.forEach(d.SubNav, function (s) {
                    if (s.IsEnabled) {
                        enabledNavUrls.push(s.Url);
                    }
                });
            });

            //H&B Nav is structured different from LE nav
            _.forEach(benefits, function (benefit) {
                var nav = getNavMapping(benefit.BenefitCategory, 'health-benefits');
                response[benefit.BenefitID] = enabledNavUrls.indexOf('/' + nav.tab + '/' + nav.subtab) > -1;
            });

            return response;
        }

        function getNavMapping(category, section, benefitType) {
            //Get nav mapping for OE and HB section

            //All voluntary benefits should start with VB_
            if (category.indexOf('VB_') === 0) {
                if (section === 'health-benefits') {
                    switch (category) {
                        case 'VB_AUTO':
                            return { 'tab': 'voluntary-benefits', 'subtab': 'auto' };
                        case 'VB_HOME':
                            return { 'tab': 'voluntary-benefits', 'subtab': 'home' };
                        case 'VB_AUTOHOME':
                            return { 'tab': 'voluntary-benefits', 'subtab': 'autohome' };
                        case 'VB_PET':
                            return { 'tab': 'voluntary-benefits', 'subtab': 'pet' };
                        case 'VB_PERSONALPROTECTION':
                            return { 'tab': 'voluntary-benefits', 'subtab': 'protection' };
                        case 'VB_SAVINGS':
                            return { 'tab': 'voluntary-benefits', 'subtab': 'savings' };
                        case 'VB_OTHER':
                            return { 'tab': 'voluntary-benefits', 'subtab': 'other' };
                    }
                }
                else {
                    return { 'tab': section, 'subtab': 'voluntary-benefits' };
                }
            }

            switch (category) {
                case 'MEDICAL':
                    return { 'tab': section, 'subtab': 'medical' };
                case 'SUPPLEMENTAL':
                    return { 'tab': section, 'subtab': 'supplemental-benefits' };
                case 'DENTAL':
                    return { 'tab': section, 'subtab': 'dental' };
                case 'VISION':
                    return { 'tab': section, 'subtab': 'vision' };
                case 'SPENDING':
                    //Special handling for HSA in health-benefits section
                    if (section === 'health-benefits' && benefitType === 'HSA') {
                        return { 'tab': section, 'subtab': 'hsa' };
                    }
                    return { 'tab': section, 'subtab': 'accounts' };
                case 'LIFE INSURANCE':
                    return { 'tab': section, 'subtab': 'life-insurance' };
                case 'ADDITIONAL':
                    return { 'tab': section, 'subtab': 'additional-benefits' };
                case 'DISABILITY':
                    return { 'tab': section, 'subtab': 'disability-insurance' };
                case 'PROTECTION':
                    return { 'tab': section, 'subtab': 'protection' };
                case 'U65MED':
                    return { 'tab': section, 'subtab': 'medical-under65' };
                case 'O65MED':
                    return { 'tab': section, 'subtab': 'medical-over65' };
            }
            return '';
        }

        function updateTabContent(tabKey, contentData, disabledItems) {
            logger.debug('updateTabContent', tabKey, contentData, disabledItems);

            var tab = null;
            if (tabKey) {
                angular.forEach(currentPortalSection, function (value) {
                    if (tabKey === value.Key) {
                        tab = value;
                    }
                });
            }
            if (tab) {
                processNavLink(tab, contentData, disabledItems);
            }
        }

        function updateAllTabsContent(contentData, disabledItems, autocompleteItems) {
            angular.forEach(currentPortalSection, function (tab) {
                processNavLink(tab, contentData, disabledItems, autocompleteItems);
            });
        }

        function adminAccessAllowed(participantData) {
            return (parseInt(participantData.Configuration['Portal.Participant.IsCognosReportsAccessAllowed']) > 0 ||
                parseInt(participantData.Configuration['Portal.Participant.ProxyAccessLevel']) > 0) && !flags.isImpersonation;
        }

        function checkPageAccess(subTypeId) {
            var typeId = 'forms-documents';

            //Used for forms & docs and health & benefits sections where navs are formed by UI, need to check user has access to the page using nav service
            var typeNavEnabled = false;
            var subTypeNavEnabled = false;
            var id;

            mbcContentAndData.getMegaNavPromise()
                .then(function (response) {
                    _.forEach(response.Data.Navigation.MegaNav.Items, function (item) {
                        if (dynamicNavMap[item.Id] && typeId === dynamicNavMap[item.Id].navKey) {
                            typeNavEnabled = true;
                            _.forEach(item.Items, function (subItem) {
                                id = dynamicNavMap[item.Id].subTabs &&
                                     dynamicNavMap[item.Id].subTabs.filter(x => x.Key === subItem.Id)[0] &&
                                     dynamicNavMap[item.Id].subTabs.filter(x => x.Key === subItem.Id)[0].navKey;
                                if (subTypeId === id) {
                                    subTypeNavEnabled = true;
                                }
                            });
                        }
                    });

                    //Redirect to the dashboard if the item was not in meganav service
                    if ((typeId && !typeNavEnabled) || (subTypeId && !subTypeNavEnabled)) {
                        //$state.go('dashboard');
                    }
                });
        }

        function getCurrentPortalSection() {
            _.remove(currentPortalSection, function (tab) {
                var isLifeEventTab = tab.Url && tab.Url.includes('life-event');
                return tab.SubNav && tab.SubNav.length === 0 && (!isLifeEventTab || isLifeEventTab && tab.IsShoppingCartLoaded);
            });
            return currentPortalSection;
        }

        function getEnrollmentMode(employeeData) {
            var pendingEmployee = employeeData?.Data?.PendingEmployee;
            if (!pendingEmployee) {
              return null;
            }

            var lifeEvent = pendingEmployee.LifeEvents[0];

            var linearFlowSettingName = lifeEvent.IsOpenEnrollment
                ? 'HB.LifeEvent.EnrollmentFlow'
                : 'HB.LifeEvent.EnrollmentMode';

            return employeeData.Configuration[linearFlowSettingName];
        }

        function setIsLinear(employeeData) {
            logger.debug('setIsLinear', 'before', isLinear);
            isLinear = getEnrollmentMode(employeeData) === 'L';
            logger.debug('setIsLinear', 'after', isLinear);
        }

        function setCurrentPortalSection(key) {
            logger.debug('setCurrentPortalSection', key);

            if (typeof key === 'object') {
                logger.debug('setCurrentPortalSection', 'key is object, setting currentPortalSectionSource and currentPortalSection');
                currentPortalSectionSource = key;
                currentPortalSection = currentPortalSectionSource;
            }
            else {
                logger.debug('setCurrentPortalSection', 'key is a value', allPortalSections[key]);
                currentPortalSectionKey = key;
                currentPortalSectionSource = allPortalSections[key];
                currentPortalSection = _.cloneDeep(currentPortalSectionSource);
            }

            if (currentPortalSection) {
                return $q.resolve(true);
            }
            else {
                return $q.reject('No nav data found');
            }
        }

        function processNavLink(link, contentData, disabledItems, autocompleteItems) {
            logger.debug('processNavLink', link, contentData, disabledItems, autocompleteItems);
            var contentAlias = contentData.ContentAliases[link.Name];
            var content;
            if (contentAlias) {
                logger.debug('processNavLink', 'contentAlias path');
                content = contentData.Content[contentAlias];
                link.DisplayName = content && (content.Title || content);
            }
            else {
                var configData = contentData.Configuration[link.Name];

                if (configData && configData.CONTENT_ALIAS) {
                    logger.debug('processNavLink', 'configData path');
                    content = contentData.Content[configData.CONTENT_ALIAS];
                    link.DisplayName = content && (content.Title || content);
                }
            }

            link.Hidden = !!_.find(disabledItems, function (item) {
                return item === link.Key;
            });
            link.autocomplete = !!_.find(autocompleteItems, function (item) {
                return item === link.Key;
            });
            _.forEach(link.SubNav, function (subtab) {
                processNavLink(subtab, contentData, disabledItems, autocompleteItems);
            });

            logger.debug('processNavLink', 'done', link);
        }

        function getUpdateNavEventArg() {
            return {
                tab: currentTab ? currentTab.Key : null,
                subtab: currentSubtab ? currentSubtab.Key : null
            };
        }

        function deepSearch(element, matchingValue, matchingFieldName, childFieldName) {
            if (element[matchingFieldName] != null && element[matchingFieldName].toLowerCase() === matchingValue.toLowerCase()) {
                return element;
            } else if (element[childFieldName] != null) {
                var result = null;
                _.forEach(element[childFieldName], function (item) {
                    var innerResult = deepSearch(item, matchingValue, matchingFieldName, childFieldName);
                    if (innerResult) {
                        result = innerResult;
                    }
                });
                return result;
            }
            return null;
        }

        function getTabByKeyPure(key, currentPortalSection) {
            return _(currentPortalSection).find({ Key: key });
        }

        function getTabByKey(key) {
            return getTabByKeyPure(key, currentPortalSection);
        }

        function getCategoryOrder(newLifeEventNavigationData) {
            var navKeysToCategories = newLifeEventNavigationData.NavKeysToCategories;
            var categoryOrder = newLifeEventNavigationData.CategoryOrder;

            if (!navKeysToCategories || !categoryOrder) {
                return;
            }

            return _(navKeysToCategories)
                .reduce(function (result, navKeyToCategory, key) {
                    result[key] = Number(categoryOrder[navKeyToCategory]);
                    return result;
                }, {});
        }

        function getSupplementalCategoryOrder(tab) {
            var i = 0;

            return _(tab.SubNav).mapKeys(function () {
                i++;
                return i;
            });
        }

        function getTabIndexByKey(key) {
            return _(currentPortalSection).findIndex({ Key: key });
        }

        function getSubtabByKey(tab, key) {
            return _(tab.SubNav).find({ Key: key });
        }

        function getSubtabIndexByKey(key, tab) {
            return _(tab.SubNav).findIndex({ Key: key });
        }

        function updateNavStateWithFreshLifeEventData() {
            logger.debug('resetHasLifeEventData', 'updateNavStateWithFreshLifeEventData');
            return cachedLifeEventNavigationService.getLifeEventNavigation(false)
                .then(applyLifeEventData);
        }

        function updateLifeEventNavigationDataIfNeeded() {
            logger.debug('updateLifeEventNavigationDataIfNeeded');
            if (hasLifeEventNavigationData) {
                logger.debug('hasLifeEventNavigationData');
                return $q.resolve();
            }

            return updateLifeEventNavigationData(false);
        }

        function updateLifeEventNavigationData(supressLeRedirects) {
            logger.debug('updateLifeEventNavigationData', supressLeRedirects);

            return executeWithSpinnerIfDisplaying(function () {
                return cachedLifeEventNavigationService.getLifeEventNavigation(false)
                    .then(function (newLifeEventNavigationData) {
                        logger.debug('updateLifeEventNavigationData', currentPortalSection, lifeEventNavigationData, newLifeEventNavigationData);
                        if (currentPortalSection) {
                            if (!lifeEventNavigationData) {
                                lifeEventNavigationData = newLifeEventNavigationData;
                            }

                            applyLifeEventData(newLifeEventNavigationData);
                        } else {
                            lifeEventNavigationData = newLifeEventNavigationData;
                        }

                        hasLifeEventNavigationData = true;

                        // Set Available and Enabled Links
                        var cartTab = getTabByKey('cart');

                        if(!_.isEmpty(currentTab) && !_.isEmpty(currentSubtab)) {
                            if (currentIsCheckListOrConfirmation()) {
                                logger.debug('updateLifeEventNavigationData', 'currentIsCheckListOrConfirmation');
                                //Special handling for when cart is empty but user is going to the confirmation page from the review page
                                if (cartTab) {
                                    logger.debug('updateLifeEventNavigationData', 'enable cartTab');
                                    cartTab.IsEnabled = true;

                                    var confirmationSubtab = getSubtabByKey(cartTab, 'confirmation');
                                    if (confirmationSubtab) {
                                        logger.debug('updateLifeEventNavigationData', 'enable confirmationSubtab');
                                        confirmationSubtab.IsEnabled = true;
                                    }

                                    var reviewSubtab = getSubtabByKey(cartTab, 'review');
                                    if (reviewSubtab) {
                                        logger.debug('updateLifeEventNavigationData', 'enable reviewSubtab');
                                        reviewSubtab.IsEnabled = false;
                                    }
                                }
                            } else {
                                logger.debug('updateLifeEventNavigationData', '!currentIsCheckListOrConfirmation');
                                if (isLinear && !supressLeRedirects) {
                                    if (!currentTabIsEnabled() && !$rootScope.isEnrollmentFlowV2) {
                                        logger.debug('updateLifeEventNavigationData', 'redirectToTheFirstTabInCurrentPortalSection()');
                                        redirectToTheFirstTabInCurrentPortalSection();
                                        return $q.reject();
                                    }
                                }
                            }
                        }

                        logger.debug('updateLifeEventNavigationData', 'broadcast nav.cartStatus', currentPortalSection);
                        // So we know if we should show skip to checkout
                        $rootScope.$broadcast('nav.cartStatus', currentPortalSection);

                        return $q.resolve();
                    })
                ['finally'](function () {
                    logger.debug('updateLifeEventNavigationData', 'notify all');
                    notifyNavUpdated();
                    notifyNavIsReady();
                });
            });
        }

        function applyLifeEventData(newLifeEventNavigationData) {
            logger.debug('applyLifeEventData', 'before', newLifeEventNavigationData, currentPortalSection);
            currentPortalSection = mergeNewLifeEventNavigationDataWithCurrentPortalSection(newLifeEventNavigationData);
            lifeEventNavigationData = newLifeEventNavigationData;
            logger.debug('applyLifeEventData', 'updated currentPortalSection', currentPortalSection);
            
            updateCurrentTabs();
        }

        function mergeNewLifeEventNavigationDataWithCurrentPortalSection(newLifeEventNavigationData) {
            return mergeNewLifeEventNavigationDataWithCurrentPortalSectionPure(newLifeEventNavigationData, currentPortalSection, currentPortalSectionSource, lifeEventNavigationData);
        }

        function mergeNewLifeEventNavigationDataWithCurrentPortalSectionPure(newLifeEventNavigationData, currentPortalSection, currentPortalSectionSource, lifeEventNavigationData) {
            var mergedTabs = _(currentPortalSectionSource)
                .map(function (sourceTab) {
                    var tabKey = sourceTab.Key;
                    var isChooseBenefit = tabKey === 'choose-benefits';
                    var isSupplementalBenefitSection = tabKey === 'supplemental-benefits';
                    var existingTab = getTabByKeyPure(tabKey, currentPortalSection);
                    var initialTabStatus = lifeEventNavigationData.NavigationStatus[tabKey];
                    var newTabStatus = newLifeEventNavigationData.NavigationStatus[tabKey];
                    var categoryOrder = undefined;

                    if (isChooseBenefit) {
                        categoryOrder = getCategoryOrder(newLifeEventNavigationData);
                    }

                    if (isSupplementalBenefitSection) {
                        categoryOrder = getSupplementalCategoryOrder(initialTabStatus);
                    }

                    return _.defaults({
                        SubNav: getSubNav()
                    },
                        getChangesInTab(),
                        newTabStatus,
                        sourceTab);

                    function getSubNav() {
                        var result = _(sourceTab.SubNav)
                            .map(function (sourceSubtab) {
                                var subtabKey = sourceSubtab.Key;
                                var newSubtab = isSupplementalBenefitSection ?
                                    newTabStatus.SubNav :
                                    newTabStatus.SubNav[subtabKey];

                                if (isSupplementalBenefitSection) {
                                    return _.sortBy(getChangedSupplementalBenefitSection(), 'DisplayOrder');
                                }

                                return _.defaults(
                                    { DisplayOrder: getDisplayOrder(subtabKey) },
                                    getChangesInSubtab(),
                                    newSubtab,
                                    sourceSubtab);

                                function getChangedSupplementalBenefitSection() {
                                    var i = 0;

                                    return _(newSubtab).map(function (status, key) {
                                        var result = _.defaults(
                                            getChangesInSupplementalSubtab(),
                                            status,
                                            sourceSubtab);
                                        i++;

                                        return result;

                                        function getChangesInSupplementalSubtab() {
                                            if (!existingTab) {
                                                return {};
                                            }

                                            var existingSubtabStatus = initialTabStatus.SubNav[key];
                                            var isChanged = !existingSubtabStatus || existingSubtabStatus.IsEnabled !== status.IsEnabled;
                                            var benefitContext = getBenefit(key);

                                            var subNavInfo = {
                                                IsEnabled: isChanged ? status.IsEnabled : existingSubtabStatus.IsEnabled,
                                                Url: '/life-event/supplemental-benefits/' + key,
                                                Key: key.toLowerCase(),
                                                Name: benefitContext ? benefitContext.Content.LongName : '',
                                                DisplayOrder: benefitContext ? benefitContext.DisplayOrder : i
                                            };

                                            function getBenefit(benefitId) {
                                                var enrollment = mbcContentAndData.getEnrollment();
                                                if (enrollment.Employee) {
                                                    var eligibleBenefitsArray = enrollment.Employee.PendingEmployee.LifeEvents[0].EligibleBenefits;
                                                    return _.find(eligibleBenefitsArray, { BenefitID: benefitId });
                                                }

                                                return null;
                                            }

                                            return subNavInfo;
                                        }
                                    }).value();
                                }

                                function getChangesInSubtab() {
                                    if (!existingTab) {
                                        return {};
                                    }

                                    var existingSubtab = getSubtabByKey(existingTab, subtabKey);
                                    if (!existingSubtab) {
                                        return {};
                                    }

                                    var existingSubtabStatus = initialTabStatus.SubNav[subtabKey];
                                    var isChanged = existingSubtabStatus.IsEnabled !== existingSubtab.IsEnabled;

                                    if (isChanged) {
                                        return {
                                            IsEnabled: existingSubtab.IsEnabled
                                        };
                                    }

                                    return {};
                                }

                                function getDisplayOrder(subtabKey) {
                                    if (isChooseBenefit && subtabKey && categoryOrder) {
                                        return categoryOrder[subtabKey];
                                    }

                                    return sourceSubtab.DisplayOrder;
                                }
                            }).value();

                        result = isSupplementalBenefitSection ? result[0] : result;

                        result = result.filter(function (item) {
                            return item.IsAvailable;
                        });

                        return isChooseBenefit ? _.sortBy(result, 'DisplayOrder') : result;
                    }

                    function getChangesInTab() {
                        if (!existingTab) {
                            return {};
                        }

                        var isChanged = initialTabStatus.IsEnabled !== existingTab.IsEnabled;

                        if (isChanged) {
                            return {
                                IsEnabled: existingTab.IsEnabled
                            };
                        }

                        return {};
                    }
                })
                .filter('IsAvailable')
                .value();

            _(mergedTabs)
                .filter({ 'Key': 'choose-benefits' })
                .forEach(function (tab) {
                    tab.Url = (tab.SubNav.length !== 0) ? tab.SubNav[0].Url : tab.Url;
                });

            return mergedTabs;
        }

        function updateCurrentTabs() {
            logger.debug('updateCurrentTabs', 'before', currentTab, currentSubtab);

            if (!_.isEmpty(currentTab)) {
                currentTab = getTabByKey(currentTab.Key);

                if (currentTab && currentSubtab && currentSubtab.Key) {
                    currentSubtab = getSubtabByKey(currentTab, currentSubtab.Key);
                }
            }

            logger.debug('updateCurrentTabs', 'after', currentTab, currentSubtab);
        }

        function setCurrentTabByKeys(tabKey, subtabKey) {
            logger.debug('setCurrentTabByKeys', 'before', navKeys, currentTab, currentPageTitle, tabKey, subtabKey);

            // Store these, incase we need them later
            navKeys = {
                tabKey: tabKey,
                subtabKey: subtabKey
            };

            // If we got passed a tab, find it and set it as the current tab
            if (tabKey) {
                var newTab = getTabByKey(tabKey);

                if (newTab) {
                    logger.debug('setCurrentTabByKeys', tabKey, newTab);
                    currentTab = newTab;
                    // Some pages use nav data for title
                    currentPageTitle = newTab.Name;
                }
            }

            // If we got passed a subnav link, find it and set it as the current subnav
            if (subtabKey) {
                var newSubtab = getSubtabByKey(currentTab, subtabKey);

                if (newSubtab) {
                    logger.debug('setCurrentTabByKeys', subtabKey, newSubtab);
                    currentSubtab = newSubtab;
                    // Some pages use nav data for title, if subnav that takes over tab value
                    currentPageTitle = newSubtab.Name;
                }
            }
            else {
                logger.debug('setCurrentTabByKeys', 'default');
                currentSubtab = {};
            }

            logger.debug('setCurrentTabByKeys', 'after', navKeys, currentTab, currentPageTitle);

            notifyNavUpdated();
        }

        function getUrl(nav) {
            var url = angular.isString(nav) ? nav : nav.Url;
            var newUrl = $urlMatcherFactory.compile(url).format($stateParams);
            return newUrl;
        }

        function mapNames(content) {
            logger.debug('mapNames');
            // Mobile nav lives outside of all our scopes, so in some cases we need to just replace our content aliases with content
            _.forEach(currentPortalSection, function (tab) {
                tab.Name = content[tab.Name].PageTitle;
                // Replace any ampersands...
                tab.Name = tab.Name.replace(/&amp;/g, '&');
                _.forEach(tab.SubNav, function (subtab) {
                    if (content[subtab.Name]) {
                        subtab.Name = content[subtab.Name].Title;
                        // Replace any ampersands...
                        subtab.Name = subtab.Name.replace(/&amp;/g, '&');
                    }
                });
            });
        }

        function setUrl(subtab, settings) {

            logger.debug('setUrl', subtab, settings);
            
            if (!$rootScope.isEnrollmentFlowV2) {
                $timeout(function () {
                    var parsedUrl = getUrl(subtab.Url);
                    var path = $location.path(parsedUrl);
                    if (settings && settings.ignoreHistory) {
                        path.replace();
                    }
                }, 0);
            }            

            notifyNavUpdated();
        }

        function setRouterState(subtab, settings) {
            logger.debug('setRouterState', subtab, settings);

            if (!$rootScope.isEnrollmentFlowV2) {
                $state.go(settings.sectionName + '.' + subtab.Key, null, { reload: !!settings.forceRefresh });
            }
           
            notifyNavUpdated();
        }

        function setCurrentTabByCurrentUrl() {
            logger.debug('setCurrentTabByCurrentUrl');
            var pathArray = $location.path().split('/');

            // 0 and 1 are things we dont want...
            var tabKey = pathArray[2] || null;
            var subtabKey = pathArray[3] || null;

            // Need to timeout, routing takes its time displaying

            $timeout(function () {
                setCurrentTabByKeys(tabKey, subtabKey);
            }, 1500);

        }

        function notifyNavUpdated() {
            logger.debug('notifyNavUpdated', getUpdateNavEventArg());
            $rootScope.$broadcast('nav.update', getUpdateNavEventArg());
        }

        function notifyNavIsReady() {
            logger.debug('notifyNavIsReady');
            $rootScope.$broadcast('nav.ready');
        }

        function notifyMeganavUpdated() {
            logger.debug('notifyMeganavUpdated');
            $rootScope.$broadcast('meganav.update');
        }

        function updatePreviousStatesLinkable(positionKey) {
            logger.debug('updatePreviousStatesLinkable', positionKey);
            var states = [];
            for (var i = 0; i < currentPortalSection.length; i++) {
                var tab = currentPortalSection[i];
                states.push(tab);
                if (tab.SubNav) {
                    for (var j = 0; j < tab.SubNav.length; j++)
                        states.push(tab.SubNav[j]);
                }
            }

            var targetState = _.find(states,
                {
                    Key: positionKey
                });

            if (!targetState) {
                mbcLog.logError('navigationService -> updatePreviousStatesLinkable: positionKey does not exist among navigation states');
                return;
            }

            logger.debug('updatePreviousStatesLinkable', 'before', states);
            var flag = false;
            _.forEach(states, function (item) {
                item.IsEnabled = !flag || item.IsAlwaysEnabled;
                flag = flag || item.Key === positionKey;
            });
            logger.debug('updatePreviousStatesLinkable', 'after', states);
        }

        function currentTabIsEnabled() {
            return currentTab.IsEnabled && currentSubtab.IsEnabled;
        }

        function redirectToTheFirstTabInCurrentPortalSection() {
            logger.debug('redirectToTheFirstTabInCurrentPortalSection');
            var firstTabInCurrentPortalSection = currentPortalSection[0];
            var firstSubtabInCurrentPortalSection = firstTabInCurrentPortalSection.SubNav[0];

            currentTab = firstTabInCurrentPortalSection;
            currentSubtab = firstSubtabInCurrentPortalSection;
            activateSubtab(firstSubtabInCurrentPortalSection.Key);
        }

        function activateSubtab(subtabKey, settings) {
            logger.debug('activateSubtab', 'before', subtabKey, settings);

            if (subtabKey === 'confirmation') {
                logger.debug('activateSubtab', 'is confirmation');
                getTabByKey('confirmation').IsEnabled = true;
                return;
            }

            //Non Linear, set only the link we are accessing
            var navigationItem = _(flattenedCurrentPortalSection())
                .find({
                    subtabKey: subtabKey
                });

            if (navigationItem) {
                logger.debug('activateSubtab', 'has navigation item', navigationItem);

                var tab = navigationItem.tab;
                var subtab = navigationItem.subtab;

                tab.IsEnabled = true;
                subtab.IsEnabled = true;

                if (tab.Key === 'get-started') {
                    logger.debug('activateSubtab', 'get started -> enableEachPreviousNavItem');
                    enableEachPreviousNavItem(subtabKey);
                }

                // If we have a VisitID, Let shopping cart know we visited
                if (subtab.VisitID) {
                    logger.debug('activateSubtab', 'visiting', lifeEventNavigationData.LifeEventId, subtab.VisitID, lifeEventNavigationData.LifeEventDate);
                    var updatedCart = shoppingCartService.visit(lifeEventNavigationData.LifeEventId, subtab.VisitID, lifeEventNavigationData.LifeEventDate);

                    // If we reach health benefits subtab in OE we need to reset the nav life event with new data
                    var resetCurrentPortalSection = currentSubtab.Key === subTabKeys.summary;

                    if (resetCurrentPortalSection) {
                        logger.debug('activateSubtab', 'resetCurrentPortalSection');

                        updatedCart.$promise.then(function () {
                            // Check if nav data needs to update
                            resetHasLifeEventData();
                            updateLifeEventNavigationData(false);
                        });
                    }

                    $rootScope.$broadcast('cartItemVisited', subtab.VisitID);
                }

                // Move to where we belong
                if (settings && settings.stateRefresh) {
                    //Allow URL states to be used
                    setRouterState(subtab, settings);
                }
                else {
                    setUrl(subtab, settings);
                }
            }

            // For our Linear people, if they reach the cart set things that can jump to cart as true
            if (currentSubtab.Key === 'review') {
                logger.debug('activateSubtab', 'review subtab');
                $rootScope.$broadcast('nav.cartStatus', currentPortalSection);
            }
        }

        function enableEachPreviousNavItem(subtabKey) {
            logger.debug('enableEachPreviousNavItem', subtabKey);

            var items = flattenedCurrentPortalSection();
            var subtabIndex = _(items)
                .findIndex({
                    subtabKey: subtabKey
                });

            logger.debug('enableEachPreviousNavItem', 'before', items);
            _(items)
                .take(subtabIndex)
                .forEach(function (item) {
                    return item.subtab.IsEnabled = true;
                });
            logger.debug('enableEachPreviousNavItem', 'after', items);
        }

        function flattenedCurrentPortalSection() {
            return _(currentPortalSection)
                .map(function (tab) {
                    return _(tab.SubNav)
                        .map(function (subtab) {
                            return {
                                tab: tab,
                                tabKey: tab.Key,
                                subtab: subtab,
                                subtabKey: subtab.Key
                            };
                        })
                        .value();
                })
                .flattenDeep()
                .value();
        }

        function currentIsCheckListOrConfirmation() {
            var currentTabIsCart = currentTab.Key === 'cart';
            var currentSubtabIsCheckList = currentSubtab.Key === 'check-list';
            var currentSubtabIsConfirmation = currentSubtab.Key === 'confirmation';

            return currentTabIsCart && (currentSubtabIsCheckList || currentSubtabIsConfirmation);
        }

        function disableNavForConfirmation(enrollmentData) {
            logger.debug('disableNavForConfirmation', 'before', enrollmentData, currentPortalSection);
            //Checkout nav has special requirements, service can't calc nav if PendingEmployee is null so UI needs to do the calc

            currentPortalSection = mergeNewLifeEventNavigationDataWithCurrentPortalSection(lifeEventNavigationData);

            setTabIsEnabled('choose-benefits', false);
            setTabIsEnabled('supplemental-benefits', false);
            setTabIsEnabled('voluntary-benefits', false);
            if (enrollmentData.Data.PendingEmployee) {
                setTabIsEnabled('get-started', enrollmentData.Data.PendingEmployee.LifeEvents[0].IsOpenEnrollment);
            }
            setTabIsEnabled('cart', true);

            setCartSubtabIsEnabled('review', false);
            setCartSubtabIsEnabled('confirmation', true);
            setCartSubtabIsEnabled('check-list', true);

            logger.debug('disableNavForConfirmation', 'after', currentPortalSection);

            notifyNavIsReady();
        }

        function setTabIsEnabled(key, isEnabled) {
            var tab = getTabByKey(key);

            if (tab) {
                tab.IsEnabled = isEnabled;
            }
        }

        function setCartSubtabIsEnabled(key, isEnabled) {
            logger.debug('setCartSubtabIsEnabled', key, isEnabled);
            var cartTab = getTabByKey('cart');
            if (!cartTab) {
                return;
            }

            var subtab = getSubtabByKey(cartTab, key);
            if (subtab) {
                subtab.IsEnabled = isEnabled;
            }
        }

        function getDynamicNavMap() {
            return dynamicNavMap;
        }

        function resetHasLifeEventData() {
            logger.debug('resetHasLifeEventData', 'before', hasLifeEventNavigationData);
            hasLifeEventNavigationData = false;
        }

        function getMegaNav() {
            return megaNav;
        }

        function getCurrentlySelectedTab() {
            return currentTab;
        }

        function getCurrentlySelectedPageTitle() {
            return currentPageTitle;
        }

        function getCurrentlySelectedSubtab() {
            return currentSubtab;
        }

        function getMobileHeader() {
            return mobileHeader;
        }

        function removeSectionTab(key) {
            logger.debug('removeSectionTab', key);
            var indexnum = -1;
            _.forEach(angular.copy(currentPortalSection),
                function (tempnav) {
                    if (tempnav.Key === key) {
                        indexnum = tempnav.DisplayOrder;
                    }
                });
            if (indexnum >= 0) {
                logger.debug('removeSectionTab', 'before', currentPortalSection);
                currentPortalSection.splice(indexnum, 1);
                logger.debug('removeSectionTab', 'after', currentPortalSection);
            }
        }

        function getInitialAllPortalSections() {
            return {
                "my-account": [
                ],
                "voluntary-benefits": [
                ],
                "supplemental-benefits": [
                ],
                "life-event": [
                    {
                        Key: 'get-started',
                        Name: 'HB.LifeEvent.GetStarted.Title',
                        Url: '/life-event/get-started',
                        DisplayOrder: 0,
                        SubNav: [
                            {
                                Key: 'get-started',
                                DisplayOrder: 0,
                                Name: 'HB.LifeEvent.GetStarted.OECategory',
                                Url: '/life-event/get-started'
                            },
                            {
                                Key: 'whos-covered',
                                DisplayOrder: 1,
                                Name: 'HB.LifeEvent.GetStarted.WhosCoveredCategory',
                                Url: '/life-event/whos-covered'
                            },
                            {
                                Key: 'my-information',
                                DisplayOrder: 2,
                                Name: 'HB.LifeEvent.GetStarted.MyInformation',
                                Url: '/life-event/my-information'
                            },
                            {
                                Key: 'questionnaire',
                                DisplayOrder: 3,
                                Name: 'HB.LifeEvent.GetStarted.HelpMeFindAPlanCategory',
                                Url: '/life-event/questionnaire'
                            },
                            {
                                Key: 'summary',
                                DisplayOrder: 4,
                                Name: 'HB.LifeEvent.ChooseBenefits.Summary',
                                Url: '/life-event/summary'
                            }
                        ]
                    },
                    {
                        Key: 'choose-benefits',
                        Name: 'HB.LifeEvent.ChooseBenefits.Title',
                        Url: '/life-event/choose-benefits',
                        DisplayOrder: 1,
                        SubNav: [
                            {
                                Key: 'medical',
                                DisplayOrder: 1,
                                Name: 'HB.Common.CommonTerms.MedicalBenefitCategory',
                                Url: '/life-event/medical'
                            },
                            {
                                Key: 'medical-over65',
                                DisplayOrder: 1,
                                Name: 'HB.Common.CommonTerms.Over65MedicalBenefitCategory',
                                Url: '/life-event/medical-over65'
                            },
                            {
                                Key: 'medical-under65',
                                DisplayOrder: 2,
                                Name: 'HB.Common.CommonTerms.Under65MedicalBenefitCategory',
                                Url: '/life-event/medical-under65'
                            },
                            {
                                Key: 'dental',
                                DisplayOrder: 3,
                                Name: 'HB.Common.CommonTerms.DentalBenefitCategory',
                                Url: '/life-event/dental'
                            },
                            {
                                Key: 'vision',
                                DisplayOrder: 4,
                                Name: 'HB.Common.CommonTerms.VisionBenefitCategory',
                                Url: '/life-event/vision'
                            },
                            {
                                Key: 'accounts',
                                DisplayOrder: 5,
                                Name: 'HB.Common.CommonTerms.SpendingBenefitCategory',
                                Url: '/life-event/accounts'
                            },
                            {
                                Key: 'life-insurance',
                                DisplayOrder: 6,
                                Name: 'HB.Common.CommonTerms.LifeBenefitCategory',
                                Url: '/life-event/life-insurance'
                            },
                            {
                                Key: 'disability-insurance',
                                DisplayOrder: 7,
                                Name: 'HB.Common.CommonTerms.DisabilityBenefitCategory',
                                Url: '/life-event/disability-insurance'
                            },
                            {
                                Key: 'protection',
                                DisplayOrder: 8,
                                Name: 'HB.Common.CommonTerms.ProtectionBenefitCategory',
                                Url: '/life-event/protection'
                            },
                            {
                                Key: 'additional-benefits',
                                DisplayOrder: 9,
                                Name: 'HB.Common.CommonTerms.AdditionalBenefitsBenefitCategory',
                                Url: '/life-event/additional-benefits'
                            }
                        ]
                    },
                    {
                        Key: 'supplemental-benefits',
                        Name: 'HB.LifeEvent.SupplementalInsurance.Title',
                        Url: '/life-event/supplemental-benefits/{benefitId}',
                        DisplayOrder: 2,
                        SubNav: [
                            {
                                Key: 'supplemental-benefits',
                                DisplayOrder: 0,
                                Name: '',
                                Url: '/life-event/supplemental-benefits/'
                            }
                        ]
                    },
                    {
                        Key: 'voluntary-benefits',
                        Name: 'HB.LifeEvent.VoluntaryBenefits.Title',
                        Url: '/life-event/voluntary-benefits',
                        DisplayOrder: 3,
                        SubNav: [
                            {
                                Key: 'voluntary-benefits',
                                DisplayOrder: 0,
                                Name: 'HB.LifeEvent.VoluntaryBenefits.Overview',
                                Url: '/life-event/voluntary-benefits'
                            }
                        ]
                    },
                    {
                        Key: 'cart',
                        Name: 'HB.LifeEvent.YourCart.Title',
                        Url: '/life-event/review',
                        DisplayOrder: 4,
                        SubNav: [
                            {
                                Key: 'review',
                                DisplayOrder: 0,
                                Name: 'HB.LifeEvent.YourCart.Review.Title',
                                Url: '/life-event/review'
                            },
                            {
                                Key: 'confirmation',
                                DisplayOrder: 1,
                                Name: 'HB.LifeEvent.YourCart.Confirmation.Title',
                                Url: '/life-event/confirmation'
                            },
                            {
                                Key: 'check-list',
                                DisplayOrder: 2,
                                Name: 'HB.Common.CommonTerms.Checklist',
                                Url: '/life-event/checklist'
                            }
                        ]
                    }
                ],
                "db-plan": [
                    {
                        Key: 'overview',
                        IsEnabled: true,
                        Name: '',
                        Url: '/db-plan/{planCode}/summary',
                        DisplayOrder: 0,
                        SubNav: [
                            {
                                Key: 'summary',
                                IsEnabled: true,
                                DisplayOrder: 0,
                                Name: 'DB.Plan.PlanSummary.SummarySubNav',
                                Url: '/db-plan/{planCode}/summary'
                            },
                            {
                                Key: 'history',
                                IsEnabled: true,
                                DisplayOrder: 1,
                                Name: 'DB.CashBalanceHistory.SubNav',
                                Url: '/db-plan/{planCode}/history'
                            }
                        ]
                    },
                    {
                        Key: 'estimates',
                        IsEnabled: true,
                        DisplayOrder: 1,
                        Name: '',
                        Url: '/db-plan/{planCode}/estimates',
                        SubNav: [
                            {
                                Key: 'estimate-your-pension',
                                IsEnabled: true,
                                DisplayOrder: 0,
                                Name: 'DB.EstimateYourPension.EstimateSubNav',
                                Url: '/db-plan/{planCode}/estimate-your-pension'
                            },
                            {
                                Key: 'most-recent-estimate',
                                IsEnabled: true,
                                DisplayOrder: 1,
                                Name: 'DB.Estimates.SavedEstimate.SavedEstimateMostRecentSubNav',
                                Url: '/db-plan/{planCode}/most-recent-estimate'
                            },
                            {
                                Key: 'saved-estimates',
                                IsEnabled: true,
                                DisplayOrder: 1,
                                Name: 'DB.Estimates.SavedEstimate.SavedEstimateSubNav',
                                Url: '/db-plan/{planCode}/saved-estimates'
                            }
                        ]
                    },
                    {
                        Key: 'my-data',
                        IsEnabled: true,
                        DisplayOrder: 2,
                        Name: '',
                        Url: '/db-plan/{planCode}/my-data'
                    },
                    {
                        Key: 'my-election',
                        IsEnabled: true,
                        DisplayOrder: 3,
                        Name: '',
                        Url: '/db-plan/{planCode}/my-election'
                    }
                ],
                "pension-payments": [
                    {
                        Key: 'overview',
                        IsEnabled: true,
                        Name: '',
                        Url: '/pension-payments/summary',
                        DisplayOrder: 0,
                        SubNav: [
                            {
                                Key: 'summary',
                                IsEnabled: true,
                                DisplayOrder: 0,
                                Name: 'DB.PensionPayment.PaymentSummary.SummarySubNav',
                                Url: '/pension-payments/summary'
                            },
                            {
                                Key: 'payment-history',
                                IsEnabled: true,
                                DisplayOrder: 1,
                                Name: 'DB.PensionPayment.PayHistory.SubNav',
                                Url: '/pension-payments/payment-history'
                            },
                            {
                                Key: 'payment-deductions',
                                IsEnabled: true,
                                DisplayOrder: 2,
                                Name: 'DB.PensionPayment.Deductions.PageTitle',
                                Url: '/pension-payments/payment-deductions'
                            }
                        ]
                    },
                    {
                        Key: 'tax-withholding',
                        IsEnabled: true,
                        DisplayOrder: 1,
                        Name: '',
                        Url: '/pension-payments/tax-withholding-federal',

                        SubNav: [
                            {
                                Key: 'federal',
                                IsEnabled: true,
                                DisplayOrder: 0,
                                Name: 'DB.Tax.FederalSubNav',
                                Url: '/pension-payments/tax-withholding-federal'
                            },
                            {
                                Key: 'state',
                                IsEnabled: true,
                                DisplayOrder: 1,
                                Name: 'DB.Tax.StateSubNav',
                                Url: '/pension-payments/tax-withholding-state'
                            }
                        ]
                    },
                    {
                        Key: 'payment-method',
                        IsEnabled: true,
                        DisplayOrder: 2,
                        Name: '',
                        Url: '/pension-payments/payment-method'
                    }
                ],
                "benefit-commencement-online": [
                    {
                        Key: 'get-started',
                        IsEnabled: true,
                        Name: 'Get Started',
                        Url: '/benefit-commencement/online/{planCode}/dro/',
                        DisplayOrder: 0,
                        SubNav: [
                            {
                                Key: 'dro',
                                IsEnabled: true,
                                DisplayOrder: 0,
                                Name: 'DB.ROLDroQdro.SubNav',
                                Url: '/benefit-commencement/online/{planCode}/dro'
                            },
                            {
                                Key: 'commencement-details',
                                IsEnabled: false,
                                DisplayOrder: 1,
                                Name: 'DB.ROLCalc.Subnav',
                                Url: '/benefit-commencement/online/{planCode}/commencement-details'
                            }
                        ]
                    },
                    {
                        Key: 'choose-options',
                        IsEnabled: false,
                        DisplayOrder: 1,
                        Name: 'Choose Options',
                        Url: '/benefit-commencement/online/{planCode}/payment-options',
                        SubNav: [
                            {
                                Key: 'payment-options',
                                IsEnabled: true,
                                DisplayOrder: 0,
                                Name: 'DB.ROLPaymentOption.SubNav',
                                Url: '/benefit-commencement/online/{planCode}/payment-options'
                            },
                            {
                                Key: 'payment-summary',
                                IsEnabled: true,
                                DisplayOrder: 1,
                                Name: 'DB.ROLPmtSummary.SubNav',
                                Url: '/benefit-commencement/online/{planCode}/payment-summary'
                            },
                            {
                                Key: 'beneficiaries',
                                IsEnabled: true,
                                DisplayOrder: 2,
                                Name: 'Beneficiaries',
                                Url: '/benefit-commencement/online/{planCode}/beneficiaries'
                            },
                            {
                                Key: 'payment-method',
                                IsEnabled: false,
                                DisplayOrder: 3,
                                Name: 'DB.ROLPayMethod.SubNav',
                                Url: '/benefit-commencement/online/{planCode}/payment-method'
                            },
                            {
                                Key: 'commencement-tax-withholding',
                                IsEnabled: false,
                                DisplayOrder: 4,
                                Name: 'DB.ROLTax.Subnav',
                                Url: '/benefit-commencement/online/{planCode}/tax-withholding'
                            }
                        ]
                    },
                    {
                        Key: 'review',
                        IsEnabled: false,
                        DisplayOrder: 2,
                        Name: 'Review',
                        Url: '/benefit-commencement/online/{planCode}/required-documents',
                        SubNav: [
                            {
                                Key: 'required-documents',
                                IsEnabled: true,
                                DisplayOrder: 0,
                                Name: 'DB.RequiredDocs.SubNav',
                                Url: '/benefit-commencement/online/{planCode}/required-documents'
                            },
                            {
                                Key: 'final-review',
                                IsEnabled: false,
                                DisplayOrder: 1,
                                Name: 'DB.ROLReview.Subnav',
                                Url: '/benefit-commencement/online/{planCode}/final-review'
                            },
                            {
                                Key: 'waivers',
                                IsEnabled: false,
                                DisplayOrder: 2,
                                Name: 'DB.ROLReviewWaivers.SubNav',
                                Url: '/benefit-commencement/online/{planCode}/waivers'
                            },
                            {
                                Key: 'consents',
                                IsEnabled: false,
                                DisplayOrder: 3,
                                Name: 'DB.ROLReviewConsents.SubNav',
                                Url: '/benefit-commencement/online/{planCode}/consents'
                            }
                        ]
                    },
                    {
                        Key: 'confirmation',
                        IsEnabled: false,
                        DisplayOrder: 3,
                        Name: 'Confirmation',
                        Url: '/benefit-commencement/online/{planCode}/confirmation'
                    }
                ],
                "documents-upload": []
            };
        }

        function getInitialDynamicNavMap() {
            return {
                'FORMSDOCUMENTS': {
                    navKey: 'forms-documents',
                    TabCode: 'HB',
                    subTabs: [
                        {
                            Key: 'HEALTHANDBENEFITS',
                            navKey: 'health',
                            TabCode: 'HB'
                        },
                        {
                            Key: 'PENSION',
                            navKey: 'pension',
                            TabCode: 'DB'
                        },
                        {
                            Key: 'SAVINGS',
                            navKey: 'savings',
                            TabCode: 'DCTA'
                        }
                    ]
                }
            };
        }

        function getLifeEventPortalSectionWithNextRequestCaching() {
            return cachedLifeEventNavigationService.getLifeEventNavigation(true)
                .then(function (newLifeEventNavigationData) {
                    var currentPortalSectionSource = allPortalSections['life-event'];
                    var currentPortalSection = _.cloneDeep(currentPortalSectionSource);
                    var lifeEventNavigationData = newLifeEventNavigationData;

                    return mergeNewLifeEventNavigationDataWithCurrentPortalSectionPure(newLifeEventNavigationData, currentPortalSection,
                        currentPortalSectionSource, lifeEventNavigationData);
                });
        }       
    }
]);
