'use strict';

angular.module('mercerApp').directive('comparisonBenefit', ['coverageStateFactoryService', 'coverageSourcesService', 'coverageGridConfigService', function (coverageStateFactoryService, coverageSourcesService, coverageGridConfigService) {
  return {
    restrict: 'A',
    scope: {
      planData: '=comparisonBenefit',
      data: '=context',
      planType: '=type',
      healthLink: '=',
      healthData: '=',
      getCovImage: '='
    },
    templateUrl: '/health-benefits/views/comparisonBenefit',
    controller: ['$scope', function ($scope) {
      this.$onInit = function () {
        $scope.employee = $scope.planData;
        $scope.coverage = calculateCoverage();
        $scope.coverageIsInitiallyExpanded = coverageIsInitiallyExpanded();

        function coverageIsInitiallyExpanded() {
          return coverageGridConfigService.forData($scope.data.employeeData).shouldBeExpandedInDomainPage;
        }

        function calculateCoverage() {
          var coverageSource = getCoverageSource();
          return coverageStateFactoryService.getCoverageByCategories(coverageSource);
        }

        function getCoverageSource() {
          return coverageSourcesService.fromDomElections($scope.data.employeeData, $scope.employee);
        }
      };
    }]
  };
}]);