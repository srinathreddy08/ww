angular.module('mercerApp').controller('healthBenefitsSummaryController', [
    '$scope', 'navigationService', 'employeeData', 'contentAliasService', 'comparisonBenefitCategories', 'lifeEventsService',
    'displayedComparisonCategories', 'questionnairePrintFormService', '$location', 'coverageStateFactoryService', 'coverageSourcesService',
    'shoppingCartService', 'leBenefitsService', 'coverageEffectiveDateService', 'benefitCategoryMap', 'pageLoadHelperService', 'lifeEventVerificationService',
    'featureToggles', '$timeout',
    function ($scope, navigationService, employeeData, contentAliasService, comparisonBenefitCategories, lifeEventsService,
        displayedComparisonCategories, questionnairePrintFormService, $location, coverageStateFactoryService, coverageSourcesService,
        shoppingCartService, leBenefitsService, coverageEffectiveDateService, benefitCategoryMap, pageLoadHelperService, lifeEventVerificationService, featureToggles, $timeout) {
        this.$onInit = async function () {
            pageLoadHelperService.loadPageWithSpinner($location.path());

            await lifeEventsService.initLifeEvents();

            $scope.comparisonBenefitCategories = comparisonBenefitCategories;
            $scope.displayedComparisonCategories = displayedComparisonCategories;
            $scope.enrollmentContent = contentAliasService.forData(employeeData);
            const dataContent = contentAliasService.forData(employeeData);
            const isVerificationDocumentsToggle = dataContent.getConfigurationValue('HB.VerificationDocuments.Toggle') === 'Yes';

            // SET NAVIGATION
            navigationService.setCurrentTabByKeys('healthsummary'); //Keep two separate variables because the tabs on this page need different data

            $scope.employeeData = employeeData;
            $scope.tabStructure = getDisplayedTabs(employeeData);
            $scope.selectedSummary = _($scope.tabStructure).map('key').first();
            $scope.location = $location.search();
            $scope.tabs = $scope.tabStructure.map(function (value) {
                const isCurrentCoverageTab = $scope.location?.tab === 'current-coverage-tab';
                return {
                    active: isCurrentCoverageTab ? value.key === 'tab2' : value.key === $scope.selectedSummary,
                    employee: value.employee,
                    employeeType: value.employeeType,
                    questionsInfo: Object.values(value.questions.questions)
                };
            });

            $scope.openPrintScreenModal = false;
            $scope.printPage = printPage;
            $scope.tabHasChanged = false;
            $scope.isPDFConfirmationStatementToggleOn = isPDFConfirmationStatementToggleOn();

            function getDisplayedTabs(employeeData) {
                let tab2EmpData;
                let tab2EmpType;
                const coverageType = lifeEventVerificationService.setCoverageTypeWithLEV(employeeData.Employee, isVerificationDocumentsToggle);
                tab2EmpData = coverageType.coverage;
                tab2EmpType = coverageType.type;

                var tabs = [{
                    key: 'tab1',
                    employee: employeeData.Employee.FutureCoverages && employeeData.Employee.FutureCoverages[0],
                    label: dataContent.getEvaluationPointValue('HB.LifeEvent.Summary.FutureCoverageTabLabel'),
                    employeeType: 'FutureCoverages[0]',
                    subTitle: dataContent.getEvaluationPointValue('HB.LifeEvent.Summary.FutureCoverageHeader'),
                    questions: questionnairePrintFormService.getQuestions(employeeData, 'FutureCoverages[0]')
                }, {
                    key: 'tab2',
                    employee: tab2EmpData,
                    label: dataContent.getEvaluationPointValue('HB.LifeEvent.ChooseBenefits.Summary.CurrentCovTab'),
                    employeeType: tab2EmpType,
                    subTitle: dataContent.getEvaluationPointValue('HB.LifeEvent.Summary.CurrentCoverageHeader'),
                    questions: questionnairePrintFormService.getQuestions(employeeData, tab2EmpType)
                }, {
                    key: 'tab3',
                    employee: employeeData.Employee.HistoricalCoverages && employeeData.Employee.HistoricalCoverages[0],
                    label: dataContent.getEvaluationPointValue('HB.LifeEvent.ChooseBenefits.Summary.PriorCovTab'),
                    employeeType: 'HistoricalCoverages[0]',
                    subTitle: dataContent.getEvaluationPointValue('HB.LifeEvent.Summary.PriorCoverageHeader'),
                    questions: questionnairePrintFormService.getQuestions(employeeData, 'HistoricalCoverages[0]')
                    }];
                return _(tabs).filter(function (tab) {
                    return !!tab.employee;
                }).value();
            }

            function printPage() {
                if (isPDFConfirmationStatementToggleOn() && !$scope.openPrintScreenModal) {
                    $scope.showListOfCoveredDependents = featureToggles.showListOfCoveredDependents;
                    $scope.onTabChange = onTabChange;
                    $scope.currentTab = $scope.tabs.find(t => t.active);
            
                    if ($scope.currentTab && $scope.currentTab.employee && $scope.currentTab.employee.LifeEvents && $scope.currentTab.employee.LifeEvents[0]) {
                        $scope.cartData = shoppingCartService.get(
                            $scope.currentTab.employee.LifeEvents[0].LifeEventID,
                            $scope.currentTab.employee.LifeEvents[0].LifeEventSequenceNumber,
                            $scope.currentTab.employee.LifeEvents[0].LifeEventDate
                        );
                        $scope.coverages = calculateCoverage($scope.currentTab.employee);
                        $scope.benefitsList = benefitListData($scope.currentTab.employee);
                        $scope.benefitCategories = benefitCategoryMap;
                        $scope.openPrintScreenModal = true;
                    }
                }
                $timeout(function () {
                    window.print();
                }, 0);
            }

            window.onbeforeprint = function() {
                isPDFConfirmationStatementToggleOn() && !$scope.openPrintScreenModal && printPage();
            };

            window.onafterprint = function() {
                $scope.openPrintScreenModal = false;
            };

            function isPDFConfirmationStatementToggleOn() {
                return dataContent.getConfigurationValue('HB.PDFConfirmationStatement.Toggle') === 'Yes';
            }

            function calculateCoverage(employee) {
                var coverageSource = getCoverageSource(employee);

                return coverageStateFactoryService.getCoverageByCategories(coverageSource);
            }

            function getCoverageSource(employee) {
                return coverageSourcesService.fromDomElections(employeeData, employee);
            }

            function onTabChange(employee) {
                $scope.benefitsList = benefitListData(employee);
                $scope.coverages = calculateCoverage(employee);
                $scope.currentTab = $scope.tabs.find(t => t.active);
                $scope.currentTab.employee = employee;
                $scope.tabHasChanged = true;
            }

            function benefitListData(employee) {
                const cartData = $scope.cartData || {};
                const benefitListData = leBenefitsService.getBenefitListData(
                    $scope.enrollmentContent,
                    $scope.tabs.find(t => t.active)?.employeeType,
                    { ShoppingCart: cartData?.ShoppingCart },
                    null, false, false
                );

                const coverageEffectiveDateInfoModel = {
                    data: $scope.enrollmentContent.contentSource,
                    employee: employee,
                    electionData: benefitListData.availableNonTaxSavingAccountsItems.concat(benefitListData.availableTaxSavingAccountsItems.concat(benefitListData.offeredItems))
                };

                const coverageEffectiveDateInfo = coverageEffectiveDateService.getCoverageEffectiveDateInfo(coverageEffectiveDateInfoModel);

                return { benefitListData, coverageEffectiveDateInfo }
            }
        };
    }]);