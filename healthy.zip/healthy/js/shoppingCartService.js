﻿'use strict';
angular.module('mercer.hb').factory('shoppingCartService', [
    'cacheService', 'pubsub', 'shoppingCartResource', 'shoppingCartExpertGuidanceResource', 'expertGuidanceState', 'beneficiaryCollectionOverlay', 'beneficiaryCollectionRequiredService', 'executeWithSpinner', 'negativeDisclaimerAnswersService', 'mbcContentAndData',
    function (cacheService, pubsub, shoppingCartResource, shoppingCartExpertGuidanceResource, expertGuidanceState, beneficiaryCollectionOverlay, beneficiaryCollectionRequiredService,executeWithSpinner, negativeDisclaimerAnswersService, mbcContentAndData) {
        return {
            get: getCart,
            getCartByLifeEvent: getCartByLifeEvent,
            clearCartCache: clearCartCache,
            clearCart: clearCart,
            load: load,
            batchAdd: batchAdd,
            visit: visit,
            submit: submit,
            addProvidersForCartItem: addProvidersForCartItem,
            getProvidersForCartItem: getProvidersForCartItem,
            selectPackage: selectPackage,
            getElectionAddedToCart: getElectionAddedToCart
        };

        function getCart(lifeEventId, lifeEventSeqNo, lifeEventDate, useSuggestedPackageResource) {
            var lifeEvent = createLifeEvent(lifeEventId, lifeEventSeqNo, lifeEventDate);
            var resource = selectResource(useSuggestedPackageResource);

            return getCartFromResource(resource, lifeEvent);
        }

        function getCartByLifeEvent(lifeEventSource, useSuggestedPackageResource) {
            var lifeEvent = convertLifeEvent(lifeEventSource);
            var resource = selectResource(useSuggestedPackageResource);

            return getCartFromResource(resource, lifeEvent);
        }

        function clearCartCache(lifeEventId, lifeEventSeqNo, lifeEventDate, useSuggestedPackageResource) {
            var resource = selectResource(useSuggestedPackageResource);

            clearCache(resource, createLifeEvent(lifeEventId, lifeEventSeqNo, lifeEventDate));
        }

        function clearCart(lifeEventId, lifeEventSeqNo, lifeEventDate, useSuggestedPackageResource) {
            var resource = selectResource(useSuggestedPackageResource);

            var lifeEvent = createLifeEvent(lifeEventId, lifeEventSeqNo, lifeEventDate);

            return resource
                .clear(lifeEvent)
                .$promise.then(function (result) {
                    clearCache(resource, lifeEvent);
                    return result;
                });
        }

        function load(lifeEventSource, isNoValidationAndReloadNeeded, useSuggestedPackageResource) {
            return executeWithSpinner(loadInternal(lifeEventSource, isNoValidationAndReloadNeeded, useSuggestedPackageResource));
        }

        function loadInternal(lifeEventSource, isNoValidationAndReloadNeeded, useSuggestedPackageResource) {
            var resource = selectResource(useSuggestedPackageResource);

            var lifeEvent = convertLifeEvent(lifeEventSource);
            clearCache(resource, lifeEvent);
            var cartData = resource.load(lifeEvent);
            var promise = updateCache(resource, cartData, lifeEvent, isNoValidationAndReloadNeeded).$promise;

            promise.then(function () {
                if (isNoValidationAndReloadNeeded) {
                    return;
                }

                pubsub.publish('toggleLifeEventCTA', { toggle: true, isExpertGuidance: resource.isExpertGuidance });
                pubsub.publish('cartUpdated', { data: cartData, isExpertGuidance: resource.isExpertGuidance });
                mbcContentAndData.remove('enrollment');
                mbcContentAndData.remove('dashboard');
            });

            return promise;
        }

        function updateRemovedBenefits(items) {
            var removedBenefits = negativeDisclaimerAnswersService.getRemovedBenefits();
            if (removedBenefits) {
                _(items).forEach(function (item) {
                    if (_.includes(removedBenefits), item.BenefitID)
                        return negativeDisclaimerAnswersService.deleteRemovedBenefits(item.BenefitID);
                });
            }
        }

        function batchAdd(options, useSuggestedPackageResource) {
            var resource = selectResource(useSuggestedPackageResource);

            var items = options.items;
            var lifeEvent = options.lifeEvent;

            _(items).forEach(function (item) {
                if (options.isRepriced) {
                    item.isRepriced = options.isRepriced;
                }
            });

            if (!options.keepCosts) {
                _(items).forEach(clearCosts);
            }

            if (options.visitedBenefitId) {
                var visitedBenefit = _(items)
                    .find({
                        BenefitID: options.visitedBenefitId
                    });

                visitedBenefit.IsVisited = true;
            }

            updateRemovedBenefits(items);

            return executeWithSpinner(function () {
                var cartData = resource.batchAdd({
                    Items: items,
                    LifeEventSeqNo: lifeEvent.LifeEventSequenceNumber
                });

                var lifeEventParam = convertLifeEvent(lifeEvent);

                // MMBC-11334 - Remove the Modal Dialog that appears when a user enrolls in a Plan where beneficiaries may be designated.
                // beneficiaryCollectionOverlay(options.editedBenefitId, cartData);
                //Similar functionality to the collection overlay, but sets the plans into a cache for use in EG
                if (!useSuggestedPackageResource) {
                    beneficiaryCollectionRequiredService.setBeneficiaryCollectionRequiredCacheItems(options.editedBenefitId, cartData);
                }
                return updateCache(resource, cartData, lifeEventParam, undefined).$promise;
            });

            function clearCosts(item) {
                item.EmployeeAnnualCost = 0;
                item.EmployerPayPeriodCost = 0;
                item.EmployerAnnualCost = 0;
                item.EOIPendingStatus = 0;
                item.PremiumMonthly = 0;
                item.PremiumAnnual = 0;
                item.AdministrativeCostMonthly = 0;
                item.AdministrativeCostAnnual = 0;
                item.AmountPended = 0;
                item.AmountInforce = 0;
                item.PendedEmployeePayPeriodCost = 0;
                item.PendedEmployeeAnnualCost = 0;
            }
        }

        function visit(lifeEventId, benefitId, lifeEventDate, useSuggestedPackageResource) {
            var resource = selectResource(useSuggestedPackageResource);
            return resource.visit({ LifeEventId: lifeEventId, BenefitId: benefitId, LifeEventDate: lifeEventDate });
        }

        function submit(lifeEventId, lifeEventSeqNo, lifeEventDate, useSuggestedPackageResource) {
            var resource = selectResource(useSuggestedPackageResource);

            var lifeEvent = { LifeEventId: lifeEventId, LifeEventSeqNo: lifeEventSeqNo, LifeEventDate: lifeEventDate };

            return resource
                .submit(lifeEvent)
                .$promise
                .then(function (newEmployeeData) {
                    clearCache(shoppingCartResource, lifeEvent);
                    clearCache(shoppingCartExpertGuidanceResource, lifeEvent);
                    return newEmployeeData;
                });
        }

        function addProvidersForCartItem(lifeEvent, election, primaryCarePhysicians) {
            var cartItem = {
                LifeEventID: lifeEvent.LifeEventID,
                LifeEventDate: lifeEvent.LifeEventDate,
                BenefitID: election.BenefitID,
                PlanID: election.PlanID,
                OptionID: election.OptionID
            };

            return shoppingCartResource.addProvidersForCartItem({
                CartItem: cartItem,
                PrimaryCarePhysicians: primaryCarePhysicians
            }).$promise;
        }

        function getProvidersForCartItem(lifeEvent, election) {
            var cartItem = {
                LifeEventID: lifeEvent.LifeEventID,
                LifeEventDate: lifeEvent.LifeEventDate,
                BenefitID: election.BenefitID,
                PlanID: election.PlanID,
                OptionID: election.OptionID
            };

            return shoppingCartResource.getProvidersForCartItem(cartItem).$promise;
        }

        function selectPackage(lifeEvent) {
            return shoppingCartResource.selectPackage()
                .then(function () {
                    return reloadCart(shoppingCartResource, convertLifeEvent(lifeEvent));
                });
        }

        function reloadCart(resource, lifeEvent) {
            clearCache(resource, lifeEvent);
            return getCartFromResource(resource, lifeEvent);
        }

        function selectResource(useSuggestedPackageResourceParameter) {
            return expertGuidanceState.parseUseSuggestedPackageResourceParameter(useSuggestedPackageResourceParameter)
                ? shoppingCartExpertGuidanceResource
                : shoppingCartResource;
        }

        function getCartFromResource(resource, lifeEvent) {
            var cachedValue = getCachedValue(resource, lifeEvent);

            return cachedValue !== undefined
                ? cachedValue
                : updateCache(resource, resource.get(lifeEvent), lifeEvent, undefined);
        }

        function getCachedValue(resource, lifeEvent) {
            var cacheKey = constructKey(resource, lifeEvent);
            return cacheService.cache.get(cacheKey);
        }

        function updateCache(resource, cartData, lifeEvent, isNoValidationAndReloadNeeded) {
            pubsub.publish('shoppingCartService.cache.updating',
                {
                    lifeEvent: lifeEvent,
                    isExpertGuidance: resource.isExpertGuidance
                });

            cartData.$promise.then(function (newData) {
                pubsub.publish('shoppingCartService.cache.updated', {
                    lifeEvent: lifeEvent,
                    newData: newData,
                    isNoValidationAndReloadNeeded: isNoValidationAndReloadNeeded,
                    isExpertGuidance: resource.isExpertGuidance
                });
            });

            var cacheKey = constructKey(resource, lifeEvent);
            cacheService.cache.put(cacheKey, cartData);

            return getCachedValue(resource, lifeEvent);
        }

        function clearCache(resource, lifeEvent) {
            var cacheKey = constructKey(resource, lifeEvent);
            cacheService.cache.remove(cacheKey);
            pubsub.publish('shoppingCartService.cache.updating', { lifeEvent: lifeEvent, isExpertGuidance: resource.isExpertGuidance });
        }

        function convertLifeEvent(lifeEvent) {
            return createLifeEvent(lifeEvent.LifeEventID, lifeEvent.LifeEventSequenceNumber, lifeEvent.LifeEventDate);
        }

        function createLifeEvent(lifeEventId, lifeEventSeqNo, lifeEventDate) {
            return {
                LifeEventId: lifeEventId,
                LifeEventSeqNo: lifeEventSeqNo,
                LifeEventDate: lifeEventDate
            };
        }

        function constructKey(resource, lifeEvent) {
            return resource.cacheKeyPrefix + 'shoppingCartService.get.' + lifeEvent.LifeEventId + '.' + lifeEvent.LifeEventSeqNo + '.' + lifeEvent.LifeEventSeqNo;
        }
        
        function getElectionAddedToCart(elections, benefitId) {
            var election = _(elections).find(function (elect) {
                return elect.BenefitID === benefitId;
            });

            if (!election) {
                election = _(elections).head();
            }

            return election;
        }
    }
]);