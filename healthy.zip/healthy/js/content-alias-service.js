﻿'use strict';
angular.module('mercer.db.shared').factory('contentAliasService', [
    '$log', 'stringService', 'featureToggles',
function ($log, stringService, featureToggles) {
    return {
        forData: forData,
        ContentWrapper: ContentWrapper
    };

    function forData(data) {
        return data instanceof ContentWrapper ?  data: new ContentWrapper(data);
    }

    function ContentWrapper(data) {
        if (!data) {
            logError('forData, data missing');
        }

        if (data) {
            if (!data.Data) {
                logError('forData, data.Data missing');
            }

            if (!data.Content) {
                logError('forData, data.Content missing');
            }

            if (!data.ContentAliases) {
                logError('forData, data.ContentAliases missing');
            }

            if (!data.Configuration) {
                logError('forData, data.Configuration missing');
            }
        }

        this.data = data?.Data;
        this.contentSource = data;
        this.getContentValue = getContentValue;
        this.getContentObject = getContentObject;
        this.getContentString = getContentString;
        this.getAlias = getAlias;
        this.getEvaluationPoint = getEvaluationPoint;
        this.getEvaluationPointValue = getEvaluationPointValue;
        this.getAliasObject = getAliasObject;
        this.getString = getStringValue;
        this.getObject = getObjectValue;
        this.getConfiguration = getConfiguration;
        this.getConfigurationValue = getConfigurationValue;
        this.evaluationPointExists = evaluationPointExists;
        this.getStringOrDefault = getStringOrDefault;
        this.getObjectOrDefault = getObjectOrDefault;
        this.getContentObjectOrDefault = getContentObjectOrDefault;
        this.getAliasObjectOrDefault = getAliasObjectOrDefault;
        
        function getObjectOrDefault(evaluationPoint) {
            return getObjectValue(evaluationPoint) || {};
        }

        function getStringOrDefault(evaluationPoint) {
            return getStringValue(evaluationPoint) || '';
        }

        function getAliasObjectOrDefault(evaluationPoint) {
            return getAliasObject(evaluationPoint) || {};
        }

        function getContentObjectOrDefault(aliasPath) {
            return getContentObject(aliasPath) || {};
        }

        function getContentValue(aliasPath) {
            if (aliasPath === undefined) {
                logError('getContentValue(aliasPath), aliasPath === undefined');
            }

            if (aliasPath === null) {
                logError('getContentValue(aliasPath), aliasPath === null');
            }

            if (aliasPath && data && data.Content && data.Content[aliasPath] === undefined) {
                logError('getContentValue(aliasPath), data.Content[aliasPath] === undefined, aliasPath=' + aliasPath);
            }

            return aliasPath && data?.Content[aliasPath];
        }

        function getAliasValue(evaluationPoint) {
            if (data && data.ContentAliases && data.ContentAliases[evaluationPoint] === undefined) {
                logError('getAliasValue(evaluationPoint), data.ContentAliases[evaluationPoint] === undefined, evaluationPoint=' + evaluationPoint);
            }

            return data?.ContentAliases[evaluationPoint];
        }

        function logError(errorMessage) {
            if (featureToggles.contentAliasServiceErrorLogging) {
                $log.error('contentAliasService: ' + errorMessage);
            }
        }

        function checkValue(value, expectedType, valueName) {
            if (value !== undefined && value !== null) {
                var valueType = typeof value;
                if (valueType !== expectedType) {
                    logError('Value of ' + valueName + ' is expected to be of \'' + expectedType + '\' type, but received a value of \'' + valueType + '\' type');
                }
            }

            return value;
        }

        function evaluationPointName(evaluationPoint) {
            return 'evaluation point \'' + evaluationPoint + '\'';
        }

        function aliasPathName(aliasPath) {
            return 'SiteCore alias path \'' + aliasPath + '\'';
        }

        function getAliasPath(evaluationPoint) {
            var result = getAliasValue(evaluationPoint);

            return checkValue(result, 'string', 'SiteCore alias path for ' + evaluationPointName(evaluationPoint));
        }

        function getAliasObject(evaluationPoint) {
            var result = getAliasValue(evaluationPoint);

            return checkValue(result, 'object', 'alias object for ' + evaluationPointName(evaluationPoint));
        }

        function getContentObject(aliasPath) {
            var result = getContentValue(aliasPath);
            return checkValue(result, 'object', aliasPathName(aliasPath));
        }

        function getContentString(aliasPath) {
            var result = getContentValue(aliasPath);
            return checkValue(result, 'string', aliasPathName(aliasPath));
        }

        function getEvaluationPointValue(evaluationPoint) {
            var aliasPath = getAliasPath(evaluationPoint);
            return getContentValue(aliasPath);
        }

        function getEvaluationPoint(evaluationPoint) {
            return valueWrapper(getEvaluationPointValue(evaluationPoint));
        }

        function getEvaluationPointTypedValue(evaluationPoint, expectedType) {
            var result = getEvaluationPointValue(evaluationPoint);

            return checkValue(result, expectedType, evaluationPointName(evaluationPoint));
        }

        function getStringValue(evaluationPoint) {
            return getEvaluationPointTypedValue(evaluationPoint, 'string');
        }

        function getObjectValue(evaluationPoint) {
            return getEvaluationPointTypedValue(evaluationPoint, 'object');
        }

        function getConfiguration(configurationPoint) {
            var value = data?.Configuration[configurationPoint];

            if (value === undefined) {
                logError('getConfiguration(configurationPoint), data.Configuration[configurationPoint] === undefined, configurationPoint=' + configurationPoint);
            }

            return valueWrapper(value);
        }

        function getAlias(evaluationPoint) {
            var value = getAliasValue(evaluationPoint);

            return valueWrapper(value);
        }

        function getConfigurationValue(configurationPoint) {
            return getConfiguration(configurationPoint).value;
        }

        function evaluationPointExists(evaluationPoint) {
            return !!(data?.ContentAliases[evaluationPoint]);
        }

        function valueWrapper(value) {
            return {
                value: value,
                asNumber: asNumber,
                asDate: asDate,
                asStringArray: asStringArray,
                asFirstChildStringArray: asFirstChildStringArray,
                asLodashObject: asLodashObject,
                asSwitch: asSwitch,
                getField: getField,
                getContent: getContent,
                getLinkedContent: getLinkedContent
            };

            function asNumber() {
                return Number(value);
            }

            function asDate() {
                return new Date(moment(value));
            }

            function asStringArray() {
                if (typeof value !== 'string') {
                    throw Error('value should be string');
                }

                return stringService.convertArrayStringToArray(value);
            }

            function asFirstChildStringArray() {
                return stringService.convertArrayStringToArray(value[0]);
            }

            function getField(key) {
                return valueWrapper(value[key]);
            }

            function asLodashObject() {
                return _(value).mapValues(valueWrapper);
            }

            function asSwitch(namedValues) {
                return _(namedValues)
                    .mapValues(function (fieldValue) {
                        return fieldValue === value;
                    })
                    .value();
            }

            function getLinkedContent() {
                var aliasPath = value['CONTENT_ALIAS'];
                if (aliasPath === undefined) {
                    logError('valueWrapper.getLinkedContent, aliasPath === undefined, value=' + value);
                }
                var contentValue = getContentValue(aliasPath);

                return valueWrapper(contentValue);
            }

            function getContent() {
                var contentValue = getContentValue(value);

                return valueWrapper(contentValue);
            }
        }
    }
}
]);