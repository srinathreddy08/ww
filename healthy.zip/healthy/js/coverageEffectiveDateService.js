﻿'use strict';
angular.module('mercer.db.shared').factory('coverageEffectiveDateService', ['$state', function($state) {
        function parseDate(date) {
            return moment(date, 'MM-DD-YYYY').toDate();
        }

        var allBenefitsEffectiveDateIsSameAndLessOrEqualThanLifeEventDate = function (employee, electionData) {
            var lifeEventDate = parseDate(employee.LifeEvents[0].LifeEventDate);

            function isSameDate() {
                return _(electionData).map(function (benefit) {
                    return benefit.ElectedOption.BenefitEffectiveDate;
                }).uniq().value().length == 1;
            }

            function lessOrEqualThanLifeEventDate() {
                return _(electionData).every(function (benefit) {
                    var benefitEffectiveDate = parseDate(benefit.ElectedOption.BenefitEffectiveDate);
                    return benefitEffectiveDate <= lifeEventDate;
                });
            }

            return lessOrEqualThanLifeEventDate() && isSameDate();
        };

        var effectiveDateDisplayModeEnum = {
            disabled: 1,
            commonEffectiveDate: 2,
            effectiveDateForEachBenefit: 3
        };

        function isDisplayCoverageEffectiveDateSuppressed(data) {
            return data.Configuration['HB.Summary.DisplayCoverageEffectiveDate'] !== 'T';
        }

        function showOnPages(model) {
            return model.employee === model.data.Employee.CurrentCoveragesEmployee && $state.current.name !== 'life-event.choose-benefits' ||
                _.some(['life-event.confirmation', 'life-event.review', 'expert-guidance.package-review', 'expert-guidance.confirmation', 'health-benefits.summary'],
                    function (route) {
                        return route === $state.current.name
                    });
        }

        function getEffectiveDateDisplayMode(model) {
            if (!model.employee ||
                isDisplayCoverageEffectiveDateSuppressed(model.data) ||
                !showOnPages(model)
            ) {
                return effectiveDateDisplayModeEnum.disabled;
            }
            if (model.employee.LifeEvents[0].LifeEventDate && allBenefitsEffectiveDateIsSameAndLessOrEqualThanLifeEventDate(model.employee, model.electionData)) {
                return effectiveDateDisplayModeEnum.commonEffectiveDate;
            }

            return effectiveDateDisplayModeEnum.effectiveDateForEachBenefit;
        }

        var getCoverageEffectiveDateInfo = function(model) {
            var displayMode = getEffectiveDateDisplayMode(model);
            return {
                showCommonEffectiveDate: displayMode === effectiveDateDisplayModeEnum.commonEffectiveDate,
                showBenefitsEffectiveDate: displayMode === effectiveDateDisplayModeEnum.effectiveDateForEachBenefit,
                commonEffectiveDate: model.employee && model.employee.LifeEvents[0].LifeEventDate
            }
        };

        return {
            getCoverageEffectiveDateInfo: getCoverageEffectiveDateInfo
        }
    }
]);