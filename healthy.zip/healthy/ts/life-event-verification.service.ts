import { Injectable } from '@angular/core';
import { EmployeeModel } from '../common-dto/employee.model';
import { IEmployeeLifeEventModel } from '../common-dto/employee-life-event.model';
import { ICompanyModel } from '../common-dto/company.model';
import { EvaluationPointConstants } from '../common-dto/evalutation-point.constants';
import { IEnrollment, IEnrollmentData } from '../common-dto/enrollment.model';

@Injectable({
  providedIn: 'root',
})
export class LifeEventVerificationService {

  private readonly leVerificationStatuses: Array<string> = ['N', 'I', 'D'];
  private readonly leVerificationTypes: Array<string> = ['ANY', 'BOTH', 'ADD'];

  constructor() {
  }

  isLevOn(enrollmentData: IEnrollmentData, nameFrom?: string): boolean {
    const employeeCoverage = enrollmentData?.PendingLEVEmployee;
    if (!employeeCoverage) return false;
    const pendingLifeEvent = employeeCoverage?.LifeEvents[0];
    const smallMarketData = employeeCoverage?.SmallMarketData;

    return pendingLifeEvent && this.isLeHasPendingStatus(pendingLifeEvent) && smallMarketData && this.isLeHasLeIdForLev(smallMarketData, pendingLifeEvent)
    && this.isLeHasLevType(smallMarketData) && nameFrom === 'submitLifeEventService'
      ? pendingLifeEvent.LifeEventVerificationStatus === this.leVerificationStatuses[0] : this.isLeHasLevStatus(enrollmentData);
  }

  isLevOnForPersonCoverageService(employeeCoverage: EmployeeModel): boolean {
    const pendingLifeEvent = employeeCoverage?.LifeEvents[0];
    const smallMarketData = employeeCoverage?.SmallMarketData;

    return pendingLifeEvent && smallMarketData && this.isLeHasLeIdForLev(smallMarketData, pendingLifeEvent)
      && this.isLeHasLevType(smallMarketData) && this.isLeHasPendingStatus(pendingLifeEvent)
      && (this.isLeHasLevStatus({
        PendingLEVEmployee: employeeCoverage,
      } as IEnrollmentData) || pendingLifeEvent.LifeEventVerificationStatus === null);
  }

  setCoverageTypeWithLEV(enrollmentData: IEnrollmentData, toggle: boolean): { type: string, coverage: EmployeeModel } {
    if (toggle && enrollmentData && this.isLeHasLevStatus(enrollmentData)) return {
      type: 'PendingLEVEmployee',
      coverage: enrollmentData.PendingLEVEmployee,
    };
    return { type: 'CurrentCoveragesEmployee', coverage: enrollmentData.CurrentCoveragesEmployee };
  }

  isLePendingDueToLev(enrollment: IEnrollment): boolean {
    const lifeEvent = enrollment?.Data?.PendingLEVEmployee?.LifeEvents.length > 0 ? enrollment?.Data?.PendingLEVEmployee?.LifeEvents[0] : null;
    return enrollment.Configuration[EvaluationPointConstants.VERIFICATION_DOCUMENTS_TOGGLE] === 'Yes' && lifeEvent && this.isLeHasLevStatus(enrollment.Data)
      && this.isLeHasPendingStatus(lifeEvent) && this.isLeHasLeIdForLev(enrollment?.Data?.PendingLEVEmployee?.SmallMarketData, lifeEvent);
  }

  isLeHasLevType(smallMarketData: ICompanyModel): boolean {
    return this.leVerificationTypes.includes(smallMarketData.LifeEventVerificationType);
  }

  isLeHasLevStatus(enrollmentData: IEnrollmentData): boolean {
    const employeeCoverage = enrollmentData?.PendingLEVEmployee;
    if (!employeeCoverage) return false;
    const lifeEvent = employeeCoverage?.LifeEvents[0];
    return this.leVerificationStatuses.includes(lifeEvent.LifeEventVerificationStatus);
  }

  isLeHasLeIdForLev(smallMarketData: ICompanyModel, lifeEvent: IEmployeeLifeEventModel): boolean {
    return smallMarketData && smallMarketData.LifeEventsWithVerificationEnabled !== null && smallMarketData.LifeEventsWithVerificationEnabled?.split(',').includes(lifeEvent.LifeEventID);
  }

  isLeHasPendingStatus(lifeEvent: IEmployeeLifeEventModel): boolean {
    return lifeEvent.LifeEventStatus === 'P';
  }

}
