import { Injectable } from '@angular/core';
import { RawParams } from '@uirouter/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, take, tap } from 'rxjs/operators';
import * as moment from 'moment';
import { getTilesLifeEventData, TilesLifeEventDto } from 'src/app/common-dto/tilesLifeEventDto';
import { TilesOeDto } from 'src/app/common-dto/tilesOeDto';
import { IEnrollment, LifeEventPathMode } from 'src/app/common-dto/enrollment.model';
import { FirstTimeConfigDto } from 'src/app/common-dto/firstTimeConfigDto';
import { Static } from 'src/app/common-dto/static';
import { ApiService } from 'src/app/mercer.services/api.service';
import { CommonDataService } from 'src/app/mercer.services/common-data.service';
import { LifeEventType } from '../dto/life-event-type.model';
import { IShoppingCart } from 'src/app/common-dto/shopping-cart.model';
import { LifeEventAction } from '../dto/lifeEventAction.model';
import { EvaluationPointConstants } from 'src/app/common-dto/evalutation-point.constants';
import { FutureDatedLifeEvent } from '../dto/pending-life-event-data.model';
import { convertArrayStringToArray } from 'src/app/utils/string.utils';
import { DashboardModel } from 'src/app/common-dto/dashboard.model';
import { TimeService } from 'src/app/services/time.service';
import { EmployeeModel } from '../../../../common-dto/employee.model';
import { IParticipant } from 'src/app/common-dto/participant.model';
import { IEmployeeLifeEventModel } from '../../../../common-dto/employee-life-event.model';
import { EnrollmentService } from '../../../../services/enrollment.service';
import { ApiTypesConstants } from 'src/app/common-dto/api-type.constants';
import { CachedLifeEventNavigationService } from '@my-account/life-event-page/services/cached-life-event-navigation.service';
import { IBenefitModel } from '../../../../common-dto/benefit.model';
import { NavigationLifeEventResponse } from '../../../../common-dto/navigation-life-event.response';
import { LifeEventNavigationsState } from 'src/app/common-dto/life-event-navigations-state.constants';
import { LifeEventIdentifier } from 'src/app/common-dto/life-event-identifier.constants';

@Injectable({
  providedIn: 'root',
})
export class LifeEventsService {
  static readonly PENDING_EMPLOYEE = 'PendingEmployee';
  static readonly CURRENT_COVERAGE_EMPLOYEE = 'CurrentCoveragesEmployee';
  static readonly FUTURE_COVERAGES = 'FutureCoverages';
  private static readonly lifeEventIdEpEnableMap = {
    [LifeEventIdentifier.NEW_HIRE]: EvaluationPointConstants.ENABLE_NHSELF_SERVICE_MODE,
    [LifeEventIdentifier.OPEN_ENROLMENT]: EvaluationPointConstants.LIFE_EVENT_ENABLE_OE_SELF_SERVICE_MODE,
  };
  private static readonly lifeEventIdHasFutureDatedLeMap = {
    [LifeEventIdentifier.NEW_HIRE]: 'HasFutureDatedNH',
    [LifeEventIdentifier.OPEN_ENROLMENT]: 'HasFutureDatedOE',
  };
  private static readonly lifeEventIdFutureDatedLeMap = {
    [LifeEventIdentifier.NEW_HIRE]: 'FutureDatedNH',
    [LifeEventIdentifier.OPEN_ENROLMENT]: 'FutureDatedOE',
  };

  private employeeLifeEventActions: LifeEventAction[];
  private lifeEvent$ = new BehaviorSubject<LifeEventType>(null);
  private dashboard: DashboardModel;

  static: Static;
  participant: IParticipant;
  enrollment: IEnrollment;
  IsImpersonation: boolean;
  currentLifeEvents: IEmployeeLifeEventModel[];

  pendingEmployeeData: EmployeeModel;
  currentCoveragesData: EmployeeModel;

  getTilesOeData: TilesOeDto;
  getTilesLifeEventData: getTilesLifeEventData;

  participantLifeEventsEpNames = {
    initiate: {
      proxy: EvaluationPointConstants.LIST_OF_LE_PROXY_INITIATE,
      employee: EvaluationPointConstants.LIST_OF_LE_PATRICIPANT_INITIATE,
    },
    complete: {
      proxy: EvaluationPointConstants.LIST_OF_LE_PROXY_COMPLETE,
      employee: EvaluationPointConstants.LIST_OF_LE_PATRICIPANT_COMPLETE,
    },
  };

  constructor(
    private apiService: ApiService,
    private commonDataService: CommonDataService,
    private timeService: TimeService,
    private enrollmentService: EnrollmentService,
    private cachedLifeEventNavigationService: CachedLifeEventNavigationService,
  ) {
  }

  lifeEventEmit(lifeEvent: LifeEventType): void {
    this.lifeEvent$.next(lifeEvent);
  }

  get isReinitialized(): boolean {
    return !!this.employeeLifeEventActions.find((action) => action.Type === 'REINITIALIZED' && action.Value === 'TRUE');
  }

  isLifeEventInProgress(lifeEventID: string): boolean {
    return !!this.currentLifeEvents.find(
      (currentLifeEvent) => currentLifeEvent.LifeEventStatus === 'P' && currentLifeEvent.LifeEventID === lifeEventID,
    );
  }

  isLifeEventPending(lifeEventID: string): boolean {
    return !!this.pendingLE.length && this.pendingLE[0].LifeEventID === lifeEventID;
  }

  getEvaluationPointValue(ep: string) {
    return this.enrollment.Content[this.enrollment.ContentAliases[ep]];
  }

  getEvaluationPointFromDashboardObj(ep: string): any {
    return this.dashboard.Content[this.dashboard.ContentAliases[ep]];
  }

  getEvaluationPointFromDashboardConfigurationObj(ep: string): any {
    return this.dashboard.Configuration[ep];
  }

  getLifeEventData(alias: boolean = false, data: string, ep: string, type?: string): any {
    if (alias) {
      return this[data][type][ep];
    }
    return this[data].Content[this[data].ContentAliases[ep]];
  }

  getDashboardData(): Promise<void> {
    return this.commonDataService.dashboard$
      .pipe(take(1))
      .toPromise()
      .then((dashboardData) => {
        this.dashboard = dashboardData;
      });
  }

  initLifeEvents(): Promise<boolean> {
    this.currentLifeEvents = [];
    return Promise.all([
      this.getFirstTimeConfigData(),
      this.getTilesLifeEvent(),
      this.getTilesOe(),
      this.getCurrentLifeEvents()
    ])
      .then(() => true);
  }

  getFirstTimeConfigData(): Promise<FirstTimeConfigDto> {
    return this.commonDataService.firstTimeConfigData$
      .pipe(take(1))
      .toPromise()
      .then((firstTimeConfig) => {
        this.static = firstTimeConfig.Static;
        this.enrollment = firstTimeConfig.Enrollment;
        this.participant = firstTimeConfig.Participant;
        this.IsImpersonation = firstTimeConfig.IsImpersonation;
        this.employeeLifeEventActions = firstTimeConfig.EmployeeLifeEventActions;
        this.pendingEmployeeData = firstTimeConfig.Enrollment.Data.PendingEmployee;
        this.currentCoveragesData = firstTimeConfig.Enrollment.Data.CurrentCoveragesEmployee;
        return firstTimeConfig;
      });
  }

  getLifeEventTypes$(): Observable<LifeEventType[]> {
    return this.commonDataService.lifeEventTypes$;
  }

  async updateEnrollment() {
    this.enrollment = await this.enrollmentService.reloadEnrollmentDataForBothAngulars().toPromise();
  }

  async getEnrollment(): Promise<IEnrollment> {
    return this.enrollmentService.enrollment$
      .pipe(take(1))
      .toPromise()
      .then((enrollment) => {
        this.enrollment = enrollment;
        return enrollment;
      })
  }

  async getCurrentLifeEvents(): Promise<IEmployeeLifeEventModel[]> {
    if (!!this.currentLifeEvents?.length) {
      return Promise.resolve(this.currentLifeEvents);
    }

    return this.apiService
      .getCurrentLifeEvents()
      .pipe(
        map((currentLifeEvents) => {
          this.currentLifeEvents = currentLifeEvents.LifeEvents;
          return currentLifeEvents.LifeEvents;
        }),
      )
      .toPromise();
  }

  async getTilesOe(): Promise<TilesOeDto> {
    return this.apiService.getTilesOe()
      .pipe(
        tap(data => {
          this.getTilesOeData = data;
        }),
        take(1),
      )
      .toPromise();
  }

  async getShoppingCart(lifeEventDate: string, lifeEventId: string, lifeEventSeqNo: string): Promise<IShoppingCart> {
    return this.apiService.getShoppingCart(lifeEventDate, lifeEventId, lifeEventSeqNo, ApiTypesConstants.get).toPromise();
  }

  async getTilesLifeEvent(): Promise<TilesLifeEventDto> {
    return this.apiService.getTilesLifeEvent()
      .pipe(
        tap(data => {
          this.getTilesLifeEventData = data;
        }),
        take(1),
      )
      .toPromise();
  }

  get pendingLEType(): LifeEventType {
    const pendingLE = this.pendingLE[0];
    if (!pendingLE) {
      return null;
    }

    return this.commonDataService.lifeEventTypes.find(lft => lft.LifeEventId === pendingLE.LifeEventID);
  }

  get pendingLE(): IEmployeeLifeEventModel[] {
    return this.getLifeEventData(true, 'enrollment', LifeEventsService.PENDING_EMPLOYEE, 'Data')?.LifeEvents || [];
  }

  get pendingEmployee(): EmployeeModel {
    return this.getLifeEventData(true, 'enrollment', LifeEventsService.PENDING_EMPLOYEE, 'Data');
  }

  get currentCoveragesEmployee(): EmployeeModel {
    return this.getLifeEventData(true, 'enrollment', LifeEventsService.CURRENT_COVERAGE_EMPLOYEE, 'Data');
  }

  get futureCoverages(): EmployeeModel[] {
    return this.getLifeEventData(true, 'enrollment', LifeEventsService.FUTURE_COVERAGES, 'Data') || [];
  }

  get eligibleLifeEvents(): string[] {
    return this.getLifeEventData(
      true,
      'enrollment',
      EvaluationPointConstants.LIST_OF_ELIGIBLE_LIFE_EVENT_ID,
      'Configuration',
    );
  }

  hasCurrentOrFutureCoverage = (enrollment: IEnrollment): boolean => {
    const enrollmentData = enrollment.Data;
    const employee = enrollmentData?.CurrentCoveragesEmployee || enrollmentData?.FutureCoverages?.[0];
    return employee?.LifeEvents?.[0] ? true : false;
  };

  canComplete(lifeEventId: string): boolean {
    const canComplete = this.getLifeEventData(true, 'enrollment', this.getParticipantLifeEventsEP(false), 'Configuration');

    return (
      this.pendingLE.length &&
      this.pendingLE[0].LifeEventID === lifeEventId &&
      !canComplete.includes(lifeEventId) &&
      this.eligibleLifeEvents.includes(lifeEventId)
    );
  }

  getParticipantLifeEventsEP(isInitiate: boolean): any {
    const isProxy = this.IsImpersonation;

    return convertArrayStringToArray(
      this.participantLifeEventsEpNames[isInitiate ? 'initiate' : 'complete'][isProxy ? 'proxy' : 'employee'],
    );
  }

  async withinOeWindow() {
    await this.getDashboardData();

    const dashboardConfiguration = this.dashboard.Configuration;

    const startDate = getStartDate(dashboardConfiguration);
    const endDate = getEndDate(dashboardConfiguration);

    const isValidOEWindow = startDate < endDate;

    if (!isValidOEWindow) {
      return false;
    }

    const now = this.timeService.now();
    const openEnrollmentStarted: boolean = now >= startDate;
    const openEnrollmentEnded: boolean = now > endDate;

    return openEnrollmentStarted && !openEnrollmentEnded;

    function getStartDate(configuration: Record<string, any>): Date {
      return getDateFromConfig(configuration, 'Portal.OEStartDateTime');
    }

    function getEndDate(configuration: Record<string, any>): Date {
      const endDate = getDateFromConfig(configuration, 'Portal.OEEndDateTime');
      const silentEndDate = getDateFromConfig(configuration, 'Portal.SilentOEEndDateTime');

      if (!silentEndDate) return endDate;

      return moment.max(moment(endDate), moment(silentEndDate)).toDate();
    }

    function getDateFromConfig(configuration: Record<string, any>, configKey: string): Date | null {
      if (!configuration[configKey]) {
        return null;
      }

      return new Date(configuration[configKey]);
    }
  }

  canReinitiate(lifeEventId: string): boolean {
    const { lifeEventIdEpEnableMap } = LifeEventsService;
    const pendingLE = this.pendingLE[0];
    if (!lifeEventIdEpEnableMap[lifeEventId] || (!!pendingLE && this.isReinitiationEnabledForLifeEvent(pendingLE, lifeEventId)))
      return false;

    const employees = [].concat(this.currentCoveragesEmployee, this.futureCoverages[0] || []);
    const lifeEventForReinitiate = employees
      .filter((em) => LifeEventsService.hasFutureDatedLE(lifeEventId, em))
      .map((em) => {
        const futureDatedLEId = LifeEventsService.getFutureDatedLifeEvent(lifeEventId, em).LifeEventId;
        return this.isReinitiationEnabledForLEByConfig(futureDatedLEId) ? futureDatedLEId : null;
      })
      .filter(Boolean);

    return !!lifeEventForReinitiate.length;
  }

  private isReinitiationEnabledForLifeEvent(lifeEvent: IEmployeeLifeEventModel, lifeEventId: string): boolean {
    return (
      this.isReinitiationEnabledForLEByConfig(lifeEvent.LifeEventID) && lifeEvent.LifeEventID === lifeEventId
    );
  }

  isReinitiationEnabledForLEByConfig(lifeEventId: string): boolean {
    const isEnabled = this.getLifeEventData(
      true,
      'enrollment',
      LifeEventsService.lifeEventIdEpEnableMap[lifeEventId],
      'Configuration',
    );

    return isEnabled !== 'N';
  }

  static hasFutureDatedLE(lifeEventId: string, employee: EmployeeModel): boolean {
    const { lifeEventIdHasFutureDatedLeMap } = LifeEventsService;
    const hasFutureDatedLeKey = lifeEventIdHasFutureDatedLeMap[lifeEventId];
    return !!(employee && employee[hasFutureDatedLeKey]);
  }

  static getFutureDatedLifeEvent(lifeEventId: string, employee: EmployeeModel): FutureDatedLifeEvent {
    const { lifeEventIdFutureDatedLeMap } = LifeEventsService;
    const futureDatedLeKey = lifeEventIdFutureDatedLeMap[lifeEventId];
    const futureDatedLe = employee[futureDatedLeKey];
    const futureDatedLifeEvent = new FutureDatedLifeEvent();
    futureDatedLifeEvent.LifeEventDate = futureDatedLe ? futureDatedLe.split(',')[1] : null;
    futureDatedLifeEvent.LifeEventId = futureDatedLe ? futureDatedLe.split(',')[0] : null;
    return futureDatedLifeEvent.LifeEventDate !== null && futureDatedLifeEvent.LifeEventId !== null
      ? futureDatedLifeEvent : null;
  }

  async getLifeEventButtonLink(lifeEvent: IEmployeeLifeEventModel | LifeEventType): Promise<[string, RawParams | null]> {
    const pathMode: LifeEventPathMode = this.getLifeEventPathMode();
    const lifeEventId = 'LifeEventDesc' in lifeEvent ? lifeEvent.LifeEventId : lifeEvent.LifeEventID;
    const isGuidedShoppingEnabled = lifeEvent?.GuidedShoppingEnabled === 'Y';

    if (this.canReinitiate(lifeEventId)) {
      const reinitState: string = await this.getReinitiateLifeEventLink();

      if (!!reinitState) {
        return [reinitState, { lifeEventId }];
      }
    } else if (isGuidedShoppingEnabled && pathMode !== LifeEventPathMode.chooseYourOwn) {
      if (pathMode === LifeEventPathMode.userChoice) {
        return [LifeEventNavigationsState.ExpertGuidanceGetStarted, null];
      }
      if (pathMode === LifeEventPathMode.expertGuidance) {
        return [LifeEventNavigationsState.ExpertGuidancePackageReview, null];
      }
    } else {
      const stateForReview: string = await this.getLinkForReviewElections();

      if (!!stateForReview) {
        return [stateForReview, null];
      }

      const eligibleBenefits = 'EligibleBenefits' in lifeEvent ?
        lifeEvent.EligibleBenefits :
        this.pendingLE.find(le => le.LifeEventID === lifeEventId)?.EligibleBenefits;
      const navResponse: NavigationLifeEventResponse = await this.cachedLifeEventNavigationService
        .getLifeEventNavigation(true);

      return this.calculateStateOnNavStatus(navResponse.NavigationStatus, eligibleBenefits);
    }
  }

  async getLifeEventIdsToReinitiate(): Promise<string[]> {
    const lifeEventIds: string[] = [];

    const pendingLifeEvent = this.pendingLE[0];
    const oeForReinitiate: boolean = this.canReinitiate(LifeEventIdentifier.OPEN_ENROLMENT);
    const nhForReinitiate: boolean = this.canReinitiate(LifeEventIdentifier.NEW_HIRE);
    const isNewHireReinitialization: boolean = nhForReinitiate && pendingLifeEvent?.LifeEventID !== LifeEventIdentifier.NEW_HIRE;
    const isOpenEnrollmentReinitialization: boolean = oeForReinitiate && await this.withinOeWindow() &&
      pendingLifeEvent?.LifeEventID !== LifeEventIdentifier.OPEN_ENROLMENT;

    if (isNewHireReinitialization) {
      lifeEventIds.push(LifeEventIdentifier.NEW_HIRE);
    }

    if (isOpenEnrollmentReinitialization) {
      lifeEventIds.push(LifeEventIdentifier.OPEN_ENROLMENT);
    }

    return lifeEventIds;
  }

  private calculateStateOnNavStatus(navigationStatus: any, eligibleBenefits: IBenefitModel[]): [string, RawParams | null] {
    if (navigationStatus.cart.IsEnabled) {
      return [LifeEventNavigationsState.CartReview, null];
    }

    const supplementalBenefitStatus = navigationStatus['supplemental-benefits'];
    if (supplementalBenefitStatus?.IsEnabled) {
      const supplementalBenefitSubNav = supplementalBenefitStatus.SubNav;
      let firstSectionBenefitId = '';
      let minimalDisplayOrderInSubNav = null;
      let currentDisplayOrderInSubNav = null;
      Object.keys(supplementalBenefitSubNav).forEach((subNavBenefitId: string) => {
        if (supplementalBenefitSubNav[subNavBenefitId]) {
          const displayOrderMap = this.getDisplayOrderMap();
          if (!displayOrderMap[subNavBenefitId]) {
            const benefit: IBenefitModel = eligibleBenefits.find((bm: IBenefitModel) => bm.BenefitID === subNavBenefitId);
            currentDisplayOrderInSubNav = benefit?.DisplayOrder;
          } else {
            currentDisplayOrderInSubNav = displayOrderMap[subNavBenefitId];
          }

          if (currentDisplayOrderInSubNav) {
            if (minimalDisplayOrderInSubNav === null || currentDisplayOrderInSubNav < minimalDisplayOrderInSubNav) {
              minimalDisplayOrderInSubNav = currentDisplayOrderInSubNav;
              firstSectionBenefitId = subNavBenefitId;
            }
          }
        }
      });

      return [LifeEventNavigationsState.SupplementalBenefits, { benefitId: firstSectionBenefitId }];
    }

    if (navigationStatus['choose-benefits'].IsEnabled) {
      return [LifeEventNavigationsState.ChooseBenefitsSummary, null];
    }

    return [LifeEventNavigationsState.GetStarted, null];
  }

  private getDisplayOrderMap(): Record<string, string> {
    const benefitDisplayOrderOverrideConfig = this.enrollment.Configuration[EvaluationPointConstants.LIFE_EVENT_BENEFITS_DISPLAY_ORDER];
    if (!benefitDisplayOrderOverrideConfig) return null;
    const result = {};
    Object.keys(benefitDisplayOrderOverrideConfig).forEach((key: string) => {
      const displayOrder = Number(benefitDisplayOrderOverrideConfig[key].DISPLAY_ORDER);
      if (!isNaN(displayOrder)) {
        result[benefitDisplayOrderOverrideConfig[key]
          [EvaluationPointConstants.LIFE_EVENT_BENEFITS_DISPLAY_ORDER.toUpperCase()]] = displayOrder;
      }
    });
    return result;
  }

  private getLifeEventPathMode(): LifeEventPathMode {
    return this.enrollment.Configuration[EvaluationPointConstants.LIFE_EVENT_BENEFIT_ELECTION_PATHS];
  }

  private async getReinitiateLifeEventLink(): Promise<string> {
    const pendingLifeEvent = this.pendingLE[0];
    const oeForReinitiate: boolean = this.canReinitiate(LifeEventIdentifier.OPEN_ENROLMENT);
    const nhForReinitiate: boolean = this.canReinitiate(LifeEventIdentifier.NEW_HIRE);
    const isNewHireReinitialization: boolean = nhForReinitiate && pendingLifeEvent?.LifeEventID !== LifeEventIdentifier.NEW_HIRE;
    const isOpenEnrollmentReinitialization: boolean = oeForReinitiate && await this.withinOeWindow() &&
      pendingLifeEvent?.LifeEventID !== LifeEventIdentifier.OPEN_ENROLMENT;

    if (isOpenEnrollmentReinitialization || isNewHireReinitialization) {
      return LifeEventNavigationsState.ReInitiate;
    }

    return null;
  }

  private async getLinkForReviewElections(): Promise<string> {
    const oeForReinitiate: boolean = this.canReinitiate(LifeEventIdentifier.OPEN_ENROLMENT);
    const nhForReinitiate: boolean = this.canReinitiate(LifeEventIdentifier.NEW_HIRE);
    const pendingLE: IEmployeeLifeEventModel = this.pendingLE[0];

    const isOpenEnrollmentForFutureAndPendingEmployee =
      oeForReinitiate &&
      pendingLE?.LifeEventID === LifeEventIdentifier.OPEN_ENROLMENT &&
      await this.withinOeWindow();
    const isNewHireReinitialization = nhForReinitiate && pendingLE?.LifeEventID === LifeEventIdentifier.NEW_HIRE;

    if (isOpenEnrollmentForFutureAndPendingEmployee || isNewHireReinitialization) {
      return LifeEventNavigationsState.CartReview;
    }

    return null;
  }

  hasChecklist(lifeEventId: string): boolean {
    return this.lifeEventHasChecklistSetup(lifeEventId) && !this.lifeEventChecklistIsSuppressed();
  }

  lifeEventHasChecklistSetup(lifeEventId: string): boolean {
    return !!this.enrollment.ContentAliases[EvaluationPointConstants.LIFE_EVENT_DETAIL_CHECKLIST + lifeEventId];
  }

  lifeEventChecklistIsSuppressed(): boolean {
    const valueToSuppress = '2';
    return this.enrollment.Configuration[EvaluationPointConstants.LIFE_EVENT_DETAIL_CHECK_DISPLAY_OPTIONS] === valueToSuppress;
  }

  hasForms(lifeEventId: string): boolean {
    return !!this.enrollment.ContentAliases[EvaluationPointConstants.LIFE_EVENT_DETAIL_RIGHT_MODULES + lifeEventId]
      && this.enrollment.ContentAliases[EvaluationPointConstants.LIFE_EVENT_DETAIL_RIGHT_MODULES + lifeEventId].length !== 0;
  }
}
