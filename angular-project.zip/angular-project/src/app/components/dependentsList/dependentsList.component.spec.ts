import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DependentListComponent } from './dependent-list.component';

describe('DependentListComponent', () => {
    let component: DependentListComponent;
    let fixture: ComponentFixture<DependentListComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ DependentListComponent ]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(DependentListComponent);
        component = fixture.componentInstance;
        component.dependentCoveredTitle = 'Covered Dependents';
        component.dependents = [
            { FirstName: 'John', LastName: 'Doe', BirthDate: new Date('1990-01-01') },
            { FirstName: 'Jane', LastName: 'Doe', BirthDate: new Date('1992-02-02') }
        ];
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should display the correct number of dependents', () => {
        const compiled = fixture.nativeElement;
        expect(compiled.querySelectorAll('.list-item').length).toBe(2);
    });

    it('should display the correct dependent names', () => {
        const compiled = fixture.nativeElement;
        expect(compiled.querySelector('.list-item').textContent).toContain('John Doe');
    });
});