import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-health-benefits-summary',
    templateUrl: './health-benefits-summary.component.html',
    styleUrls: ['./health-benefits-summary.component.css']
})
export class HealthBenefitsSummaryComponent {
    @Input() openPrintScreenModal: boolean = false;
    @Input() content: any = {};
    @Input() data: any = {};
    @Input() employeeData: any = {};
    @Input() tabStructure: any[] = [];
    @Input() tabs: any[] = [];
    @Input() isPDFConfirmationStatementToggleOn: boolean = false;
    @Input() coverages: any = {};
    @Input() currentTab: any = {};
    @Input() benefitsList: any = {};
    @Input() tabHasChanged: boolean = false;
    @Input() benefitCategories: any = {};
    @Input() cartData: any = {};
    @Input() showListOfCoveredDependents: boolean = false;
    @Input() enrollmentContent: any = {};
    @Input() static: any = {};

    printPage() {
        // Implement print logic here
    }

    onTabChange(employee: any) {
        // Implement tab change logic here
    }
}