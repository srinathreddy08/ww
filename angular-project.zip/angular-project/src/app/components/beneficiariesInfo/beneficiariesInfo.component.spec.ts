import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BeneficiariesComponent } from './beneficiaries.component';

describe('BeneficiariesComponent', () => {
    let component: BeneficiariesComponent;
    let fixture: ComponentFixture<BeneficiariesComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ BeneficiariesComponent ]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(BeneficiariesComponent);
        component = fixture.componentInstance;
        component.beneficiaries = {
            1: { Id: 1, Name: 'John Doe' },
            2: { Id: 2, Name: 'Jane Smith' }
        };
        component.beneficiariesDesignations = [
            { Id: 1, Percentage: 50, IsSecondary: false },
            { Id: 2, Percentage: 50, IsSecondary: true }
        ];
        component.enrollmentContent = {
            Common: {
                Beneficiary: {
                    PrimaryLabel: 'Primary Beneficiary',
                    SecondaryLabel: 'Secondary Beneficiary'
                }
            }
        };
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should correctly categorize primary and secondary beneficiaries', () => {
        expect(component.primary.length).toBe(1);
        expect(component.secondary.length).toBe(1);
    });

    // Add more tests as needed
});