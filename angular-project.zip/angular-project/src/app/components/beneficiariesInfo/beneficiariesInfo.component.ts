import { Component, Input, OnInit } from '@angular/core';

interface Beneficiary {
    Id: number;
    Name: string;
}

interface Designation {
    Id: number;
    Percentage: number;
    IsSecondary: boolean;
}

@Component({
    selector: 'app-beneficiaries',
    templateUrl: './beneficiaries.component.html',
    styleUrls: ['./beneficiaries.component.css']
})
export class BeneficiariesComponent implements OnInit {
    @Input() beneficiaries: { [key: number]: Beneficiary } = {};
    @Input() beneficiariesDesignations: Designation[] = [];
    @Input() enrollmentContent: any = {};
    terms = { Beneficiaries: 'Beneficiaries' };
    primary: Designation[] = [];
    secondary: Designation[] = [];

    ngOnInit() {
        this.primary = this.beneficiariesDesignations.filter(d => !d.IsSecondary);
        this.secondary = this.beneficiariesDesignations.filter(d => d.IsSecondary);
    }

    getDesignationBirthDate(id: number): Date | null {
        // Implement logic to get birth date
        return null;
    }
}