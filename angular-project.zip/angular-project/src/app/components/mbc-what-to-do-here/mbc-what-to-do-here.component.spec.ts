import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WhatToDoHereComponent } from './what-to-do-here.component';

describe('WhatToDoHereComponent', () => {
    let component: WhatToDoHereComponent;
    let fixture: ComponentFixture<WhatToDoHereComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ WhatToDoHereComponent ]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(WhatToDoHereComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should toggle expanded state', () => {
        component.expanded = false;
        component.toggle();
        expect(component.expanded).toBe(true);
    });

    it('should detect links presence', () => {
        component.content.Link1 = { Id: 1 };
        expect(component.hasLinks(component.content)).toBe(true);
    });
});