import { Component } from '@angular/core';

@Component({
    selector: 'app-what-to-do-here',
    templateUrl: './what-to-do-here.component.html',
    styleUrls: ['./what-to-do-here.component.css']
})
export class WhatToDoHereComponent {
    expanded: boolean = false;
    expandable: boolean = true;
    contentLoaded: boolean = true;
    contentKey: string = 'contentKey';
    static = {
        Terms: {
            WhatToDoHere: 'What to Do Here',
            Close: 'Close'
        }
    };
    content = {
        Copy: '',
        Value: '',
        Link1: null,
        Link2: null
    };

    toggle(): void {
        this.expanded = !this.expanded;
    }

    hasLinks(content: any): boolean {
        return content.Link1 || content.Link2;
    }
}