import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-coverage-display',
  templateUrl: './coverage-display.component.html',
  styleUrls: ['./coverage-display.component.css']
})
export class CoverageDisplayComponent {
  @Input() data: any;
  @Input() displayedComparisonCategories: any[];
  @Input() showPrimaryCareProviders: boolean = false;
  @Input() widgetTitle: string = '';
  @Input() hideTitle: boolean = false;
  @Input() detailsLink: string = '';
  @Input() coverage: any;
}