import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-view-primary-care-providers',
    templateUrl: './view-primary-care-providers.component.html',
    styleUrls: ['./view-primary-care-providers.component.css']
})
export class ViewPrimaryCareProvidersComponent {
    @Input() content: string = 'View Primary Care Providers';
    viewPCPLabel: string = 'HB.LifeEvent.LESubmit.ViewPCPLabel';

    showPrimaryCareProviders(): boolean {
        // Logic to determine if primary care providers should be shown
        return true;
    }

    viewPrimaryCareProviders(): void {
        // Logic to handle viewing primary care providers
        console.log('Viewing primary care providers');
    }
}