import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewPrimaryCareProvidersComponent } from './view-primary-care-providers.component';

describe('ViewPrimaryCareProvidersComponent', () => {
    let component: ViewPrimaryCareProvidersComponent;
    let fixture: ComponentFixture<ViewPrimaryCareProvidersComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ ViewPrimaryCareProvidersComponent ]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ViewPrimaryCareProvidersComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should display the correct content', () => {
        component.content = 'Test Content';
        fixture.detectChanges();
        const compiled = fixture.nativeElement;
        expect(compiled.querySelector('a').textContent).toContain('Test Content');
    });

    it('should call viewPrimaryCareProviders on click', () => {
        spyOn(component, 'viewPrimaryCareProviders');
        const compiled = fixture.nativeElement;
        compiled.querySelector('a').click();
        expect(component.viewPrimaryCareProviders).toHaveBeenCalled();
    });
});