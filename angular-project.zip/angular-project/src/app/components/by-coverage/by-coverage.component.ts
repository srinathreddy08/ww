import { Component, Input, OnInit } from '@angular/core';

@Component({
    selector: 'app-benefit-list',
    templateUrl: './benefit-list.component.html',
    styleUrls: ['./benefit-list.component.css']
})
export class BenefitListComponent implements OnInit {
    @Input() electionCoverageData: any[] = [];
    covPlans: any[] = [];
    noCovPlans: any[] = [];
    benefitsSelectedContent: string = 'Benefits Selected';
    waivedBenefitsContent: string = 'Waived Benefits';

    ngOnInit() {
        this.covPlans = this.electionCoverageData.filter(election => !election.IsNoCovPlan).sort((a, b) => a.ElectedBenefit.DisplayOrder - b.ElectedBenefit.DisplayOrder);
        this.noCovPlans = this.electionCoverageData.filter(election => election.IsNoCovPlan).sort((a, b) => a.ElectedBenefit.DisplayOrder - b.ElectedBenefit.DisplayOrder);
    }
}