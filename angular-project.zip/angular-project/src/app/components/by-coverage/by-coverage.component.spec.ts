import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BenefitListComponent } from './benefit-list.component';

describe('BenefitListComponent', () => {
    let component: BenefitListComponent;
    let fixture: ComponentFixture<BenefitListComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ BenefitListComponent ]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(BenefitListComponent);
        component = fixture.componentInstance;
        component.electionCoverageData = [
            { IsNoCovPlan: false, ElectedBenefit: { DisplayOrder: 1 } },
            { IsNoCovPlan: true, ElectedBenefit: { DisplayOrder: 2 } }
        ];
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should filter and sort covPlans correctly', () => {
        expect(component.covPlans.length).toBe(1);
        expect(component.covPlans[0].IsNoCovPlan).toBe(false);
    });

    it('should filter and sort noCovPlans correctly', () => {
        expect(component.noCovPlans.length).toBe(1);
        expect(component.noCovPlans[0].IsNoCovPlan).toBe(true);
    });
});