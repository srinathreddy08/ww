import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-benefits',
  templateUrl: './benefits.component.html',
  styleUrls: ['./benefits.component.css']
})
export class BenefitsComponent {
  @Input() data: any;
  @Input() separateByStatus: boolean;
  @Input() hasEditableBenefits: boolean;
  @Input() coverageEffectiveDateInfo: any;
  @Input() displayCosts: boolean;
  @Input() showAnnualAmounts: boolean;
  @Input() electionData: any;
  @Input() benefitsAvailableToUpdate: any;
  @Input() hasNonEditableBenefits: boolean;
  @Input() benefitsNotAvailableToUpdate: any;
  @Input() totals: any;
  @Input() showSubtotals: boolean;
  @Input() dcSubTotalTooltipEnabled: boolean;
  @Input() credits: any[];
  @Input() charges: any[];
  @Input() companyCont: boolean;
  @Input() isQuaterlyOrSemiAnnual: boolean;
  columnClasses = {
    header: 'header-class',
    footer: 'footer-class'
  };
  static = {
    Terms: {
      EffectiveAsOf: 'Effective as of',
      BeforeTax: 'Before Tax',
      AfterTax: 'After Tax',
      ChooseBenefitsCostOfBenefits: 'Cost of Benefits'
    }
  };
  HB = {
    LifeEvent: {
      ChooseBenefits: {
        AvailableToUpdate: 'Available to Update',
        NoChangesAllowed: 'No Changes Allowed'
      },
      Summary: {
        CompanyContributions: 'Company Contributions'
      }
    },
    Common: {
      CommonTerms: {
        Column1Header: 'Column 1',
        Column2Header: 'Column 2',
        CostSummary: 'Cost Summary'
      }
    },
    DefinedContributionInformationMessage: 'Defined Contribution Information Message'
  };
  content = {
    TotalLabel: 'Total',
    CreditsLabel: 'Credits',
    CompanySurchargesLabel: 'Company Surcharges',
    NetCostLabel: 'Net Cost',
    LongName: 'Long Name'
  };
}