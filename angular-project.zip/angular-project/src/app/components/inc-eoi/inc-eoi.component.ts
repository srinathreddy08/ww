import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-eoi-alert',
    templateUrl: './eoi-alert.component.html',
    styleUrls: ['./eoi-alert.component.css']
})
export class EoiAlertComponent {
    @Input() alignBottom: boolean = false;
    @Input() eoiPendingStatus: string = '';
    @Input() externalEoi: boolean = false;
    @Input() electedBenefit: { BenefitID: string } = { BenefitID: '' };
    @Input() content: { Value?: string, Link?: string } = {};

    getEoiContent(): string {
        const baseContent = this.externalEoi ? 'HB.LifeEvent.EOIContent.' : 'HB.ChooseBenefits.EOIContent.';
        return baseContent + this.electedBenefit.BenefitID;
    }

    getEoiAlertContent(): string {
        return 'HB.Common.CommonTerms.EOIAlert';
    }
}