import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EoiAlertComponent } from './eoi-alert.component';

describe('EoiAlertComponent', () => {
    let component: EoiAlertComponent;
    let fixture: ComponentFixture<EoiAlertComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ EoiAlertComponent ]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(EoiAlertComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should return correct EOI content', () => {
        component.externalEoi = true;
        component.electedBenefit = { BenefitID: '123' };
        expect(component.getEoiContent()).toBe('HB.LifeEvent.EOIContent.123');
    });

    it('should return correct EOI alert content', () => {
        expect(component.getEoiAlertContent()).toBe('HB.Common.CommonTerms.EOIAlert');
    });

    // Add more tests here
});