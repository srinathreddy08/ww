import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-coverage-main',
    templateUrl: './coverage-main.component.html',
    styleUrls: ['./coverage-main.component.css']
})
export class CoverageMainComponent {
    @Input() content: any = {};
    @Input() data: any = {};
    @Input() static: any = {};
    @Input() config: any = {};
    @Input() profileData: any = {};
    @Input() questions: any = {};
    @Input() dependentRestrictions: any = {};
    @Input() categories: any = {};
    @Input() comparisonBenefitCategories: any = {};
    @Input() employee: any = {};
    @Input() participantData: any = {};
    @Input() currentCoverage: any = {};
    @Input() newDependentData: any = [];
    @Input() dependentSaveErrors: any = [];
    @Input() categoriesToShow: any = [];
    @Input() isAddDependentEnabledByEp: boolean = false;
    @Input() editAllowed: boolean = false;
    @Input() showCoverage: boolean = false;
    @Input() showCoverageForPendingEmployee: boolean = false;
    @Input() allFormsValid: boolean = false;
    @Input() newDependents: number = 1;
    @Input() wtdhAlias: string = '';
    @Input() upcomingCoverageTabLabel: string = '';
    @Input() currentCoverageTabLabel: string = '';

    decrementNewDependents(): void {
        if (this.newDependents > 1) {
            this.newDependents--;
        }
    }

    incrementNewDependents(): void {
        if (this.newDependents < 9) {
            this.newDependents++;
        }
    }

    addNewDependents(count: number): void {
        // Logic to add new dependents
    }

    saveNewDependents(): void {
        // Logic to save new dependents
    }

    deleteNewDependent(index: number): void {
        // Logic to delete a new dependent
    }

    next(): void {
        // Logic for next button
    }
}