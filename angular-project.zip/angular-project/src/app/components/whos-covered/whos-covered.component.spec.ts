import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CoverageMainComponent } from './coverage-main.component';

describe('CoverageMainComponent', () => {
    let component: CoverageMainComponent;
    let fixture: ComponentFixture<CoverageMainComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ CoverageMainComponent ]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(CoverageMainComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should decrement new dependents', () => {
        component.newDependents = 2;
        component.decrementNewDependents();
        expect(component.newDependents).toBe(1);
    });

    it('should increment new dependents', () => {
        component.newDependents = 1;
        component.incrementNewDependents();
        expect(component.newDependents).toBe(2);
    });

    // Add more tests as needed
});