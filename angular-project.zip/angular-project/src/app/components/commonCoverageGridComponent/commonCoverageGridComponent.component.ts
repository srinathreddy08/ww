import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-coverage-options',
    templateUrl: './coverage-options.component.html',
    styleUrls: ['./coverage-options.component.css']
})
export class CoverageOptionsComponent {
    @Input() isCoverageCollapsed: boolean = false;
    @Input() isExpertGuidanceFlow: boolean = false;
    @Input() showCoverage: boolean = false;
    @Input() initialCollapseOpen: boolean = false;
    @Input() associationEditable: boolean = false;
    @Input() isSingleColumn: boolean = false;
    @Input() isMobile: boolean = false;
    @Input() showCategoryNames: boolean = false;
    @Input() categoriesToShow: string[] = [];
    @Input() coverage: any = {};
    @Input() data: any = {};
    @Input() showByBenefits: boolean = false;
    @Input() benefitsToShow: any[] = [];
    @Input() isEditMode: boolean = false;
    @Input() useSuppressingIneligibleBenefits: boolean = false;
    @Input() showPrimaryCareProviders: boolean = false;
    @Input() hideButtons: boolean = false;
    @Input() detailsLink: any = {};
    @Input() static: any = {};

    toggleCoverageView() {
        this.isCoverageCollapsed = !this.isCoverageCollapsed;
    }

    isGridVisible(): boolean {
        return true;
    }

    dependentCoverageGridSettings() {
        return {
            PlannedCoverageInstruction: 'Planned Coverage Instruction',
            PlannedCoverage: 'Planned Coverage',
            Name: 'Name',
            DOB: 'Date of Birth'
        };
    }

    shouldGrayOutButtons(): boolean {
        return false;
    }

    cancel() {
        // Implement cancel logic here
    }

    apply() {
        // Implement apply logic here
    }

    switchEditMode(editMode: boolean) {
        this.isEditMode = editMode;
    }
}